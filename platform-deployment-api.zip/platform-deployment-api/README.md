# Egain Platform Deployment API

AWS Api Gateway with ASP.NET Core Lambda

[![.NET](https://github.com/eGainDev/platform-deployment-api/actions/workflows/dotnet.yml/badge.svg)](https://github.com/eGainDev/platform-deployment-api/actions/workflows/dotnet.yml)

## Steps to Build and Deploy for DEVs

### Prerequisites
```
1) Must have .NET 6.0 installed
2) Must have AWS SDK configured with the system
3) AWS default credentials should be set using 'aws configure' in cmd prompt
4) Take checkout of the repository and run following cmds at src/Egain.Platform.Deployment/ in cmd.exe : 
    a) dotnet tool install -g Amazon.Lambda.Tools
    b) dotnet restore
```
### Build and Deploy
```
1) Make sure Prerequisites are complete
2) Edit values according to deployment in src\Egain.Platform.Deployment\aws-lambda-tools-defaults.json, values are stack specific and should be in sync with the existing stack
3) Build you code and changes using 
    dotnet build --no-restore
4) Once build is successful, deploy changes to the Stack (specified in aws-lambda-tools-defaults.json) using 
    dotnet lambda deploy-serverless
    The Above command uses 'template' from aws-lambda-tools-defaults.json, serverless.template in our case
Tip :- Logging levels for the deployed lambda are defined in Env Variables for the Lambda : Example || Logging__LogLevel__Egain : Debug
Above Key Value pair is needed to catch Debug statements
```

## Example APIs

### #1 Updating Analytics

```
PATCH /deployments/<analytics-deployment-id>/tenants/<tenantmgr-tenant-id>
Content-Type: application/json
Authorization: <AWS signature>
 
[
    {
        "op": "replace",
        "path": "/displayName",
        "value": "NewTenantName"
    },
    {
        "op": "replace",
        "path": "/domains/0",
        "value": {
            "fqdn": "https://newdomain.ezdev.net"
        }
    }
]
``` 
    
### #2 Updating B2C  
   
```
PATCH /deployments/<solve-deployment-id>
Content-Type: application/json
Authorization: <AWS signature>
 
[
  {
    "op": "add",
    "path": "/domains/-",
    "value": { 
        "remove" : "https://olddomain.ezdev.net", 
        "fqdn" : "https://newdomain.ezdev.net" 
    }
  }
]
```
