﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Egain.Identity.Web;
using Egain.Platform.Deployment.Models;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Egain.Platform.Deployment.Controllers
{
    /// <summary>
    /// Deployments Controller
    /// </summary>
    [ApiController]
    public class DeploymentsController : ControllerBase
    {
        private readonly IDeploymentConfiguration _config;
        private readonly ILogger _logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="config"></param>
        public DeploymentsController(ILogger<DeploymentsController> logger, IDeploymentConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        /// <summary>
        /// PATCH deployments/deploy1
        /// </summary>
        /// <param name="id"></param>
        /// <param name="patchDoc"></param>
        /// <returns></returns>
        [HttpPatch("deployments/{id}")]
        public async Task<IActionResult> Patch(string id, JsonPatchDocument<Models.Deployment> patchDoc)
        {
            var secretErn = $"ern/{id}/solve/any/any/B2C_CONFIG";

            // load the b2c config from secrets manager for this deployment
            var secret = await _config.GetAsync(secretErn);
            if (string.IsNullOrWhiteSpace(secret))
            {
                // deployment not found
                throw new DeploymentException("Missing configuration", secretErn);
            }

            // Retrieve the eGain Tenant Manager Tenant Id
            B2CConfig config = JsonConvert.DeserializeObject<B2CConfig>(secret);

            string tenantId = config.TenantId;
            if (string.IsNullOrWhiteSpace(tenantId))
            {
                throw new DeploymentException("Invalid TENANT configuration", secretErn);
            }

            string gatewayId = config.GatewayId;
            if (string.IsNullOrWhiteSpace(gatewayId))
            {
                throw new DeploymentException("Invalid GATEWAY_ID configuration", secretErn);
            }

            List<Task> updates = new List<Task>();

            // patch this tenants applications
            if (!string.IsNullOrWhiteSpace(config.CustomerAppObjectId))
            {
                _logger.LogDebug("Updating external application {config.CustomerAppObjectId} for tenant {tenantId}", config.CustomerAppObjectId, tenantId);

                // connect to the graph api
                GraphApiService externalService = (GraphApiService)
                    HttpContext.RequestServices.GetRequiredService(typeof(GraphApiService));

                // external
                updates.Add(externalService.UpdateApplication($"e:{tenantId}", config.CustomerAppObjectId, patchDoc));
            }

            if (!string.IsNullOrWhiteSpace(config.UserAppObjectId))
            {
                _logger.LogDebug("Updating internal application {config.UserAppObjectId} for tenant {tenantId}", config.UserAppObjectId, tenantId);

               // connect to the graph api
               GraphApiService internalService = (GraphApiService)
                   HttpContext.RequestServices.GetRequiredService(typeof(GraphApiService));

               // internal
               updates.Add(internalService.UpdateApplication($"i:{tenantId}", config.UserAppObjectId, patchDoc));
            }

            if (!string.IsNullOrWhiteSpace(config.GatewayAppObjectId))
            {
                _logger.LogDebug("Updating gateway application {config.GatewayAppObjectId} for tenant {tenantId}", config.GatewayAppObjectId, tenantId);

                // connect to the graph api
                GraphApiService gatewayService = (GraphApiService)
                    HttpContext.RequestServices.GetRequiredService(typeof(GraphApiService));

                // gateway
                updates.Add(gatewayService.UpdateApplication($"g:{gatewayId}", config.GatewayAppObjectId, patchDoc));

                // update analytics with report url SPA redirect url https://example.ezdev.net/system/web/apps/reports/
                if (!string.IsNullOrWhiteSpace(config.AnalyticsAppClientId))
                {
                    // use ANALYTICS_APP_ID (client id) from solve's B2C_CONFIG to locate analytics b2c app registration on gateway
                    updates.Add(gatewayService.UpdateAnalyticsApplication($"g:{gatewayId}", config.AnalyticsAppClientId,
                        patchDoc));
                }

                // update Tenants.xml policy
                updates.Add(gatewayService.UpdateTenantPolicy($"g:{gatewayId}", tenantId, patchDoc));
            }

            Task.WaitAll(updates.ToArray());

            return NoContent();
        }
    }
}
