﻿using System.Threading.Tasks;
using Amazon.SimpleSystemsManagement;
using Egain.Identity.Web;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Egain.Platform.Deployment.Controllers
{
    /// <summary>
    /// Tenants Controller
    /// </summary>
    [ApiController]
    public class TenantsController : ControllerBase
    {
        private readonly IDeploymentConfiguration _config;
        private readonly ILogger _logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="config"></param>
        public TenantsController(ILogger<DeploymentsController> logger, IDeploymentConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        /// <summary>
        /// PATCH deployments/deploy1/tenants/tenant1
        /// </summary>
        /// <param name="deploymentId"></param>
        /// <param name="id"></param>
        /// <param name="patchDoc"></param>
        /// <returns></returns>
        [HttpPatch("deployments/{deploymentId}/tenants/{id}")]
        public async Task<IActionResult> Patch(string deploymentId, string id, JsonPatchDocument<Models.Deployment> patchDoc)
        {
            // AWS Systems Manager document
            SystemsManagerService service = (SystemsManagerService)
                HttpContext.RequestServices.GetRequiredService(typeof(SystemsManagerService));

            // Try to get the AWS request ID from HttpContext.Items
            var awsRequestId = HttpContext.Items.ContainsKey("AwsRequestId")
                ? HttpContext.Items["AwsRequestId"]?.ToString()
                : "UNKNOWN";

            // patch this tenants application
            CommandInvocationStatus status = await service.Update(deploymentId, id, patchDoc, awsRequestId);

            if (status != CommandInvocationStatus.Success)
            {
                throw new DeploymentException("Update not successful.", status);
            }

            return NoContent();
        }
    }
}
