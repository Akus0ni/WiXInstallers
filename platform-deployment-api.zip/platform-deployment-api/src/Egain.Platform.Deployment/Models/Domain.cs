﻿namespace Egain.Platform.Deployment.Models
{
    /// <summary>
    /// Domain
    /// </summary>
    public class Domain
    {
        /// <summary>
        /// Fully qualified domain name
        /// </summary>
        // ReSharper disable once InconsistentNaming
        // ReSharper disable once UnusedMember.Global
        public string FQDN { get; set; }
    }
}
