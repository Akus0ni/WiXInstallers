﻿using Newtonsoft.Json;

namespace Egain.Platform.Deployment.Models
{
    /// <summary>
    /// /Tenant configuration
    /// </summary>
    internal class TenantConfig
    {
        [JsonProperty("internalAzureB2cDirectoryId")]
        public string InternalDirectoryId { get; set; }

        [JsonProperty("internalAzureB2cDeployerAppClientId")]
        public string  InternalDeployerAppClientId { get; set; }

        [JsonProperty("internalAzureB2cDeployerAppSecret")]
        public string  InternalDeployerAppSecret { get; set; }
        
        [JsonProperty("externalAzureB2cDirectoryId")]
        public string ExternalDirectoryId { get; set; }

        [JsonProperty("externalAzureB2cDeployerAppClientId")]
        public string  ExternalDeployerAppClientId { get; set; }

        [JsonProperty("externalAzureB2cDeployerAppSecret")]
        public string  ExternalDeployerAppSecret { get; set; }
    }
}
