﻿using Newtonsoft.Json;

namespace Egain.Platform.Deployment.Models
{
    /// <summary>
    /// Gateway configuration
    /// </summary>
    internal class GatewayConfig
    {
        [JsonProperty("azureB2cGatewayDirectoryId")]
        public string DirectoryId { get; set; }

        [JsonProperty("azureB2cGatewayDeployerAppClientId")]
        public string DeployerAppClientId { get; set; }

        [JsonProperty("azureB2cGatewayDeployerAppSecret")]
        public string DeployerAppSecret { get; set; }
    }
}
