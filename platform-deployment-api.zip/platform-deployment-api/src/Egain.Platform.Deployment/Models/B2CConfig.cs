﻿using Newtonsoft.Json;

namespace Egain.Platform.Deployment.Models
{
    /// <summary>
    /// B2CConfig class
    /// </summary>
    internal class B2CConfig
    {
        [JsonProperty("TENANT")]
        public string TenantId { get; set; }

        [JsonProperty("GATEWAY_ID")]
        public string GatewayId { get; set; }

        [JsonProperty("B2C_APP_OBJECT_ID_CUSTOMER")]
        public string CustomerAppObjectId { get; set; }

        [JsonProperty("B2C_APP_OBJECT_ID_USER")]
        public string UserAppObjectId { get; set; }

        [JsonProperty("B2C_APP_OBJECT_ID_GATEWAY")]
        public string GatewayAppObjectId { get; set; }

        [JsonProperty("ANALYTICS_APP_ID")]
        public string AnalyticsAppClientId { get; set; }
    }
}
