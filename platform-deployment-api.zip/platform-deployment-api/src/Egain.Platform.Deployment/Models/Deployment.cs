﻿using System.Collections.Generic;

namespace Egain.Platform.Deployment.Models
{
    /// <summary>
    /// Deployment
    /// </summary>
    public class Deployment
    {
        /// <summary>
        /// Deployment Id
        /// </summary>
        // ReSharper disable once UnusedMember.Global
        public string DeploymentId { get; set; }
        
        /// <summary>
        /// Domains associated with deployment
        /// </summary>
        // ReSharper disable once UnusedMember.Global
        public List<Domain> Domains { get; set; }

        /// <summary>
        /// Gets or sets the user login name to be updated or inserted.
        /// </summary>
        // ReSharper disable once UnusedMember.Global
        public string PaUserName { get; set; }
    }
}
