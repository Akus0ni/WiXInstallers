﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
// ReSharper disable once RedundantUsingDirective
using System.Xml;
using Egain.Identity.Web.MicrosoftGraph;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.Extensions.Logging;
using Microsoft.Graph;
using Newtonsoft.Json;

namespace Egain.Platform.Deployment
{
    /// <summary>
    /// Graph API service
    /// </summary>
    public class GraphApiService
    {
        private readonly GraphServiceClient _client;
        private readonly ILogger _logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="client"></param>
        /// <param name="logger"></param>
        public GraphApiService(GraphServiceClient client, ILogger<GraphApiService> logger)
        {
            _client = client;
            _logger = logger;
        }

        /// <summary>
        /// Update an application
        /// </summary>
        /// <param name="deploymentKey"></param>
        /// <param name="appObjectId"></param>
        /// <param name="patchDoc"></param>
        /// <returns></returns>
        public async Task UpdateApplication(string deploymentKey, string appObjectId, JsonPatchDocument<Models.Deployment> patchDoc)
        {
            foreach (var operation in patchDoc.Operations)
            {
                // version 1.1,  "add" - support removal of "remove" value
                if (operation.op == "add")
                {
                    // only supported paths
                    // with our custom extension, to remove previous
                    if (operation.path == "/domains/-")
                    {
                        var app = await _client.Applications[appObjectId]
                            .Request()
                            .WithDeploymentKey(deploymentKey)
                            .GetAsync()
                            .ConfigureAwait(false);

                        var urls = new List<string>(app.Web.RedirectUris);

                        dynamic d = JsonConvert.DeserializeObject(operation.value.ToString());
                        string newUri = d.fqdn;
                        newUri = newUri.TrimEnd('/').Replace("https://", "", StringComparison.OrdinalIgnoreCase);

                        string oldUri = d.remove;
                        oldUri = oldUri.TrimEnd('/').Replace("https://", "", StringComparison.OrdinalIgnoreCase);

                        // find old redirect and replace hostname - works for both user/customer apps (which are different)
                        var replacements = urls.Select(s => s.Replace(oldUri, newUri, StringComparison.OrdinalIgnoreCase)).ToList();

                        // update the Application ID URI
                        var ids = app.IdentifierUris.Select(s => s.Replace(oldUri, newUri, StringComparison.OrdinalIgnoreCase)).ToList();

                        // update logout URL
                        var logoutUrl = app.Web.LogoutUrl?.Replace(oldUri, newUri, StringComparison.OrdinalIgnoreCase);

                        // build the delta
                        Application updates = new Application
                        {
                            IdentifierUris = ids,
                            Web = new WebApplication
                            {
                                RedirectUris = replacements,
                                LogoutUrl = logoutUrl
                            }
                        };

                        await _client.Applications[appObjectId]
                            .Request()
                            .WithDeploymentKey(deploymentKey)
                            .UpdateAsync(updates);
                    }
                }
            }
        }

        /// <summary>
        /// Update Analytics Application
        /// </summary>
        /// <param name="deploymentKey"></param>
        /// <param name="appClientId"></param>
        /// <param name="patchDoc"></param>
        public async Task UpdateAnalyticsApplication(string deploymentKey, string appClientId, JsonPatchDocument<Models.Deployment> patchDoc)
        {
            foreach (var operation in patchDoc.Operations)
            {
                // version 1: "replace" - obsolete
                if (operation.op == "add")
                {
                    // only supported paths
                    // with our custom extension, to remove previous
                    if (operation.path == "/domains/-")
                    {
                        var apps = await _client.Applications
                            .Request()
                            .WithDeploymentKey(deploymentKey)
                            .Filter($"appId eq '{appClientId}'")
                            .GetAsync()
                            .ConfigureAwait(false);

                        var app = apps.FirstOrDefault();
                        if (app == null)
                        {
                            throw new DeploymentException("Invalid ANALYTICS_APP_ID configuration", appClientId);
                        }

                        var urls = new List<string>(app.Spa.RedirectUris);
                        if (urls.Any())
                        {
                            bool updated = false;

                            dynamic d = JsonConvert.DeserializeObject(operation.value.ToString());
                            string newUri = d.fqdn;
                            newUri = newUri.TrimEnd('/');

                            string reportUrl = $"{newUri}/system/web/apps/reports/";
                            if (!urls.Exists(u => u.Equals(reportUrl, StringComparison.OrdinalIgnoreCase)))
                            {
                                _logger.LogDebug($"Adding new report url: {reportUrl} to application objectId {app.Id}");
                                urls.Add(reportUrl);
                                updated = true;
                            }

                            // remove previous value, if present
                            string oldUri = d.remove;
                            if (!string.IsNullOrWhiteSpace(oldUri))
                            {
                                oldUri = oldUri.TrimEnd('/');
                                string oldReportsUrl = $"{oldUri}/system/web/apps/reports/";

                                _logger.LogDebug($"Removing old report url (if present): {oldReportsUrl} from application objectId {app.Id}");

                                updated |= urls.RemoveAll(u => u.Equals(oldReportsUrl, StringComparison.OrdinalIgnoreCase)) > 0;
                            }

                            if (updated)
                            {
                                Application updates = new Application
                                {
                                    Spa = new SpaApplication { RedirectUris = urls }
                                };

                                await _client.Applications[app.Id]
                                    .Request()
                                    .WithDeploymentKey(deploymentKey)
                                    .UpdateAsync(updates);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Update Tenant policy
        /// </summary>
        /// <param name="deploymentKey"></param>
        /// <param name="tenantId"></param>
        /// <param name="patchDoc"></param>
        public async Task UpdateTenantPolicy(string deploymentKey, string tenantId, JsonPatchDocument<Models.Deployment> patchDoc)
        {
            foreach (var operation in patchDoc.Operations)
            {
                // version 1: "replace" - obsolete
                // version 1.1,  "add" - support removal of "remove" value
                if (operation.op == "add")
                {
                    // only supported paths
                    // with our custom extension, to remove previous
                    if (operation.path == "/domains/-")
                    {
                        dynamic d = JsonConvert.DeserializeObject(operation.value.ToString());
                        string fqdn = d.fqdn;
                        fqdn = fqdn.TrimEnd('/').Replace("https://", "", StringComparison.OrdinalIgnoreCase);


                        await using Stream policy = await _client.TrustFramework.Policies["B2C_1A_Gateway_Tenants"].Content
                            .Request()
                            .WithDeploymentKey(deploymentKey)
                            .GetAsync()
                            .ConfigureAwait(false);

#if XML_UPDATE
                        // load the policy xml
                        StreamReader reader = new StreamReader(policy);
                        XmlDocument doc = new XmlDocument();
                        doc.Load(reader);

                        XmlNode root = doc.DocumentElement;  
                        XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable); 
                        nsmgr.AddNamespace("tf",  "http://schemas.microsoft.com/online/cpim/schemas/2013/06");  

                        // find all the nodes that need updating - using tenant Id as search key
                        var nodes = root?.SelectNodes($"//tf:ClaimsProvider[./tf:DisplayName/text()='{tenantId}']//tf:Item[@Key='ClaimValueOnWhichToEnable']", nsmgr);
                        if (nodes == null || nodes.Count == 0)
                        {
                            throw new DeploymentException($"ClaimsProvider for tenant {tenantId} was not found in B2C_1A_Gateway_Tenants policy.");
                        }

                        _logger.LogDebug($"Scanning B2C_1A_Gateway_Tenants policy for tenant {tenantId}. Found {nodes.Count} elements to process.");
                        
                        // update all the nodes, using FQDN
                        bool updated = false;
                        foreach (XmlNode node in nodes)
                        {
                            string claimValue = node.InnerText;
                            claimValue = claimValue.Remove(0, claimValue.LastIndexOf("-", StringComparison.OrdinalIgnoreCase));

                            claimValue = fqdn + claimValue;

                            if (!string.Equals(node.InnerText, claimValue, StringComparison.OrdinalIgnoreCase))
                            {
                                _logger.LogTrace($"Updating node. Before: {node.InnerText}. After: {claimValue}");

                                node.InnerText = claimValue;
                                updated = true;
                            }
                        }

                        // upload modified policy
                        if (updated)
                        {
                            _logger.LogDebug($"Saving B2C_1A_Gateway_Tenants policy changes for tenant {tenantId}");

                            MemoryStream xmlStream = new MemoryStream();
                            doc.Save(xmlStream);
                            xmlStream.Position = 0;

                            await _client.TrustFramework.Policies["B2C_1A_Gateway_Tenants"].Content
                                .Request()
                                .WithDeploymentKey(deploymentKey)
                                .PutAsync(xmlStream);
                        }
#else
                        // load the policy xml
                        StreamReader reader = new StreamReader(policy);
                        
                        await using MemoryStream memStream = new MemoryStream();
                        StreamWriter writer = new StreamWriter(memStream);

                        // search/replace line by line
                        string remove = d.remove;
                        remove = remove.TrimEnd('/').Replace("https://", "", StringComparison.OrdinalIgnoreCase);

                        _logger.LogDebug($"Updating domain. Before: {remove}. After: {fqdn}");

                        bool modified = false;
                        string line;
                        while ((line = await reader.ReadLineAsync()) != null)
                        {
                            string newline = line.Replace(remove, fqdn, StringComparison.OrdinalIgnoreCase);
                            if (!newline.Equals(line, StringComparison.OrdinalIgnoreCase))
                            {
                                modified = true;
                            }

                            await writer.WriteLineAsync(newline);
                        }

                        if (modified)
                        {
                            await writer.FlushAsync();
                            memStream.Position = 0;

                            await _client.TrustFramework.Policies["B2C_1A_Gateway_Tenants"].Content
                                .Request()
                                .WithDeploymentKey(deploymentKey)
                                .PutAsync(memStream);
                        }
                        else
                        {
                            _logger.LogWarning($"B2C_1A_Gateway_Tenants not updated. Previous domain not found. Before: {remove}. After: {fqdn}");
                        }
#endif
                    }
                }
            }
        }
    }
}
