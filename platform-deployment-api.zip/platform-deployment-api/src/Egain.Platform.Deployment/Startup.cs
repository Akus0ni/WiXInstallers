using System;
using Amazon.EC2;
using Amazon.SecretsManager;
using Amazon.SimpleSystemsManagement;
using Egain.Identity.Web;
using Egain.Identity.Web.MicrosoftGraph;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace Egain.Platform.Deployment
{
    /// <summary>
    /// Startup
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Configuration
        /// </summary>
        public static IConfiguration Configuration { get; private set; }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container 
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            // unique parameter name to store shared data protection keys
            var function = Environment.GetEnvironmentVariable("AWS_LAMBDA_FUNCTION_NAME") ?? Environment.MachineName;

            services
                .AddDataProtection()
                .PersistKeysToAWSSystemsManager($"/{function}/DataProtection", options => options.KMSKeyId = "alias/aws/ssm");

            services
                .AddSingleton<IDeploymentConfiguration, ConfigurationSecrets>()
                .AddTransient<ProblemDetailsFactory, DeploymentProblemDetailsFactory>()
                .AddControllers()
                .AddNewtonsoftJson();

            services
                .AddTransient<GraphApiService>()
                .AddScoped<SystemsManagerService>()
                .AddDefaultAWSOptions(Configuration.GetAWSOptions())
                .AddAWSService<IAmazonSimpleSystemsManagement>()
                .AddAWSService<IAmazonSecretsManager>()
                .AddAWSService<IAmazonEC2>()
                .AddSingleton<IConfigureOptions<DeploymentOptions>, ConfigureDeploymentOptions>()
                .AddEgainIdentityWebApiAuthentication(Configuration)
                    .EnableTokenAcquisitionToCallDownstreamApi()
                        .AddMicrosoftGraph(Configuration.GetSection("MsGraph"))
                    .AddInMemoryTokenCaches();
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware<LambdaContextMiddleware>();

            app.UseExceptionHandler(env.IsDevelopment() ? "/error-development" : "/error");

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("Welcome to running ASP.NET Core on AWS Lambda");
                });
            });
        }
    }
}
