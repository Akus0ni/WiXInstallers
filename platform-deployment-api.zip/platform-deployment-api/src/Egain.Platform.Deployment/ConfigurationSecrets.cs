﻿using System;
using System.Threading.Tasks;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Extensions.Caching;
using Amazon.SecretsManager.Model;
using Egain.Identity.Web;
using Microsoft.Extensions.Logging;

namespace Egain.Platform.Deployment
{
    /// <summary>
    /// Configuration
    /// </summary>
    public class ConfigurationSecrets : IDeploymentConfiguration, IDisposable
    {
        private readonly IAmazonSecretsManager _secretsManager;
        private readonly SecretsManagerCache _cache;

        private readonly ILogger<ConfigurationSecrets> _logger;
        private bool _disposedValue;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="secretsManager"></param>
        public ConfigurationSecrets(ILogger<ConfigurationSecrets> logger, IAmazonSecretsManager secretsManager)
        {
            _logger = logger;
            _secretsManager =secretsManager;
            _cache = new SecretsManagerCache(_secretsManager);
        }

        /// <summary>
        /// Gets a secret
        /// </summary>
        /// <param name="secretName"></param>
        /// <returns></returns>
        public async Task<string> GetAsync(string secretName)
        {
            var request = new GetSecretValueRequest
            {
                SecretId = secretName
            };

            GetSecretValueResponse response = null;
            try
            {
                response = await _secretsManager.GetSecretValueAsync(request);
            }
            catch (ResourceNotFoundException)
            {
                _logger.LogError("The requested secret " + secretName + " was not found");
            }
            catch (InvalidRequestException e)
            {
                _logger.LogError("The request was invalid due to: " + e.Message);
            }
            catch (InvalidParameterException e)
            {
                _logger.LogError("The request had invalid params: " + e.Message);
            }

            return response?.SecretString;
        }

        /// <summary>
        /// Dispose
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    // dispose managed state (managed objects)
                    _secretsManager.Dispose();
                    _cache.Dispose();
                }

                _disposedValue = true;
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
