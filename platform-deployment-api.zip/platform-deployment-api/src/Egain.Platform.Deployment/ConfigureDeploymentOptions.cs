﻿using Egain.Identity.Web;
using Egain.Platform.Deployment.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Egain.Platform.Deployment
{
    /// <summary>
    /// Configure DeploymentOptions
    /// </summary>
    public class ConfigureDeploymentOptions : IConfigureNamedOptions<DeploymentOptions>
    {
        private readonly IDeploymentConfiguration _config;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="config"></param>
        public ConfigureDeploymentOptions(IDeploymentConfiguration config)
        {
            _config = config;
        }


        /// <inheritdoc />
        public void Configure(DeploymentOptions options)
        {
            throw new System.NotImplementedException();
        }

        /// <inheritdoc />
        public void Configure(string name, DeploymentOptions options)
        {
            string[] keys = name.Split(':');

            var config = _config.GetAsync($"ern/automation/{keys[1]}").GetAwaiter().GetResult();

            switch (keys[0])
            {
                case "g":
                    GatewayConfig gateway = JsonConvert.DeserializeObject<GatewayConfig>(config);
                    options.ClientId = gateway.DeployerAppClientId;
                    options.ClientSecret = gateway.DeployerAppSecret;
                    options.TenantId = gateway.DirectoryId;

                    break;
                case "e" :
                    TenantConfig tenantExternal = JsonConvert.DeserializeObject<TenantConfig>(config);
                    options.ClientId = tenantExternal.ExternalDeployerAppClientId;
                    options.ClientSecret = tenantExternal.ExternalDeployerAppSecret;
                    options.TenantId = tenantExternal.ExternalDirectoryId;
                    break;
                case "i":
                    TenantConfig tenantInternal = JsonConvert.DeserializeObject<TenantConfig>(config);
                    options.ClientId = tenantInternal.InternalDeployerAppClientId;
                    options.ClientSecret = tenantInternal.InternalDeployerAppSecret;
                    options.TenantId = tenantInternal.InternalDirectoryId;
                    break;
            }
        }
    }
}
