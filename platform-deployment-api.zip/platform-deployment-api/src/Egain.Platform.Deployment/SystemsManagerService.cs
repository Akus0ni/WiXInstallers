﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Amazon.EC2;
using Amazon.EC2.Model;
using Amazon.SimpleSystemsManagement;
using Amazon.SimpleSystemsManagement.Model;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ResourceType = Amazon.SimpleSystemsManagement.ResourceType;

namespace Egain.Platform.Deployment
{
    /// <summary>
    /// SystemsManager Service
    /// </summary>
    public class SystemsManagerService
    {
        private readonly IAmazonSimpleSystemsManagement _client;
        private readonly IAmazonEC2 _ec2Client;
        private readonly ILogger _logger;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="client"></param>
        /// <param name="ec2Client"></param>
        /// <param name="logger"></param>
        public SystemsManagerService(IAmazonSimpleSystemsManagement client, IAmazonEC2 ec2Client,  ILogger<SystemsManagerService> logger)
        {
            _client = client;
            _ec2Client = ec2Client;
            _logger = logger;
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="deploymentId"></param>
        /// <param name="tenantId"></param>
        /// <param name="patchDoc"></param>
        /// <param name="awsRequestId"></param>
        /// <returns></returns>
        public async Task<CommandInvocationStatus> Update(string deploymentId, string tenantId, JsonPatchDocument<Models.Deployment> patchDoc, string awsRequestId)
        {
            string newName = null;
            string newDomain = null;
            string newUserName = null;
            foreach (var operation in patchDoc.Operations)
            {
                if (operation.op == "replace")
                {
                    if (operation.path == "/displayName")
                    {
                        newName = operation.value.ToString();
                    }

                    if (operation.path == "/domains/0")
                    {
                        dynamic d = JsonConvert.DeserializeObject(operation.value.ToString());
                        newDomain = d.fqdn;
                    }

                    if (operation.path == "/paUserName")
                    {
                        newUserName = operation.value.ToString();
                    }
                }
            }

            // nothing to do
            if (string.IsNullOrWhiteSpace(newName) && string.IsNullOrWhiteSpace(newDomain) && string.IsNullOrWhiteSpace(newUserName))
            {
                throw new DeploymentException("Nothing to update.");
            }

            // search for managed instance by deploymentId
            string nextToken = string.Empty;
            string databaseHost = string.Empty;
            string instanceId = string.Empty;
            string deploymentIdUpper = deploymentId.ToUpper(CultureInfo.InvariantCulture);
            bool isAlwaysOn = false;

            var filter = new List<InstanceInformationStringFilter>()
            {
                new InstanceInformationStringFilter()
                {
                    Key = "tag:ServerRole", Values = new List<string>() { "DB", "DB+MED+OLAP" }
                },
                new InstanceInformationStringFilter()
                {
                    Key = "tag:Application", Values = new List<string>() { "VIM" }
                },
                new InstanceInformationStringFilter()
                {
                    Key = "tag:Name", Values = new List<string>() { $"{deploymentIdUpper}D", $"{deploymentIdUpper}D1", $"{deploymentIdUpper}DOM", $"{deploymentIdUpper}DS", $"{deploymentIdUpper}DS1" }
                }
            };

            do
            {
                var instanceInformation = await _client.DescribeInstanceInformationAsync(new DescribeInstanceInformationRequest()
                {
                    Filters = filter,
                    NextToken = nextToken
                });

                var configuredInstances =
                    instanceInformation.InstanceInformationList.Where(i =>
                        i.ResourceType == ResourceType.EC2Instance).ToList();
                _logger.LogDebug($"Searching {configuredInstances.Count} EC2 instances for tag:ServerRole in ('DB', 'DB+MED+OLAP')");

                foreach (var instance in configuredInstances)
                {
                    string tagsNextToken = null;
                    do
                    {
                        var tags = await _ec2Client.DescribeTagsAsync(new DescribeTagsRequest()
                        {
                            Filters =
                            {
                                new Filter()
                                {
                                    Name = "resource-id",
                                    Values = new List<string>() { instance.InstanceId }
                                }
                            },
                            MaxResults = 50,
                            NextToken = tagsNextToken
                        });

                        if (tags.Tags.Exists(t => t.Key == "ServerRole" && (t.Value == "DB" || t.Value == "DB+MED+OLAP")))
                        {
                            var name = tags.Tags.Find(n =>
                                n.Key == "Name" &&
                                n.Value.StartsWith(deploymentId, StringComparison.OrdinalIgnoreCase));

                            if(!string.IsNullOrWhiteSpace(name?.Value))
                            {
                                if (name.Value.Equals($"{deploymentIdUpper}DS") || name.Value.Equals($"{deploymentIdUpper}DS1"))
                                {
                                    // AlwaysOn instance found for database services hence break the loop
                                    isAlwaysOn = true;
                                    instanceId = instance.InstanceId;
                                    _logger.LogDebug($"Found EC2 instance {instanceId} for database services on host {name.Value} ");
                                    break;
                                }
                                else 
                                {
                                    databaseHost = name.Value;
                                    instanceId = instance.InstanceId;
                                    _logger.LogDebug(
                                        $"Found EC2 instance {instanceId} for database on host {databaseHost} ");
                                }
                            }
                        }

                        tagsNextToken = tags.NextToken;
                    } while (!string.IsNullOrWhiteSpace(tagsNextToken));
                    // If always on instance found then break the loop no need to search further
                    if (isAlwaysOn)
                    {
                        break;
                    }
                }
                // If always on instance found then break the loop no need to search further
                if (isAlwaysOn)
                {
                    break;
                }

                nextToken = instanceInformation.NextToken;
            } while (!string.IsNullOrWhiteSpace(nextToken));
            
            var parameters = new Dictionary<string, List<string>>
            {
                // mandatory
                { "TenantManagerTenantID", new List<string>() { tenantId } }
            };

            // optional for databaseHost
            if (!string.IsNullOrWhiteSpace(databaseHost))
            {
                parameters.Add("AnalyticsDatabaseHost", new List<string>() { databaseHost });
            }

            // optional for rename
            if (!string.IsNullOrWhiteSpace(newName))
            {
                parameters.Add("TenantName", new List<string>() { newName });
            }

            // optional for custom domain
            if (!string.IsNullOrWhiteSpace(newDomain))
            {
                parameters.Add("DomainName", new List<string>() { newDomain });
            }

            // optional for pa user login rename
            if (!string.IsNullOrWhiteSpace(newUserName))
            {
                parameters.Add("PaUserName", new List<string>() { newUserName });
            }

            // Construct the secret name
            string secretName = $"ern/{deploymentId.ToUpper(CultureInfo.InvariantCulture)}/analytics/any/{tenantId.ToLower(CultureInfo.InvariantCulture)}/idp/auth";;
            parameters.Add("TenantAuthSecretName", new List<string>() { secretName });

            // document name can be override with env var
            string documentName = Environment.GetEnvironmentVariable("EG_RENAME_TENANT_DOCUMENT") ?? DocumentName;

            SendCommandRequest request = new SendCommandRequest { DocumentName = documentName, Parameters = parameters };
            _logger.LogInformation($"Sending command {documentName} to {instanceId} with parameters {JsonConvert.SerializeObject(parameters)}");

            request.InstanceIds = new List<string>() { instanceId };
            request.TimeoutSeconds = 30; // we are limited by the execution of lambda functions, and api gateways
            request.Comment = $"{tenantId}-{awsRequestId}";
            // send command
            SendCommandResponse response = await _client.SendCommandAsync(request);
            _logger.LogInformation($"Command sent (CommandId: {response.Command.CommandId})");

            int.TryParse(Environment.GetEnvironmentVariable("EG_RENAME_TENANT_MAX_POLL") ?? "60", out int maxPoll);

            // poll for completion
            GetCommandInvocationResponse invocationResponse = null;
            var status = CommandInvocationStatus.InProgress;
            int count = 0;
            while (status == CommandInvocationStatus.InProgress || status == CommandInvocationStatus.Pending)
            {
                await Task.Delay(PollDelay);
                _logger.LogTrace($"Waiting for command {response.Command.CommandId} with status {status}");

                if (count++ > maxPoll)
                {
                    _logger.LogDebug($"Canceling command {response.Command.CommandId}, execution has taken too long to complete.");
                    await _client.CancelCommandAsync(response.Command.CommandId);
                    return CommandInvocationStatus.Cancelling;
                }

                // Get the invocation result for the specific instance
                invocationResponse = await _client.GetCommandInvocationAsync(new GetCommandInvocationRequest
                {
                    CommandId = response.Command.CommandId,
                    InstanceId = instanceId
                });

                status = invocationResponse.Status;

                // Optional: log detailed status or error output
                _logger.LogInformation($"Invocation status: {status}. Response: {invocationResponse.StandardOutputContent}");
            }

            _logger.LogInformation($"Command {response.Command.CommandId} completed with status {status}");
            return status;
        }

        private const int PollDelay = 500;

        private const string DocumentName = "EG-RenameTenant";
    }
}
