﻿using Amazon.Lambda.Core;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace Egain.Platform.Deployment
{
    /// <summary>
    /// Middleware to extract AWS Lambda context and store the RequestId in HttpContext.Items.
    /// </summary>
    public class LambdaContextMiddleware
    {
        private readonly RequestDelegate _next;

        /// <summary>
        /// Constructor
        /// </summary>
        public LambdaContextMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        /// <summary>
        /// Invokes the middleware.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext context)
        {
            if (context.Items.TryGetValue("LambdaContext", out var lambdaContextObj) &&
                lambdaContextObj is ILambdaContext lambdaContext)
            {
                context.Items["AwsRequestId"] = lambdaContext.AwsRequestId;
            }

            await _next(context);
        }
    }
}
