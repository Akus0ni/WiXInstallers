﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Egain.Platform.Deployment
{
    /// <summary>
    /// Deployment Exception
    /// </summary>
    public class DeploymentException : Exception
    {
        /// <summary>
        /// 
        /// </summary>
        public string Type { get; } = "http://egain.com/rfc7807/deploymentexception";
        
        /// <summary>
        /// 
        /// </summary>
        public string Title { get; } = "A deployment exception occurred.";
        
        /// <summary>
        /// 
        /// </summary>
        public object ExtendedInfo { get; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="message"></param>
        /// <param name="extendedInfo"></param>
        /// <param name="type"></param>
        /// <param name="title"></param>
        public DeploymentException([NotNull] string message,
            object extendedInfo = null,
            string type = null,
            string title = null)
            : base(message)
        {
            ExtendedInfo = extendedInfo;
            Type = type ?? Type;
            Title = title ?? Title;
        }
    }
}
