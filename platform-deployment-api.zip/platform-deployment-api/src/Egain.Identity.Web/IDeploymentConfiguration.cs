﻿using System.Threading.Tasks;

namespace Egain.Identity.Web
{
    /// <summary>
    /// IDeploymentConfiguration interface
    /// </summary>
    public interface IDeploymentConfiguration
    {
        /// <summary>
        /// GetAsync
        /// </summary>
        /// <param name="configName"></param>
        /// <returns></returns>
        public Task<string> GetAsync(string configName);
    }
}
