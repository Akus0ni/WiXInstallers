﻿using System.Net.Http;
using Microsoft.Identity.Client;

namespace Egain.Identity.Web
{
    internal class MsalAspNetCoreHttpClientFactory : IMsalHttpClientFactory
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public MsalAspNetCoreHttpClientFactory(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public HttpClient GetHttpClient()
        {
            HttpClient httpClient = _httpClientFactory.CreateClient();
            return httpClient;
        }
    }
}
