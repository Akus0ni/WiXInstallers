﻿using System;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Identity.Client;
using Microsoft.Identity.Web;
using Egain.Identity.Web.Internal;

namespace Egain.Identity.Web
{
    /// <summary>
    /// Authentication builder for a web API.
    /// </summary>
    public class EgainIdentityWebApiAuthenticationBuilder : MicrosoftIdentityBaseAuthenticationBuilder
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="services">The services being configured.</param>
        /// <param name="jwtBearerAuthenticationScheme">Default scheme used for OpenIdConnect.</param>
        /// <param name="configureJwtBearerOptions">Action called to configure the JwtBearer options.</param>
        /// <param name="configureMicrosoftIdentityOptions">Action called to configure
        /// the <see cref="MicrosoftIdentityOptions"/>Microsoft identity options.</param>
        /// <param name="configurationSection">Configuration section from which to
        /// get parameters.</param>
        internal EgainIdentityWebApiAuthenticationBuilder(
            IServiceCollection services,
            string jwtBearerAuthenticationScheme,
            Action<JwtBearerOptions> configureJwtBearerOptions,
            Action<MicrosoftIdentityOptions> configureMicrosoftIdentityOptions,
            IConfigurationSection? configurationSection)
            : base(services, configurationSection)
        {
            JwtBearerAuthenticationScheme = jwtBearerAuthenticationScheme;
            ConfigureJwtBearerOptions = configureJwtBearerOptions;
            ConfigureMicrosoftIdentityOptions = configureMicrosoftIdentityOptions;

            if (ConfigureMicrosoftIdentityOptions == null)
            {
                throw new ArgumentNullException(nameof(configureMicrosoftIdentityOptions));
            }

            if (ConfigureJwtBearerOptions == null)
            {
                throw new ArgumentNullException(nameof(configureMicrosoftIdentityOptions));
            }

            Services.Configure(jwtBearerAuthenticationScheme, configureMicrosoftIdentityOptions);
        }

        private Action<MicrosoftIdentityOptions> ConfigureMicrosoftIdentityOptions { get; }

        private string JwtBearerAuthenticationScheme { get; }

        private Action<JwtBearerOptions> ConfigureJwtBearerOptions { get; }

        /// <summary>
        /// Protects the web API with Microsoft identity platform (formerly Azure AD v2.0).
        /// </summary>
        /// <param name="configureConfidentialClientApplicationOptions">The action to configure <see cref="ConfidentialClientApplicationOptions"/>.</param>
        /// <returns>The authentication builder to chain.</returns>
        public EgainIdentityAppCallsWebApiAuthenticationBuilder EnableTokenAcquisitionToCallDownstreamApi(
            Action<ConfidentialClientApplicationOptions> configureConfidentialClientApplicationOptions)
        {
            if (configureConfidentialClientApplicationOptions == null)
            {
                throw new ArgumentNullException(nameof(configureConfidentialClientApplicationOptions));
            }

            CallsWebApiImplementation(
                Services,
                JwtBearerAuthenticationScheme,
                configureConfidentialClientApplicationOptions,
                ConfigurationSection);

            return new EgainIdentityAppCallsWebApiAuthenticationBuilder(
                Services,
                ConfigurationSection);
        }

        internal static void CallsWebApiImplementation(
            IServiceCollection services,
            string jwtBearerAuthenticationScheme,
            Action<ConfidentialClientApplicationOptions> configureConfidentialClientApplicationOptions,
            IConfigurationSection? configurationSection = null)
        {
            services.Configure(jwtBearerAuthenticationScheme, configureConfidentialClientApplicationOptions);

            WebApiBuilders.EnableTokenAcquisition(
                configureConfidentialClientApplicationOptions,
                jwtBearerAuthenticationScheme,
                services,
                configurationSection);

            services.AddHttpContextAccessor();

            services.AddOptions<JwtBearerOptions>(jwtBearerAuthenticationScheme)
                .Configure((options) =>
                {
                    options.Events ??= new JwtBearerEvents();

                    var onTokenValidatedHandler = options.Events.OnTokenValidated;

                    options.Events.OnTokenValidated = async context =>
                    {
                        context.HttpContext.StoreTokenUsedToCallWebApi(context.SecurityToken as JwtSecurityToken);
                        await onTokenValidatedHandler(context).ConfigureAwait(false);
                    };
                });
        }
    }
}
