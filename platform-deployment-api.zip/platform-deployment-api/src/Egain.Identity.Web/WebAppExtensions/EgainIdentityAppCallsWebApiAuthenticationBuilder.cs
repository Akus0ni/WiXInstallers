﻿using System;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Identity.Web;
using Microsoft.Identity.Web.TokenCacheProviders;
using Microsoft.Identity.Web.TokenCacheProviders.InMemory;

namespace Egain.Identity.Web
{
    /// <summary>
    /// Authentication builder returned by the EnableTokenAcquisitionToCallDownstreamApi methods
    /// enabling you to decide token cache implementations.
    /// </summary>
    public class EgainIdentityAppCallsWebApiAuthenticationBuilder : MicrosoftIdentityBaseAuthenticationBuilder
    {
        internal EgainIdentityAppCallsWebApiAuthenticationBuilder(
            IServiceCollection services,
            IConfigurationSection? configurationSection = null)
            : base(services, configurationSection)
        {
        }

        /// <summary>
        /// Add in memory token caches.
        /// </summary>
        /// <param name="configureOptions"><see cref="MsalMemoryTokenCacheOptions"/> to configure.</param>
        /// <param name="memoryCacheOptions"><see cref="MemoryCacheOptions"/> to configure.</param>
        /// <returns>the service collection.</returns>
        public EgainIdentityAppCallsWebApiAuthenticationBuilder AddInMemoryTokenCaches(
            Action<MsalMemoryTokenCacheOptions>? configureOptions = null,
            Action<MemoryCacheOptions>? memoryCacheOptions = null)
        {
            if (configureOptions != null)
            {
                Services.Configure(configureOptions);
            }

            if (memoryCacheOptions != null)
            {
                Services.AddMemoryCache(memoryCacheOptions);
            }
            else
            {
                Services.AddMemoryCache();
            }

            Services.AddHttpContextAccessor();
            Services.AddSingleton<IMsalTokenCacheProvider, MsalMemoryTokenCacheProvider>();
            return this;
        }
    }
}
