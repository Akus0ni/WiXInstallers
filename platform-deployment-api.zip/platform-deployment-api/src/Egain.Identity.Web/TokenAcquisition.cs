﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Client;
using Microsoft.Identity.Web;
using Microsoft.Identity.Web.TokenCacheProviders;
using Microsoft.Identity.Web.TokenCacheProviders.InMemory;
using LogLevel = Microsoft.Identity.Client.LogLevel;

namespace Egain.Identity.Web
{
    /// <summary>
    /// Token acquisition service.
    /// </summary>
    internal class TokenAcquisition : ITokenAcquisition
    {
        private readonly IOptionsMonitor<MergedOptions> _mergedOptionsMonitor;
        private readonly IMsalTokenCacheProvider _tokenCacheProvider;

        private bool _retryClientCertificate;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private HttpContext? CurrentHttpContext => _httpContextAccessor.HttpContext;
        private readonly IMsalHttpClientFactory _httpClientFactory;
        private readonly ILogger _logger;
        private readonly IServiceProvider _serviceProvider;

        /// <summary>
        /// Constructor of the TokenAcquisition service. This requires the Azure AD Options to
        /// configure the confidential client application and a token cache provider.
        /// This constructor is called by ASP.NET Core dependency injection.
        /// </summary>
        /// <param name="tokenCacheProvider">The App token cache provider.</param>
        /// <param name="httpContextAccessor">Access to the HttpContext of the request.</param>
        /// <param name="mergedOptionsMonitor">Configuration options.</param>
        /// <param name="httpClientFactory">HTTP client factory.</param>
        /// <param name="logger">Logger.</param>
        /// <param name="serviceProvider">Service provider.</param>
        public TokenAcquisition(
            IMsalTokenCacheProvider tokenCacheProvider,
            IHttpContextAccessor httpContextAccessor,
            IOptionsMonitor<MergedOptions> mergedOptionsMonitor,
            IHttpClientFactory httpClientFactory,
            ILogger<TokenAcquisition> logger,
            IServiceProvider serviceProvider)
        {
            _httpContextAccessor = httpContextAccessor;
            _mergedOptionsMonitor = mergedOptionsMonitor;
            _tokenCacheProvider = tokenCacheProvider;
            _httpClientFactory = new MsalAspNetCoreHttpClientFactory(httpClientFactory);
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        internal (MergedOptions, DeploymentOptions) GetOptions(string authenticationScheme, string? tenant)
        {
            if (tenant == null)
            {
                throw new ArgumentNullException(nameof(tenant));
            }
            
            var mergedOptions = _mergedOptionsMonitor.Get(authenticationScheme);

            if (!mergedOptions.MergedWithCca)
            {
                var ccaOptionsMonitor = _serviceProvider.GetService<IOptionsMonitor<ConfidentialClientApplicationOptions>>();
                ccaOptionsMonitor?.Get(authenticationScheme);
                var bearerMonitor = _serviceProvider.GetService<IOptionsMonitor<JwtBearerOptions>>(); // supports event handlers
                bearerMonitor?.Get(authenticationScheme);
            }

            var deploymentOptionsSnapshot = _serviceProvider.GetRequiredService<IOptionsMonitor<DeploymentOptions>>();

            var deploymentOptions = deploymentOptionsSnapshot.Get(tenant);

            return (mergedOptions, deploymentOptions);
        }

        /// <summary>
        /// Scopes which are already requested by MSAL.NET. They should not be re-requested;.
        /// </summary>
        private readonly string[] _scopesRequestedByMsal = new string[]
        {
            "openid",
            "profile",
            "offline_access",
        };

        /// <summary>
        /// Meta-tenant identifiers which are not allowed in client credentials.
        /// </summary>
        private readonly ISet<string> _metaTenantIdentifiers = new HashSet<string>(
            new[]
            {
                "common",
                "organizations",
            },
            StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Acquires an authentication result from the authority configured in the app, for the confidential client itself (not on behalf of a user)
        /// using the client credentials flow. See https://aka.ms/msal-net-client-credentials.
        /// </summary>
        /// <param name="scope">The scope requested to access a protected API. For this flow (client credentials), the scope
        /// should be of the form "{ResourceIdUri/.default}" for instance <c>https://management.azure.net/.default</c> or, for Microsoft
        /// Graph, <c>https://graph.microsoft.com/.default</c> as the requested scopes are defined statically with the application registration
        /// in the portal, and cannot be overridden in the application, as you can request a token for only one resource at a time (use
        /// several calls to get tokens for other resources).</param>
        /// <param name="tenant">Enables overriding of the tenant/account for the same identity. This is useful
        /// for multi tenant apps or daemons.</param>
        /// <param name="tokenAcquisitionOptions">Options passed-in to create the token acquisition object which calls into MSAL .NET.</param>
        /// <returns>An authentication result for the app itself, based on its scopes.</returns>
        public Task<AuthenticationResult> GetAuthenticationResultForAppAsync(
            string scope,
            string? tenant = null,
            TokenAcquisitionOptions? tokenAcquisitionOptions = null)
        {
            return GetAuthenticationResultForAppAsync(
                scope,
                null,
                tenant,
                tokenAcquisitionOptions);
        }

        /// <summary>
        /// Acquires an authentication result from the authority configured in the app, for the confidential client itself (not on behalf of a user)
        /// using the client credentials flow. See https://aka.ms/msal-net-client-credentials.
        /// </summary>
        /// <param name="scope">The scope requested to access a protected API. For this flow (client credentials), the scope
        /// should be of the form "{ResourceIdUri/.default}" for instance <c>https://management.azure.net/.default</c> or, for Microsoft
        /// Graph, <c>https://graph.microsoft.com/.default</c> as the requested scopes are defined statically with the application registration
        /// in the portal, and cannot be overridden in the application, as you can request a token for only one resource at a time (use
        /// several calls to get tokens for other resources).</param>
        /// <param name="authenticationScheme">AuthenticationScheme to use.</param>
        /// <param name="tenant">Enables overriding of the tenant/account for the same identity. This is useful
        /// for multi tenant apps or daemons.</param>
        /// <param name="tokenAcquisitionOptions">Options passed-in to create the token acquisition object which calls into MSAL .NET.</param>
        /// <returns>An authentication result for the app itself, based on its scopes.</returns>
        public Task<AuthenticationResult> GetAuthenticationResultForAppAsync(
            string scope,
            string? authenticationScheme = null,
            string? tenant = null,
            TokenAcquisitionOptions? tokenAcquisitionOptions = null)
        {
            if (string.IsNullOrEmpty(scope))
            {
                throw new ArgumentNullException(nameof(scope));
            }

            if (!scope.EndsWith("/.default", true, CultureInfo.InvariantCulture))
            {
                throw new ArgumentException("IDWebErrorMessage.ClientCredentialScopeParameterShouldEndInDotDefault", nameof(scope));
            }

            authenticationScheme = GetEffectiveAuthenticationScheme(authenticationScheme);

            var options = GetOptions(authenticationScheme, tenant);

            // Case of an anonymous controller, no [Authorize] attribute will trigger the merge options
            if (string.IsNullOrEmpty(options.Item1.Instance))
            {
                var mergedOptionsMonitor = _serviceProvider.GetService<IOptionsMonitor<JwtBearerOptions>>();
                mergedOptionsMonitor?.Get(JwtBearerDefaults.AuthenticationScheme);
            }

            // update tenant with 'real' tenant id
            tenant = options.Item2.TenantId;

            if (!string.IsNullOrEmpty(tenant) && _metaTenantIdentifiers.Contains(tenant))
            {
                throw new ArgumentException("IDWebErrorMessage.ClientCredentialTenantShouldBeTenanted", nameof(tenant));
            }

            // Use MSAL to get the right token to call the API
            var application = BuildConfidentialClientApplication(options.Item1, options.Item2);

            var builder = application
                   .AcquireTokenForClient(new [] { scope }.Except(_scopesRequestedByMsal))
                   .WithSendX5C(options.Item1.SendX5C)
                   .WithTenantId(tenant);

            if (tokenAcquisitionOptions != null)
            {
                builder.WithExtraQueryParameters(tokenAcquisitionOptions.ExtraQueryParameters);
                builder.WithCorrelationId(tokenAcquisitionOptions.CorrelationId);
                builder.WithForceRefresh(tokenAcquisitionOptions.ForceRefresh);
                builder.WithClaims(tokenAcquisitionOptions.Claims);
                if (tokenAcquisitionOptions.PoPConfiguration != null)
                {
                    builder.WithProofOfPossession(tokenAcquisitionOptions.PoPConfiguration);
                }
            }

            try
            {
                return builder.ExecuteAsync(tokenAcquisitionOptions?.CancellationToken ?? CancellationToken.None);
            }
            catch (MsalServiceException exMsal) when (IsInvalidClientCertificateError(exMsal))
            {
                DefaultCertificateLoader.ResetCertificates(options.Item1.ClientCertificates);

                // Retry
                _retryClientCertificate = true;
                return GetAuthenticationResultForAppAsync(scope, tenant: tenant, tokenAcquisitionOptions: tokenAcquisitionOptions);
            }
            finally
            {
                _retryClientCertificate = false;
            }
        }

        /// <summary>
        /// Acquires a token from the authority configured in the app, for the confidential client itself (not on behalf of a user)
        /// using the client credentials flow. See https://aka.ms/msal-net-client-credentials.
        /// </summary>
        /// <param name="scope">The scope requested to access a protected API. For this flow (client credentials), the scope
        /// should be of the form "{ResourceIdUri/.default}" for instance <c>https://management.azure.net/.default</c> or, for Microsoft
        /// Graph, <c>https://graph.microsoft.com/.default</c> as the requested scopes are defined statically with the application registration
        /// in the portal, cannot be overridden in the application, as you can request a token for only one resource at a time (use
        /// several calls to get tokens for other resources).</param>
        /// <param name="tenant">Enables overriding of the tenant/account for the same identity. This is useful in the
        /// cases where a given account is a guest in other tenants, and you want to acquire tokens for a specific tenant.</param>
        /// <param name="tokenAcquisitionOptions">Options passed-in to create the token acquisition object which calls into MSAL .NET.</param>
        /// <returns>An access token for the app itself, based on its scopes.</returns>
        public Task<string> GetAccessTokenForAppAsync(
            string scope,
            string? tenant = null,
            TokenAcquisitionOptions? tokenAcquisitionOptions = null)
        {
            return GetAccessTokenForAppAsync(
                scope,
                null,
                tenant,
                tokenAcquisitionOptions);
        }

        /// <summary>
        /// Acquires a token from the authority configured in the app, for the confidential client itself (not on behalf of a user)
        /// using the client credentials flow. See https://aka.ms/msal-net-client-credentials.
        /// </summary>
        /// <param name="scope">The scope requested to access a protected API. For this flow (client credentials), the scope
        /// should be of the form "{ResourceIdUri/.default}" for instance <c>https://management.azure.net/.default</c> or, for Microsoft
        /// Graph, <c>https://graph.microsoft.com/.default</c> as the requested scopes are defined statically with the application registration
        /// in the portal, and cannot be overridden in the application, as you can request a token for only one resource at a time (use
        /// several calls to get tokens for other resources).</param>
        /// <param name="authenticationScheme">AuthenticationScheme to use.</param>
        /// <param name="tenant">Enables overriding of the tenant/account for the same identity. This is useful
        /// for multi tenant apps or daemons.</param>
        /// <param name="tokenAcquisitionOptions">Options passed-in to create the token acquisition object which calls into MSAL .NET.</param>
        /// <returns>An access token for the app itself, based on its scopes.</returns>
        public async Task<string> GetAccessTokenForAppAsync(
            string scope,
            string? authenticationScheme = null,
            string? tenant = null,
            TokenAcquisitionOptions? tokenAcquisitionOptions = null)
        {
            AuthenticationResult authResult = await GetAuthenticationResultForAppAsync(
                scope,
                authenticationScheme,
                tenant,
                tokenAcquisitionOptions).ConfigureAwait(false);
            return authResult.AccessToken;
        }

        

        public void ReplyForbiddenWithWwwAuthenticateHeader(IEnumerable<string> scopes, MsalUiRequiredException msalServiceException,
            HttpResponse? httpResponse = null)
        {
            throw new NotImplementedException();
        }

        public void ReplyForbiddenWithWwwAuthenticateHeader(IEnumerable<string> scopes, MsalUiRequiredException msalServiceException,
            string? authenticationScheme = JwtBearerDefaults.AuthenticationScheme, HttpResponse? httpResponse = null)
        {
            throw new NotImplementedException();
        }

        public string GetEffectiveAuthenticationScheme(string? authenticationScheme)
        {
            if (authenticationScheme != null)
            {
                return authenticationScheme;
            }
            else
            {
                return (CurrentHttpContext?.GetTokenUsedToCallWebApi() != null)
                    ? JwtBearerDefaults.AuthenticationScheme : OpenIdConnectDefaults.AuthenticationScheme;
            }
        }

        #region User tokens not supported

        public Task<string> GetAccessTokenForUserAsync(IEnumerable<string> scopes, string? authenticationScheme, string? tenantId = null,
            string? userFlow = null, ClaimsPrincipal? user = null, TokenAcquisitionOptions? tokenAcquisitionOptions = null)
        {
            throw new NotImplementedException();
        }

        public Task<AuthenticationResult> GetAuthenticationResultForUserAsync(
            IEnumerable<string> scopes,
            string? authenticationScheme = null,
            string? tenantId = null,
            string? userFlow = null,
            ClaimsPrincipal? user = null,
            TokenAcquisitionOptions? tokenAcquisitionOptions = null)
        {
            throw new NotImplementedException();
        }

        #endregion


        private bool IsInvalidClientCertificateError(MsalServiceException exMsal)
        {
            return !_retryClientCertificate &&
                   string.Equals(exMsal.ErrorCode, "invalid_client", StringComparison.OrdinalIgnoreCase) &&
                   exMsal.Message.Contains("AADSTS700027", StringComparison.OrdinalIgnoreCase);
        }

        private string BuildCurrentUriFromRequest(
            HttpContext httpContext,
            HttpRequest request,
            MergedOptions mergedOptions)
        {
            // need to lock to avoid threading issues with code outside of this library
            // https://docs.microsoft.com/en-us/aspnet/core/performance/performance-best-practices?#do-not-access-httpcontext-from-multiple-threads
            lock (httpContext)
            {
                return UriHelper.BuildAbsolute(
                    request.Scheme,
                    request.Host,
                    request.PathBase,
                    mergedOptions.CallbackPath.Value ?? string.Empty);
            }
        }

        public Task ReplyForbiddenWithWwwAuthenticateHeaderAsync(IEnumerable<string> scopes, MsalUiRequiredException msalServiceException,
            HttpResponse? httpResponse = null)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Creates an MSAL confidential client application.
        /// </summary>
        private IConfidentialClientApplication BuildConfidentialClientApplication(MergedOptions mergedOptions, DeploymentOptions deploymentOptions)
        {
            var httpContext = CurrentHttpContext;
            var request = httpContext?.Request;
            string? currentUri = null;

            if (!string.IsNullOrEmpty(mergedOptions.ConfidentialClientApplicationOptions.RedirectUri))
            {
                currentUri = mergedOptions.ConfidentialClientApplicationOptions.RedirectUri;
            }

            if (request != null && string.IsNullOrEmpty(currentUri))
            {
                currentUri = BuildCurrentUriFromRequest(
                    httpContext!,
                    request,
                    mergedOptions);
            }

            mergedOptions.PrepareAuthorityInstanceForMsal();

            try
            {
                var appOptions = new ConfidentialClientApplicationOptions();
                appOptions.ClientId = deploymentOptions.ClientId;
                appOptions.ClientSecret = deploymentOptions.ClientSecret;
                appOptions.TenantId = deploymentOptions.TenantId;

                var builder = ConfidentialClientApplicationBuilder
                        .CreateWithApplicationOptions(appOptions)
                        .WithHttpClientFactory(_httpClientFactory)
                        .WithLogging(
                            Log,
                            ConvertMicrosoftExtensionsLogLevelToMsal(_logger),
                            enablePiiLogging: mergedOptions.ConfidentialClientApplicationOptions.EnablePiiLogging)
                        .WithExperimentalFeatures();

                if (_tokenCacheProvider is MsalMemoryTokenCacheProvider)
                {
                    builder.WithCacheOptions(CacheOptions.EnableSharedCacheOptions);
                }

                // The redirect URI is not needed for OBO
                if (!string.IsNullOrEmpty(currentUri))
                {
                    builder.WithRedirectUri(currentUri);
                }

                string authority;

                if (mergedOptions.IsB2C)
                {
                    authority = $"{mergedOptions.Instance}{ClaimConstants.Tfp}/{mergedOptions.Domain}/{mergedOptions.DefaultUserFlow}";
                    builder.WithB2CAuthority(authority);
                }
                else
                {
                    authority = $"{mergedOptions.Instance}{deploymentOptions.TenantId}/";
                    builder.WithAuthority(authority);
                }

                if (mergedOptions.ClientCertificates != null)
                {
                    X509Certificate2? certificate = DefaultCertificateLoader.LoadFirstCertificate(mergedOptions.ClientCertificates);
                    if (certificate == null)
                    {
                        Logger.TokenAcquisitionError(
                            _logger,
                            "IDW10109: All client certificates passed to the configuration have expired or can't be loaded. ",
                            null);
                        throw new ArgumentException(
                            "IDWebErrorMessage.ClientCertificatesHaveExpiredOrCannotBeLoaded",
                            nameof(mergedOptions.ClientCertificates));
                    }

                    builder.WithCertificate(certificate);
                }

                IConfidentialClientApplication app = builder.Build();

                // Initialize token cache providers
                if (!(_tokenCacheProvider is MsalMemoryTokenCacheProvider))
                {
                    _tokenCacheProvider.Initialize(app.AppTokenCache);
                    _tokenCacheProvider.Initialize(app.UserTokenCache);
                }

                return app;
            }
            catch (Exception ex)
            {
                Logger.TokenAcquisitionError(
                    _logger,
                    "IDW10501: Exception acquiring token for a confidential client. ",
                    ex);
                throw;
            }
        }

        private void Log(
            LogLevel level,
            string message,
            bool containsPii)
        {
            switch (level)
            {
                case LogLevel.Error:
                    _logger.LogError(message);
                    break;
                case LogLevel.Warning:
                    _logger.LogWarning(message);
                    break;
                case LogLevel.Info:
                    _logger.LogInformation(message);
                    break;
                case LogLevel.Verbose:
                    _logger.LogDebug(message);
                    break;
            }
        }

        private LogLevel? ConvertMicrosoftExtensionsLogLevelToMsal(ILogger logger)
        {
            if (logger.IsEnabled(Microsoft.Extensions.Logging.LogLevel.Debug)
                || logger.IsEnabled(Microsoft.Extensions.Logging.LogLevel.Trace))
            {
                return LogLevel.Verbose;
            }
            else if (logger.IsEnabled(Microsoft.Extensions.Logging.LogLevel.Information))
            {
                return LogLevel.Info;
            }
            else if (logger.IsEnabled(Microsoft.Extensions.Logging.LogLevel.Warning))
            {
                return LogLevel.Warning;
            }
            else if (logger.IsEnabled(Microsoft.Extensions.Logging.LogLevel.Error)
                     || logger.IsEnabled(Microsoft.Extensions.Logging.LogLevel.Critical))
            {
                return LogLevel.Error;
            }
            else
            {
                return null;
            }
        }

        private static class Logger
        {
            private static readonly Action<ILogger, string, Exception?> s_tokenAcquisitionError =
                LoggerMessage.Define<string>(
                    Microsoft.Extensions.Logging.LogLevel.Information,
                    new EventId(300, "TokenAcquisitionError"),
                    "[MsIdWeb] An error occurred during token acquisition: {MsalErrorMessage}");

            /// <summary>
            /// Logger for handling MSAL exceptions in TokenAcquisition.
            /// </summary>
            /// <param name="logger">ILogger.</param>
            /// <param name="msalErrorMessage">Specific log message from TokenAcquisition.</param>
            /// <param name="ex">Exception from MSAL.NET.</param>
            public static void TokenAcquisitionError(
                ILogger logger,
                string msalErrorMessage,
                Exception? ex) => s_tokenAcquisitionError(logger, msalErrorMessage, ex);
        }
    }
}
