﻿namespace Egain.Identity.Web
{
    /// <summary>
    /// Deployment Options
    /// </summary>
    public class DeploymentOptions
    {
        /// <summary>
        /// Client Id
        /// </summary>
        public string? ClientId { get; set; }

        /// <summary>
        /// Client Secret
        /// </summary>
        public string? ClientSecret { get; set; }

        /// <summary>
        /// Tenant Id
        /// </summary>
        public string? TenantId { get; set; }
    }
}
