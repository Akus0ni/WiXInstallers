﻿using System;
using Microsoft.Graph;

namespace Egain.Identity.Web.MicrosoftGraph
{
    /// <summary>
    /// Extension methods for Graph requests
    /// </summary>
    public static class BaseRequestExtensions
    {
        /// <summary>
        /// Applied to a request, expresses to use app only permissions for Graph.
        /// </summary>
        /// <typeparam name="T">Type of the request.</typeparam>
        /// <param name="baseRequest">Request.</param>
        /// <param name="key">Deployment key for which we want to make the call..</param>
        /// <returns></returns>
        public static T WithDeploymentKey<T>(this T baseRequest, string key) where T : IBaseRequest
        {
            return SetParameter(baseRequest, options =>
            {
                options.AppOnly = true;
                options.DeploymentKey = key;
            });
        }

        private static T SetParameter<T>(T baseRequest, Action<TokenAcquisitionAuthenticationProviderOption> action) where T : IBaseRequest
        {
            string authHandlerOptionKey = typeof(AuthenticationHandlerOption).FullName!;
            AuthenticationHandlerOption authHandlerOptions;

            try
            {
                authHandlerOptions = baseRequest.MiddlewareOptions[authHandlerOptionKey] as AuthenticationHandlerOption ?? new AuthenticationHandlerOption();
            }
            catch (Exception)
            {
                authHandlerOptionKey = nameof(AuthenticationHandlerOption);
                authHandlerOptions = baseRequest.MiddlewareOptions[authHandlerOptionKey] as AuthenticationHandlerOption ?? new AuthenticationHandlerOption();
            }

            TokenAcquisitionAuthenticationProviderOption msalAuthProviderOption = authHandlerOptions.AuthenticationProviderOption as TokenAcquisitionAuthenticationProviderOption ?? new TokenAcquisitionAuthenticationProviderOption();

            action(msalAuthProviderOption);

#pragma warning disable CS8602 // Dereference of a possibly null reference. The Graph SDK ensures it exists
            authHandlerOptions.AuthenticationProviderOption = msalAuthProviderOption;
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            baseRequest.MiddlewareOptions[authHandlerOptionKey] = authHandlerOptions;

            return baseRequest;
        }
    }
}
