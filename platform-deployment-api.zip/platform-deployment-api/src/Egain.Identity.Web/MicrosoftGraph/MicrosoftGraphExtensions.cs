﻿using System;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.Graph;
using Microsoft.Identity.Web;

namespace Egain.Identity.Web.MicrosoftGraph
{
/// <summary>
    /// Extensions methods on a MicrosoftIdentityAppCallingWebApiAuthenticationBuilder builder
    /// to add support to call Microsoft Graph.
    /// </summary>
    public static class MicrosoftGraphExtensions
    {
        /// <summary>
        /// Add support to call Microsoft Graph. From a named option and a configuration section.
        /// </summary>
        /// <param name="builder">Builder.</param>
        /// <param name="configurationSection">Configuration section.</param>
        /// <returns>The builder to chain.</returns>
        public static EgainIdentityAppCallsWebApiAuthenticationBuilder AddMicrosoftGraph(
            this EgainIdentityAppCallsWebApiAuthenticationBuilder builder,
            IConfigurationSection configurationSection)
        {
            return builder.AddMicrosoftGraph(
                configurationSection.Bind, (authenticationProvider, microsoftGraphOptions) =>
                {
                    string graphBaseUrl = microsoftGraphOptions.BaseUrl;

                    GraphServiceClient client = string.IsNullOrWhiteSpace(graphBaseUrl) ?
                        new GraphServiceClient(authenticationProvider) :
                        new GraphServiceClient(graphBaseUrl, authenticationProvider);
                    return client;
                });
        }

        /// <summary>
        /// Add support to call Microsoft Graph.  
        /// </summary>
        /// <param name="builder">Builder.</param>
        /// <param name="configureMicrosoftGraphOptions">Method to configure the options.</param>
        /// <param name="graphServiceClientFactory"></param>
        /// <returns>The builder to chain.</returns>
        public static EgainIdentityAppCallsWebApiAuthenticationBuilder AddMicrosoftGraph(
            this EgainIdentityAppCallsWebApiAuthenticationBuilder builder,
            Action<MicrosoftGraphOptions> configureMicrosoftGraphOptions,
            Func<IAuthenticationProvider, MicrosoftGraphOptions, GraphServiceClient> graphServiceClientFactory)
        {
            if (builder == null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            builder.Services.AddOptions<MicrosoftGraphOptions>().Configure(configureMicrosoftGraphOptions);

            builder.Services.AddTransient<GraphServiceClient, GraphServiceClient>(serviceProvider =>
            {
                ITokenAcquisition? tokenAcquisitionService = serviceProvider.GetRequiredService<ITokenAcquisition>();

                var options = serviceProvider.GetRequiredService<IOptions<MicrosoftGraphOptions>>();
                var microsoftGraphOptions = options.Value;

                return graphServiceClientFactory(new TokenAcquisitionAuthenticationProvider(
                    tokenAcquisitionService,
                    new TokenAcquisitionAuthenticationProviderOption() { AppOnly = true, AuthenticationScheme = JwtBearerDefaults.AuthenticationScheme }),
                    microsoftGraphOptions);
            });
            return builder;
        }
    }
}
