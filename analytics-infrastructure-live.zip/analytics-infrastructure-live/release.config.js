module.exports = {
  debug: true,
  branches: [
    '+([0-9])?(.{+([0-9]),x}).x',
    'main',
    { name: 'beta', prerelease: true },
    { name: 'alpha', prerelease: true }
  ],
  plugins: [
    [
      '@semantic-release/commit-analyzer',
      {
        preset: 'conventionalcommits'
      }
    ],
    [
      '@semantic-release/release-notes-generator',
      {
        preset: 'conventionalcommits'
      }
    ],
    [
      '@semantic-release/github',
      {
        successComment: 'This ${issue.pull_request ? "PR is included" : "issue has been resolved"} in version ${nextRelease.version} :tada:', // editorconfig-checker-disable-line
        labels: false,
        releasedLabels: false,
        assets: [
          {
            path: './fossa_report/fossa_report.html',
            label: 'FOSSA Report'
          }
        ]
      }
    ],
    [
      '@semantic-release/changelog',
      {
        changelogFile: 'doc/CHANGELOG.md',
        changelogTitle: '# Changelog\n\nAll notable changes to this project will be documented in this file.'
      }
    ],
    [
      '@semantic-release-extras/verified-git-commit',
      {
        assets: [
          'doc/CHANGELOG.md'
        ],
        message: 'chore(release): version ${nextRelease.version} [skip ci]\n\n${nextRelease.notes}'
      }
    ]
  ]
}
