<!-- editorconfig-checker-disable -->
# Analytics Infrastructure
[![semantic-release: conventionalcommits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-%23FE5196?logo=conventionalcommits&logoColor=white)](https://conventionalcommits.org)
<!-- editorconfig-checker-enable -->

## Overview

This repo, along with the [analytics-infrastructure-modules](https://github.com/eGainDev/analytics-infrastructure-modules) repo,
is used to deploy the analytics infrastructure with [Terragrunt](https://github.com/gruntwork-io/terragrunt)


Be sure to read through [the Terragrunt documentation on DRY
Architectures](https://terragrunt.gruntwork.io/docs/features/keep-your-terragrunt-architecture-dry/) to understand the
features of Terragrunt used in this folder organization.

## How do you deploy the infrastructure in this repo (using Github)
Read [DEPLOYMENT](doc/DEPLOYMENT.md) and [FRESH DEPLOYMENT](doc/FreshDeployment.md)


## How do you deploy the infrastructure in this repo (outside of Github)
Read [Manual Deplyment](doc/ManualDeployment.md)
