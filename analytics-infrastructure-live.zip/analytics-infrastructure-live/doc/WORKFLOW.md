
# Release Workflow with semantic-release

## Pre-releases
Manage pre-releases to test features and gather feedback before a major release.

1. **Initial Release**: Start with `master/main`, releasing version `1.0.0`.
2. **Future Release**: Create `beta` branch for features, releasing `2.0.0-beta.1`.
3. **Bug Fixes**: Fixes on `master/main` release as `1.0.1`.
4. **Additional Features**: Create `alpha` branch for new features, releasing `3.0.0-alpha.1`.
5. **Merging**: Merge `beta` to `master/main` for major release, and `alpha` to `beta`.
6. **Further Development**: Continue development on `beta`.

[Read more](https://semantic-release.gitbook.io/semantic-release/recipes/release-workflow/pre-releases)

## Maintenance Releases
Maintain old versions with fixes and features using Git branches.

1. **Initial Release**: `master/main` releases version `1.0.0`.
2. **Breaking Change**: Commit breaking changes to `master/main`, releasing `2.0.0`.
3. **Feature for Old Version**: Create `1.x` branch, commit feature, releasing `1.1.0`.
4. **Bug Fix for Old Version**: Create `1.0.x` branch, commit fix, releasing `1.0.1`.
5. **Port Fixes**: Merge `1.0.x` into `1.x`, releasing `1.1.1`.
6. **Update Latest**: Merge `1.x` into `master/main`, releasing `2.1.0`.
7. **Bug Fix for Latest**: Commit fix to `master/main`, releasing `2.1.1`.
8. **Port Latest Fix**: Cherry-pick fix to `1.x`, releasing `1.1.2`.

[Read more](https://semantic-release.gitbook.io/semantic-release/recipes/release-workflow/maintenance-releases)
