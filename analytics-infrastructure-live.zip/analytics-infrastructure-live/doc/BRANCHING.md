Semantic Release is an automated versioning and package publishing tool that uses semantic versioning to determine the
type of version bump (major, minor, or patch) based on commit messages. When used in a GitHub workflow, it automates the release process from branch to branch.

Please read [README](https://semantic-release.gitbook.io/semantic-release)

Here's a typical flow of Semantic Release from branch to branch in a GitHub repository:

# Development Workflow
## Feature Branches:
* Developers create feature branches off the main development branch (e.g., main or develop) for new features, bug fixes,
or other changes.
* Commits on these branches should follow the Conventional Commits specification to ensure Semantic Release can determine
the type of release to be made.
## Pull Requests:
* Feature branches are merged into the main development branch through pull requests.
* Pull requests are reviewed and tested before merging.
# Main Development Branch
## Merge and CI/CD:
* Once a pull request is merged into the main development branch (e.g., main or develop), the CI/CD pipeline is triggered.
* Semantic Release runs as part of the CI/CD pipeline.
# Semantic Release Workflow
## Commit Analysis:
* Semantic Release analyzes the commit messages since the last release to determine the next version bump
(major, minor, or patch).
## Version Bump:
* Based on the analysis, Semantic Release updates the version number in the project files
(e.g., package.json for Node.js projects).
## Release Notes:
* Semantic Release generates release notes based on the commit messages and includes them in the release.
## GitHub Release:
* Semantic Release creates a new GitHub release with the updated version and release notes.
## Tagging:
* A new Git tag is created for the version, marking the release point in the repository.
## Publishing:
* If the project involves publishing to a package registry (e.g., npm for Node.js projects), Semantic Release publishes the new version to the registry.
# Release Branches
## Stable Branch:
* Some workflows use a stable branch (e.g., main) to hold the latest stable release.
* Semantic Release can be configured to create releases from this branch.
* Please read [Publishing on distribution channels](https://semantic-release.gitbook.io/semantic-release/recipes/release-workflow/distribution-channels)
## Maintenance Branch:
* Please read [Publishing maintenance releases](https://semantic-release.gitbook.io/semantic-release/recipes/release-workflow/maintenance-releases)
## Pre-release Branch:
* For pre-releases (alpha, beta, etc.), Semantic Release can be configured to create releases from a pre-release branch.
* Pre-releases can be published to a different distribution channel.
* Please read [Publishing pre-releases](https://semantic-release.gitbook.io/semantic-release/recipes/release-workflow/pre-releases)
