# Deployment Instructions

>[!NOTE]
>The steps for fresh installation and for upgrade/revert are the same.

## Prerequisites
To deploy to an environment, please verify that your username is included under "Settings" tab -> "Environments" ->
<environment_name> -> "Deployment protection rules" -> "Required reviewers".

## Triggering Deployment with a Commit
1. Commit to main branch triggers the GitHub action "Generate Release", which starts with FOSSA and Fortify scan jobs
   running in parallel.
2. "Generate Release" job runs after the scans have completed and generates a new release if there is a change in
   version. Breaking change, feat, and fix type commits change major, minor, and patch release version numbers,
   respectively. Please refer to the [Commit Format Rules](#commit-format-rules) section below.
3. Next, deployments of the latest release to environments are executed in the following order: Dev -> QE -> Staging ->
   Production.
4. Deployment to each environment consists of 2 jobs. The first one runs terraform plan, and the second one runs
   terraform apply. Both jobs for each environment, require an approval.
5. Go to the "Generate Release" workflow under the "Actions" tab and select the needed workflow run from the list.
6. In the next window, follow steps 4 - 10 from the [Manual Deployment](#manual-deployment) section below for each
   environment.

## Manual Deployment

> [!WARNING]
> Deployment must only be done by someone who has sufficient experience with Terraform to make the right decision after
> carefully reviewing the results of the Terraform plan step. Certain terraform changes may cause downtime!

1. Go to the "Deploy Environment" workflow under the "Actions" tab.
2. Click on the "Run workflow" drop-down menu in the upper right corner of the workflow runs list. Select branch name
   and environment name from the drop-down lists. Click on the green "Run workflow"
   button to start the workflow.
3. After the new workflow run with "Waiting" status appears in the list, click on it.
4. Select "Review deployments" in the upper right corner.
5. Then select the checkbox with the environment's name and choose "Reject" or "Approve and deploy" to start or reject
   the terraform "plan" job.

> [!WARNING]
> Please review the Terraform plan results carefully! Certain terraform changes may cause downtime!

6. After the terraform "plan" job completes, select it and then select "Terraform Plan" step to review the terraform
   plan results.

> [!WARNING]
> The next step must only be done by someone who has sufficient experience with Terraform to make the right decision.
> Before applying the Terraform changes, please make sure to review the Terraform plan results carefully! Certain
> terraform changes may cause downtime!

7. Next, select "Terraform Apply and AWS Code Deploy" job. Click on the "Review pending deployments" link and choose
   "Reject" or "Approve and deploy" (the same as in step 5) to start or to reject the job.
8. In case of a failure, click on the failed job of the workflow to see the error logs.
9. If the job successfully completes, go to the "Terraform Apply" job, then to "Terraform Apply"
   step, and scroll all the way down to get the deployment details under "Outputs".
