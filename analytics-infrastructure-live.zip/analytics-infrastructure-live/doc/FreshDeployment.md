
# Fresh Deployment

In any new account and/or environment the following steps are *required*




## SSH Keys

Create the following three Keypairs. Do **NOT** overwrite any existing keypairs

  1. analytics-etl-nifi-[environment]
  1. analytics-etl-reg-[environment]
  1. analytics-etl-zk-[environment]

  Example,

```
  aws ec2 create-key-pair --key-name analytics-etl-nifi-qa --query 'KeyMaterial' --output text > analytics-etl-nifi-qa.pem
  aws ec2 create-key-pair --key-name analytics-etl-reg-qa --query 'KeyMaterial' --output text > analytics-etl-reg-qa.pem
  aws ec2 create-key-pair --key-name analytics-etl-zk-qa --query 'KeyMaterial' --output text > analytics-etl-zk-qa.pem
```

Store *securely* these three PEM files - **Do not lose!**

Extract the public part of the keys

Example,

```
ssh-keygen -y -f analytics-etl-nifi-qa.pem > analytics-etl-nifi-qa.pub
```

If you are using WSL on Windows, you may need to move the files into the WSL file system and chmod the files
```
chmod 700 ~/.ssh
chmod 600 ~/.ssh/analytics-etl-nifi-qa.pem
```


## Github Environment

Setup the github environment (secrets & variables)

See https://egaincorp.atlassian.net/wiki/spaces/products/pages/153681924/Github+Deployment+Environments
