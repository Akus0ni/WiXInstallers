# Linting

This repo uses super-linter, and runs during release check actions

## Run manually

Example:

```
docker run \
  -e LOG_LEVEL=INFO \
  -e RUN_LOCAL=true \
  -e USE_FIND_ALGORITHM=true \
  -e VALIDATE_BASH_EXEC=true \
  -e VALIDATE_PYTHON_PYLINT=true \
  -e VALIDATE_DOCKERFILE_HADOLINT=true \
  -e VALIDATE_TERRAGRUNT=true \
  -e VALIDATE_TERRAFORM_FMT=true \
  -e VALIDATE_GITHUB_ACTIONS=true \
  -e VALIDATE_EDITORCONFIG=true \
  -e VALIDATE_CHECKOV=true \
  -e FILTER_REGEX_EXCLUDE='.*doc/.*|.*terragrunt-cache/.*' \
  -v /mnt/c/GitHub/analytics-infrastructure-live:/tmp/lint \
  --rm \
  ghcr.io/super-linter/super-linter:latest
```

## Example supressions

### editorconfig
```
// editorconfig-checker-disable-line

// editorconfig-checker-disable
// editorconfig-checker-enable
```

## Formating  HCL

```
terragrunt hclfmt --terragrunt-hclfmt-file [hclfile]
```
