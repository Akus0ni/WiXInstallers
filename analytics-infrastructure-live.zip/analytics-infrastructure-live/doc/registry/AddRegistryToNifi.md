
# In Nifi

Add the url as

```
https://registry-1.analytics-etl-ns-[environment].local:18443
```

![alt text](registry.png)



# In Registry

## Add node users
CN=nifi-1.analytics-etl-ns-dev.local, OU=NIFI
CN=nifi-2.analytics-etl-ns-dev.local, OU=NIFI
CN=nifi-3.analytics-etl-ns-dev.local, OU=NIFI

Create group `nifi` add those node users

Grant that group permissions

/buckets policy with Read permissions
/proxy policy with Read, Write, and Delete permissions

![alt text](permissions.png)


## Add standard users

No AAD support :(

)
Now add users to registry manually. And grant permissions to buckets
