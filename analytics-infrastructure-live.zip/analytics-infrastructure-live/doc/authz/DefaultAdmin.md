# Admin Policies

## Default
![alt](nifi_admin_group.png)
