# Manual One Time Nifi Config for Auth

This needs to be before the system is used.

> :warning: **If Nifi is clustered,** you need to stop all of the nodes and make the config changes
on each of the EC2 instance hosts.

### Configuring NiFi for AAD Auth

1. Set up NiFi to run over TLS as required for User-based Authentication to be enabled. For more information see the
Nifi-toolkit [walkthrough](https://nifi.apache.org/docs/nifi-docs/html/walkthroughs.html) about enabling TLS
for a local instance.

2. Set up you OpenId properties to point to the created prevously in [Configure Azure AD](ConfigureAzureAD.md). These are located in `conf/nifi.properties`.

```properties
# OpenId Connect SSO Properties #
nifi.security.user.oidc.discovery.url=https://login.microsoftonline.com/<YOUR_TENENT_ID>/v2.0/.well-known/openid-configuration
nifi.security.user.oidc.connect.timeout=5 secs
nifi.security.user.oidc.read.timeout=5 secs
nifi.security.user.oidc.client.id=<YOUR_APPLICATION_CLIENT_ID>
nifi.security.user.oidc.client.secret=<YOUR_APPLICATION_CLIENT_SECRET>
nifi.security.user.oidc.preferred.jwsalgorithm=
nifi.security.user.oidc.additional.scopes=
nifi.security.user.oidc.claim.identifying.user=email
```


3. Next, configure `conf/authorizers.xml` to enable a `file-user-group-provider` provider for initial
SystemAdminastration and the `azure-graph-user-group-provider` for Group Sync.

Example `authorizers.xml`:
```xml
<authorizers>
    <userGroupProvider>
        <identifier>file-user-group-provider</identifier>
        <class>org.apache.nifi.authorization.FileUserGroupProvider</class>
        <property name="Users File">./conf/users.xml</property>
        <property name="Legacy Authorized Users File"></property>
    </userGroupProvider>

    <userGroupProvider>
        <identifier>azure-graph-user-group-provider</identifier>
        <class>org.apache.nifi.authorization.azure.AzureGraphUserGroupProvider</class>
        <property name="Refresh Delay">5 mins</property>
        <property name="Authority Endpoint">https://login.microsoftonline.com</property>
        <property name="Directory ID">YOUR_TENANT_ID</property>
        <property name="Application ID">YOUR_APPLICATION_CLIENT_ID</property>
        <property name="Client Secret">YOUR_APPLICATION_CLIENT_SECRET</property>
        <property name="Group Filter Prefix">Nifi-AAD</property>
        <property name="Page Size">100</property>
        <property name="Claim for Username">email</property>
    </userGroupProvider>

    <userGroupProvider>
        <identifier>composite-configurable-user-group-provider</identifier>
        <class>org.apache.nifi.authorization.CompositeConfigurableUserGroupProvider</class>
        <property name="Configurable User Group Provider">file-user-group-provider</property>
        <property name="User Group Provider 1">azure-graph-user-group-provider</property>
    </userGroupProvider>

    <accessPolicyProvider>
        <identifier>file-access-policy-provider</identifier>
        <class>org.apache.nifi.authorization.FileAccessPolicyProvider</class>
        <property name="User Group Provider">composite-configurable-user-group-provider</property>
        <property name="Authorizations File">./conf/authorizations.xml</property>
        <property name="Initial Admin Identity">SYS_ADMIN_AAD_UPN</property>
        <property name="Legacy Authorized Users File"></property>
        <property name="Node Identity 1"></property>
    </accessPolicyProvider>

    <authorizer>
        <identifier>managed-authorizer</identifier>
        <class>org.apache.nifi.authorization.StandardManagedAuthorizer</class>
        <property name="Access Policy Provider">file-access-policy-provider</property>
    </authorizer>
</authorizers>
```

### Configuring NiFi Group Access Policy

1. Now run you NiFi instance with the Configuration, logging onto the NiFi web appl now should re-direct you to a
Microsoft Branded Login portal.
2. Login with the User that the `SYS_ADMIN_AAD_UPN` was specified for.
   > __NOTE__ You may need to accept logging into a Non-Microsoft Application for the First time. <br> As AAD Admin;
   selecting `Consent on behalf of your organization` should avoid this from happening again.
   ![alt](images/aad_login_permission.png)

3. You should now have been successfully authenticated and redirected into the NiFi Canvas.
4. To verify the AAD Group Sync Provider is working and picking the created Groups, select the **hamburger menu**
(top-right) and select **Users**, their should be User Principal Name (UPN) references for all the users within the
AAD Groups and also the Groups listed also. ![alt](images/aad_nifi_users_list.png)
5. To Enforce Groups to certain abilities and pollicies, select again the **hamburger menu** (top-right) and select
**Policies**.
6. Now select each policy you wish to enforce, then select the add button the right of the table, and type in the group
 you wish to have entitlement to that policy. ![alt](images/aad_nifi_access_policies.png)
7. Now Users in that AAD group will have access to that policy when they login.

## Permissions

An example of the [default admin group permissions](../authz/DefaultAdmin.md)
