# IAM Role used for deployment from Github

## Summary

### Name: analytics-dataservices-infrastructure-github-role-[environment]

Session Duration: 4 hours

Attach policies required for deployments

* [policy 1](policy1.json)
* [policy 2](policy2.json)
* [policy 3](policy3.json)
* [policy 4](policy4.json)
* [terragrunt](terragrunt.json)

## Deploying the IAM role & policies from the Command Line

### Prerequisites
1. **Install Terraform**:
   Download and install Terraform from the [official website](https://www.terraform.io/downloads.html).

2. **Configure your environment**:
   Make sure Terraform is installed correctly by running:
   ```bash
   terraform -version
   ```

### Steps to Run a Terraform Script

1. **Initialize Terraform**
  Before running any Terraform commands, initialize your working directory with:

   ```bash
   terraform init
    ```
2. **Plan the execution**
Terraform will create an execution plan, showing what resources will be created, updated, or deleted:

   ```bash
   terraform plan
   ```
3. **Apply the configuration**
  This command executes the actions proposed by the plan:

   ```bash
   terraform apply
   ```
4. **Passing variables directly (optional)**
   If you want to override the terraform.tfvars values, you can pass variables directly from the command line:
   ```bash
   terraform apply -var="environment=dev" -var="aws_region=us-west-2" -var="account_id=696588589177"
   ```

4. **Destroy resources (optional)**
To clean up and delete all resources created by Terraform, run:

   ```bash
   terraform destroy
   ```
### Notes
Make sure you have configured your AWS credentials properly before running the script, or use environment variables like AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY.
Always review the plan before applying changes, especially when modifying production infrastructure.
