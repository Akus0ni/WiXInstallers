# Changelog

All notable changes to this project will be documented in this file.

## [4.30.5](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.30.4...v4.30.5) (2025-05-01)

### Bug Fixes

* Update service discovery permissions ([7137d1d](https://github.com/eGainDev/analytics-infrastructure-live/commit/7137d1d7344c7c74a21302e5fccc28988075190e))

## [4.30.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.30.3...v4.30.4) (2025-04-22)

### Bug Fixes

* corrected region for zk of bnl and tryg ([#182](https://github.com/eGainDev/analytics-infrastructure-live/issues/182)) ([4c2c7e3](https://github.com/eGainDev/analytics-infrastructure-live/commit/4c2c7e3a65ab43bb034ab22c71a60efa50e14e6c))

## [4.30.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.30.2...v4.30.3) (2025-04-22)

### Bug Fixes

* corrected the region for bnl ([e6db7bb](https://github.com/eGainDev/analytics-infrastructure-live/commit/e6db7bbed97d3082d89d5348b43c9d16556dc7f6))
* Corrected the region for Tryg ([c65a0fb](https://github.com/eGainDev/analytics-infrastructure-live/commit/c65a0fb9490fab7f158a7300a255ac1cec626c99))
* Corrected the region for Tryg and bnl environments ([33cbb03](https://github.com/eGainDev/analytics-infrastructure-live/commit/33cbb034495a25b9f9729ebd25702108aa4d2493))

## [4.30.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.30.1...v4.30.2) (2025-04-16)

### Bug Fixes

* wrap Secrets Manager ARNs in quotes to ensure valid syntax ([#180](https://github.com/eGainDev/analytics-infrastructure-live/issues/180)) ([c545f9e](https://github.com/eGainDev/analytics-infrastructure-live/commit/c545f9ee4033d0ffb6757090b62eede2f583db1f))

## [4.30.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.30.0...v4.30.1) (2025-04-16)

### Bug Fixes

* Correct AMI Image ID ([9cc2914](https://github.com/eGainDev/analytics-infrastructure-live/commit/9cc2914a29c861289058c9089ae9e0151851ee58))

## [4.30.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.29.0...v4.30.0) (2025-04-15)

### Features

* VIM-20929 Automation support to configure/manage eGain as a tenant ([#178](https://github.com/eGainDev/analytics-infrastructure-live/issues/178)) ([7fea614](https://github.com/eGainDev/analytics-infrastructure-live/commit/7fea614f17781a26247f36851d9285b1671a7fe9))

## [4.29.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.28.0...v4.29.0) (2025-04-14)

### Features

* Add new BNL and Tryg Environments ([b36391f](https://github.com/eGainDev/analytics-infrastructure-live/commit/b36391f216620a945432b8716064f1960895973e))

## [4.28.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.27.1...v4.28.0) (2025-04-11)

### Features

* Update dependencies for prod environment ([7e0c632](https://github.com/eGainDev/analytics-infrastructure-live/commit/7e0c6327b45dbcaabcb37e8c5795225e00a53b25))

## [4.27.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.27.0...v4.27.1) (2025-03-19)

### Bug Fixes

* Set NiFi image to valid version for Dev3 ([daa3a96](https://github.com/eGainDev/analytics-infrastructure-live/commit/daa3a96cdc0bb014d216458b3206a32d6a453ad5))

## [4.27.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.26.0...v4.27.0) (2025-03-07)

### Features

* Add qe3 environment for theseus-OA testing ([0355f4e](https://github.com/eGainDev/analytics-infrastructure-live/commit/0355f4e42abcf647d1f776ab8a13a8abd876634e))
* Add qe3 environment for Theseus-OA testing ([#173](https://github.com/eGainDev/analytics-infrastructure-live/issues/173)) ([d0f8e11](https://github.com/eGainDev/analytics-infrastructure-live/commit/d0f8e11727919b6f9c75cb2e4f66e2d13a729b72))

## [4.26.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.25.0...v4.26.0) (2025-02-28)

### Features

* Enable Provisioned Concurrency for k2 prod environment ([e73b2ee](https://github.com/eGainDev/analytics-infrastructure-live/commit/e73b2eedd146a8fd0e82d01a12d7a89f31234a2a))

## [4.25.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.24.1...v4.25.0) (2025-02-26)

### Features

* Upgrade K2 Prod and test2 non-prod environments to latest dependencies ([1a35ec8](https://github.com/eGainDev/analytics-infrastructure-live/commit/1a35ec8bbb92ca8fb670dc4f5adc033f3e8c54f4))

## [4.24.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.24.0...v4.24.1) (2025-02-24)

### Bug Fixes

* GDPR - ensure unique sequential filenames in S3, action parameter to lowercase for case-insensitive comparison ([#169](https://github.com/eGainDev/analytics-infrastructure-live/issues/169)) ([0d8227d](https://github.com/eGainDev/analytics-infrastructure-live/commit/0d8227d237b6c2d6105ff43d821f94bf33a5c166))

## [4.24.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.23.2...v4.24.0) (2025-02-13)

### Features

* Add new test2 environment ([d45cdd3](https://github.com/eGainDev/analytics-infrastructure-live/commit/d45cdd312bce418f1fb80fa4256b39b402c445b8))

## [4.23.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.23.1...v4.23.2) (2025-02-12)

### Bug Fixes

* Fix provisioned concurrency error for provisioner lambda ([fcedf12](https://github.com/eGainDev/analytics-infrastructure-live/commit/fcedf128f3bb52f2668f7f734bc9f7e910b65bcd))

## [4.23.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.23.0...v4.23.1) (2025-02-11)

### Bug Fixes

* Provisioner changes for deployment to all dev & qe2-k2 environments ([#163](https://github.com/eGainDev/analytics-infrastructure-live/issues/163)) ([410c9a0](https://github.com/eGainDev/analytics-infrastructure-live/commit/410c9a0e30305bcdc1d45c7c89d62379a66d2ef1)), closes [#162](https://github.com/eGainDev/analytics-infrastructure-live/issues/162)

## [4.23.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.22.1...v4.23.0) (2025-02-01)

### Features

* Add provisioned concurrency for the provisioner lambda in dev2 ([f26f558](https://github.com/eGainDev/analytics-infrastructure-live/commit/f26f5581c9dec39d0d66c8b881cd67ad040a82e0))

## [4.22.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.22.0...v4.22.1) (2025-01-31)

### Bug Fixes

* Add missing env secret to deploy workflow ([12017ad](https://github.com/eGainDev/analytics-infrastructure-live/commit/12017adeae774f83cf8c9e742fe6be8f11f8931e))

## [4.22.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.21.0...v4.22.0) (2025-01-31)

### Features

* Update NiFi and Registry to latest images for non prod environments ([6675c76](https://github.com/eGainDev/analytics-infrastructure-live/commit/6675c76a4b6ebe68b5e5b62854bb64a5dfb14950))

## [4.21.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.20.0...v4.21.0) (2025-01-30)

### Features

* Update dependencies for all non-prod environments ([fdf2acb](https://github.com/eGainDev/analytics-infrastructure-live/commit/fdf2acbd48ce89dbe19e37c19e90c8520d1b35c7))

## [4.20.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.19.0...v4.20.0) (2025-01-28)

### Features

* Update Dev2 Stack dependencies and integrate with Github ([68ba960](https://github.com/eGainDev/analytics-infrastructure-live/commit/68ba96034db1807fb794f3ab021f5c7dde305a81))

## [4.19.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.18.2...v4.19.0) (2025-01-23)

### Features

* Add test environment for infra deployment testing ([fdf3239](https://github.com/eGainDev/analytics-infrastructure-live/commit/fdf32394cc2fb12ec66675227518b2ee5d09bbe2))

## [4.18.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.18.1...v4.18.2) (2025-01-21)

### Bug Fixes

* Remove eGain administrators tenant from provisioner ([#155](https://github.com/eGainDev/analytics-infrastructure-live/issues/155)) ([7756eca](https://github.com/eGainDev/analytics-infrastructure-live/commit/7756eca74bbb651214ceadebd538f604afd1a1c5))

## [4.18.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.18.0...v4.18.1) (2025-01-20)

### Bug Fixes

* Update namespace and tenant name for eGain administrator ([#154](https://github.com/eGainDev/analytics-infrastructure-live/issues/154)) ([6655e12](https://github.com/eGainDev/analytics-infrastructure-live/commit/6655e12061da8c5e2187886bd59256068088bd56))

## [4.18.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.17.0...v4.18.0) (2025-01-15)

### Features

* Forcing release for update of NiFi version in egengqe1 ([9665f71](https://github.com/eGainDev/analytics-infrastructure-live/commit/9665f71059c3b3d1a0c8f20b8990ae7ebdc248fd))

## [4.17.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.16.4...v4.17.0) (2025-01-10)

### Features

* VIM-20567 & VIM-20929 ([57d10cf](https://github.com/eGainDev/analytics-infrastructure-live/commit/57d10cf01cfd6f0e1bdfa59a1c268eefc36fa1a0))
* VIM-20567 & VIM-20929 ([#150](https://github.com/eGainDev/analytics-infrastructure-live/issues/150)) ([b3082d3](https://github.com/eGainDev/analytics-infrastructure-live/commit/b3082d31d5868d93d40dee211b94130f26c09a21))
* VIM-20567 & VIM-20929 ([#151](https://github.com/eGainDev/analytics-infrastructure-live/issues/151)) ([491c52f](https://github.com/eGainDev/analytics-infrastructure-live/commit/491c52fa5895dd701b3821f7b189f502c9683741))

## [4.16.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.16.3...v4.16.4) (2025-01-09)

### Bug Fixes

* add delete tenant lambda changes to all environments (qa and prod) ([9d226d7](https://github.com/eGainDev/analytics-infrastructure-live/commit/9d226d781e96ceac83090a4c3a031c3762341448))
* add delete tenant lambda changes to all environments (qa and prod) ([#149](https://github.com/eGainDev/analytics-infrastructure-live/issues/149)) ([1163df0](https://github.com/eGainDev/analytics-infrastructure-live/commit/1163df04de16a4269378270fb2502c6974128557))
* handle legacy environments with missing (newly added) common variables ([419603f](https://github.com/eGainDev/analytics-infrastructure-live/commit/419603fe17cc26383f3defa8821bbf1d26cd34b8))

## [4.16.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.16.2...v4.16.3) (2025-01-08)

### Bug Fixes

* set node identity on legacy nifi imag ([575a70a](https://github.com/eGainDev/analytics-infrastructure-live/commit/575a70a5699170818e94a6bed6b13d2aaad4d578))
* set node identity on legacy nifi image ([#148](https://github.com/eGainDev/analytics-infrastructure-live/issues/148)) ([92e1f9d](https://github.com/eGainDev/analytics-infrastructure-live/commit/92e1f9ddd61dffdea339628188dce24c957da5a0))

## [4.16.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.16.1...v4.16.2) (2025-01-07)

### Bug Fixes

* missing nifi_set_node_identity on dev ([ef8be4e](https://github.com/eGainDev/analytics-infrastructure-live/commit/ef8be4e4e53d3d3aa3daa4e680118967f072e6f5))
* missing nifi_set_node_identity on dev ([#147](https://github.com/eGainDev/analytics-infrastructure-live/issues/147)) ([df6cc50](https://github.com/eGainDev/analytics-infrastructure-live/commit/df6cc50c49220b6a9c5e974a20da02b225cc0c1d))

## [4.16.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.16.0...v4.16.1) (2025-01-07)

### Bug Fixes

* Tenant Decomission : Redshift ([7712ed1](https://github.com/eGainDev/analytics-infrastructure-live/commit/7712ed18c31a5e320a0366cb6149a1b8a65940b9))
* Tenant Decomission : Redshift ([#146](https://github.com/eGainDev/analytics-infrastructure-live/issues/146)) ([58918c4](https://github.com/eGainDev/analytics-infrastructure-live/commit/58918c44d99e1f3df10a638556b04e0a88384dbb))

## [4.16.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.15.1...v4.16.0) (2025-01-07)

### Features

* Add Delete Tenant Lambda updates to dev, dev2 & dev3 environments ([#144](https://github.com/eGainDev/analytics-infrastructure-live/issues/144)) ([90431d4](https://github.com/eGainDev/analytics-infrastructure-live/commit/90431d4e93d3413402914db8c343251536881069))
* update dev environment with delete tenant lambda ([34d6637](https://github.com/eGainDev/analytics-infrastructure-live/commit/34d6637edcda3dd37c69f1e09c34a4d8965c8e7b))
* update dev2 & dev3 with delete tenant lambda ([b940523](https://github.com/eGainDev/analytics-infrastructure-live/commit/b94052357f5b0113109995c744068fb005cde4b0))

## [4.15.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.15.0...v4.15.1) (2024-12-31)

### Bug Fixes

* update group oid for egengqe1 environment ([07d7f9a](https://github.com/eGainDev/analytics-infrastructure-live/commit/07d7f9a7a8c2759023ca921cfe43b064cf615b64))
* update group oid for egengqe1 environment ([#143](https://github.com/eGainDev/analytics-infrastructure-live/issues/143)) ([054a33a](https://github.com/eGainDev/analytics-infrastructure-live/commit/054a33a19fb1d7991384187ba7a828492f39b356))

## [4.15.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.14.0...v4.15.0) (2024-12-23)

### Features

* New environment for QE in analytics dev POC account ([#142](https://github.com/eGainDev/analytics-infrastructure-live/issues/142)) ([20c35f8](https://github.com/eGainDev/analytics-infrastructure-live/commit/20c35f815f7d3ab6174fc55f67c73f2efe1d4c22))

## [4.14.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.13.0...v4.14.0) (2024-12-04)

### Features

* Add new Dev3 environment ([170a1da](https://github.com/eGainDev/analytics-infrastructure-live/commit/170a1dac8331104359064141f669d5c606589b30))

## [4.13.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.12.0...v4.13.0) (2024-12-02)

### Features

* Update QE2 ECR Versions ([a38db4a](https://github.com/eGainDev/analytics-infrastructure-live/commit/a38db4aa57fac00bc8c115bada39e8080c541548))
* Update QE2 ECR Versions ([#139](https://github.com/eGainDev/analytics-infrastructure-live/issues/139)) ([b4310b2](https://github.com/eGainDev/analytics-infrastructure-live/commit/b4310b2e73c3de4d91f58897c6cca9aac91109fd))

## [4.12.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.11.0...v4.12.0) (2024-11-29)

### Features

* Add new QE2 Environment ([b1a6e67](https://github.com/eGainDev/analytics-infrastructure-live/commit/b1a6e67a319b05a6999937dd640abd2725bc645f))
* Add new QE2 Environment ([#138](https://github.com/eGainDev/analytics-infrastructure-live/issues/138)) ([c7c998e](https://github.com/eGainDev/analytics-infrastructure-live/commit/c7c998e6006f9551513807367190f7146f731066))

## [4.11.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.8...v4.11.0) (2024-11-18)

### Features

* Add support for dev2 stack with smaller ec2 and redshift ([4a6f6bb](https://github.com/eGainDev/analytics-infrastructure-live/commit/4a6f6bbf67eb9fde3e6e53355baf9eee3c63324f))

## [4.10.8](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.7...v4.10.8) (2024-10-28)

### Bug Fixes

* QA K2 oidc client details ([5bcf5d7](https://github.com/eGainDev/analytics-infrastructure-live/commit/5bcf5d777471ff11442d151febbaba41d4bd3a4a))
* Setting QE1 environment to dedicated redshift clusters ([0fafb00](https://github.com/eGainDev/analytics-infrastructure-live/commit/0fafb0047b087ee05be69beaadae2a3792005d23))

## [4.10.7](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.6...v4.10.7) (2024-10-22)

### Bug Fixes

* always create the redshift reporting security group ([d904d3c](https://github.com/eGainDev/analytics-infrastructure-live/commit/d904d3c3c213f9ca01d1b69cbf510f526b1b152d))
* always create the redshift reporting security group ([#133](https://github.com/eGainDev/analytics-infrastructure-live/issues/133)) ([d4cc32a](https://github.com/eGainDev/analytics-infrastructure-live/commit/d4cc32a33dc11601afb394afed22d3264fc208bd))

## [4.10.6](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.5...v4.10.6) (2024-10-22)

### Bug Fixes

* missing dependancy caused null security group for lambda ([b903070](https://github.com/eGainDev/analytics-infrastructure-live/commit/b9030703721093c2731060bd319809bccb0f3970))
* missing dependency caused null security group for lambda ([#131](https://github.com/eGainDev/analytics-infrastructure-live/issues/131)) ([247b763](https://github.com/eGainDev/analytics-infrastructure-live/commit/247b763acaf577915d8f612e09bca445992283a4))

## [4.10.5](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.4...v4.10.5) (2024-10-17)

### Bug Fixes

* incorrect task zone for nifi-2 ([83f6450](https://github.com/eGainDev/analytics-infrastructure-live/commit/83f645075865bb8b436a3cc0c25177718f1c9b4f))
* incorrect task zone for nifi-2 ([#130](https://github.com/eGainDev/analytics-infrastructure-live/issues/130)) ([9ff741b](https://github.com/eGainDev/analytics-infrastructure-live/commit/9ff741bf392e0437802c1d7dcf677f26285f477c))

## [4.10.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.3...v4.10.4) (2024-10-17)

### Bug Fixes

* replacing hard-coded us-west-2 AZs ([513256a](https://github.com/eGainDev/analytics-infrastructure-live/commit/513256a49d76b704c50beb55d9e822bf1aa0cac1))
* replacing hard-coded us-west-2 AZs ([#129](https://github.com/eGainDev/analytics-infrastructure-live/issues/129)) ([2fb6470](https://github.com/eGainDev/analytics-infrastructure-live/commit/2fb6470f500a2995695f7d2f005351b7d3b8cdab))

## [4.10.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.2...v4.10.3) (2024-10-17)

### Bug Fixes

* ALB target group names have a 32 char limit ([1af4767](https://github.com/eGainDev/analytics-infrastructure-live/commit/1af47670df8f5e2de29e52b767c7286d09eb669b))
* ALB target group names have a 32 char limit ([#128](https://github.com/eGainDev/analytics-infrastructure-live/issues/128)) ([f6f3682](https://github.com/eGainDev/analytics-infrastructure-live/commit/f6f36822bac6d7a3f838f2c2561405f0c677f697))

## [4.10.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.1...v4.10.2) (2024-10-17)

### Bug Fixes

* EMEA/APAC CIDR configuration ([6c3a659](https://github.com/eGainDev/analytics-infrastructure-live/commit/6c3a659ee2c02ce0e776fc2b7ff98d2c56192675))

## [4.10.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.10.0...v4.10.1) (2024-10-17)

### Bug Fixes

* AMI ids are regional - adding EMEA/APAC versions ([edb9473](https://github.com/eGainDev/analytics-infrastructure-live/commit/edb9473b28ea4545cdd50ee0d35a07938bacd157))

## [4.10.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.9.4...v4.10.0) (2024-10-16)

### Features

* EMEA/APAC environments - partial configured ([994fcac](https://github.com/eGainDev/analytics-infrastructure-live/commit/994fcace6a8feec7f5d7cae7f23d9e64a7a7c975))

### Bug Fixes

* prod OIDC client id ([4c0cc7b](https://github.com/eGainDev/analytics-infrastructure-live/commit/4c0cc7b5a90e210520de4668ee11c1b5ff2bc8cd))

## [4.9.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.9.3...v4.9.4) (2024-09-30)

### Bug Fixes

* vim-20707 Nifi instance IAM policy for cloudwatch:PutMetricData ([470eeed](https://github.com/eGainDev/analytics-infrastructure-live/commit/470eeed8a9598909b47bf208bcf1c2785c210f22))

## [4.9.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.9.2...v4.9.3) (2024-09-13)

### Bug Fixes

* initial_admin_identity is case sensitive ([03f51c4](https://github.com/eGainDev/analytics-infrastructure-live/commit/03f51c4dfd240f01801fa53a89d391738cfe0a85))

## [4.9.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.9.1...v4.9.2) (2024-09-12)

### Bug Fixes

* add the deployment caller as a kms administrator ([33a2eef](https://github.com/eGainDev/analytics-infrastructure-live/commit/33a2eeff786ac490971383b99f5e5fbbd65084e6))
* remove condition from IAM policy3 - EC2 actions ([b4c9d06](https://github.com/eGainDev/analytics-infrastructure-live/commit/b4c9d06466d4093befd05c1d007716bd8766fb7c))
* remove condition from IAM policy3 - route53 ([f4fae33](https://github.com/eGainDev/analytics-infrastructure-live/commit/f4fae33825c6dd3c14e824cc13d60f387342d06f))

## [4.9.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.9.0...v4.9.1) (2024-09-11)

### Bug Fixes

* QE1 oidc client application config ([bafd01d](https://github.com/eGainDev/analytics-infrastructure-live/commit/bafd01dcb768f11835e9b962a7297dbf3551e1e9))

## [4.9.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.8.0...v4.9.0) (2024-09-05)

### Features

* Terraform script to create Infra deployment roles/policies ([8c00112](https://github.com/eGainDev/analytics-infrastructure-live/commit/8c001123a89b085b0ace6c2db1073fc928539ca4))

## [4.8.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.7.6...v4.8.0) (2024-09-04)

### Features

* QE1 environment inital drop ([026421b](https://github.com/eGainDev/analytics-infrastructure-live/commit/026421bfeba17733a6712c7e05ea24f2da0ccaa2))

## [4.7.6](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.7.5...v4.7.6) (2024-09-02)

### Bug Fixes

* Adding tags to Route53 hosted zones ([f65704a](https://github.com/eGainDev/analytics-infrastructure-live/commit/f65704a74b9cf468d4dad9fc4e34bbab26f24d79))

## [4.7.5](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.7.4...v4.7.5) (2024-08-30)

### Bug Fixes

* Tenant Provisioner IAM role & error handling ([c9276bd](https://github.com/eGainDev/analytics-infrastructure-live/commit/c9276bd1eb6ca1c1e1539f2e3179a102bd9a3b46))

## [4.7.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.7.3...v4.7.4) (2024-08-30)

### Bug Fixes

* Lambda kms iam permissions ([ff7306e](https://github.com/eGainDev/analytics-infrastructure-live/commit/ff7306e294b9deefc1d593fcaeddefe0f573ad8a))

## [4.7.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.7.2...v4.7.3) (2024-08-29)

### Bug Fixes

* increase lambda TF timeouts ([2d9a63f](https://github.com/eGainDev/analytics-infrastructure-live/commit/2d9a63f65126c9e973e0d20c277121eed8493ee5))

## [4.7.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.7.1...v4.7.2) (2024-08-29)

### Bug Fixes

* Using role arn instead of deployment id ([8d0cbb5](https://github.com/eGainDev/analytics-infrastructure-live/commit/8d0cbb5aac88fe8fd6bcf65d415f4df4cfddccae))

## [4.7.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.7.0...v4.7.1) (2024-08-29)

### Bug Fixes

* QA, Rigel & Prod environment updates ([3436375](https://github.com/eGainDev/analytics-infrastructure-live/commit/3436375843214217e7da6c3ef7a70440e1ce9217))

## [4.7.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.5...v4.7.0) (2024-08-29)

### Features

* Redshift cross-account secret access ([192eb34](https://github.com/eGainDev/analytics-infrastructure-live/commit/192eb34e10274579e3cd9bcbab58fd3d20e16603))

## [4.6.5](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.4...v4.6.5) (2024-08-28)

### Bug Fixes

* Use KMS key for Redshift secrets ([75440ef](https://github.com/eGainDev/analytics-infrastructure-live/commit/75440ef40ac8cb8fa1241608a6f894a733907cbd))

## [4.6.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.3...v4.6.4) (2024-08-23)

### Bug Fixes

* Secrets Tags case sensitive naming ([b27f2e3](https://github.com/eGainDev/analytics-infrastructure-live/commit/b27f2e381386aa8cd9ac7f6c4a6db5295438b3c2))

## [4.6.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.2...v4.6.3) (2024-08-19)

### Bug Fixes

* commerial cloud production environment ([1d83b3b](https://github.com/eGainDev/analytics-infrastructure-live/commit/1d83b3bfc60eea4a652bce189ece9f6d0d1ab40f))
* lock files for commerial prod environment ([17dccad](https://github.com/eGainDev/analytics-infrastructure-live/commit/17dccadfd4e1ecc96f8ae284d5cdcd046d4e5c01))
* lock files for non-prod environments ([f67a055](https://github.com/eGainDev/analytics-infrastructure-live/commit/f67a0558a62d0e1c910d5fcfa7e920f0dffcbac3))
* Redshift database named master ([972ca18](https://github.com/eGainDev/analytics-infrastructure-live/commit/972ca18bc388948d6e761ab063013d32cbf37a41))

## [4.6.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.1...v4.6.2) (2024-08-14)

### Bug Fixes

* adding provisioner to qa & k2 environments ([9e68b86](https://github.com/eGainDev/analytics-infrastructure-live/commit/9e68b86587c480f205c699e9373782f8523ef8b5))

## [4.6.2-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.1...v4.6.2-beta.1) (2024-08-14)

### Bug Fixes

* adding provisioner to qa & k2 environments ([9e68b86](https://github.com/eGainDev/analytics-infrastructure-live/commit/9e68b86587c480f205c699e9373782f8523ef8b5))

## [4.6.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.0...v4.6.1) (2024-08-13)

### Bug Fixes

* Lambda IAM policy updates ([40bd86c](https://github.com/eGainDev/analytics-infrastructure-live/commit/40bd86cf3a054e90e5641fe895cbb0c9908778d3))
* Lambda policy updates ([#104](https://github.com/eGainDev/analytics-infrastructure-live/issues/104)) ([c3a19c3](https://github.com/eGainDev/analytics-infrastructure-live/commit/c3a19c331591d10f6e797776fe2bb5615483568c))

## [4.6.1-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.0...v4.6.1-beta.1) (2024-08-13)

### Bug Fixes

* Lambda IAM policy updates ([40bd86c](https://github.com/eGainDev/analytics-infrastructure-live/commit/40bd86cf3a054e90e5641fe895cbb0c9908778d3))

## [4.6.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.5.1...v4.6.0) (2024-08-13)

### Features

* Merge pull request [#103](https://github.com/eGainDev/analytics-infrastructure-live/issues/103) from eGainDev/beta ([49b79ca](https://github.com/eGainDev/analytics-infrastructure-live/commit/49b79ca104b0707870d647f709b0f9c71bd458d2))
* Tenant Provisioner ([56dada5](https://github.com/eGainDev/analytics-infrastructure-live/commit/56dada5f9e55e406cc04347873d11a6640a473d1))
* Tenant Provisioner for dev environment ([662a59f](https://github.com/eGainDev/analytics-infrastructure-live/commit/662a59f89a585e75f8d74c8750c5e219ea4e7296))
* Tenant Provisioner for DEV environment ([4f8c6e0](https://github.com/eGainDev/analytics-infrastructure-live/commit/4f8c6e0893ed4f3f1903cee7811e0ac84301ed04))
* Tenant Provisioner for DEV environment ([cb33bf3](https://github.com/eGainDev/analytics-infrastructure-live/commit/cb33bf3e468983b331f46e02e99e85652d629006))
* Tenant Provisioning Lambda ([d6408e2](https://github.com/eGainDev/analytics-infrastructure-live/commit/d6408e22dba0d503c44442949499ef12e81abdbe))
* VPC peering between ETL and RPT ([851bdbf](https://github.com/eGainDev/analytics-infrastructure-live/commit/851bdbf04bb981e310365e00c8a9ecd1f4cbac1e))

### Bug Fixes

* adding some defaults to reduce drift on terraform plan ([2dd1ac4](https://github.com/eGainDev/analytics-infrastructure-live/commit/2dd1ac4c0e7a8329e32d6e484be3a6585bc5d926))
* more terraform errors with syntax ([622cdff](https://github.com/eGainDev/analytics-infrastructure-live/commit/622cdfff7418dc7fff88a32475d0b38231b11e38))
* provisioning lambda IAM policy update ([73b6adc](https://github.com/eGainDev/analytics-infrastructure-live/commit/73b6adc79c78630219cbeaac4668ef1f2ce614bb))
* QA automation updates ([87742ee](https://github.com/eGainDev/analytics-infrastructure-live/commit/87742ee475f50ee6462525406c1af028139b8ec7))
* terraform apply on 8 core runner ([b9377fd](https://github.com/eGainDev/analytics-infrastructure-live/commit/b9377fd63c5742ee383f5e4435f560581e03f6d3))
* terraform syntax errors ([3e90982](https://github.com/eGainDev/analytics-infrastructure-live/commit/3e9098281bff314f2688a42b4849192764ba9e45))
* upgrade terrafrom/terragrunt versions ([0ae2646](https://github.com/eGainDev/analytics-infrastructure-live/commit/0ae26464daf7d1b4ad1cfd5180464aeeb202306c))

## [4.6.0-beta.6](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.0-beta.5...v4.6.0-beta.6) (2024-08-13)

### Features

* Tenant Provisioner for DEV environment ([4f8c6e0](https://github.com/eGainDev/analytics-infrastructure-live/commit/4f8c6e0893ed4f3f1903cee7811e0ac84301ed04))

## [4.6.0-beta.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.0-beta.3...v4.6.0-beta.4) (2024-08-13)

### Features

* Tenant Provisioner for DEV environment ([cb33bf3](https://github.com/eGainDev/analytics-infrastructure-live/commit/cb33bf3e468983b331f46e02e99e85652d629006))

## [4.6.0-beta.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.0-beta.2...v4.6.0-beta.3) (2024-08-13)

### Features

* Tenant Provisioner for dev environment ([662a59f](https://github.com/eGainDev/analytics-infrastructure-live/commit/662a59f89a585e75f8d74c8750c5e219ea4e7296))

## [4.6.0-beta.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.6.0-beta.1...v4.6.0-beta.2) (2024-08-09)

### Bug Fixes

* QA automation updates ([87742ee](https://github.com/eGainDev/analytics-infrastructure-live/commit/87742ee475f50ee6462525406c1af028139b8ec7))

## [4.6.0-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.5.1...v4.6.0-beta.1) (2024-08-09)

### Features

* Tenant Provisioning Lambda ([d6408e2](https://github.com/eGainDev/analytics-infrastructure-live/commit/d6408e22dba0d503c44442949499ef12e81abdbe))
* VPC peering between ETL and RPT ([851bdbf](https://github.com/eGainDev/analytics-infrastructure-live/commit/851bdbf04bb981e310365e00c8a9ecd1f4cbac1e))

### Bug Fixes

* adding some defaults to reduce drift on terraform plan ([2dd1ac4](https://github.com/eGainDev/analytics-infrastructure-live/commit/2dd1ac4c0e7a8329e32d6e484be3a6585bc5d926))
* more terraform errors with syntax ([622cdff](https://github.com/eGainDev/analytics-infrastructure-live/commit/622cdfff7418dc7fff88a32475d0b38231b11e38))
* provisioning lambda IAM policy update ([73b6adc](https://github.com/eGainDev/analytics-infrastructure-live/commit/73b6adc79c78630219cbeaac4668ef1f2ce614bb))
* terraform apply on 8 core runner ([b9377fd](https://github.com/eGainDev/analytics-infrastructure-live/commit/b9377fd63c5742ee383f5e4435f560581e03f6d3))
* terraform syntax errors ([3e90982](https://github.com/eGainDev/analytics-infrastructure-live/commit/3e9098281bff314f2688a42b4849192764ba9e45))
* upgrade terrafrom/terragrunt versions ([0ae2646](https://github.com/eGainDev/analytics-infrastructure-live/commit/0ae26464daf7d1b4ad1cfd5180464aeeb202306c))

## [4.5.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.5.0...v4.5.1) (2024-08-09)

### Bug Fixes

* larger runner ([#99](https://github.com/eGainDev/analytics-infrastructure-live/issues/99)) ([28ee40a](https://github.com/eGainDev/analytics-infrastructure-live/commit/28ee40a2ae892bbd975d47b2f70d6309568e140b))

## [4.5.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.4.0...v4.5.0) (2024-08-09)

### Features

* redshift serverless cluster automation for k2 ([a1f5b73](https://github.com/eGainDev/analytics-infrastructure-live/commit/a1f5b73e8f2e93c9cf5fa9591764abc54914f180))

## [4.4.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.6...v4.4.0) (2024-07-29)

### Features

* Reporting VPC and Redshift Serverless cluster ([d30e113](https://github.com/eGainDev/analytics-infrastructure-live/commit/d30e11369dfebf7271d0c1a055063d8d1f94c216))

### Bug Fixes

* Create a task role for Nifi to access S3 ([c18704a](https://github.com/eGainDev/analytics-infrastructure-live/commit/c18704a12f7f46b6603cd0809de83cfbb5d46b00))
* iam_role_arn naming ([70e6b82](https://github.com/eGainDev/analytics-infrastructure-live/commit/70e6b82066adc7c918ce7f05303aa8f09fd5dfb6))
* policy arn correction ([333df3c](https://github.com/eGainDev/analytics-infrastructure-live/commit/333df3c60cdc0a314fa216307577712e9b7593a5))
* Redshift role for S3 access ([840c0a8](https://github.com/eGainDev/analytics-infrastructure-live/commit/840c0a8996a05eca9d29bfff404b923475fb98b2))
* STG and QA stages ([034b007](https://github.com/eGainDev/analytics-infrastructure-live/commit/034b00748c88249399cdbaeebdea1e325d9db30c))

## [4.4.0-beta.5](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.4.0-beta.4...v4.4.0-beta.5) (2024-07-26)

### Bug Fixes

* iam_role_arn naming ([70e6b82](https://github.com/eGainDev/analytics-infrastructure-live/commit/70e6b82066adc7c918ce7f05303aa8f09fd5dfb6))

## [4.4.0-beta.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.4.0-beta.3...v4.4.0-beta.4) (2024-07-26)

### Bug Fixes

* policy arn correction ([333df3c](https://github.com/eGainDev/analytics-infrastructure-live/commit/333df3c60cdc0a314fa216307577712e9b7593a5))

## [4.4.0-beta.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.4.0-beta.2...v4.4.0-beta.3) (2024-07-26)

### Bug Fixes

* Redshift role for S3 access ([840c0a8](https://github.com/eGainDev/analytics-infrastructure-live/commit/840c0a8996a05eca9d29bfff404b923475fb98b2))

## [4.4.0-beta.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.4.0-beta.1...v4.4.0-beta.2) (2024-07-26)

### Bug Fixes

* STG and QA stages ([034b007](https://github.com/eGainDev/analytics-infrastructure-live/commit/034b00748c88249399cdbaeebdea1e325d9db30c))

## [4.4.0-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.7-beta.1...v4.4.0-beta.1) (2024-07-26)

### Features

* Reporting VPC and Redshift Serverless cluster ([d30e113](https://github.com/eGainDev/analytics-infrastructure-live/commit/d30e11369dfebf7271d0c1a055063d8d1f94c216))

## [4.3.7-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.6...v4.3.7-beta.1) (2024-07-25)

### Bug Fixes

* Create a task role for Nifi to access S3 ([c18704a](https://github.com/eGainDev/analytics-infrastructure-live/commit/c18704a12f7f46b6603cd0809de83cfbb5d46b00))

## [4.3.6](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.5...v4.3.6) (2024-07-18)

### Bug Fixes

* WEB_PROXY_HOST name changes for nifi ([85379b3](https://github.com/eGainDev/analytics-infrastructure-live/commit/85379b3138f8f93bf3b33c1e81667e44b595e2d8))
## [4.3.6-beta.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.6-beta.1...v4.3.6-beta.2) (2024-07-25)

### Bug Fixes

* Create a task role for Nifi to access S3 ([c18704a](https://github.com/eGainDev/analytics-infrastructure-live/commit/c18704a12f7f46b6603cd0809de83cfbb5d46b00))

## [4.3.6-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.5...v4.3.6-beta.1) (2024-07-18)

### Bug Fixes

* WEB_PROXY_HOST name changes for nifi ([85379b3](https://github.com/eGainDev/analytics-infrastructure-live/commit/85379b3138f8f93bf3b33c1e81667e44b595e2d8))

## [4.3.5](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.4...v4.3.5) (2024-07-16)

### Bug Fixes

* certificate name changes for k2 ([7fa7b70](https://github.com/eGainDev/analytics-infrastructure-live/commit/7fa7b70c9fb2c8ea8d5bce0bc4316f91c13124de))

## [4.3.5-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.4...v4.3.5-beta.1) (2024-07-16)

### Bug Fixes

* certificate name changes for k2 ([7fa7b70](https://github.com/eGainDev/analytics-infrastructure-live/commit/7fa7b70c9fb2c8ea8d5bce0bc4316f91c13124de))

## [4.3.4](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.3...v4.3.4) (2024-07-16)

### Bug Fixes

* using etl-environment as public hostname ([287c2a4](https://github.com/eGainDev/analytics-infrastructure-live/commit/287c2a44027c852950f4acb3c9242a3644aab3fc))
* using knowledge.ai hosted zone for k2 ([6297350](https://github.com/eGainDev/analytics-infrastructure-live/commit/62973500ed8a2c93166c6c6fc1023f1f70375ce1))

## [4.3.4-beta.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.4-beta.1...v4.3.4-beta.2) (2024-07-16)

### Bug Fixes

* using etl-environment as public hostname ([287c2a4](https://github.com/eGainDev/analytics-infrastructure-live/commit/287c2a44027c852950f4acb3c9242a3644aab3fc))

## [4.3.4-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.3...v4.3.4-beta.1) (2024-07-16)

### Bug Fixes

* using knowledge.ai hosted zone for k2 ([6297350](https://github.com/eGainDev/analytics-infrastructure-live/commit/62973500ed8a2c93166c6c6fc1023f1f70375ce1))

## [4.3.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.2...v4.3.3) (2024-07-12)

### Bug Fixes

* allow mocks during destroy ([7fa8ac9](https://github.com/eGainDev/analytics-infrastructure-live/commit/7fa8ac9ade9d16061b7ecbced78cfc3c8d1cfcb2))
* destroy plan issue ([b8a3f4c](https://github.com/eGainDev/analytics-infrastructure-live/commit/b8a3f4c17b26e11ad10ebd4322f1a37407964413))

## [4.3.3-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.2...v4.3.3-beta.1) (2024-07-12)

### Bug Fixes

* allow mocks during destroy ([7fa8ac9](https://github.com/eGainDev/analytics-infrastructure-live/commit/7fa8ac9ade9d16061b7ecbced78cfc3c8d1cfcb2))
* destroy plan issue ([b8a3f4c](https://github.com/eGainDev/analytics-infrastructure-live/commit/b8a3f4c17b26e11ad10ebd4322f1a37407964413))

## [4.3.1-beta.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.1-beta.2...v4.3.1-beta.3) (2024-07-10)

### Bug Fixes

* destroy plan issue ([b8a3f4c](https://github.com/eGainDev/analytics-infrastructure-live/commit/b8a3f4c17b26e11ad10ebd4322f1a37407964413))

## [4.3.1-beta.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.1-beta.1...v4.3.1-beta.2) (2024-07-10)

### Bug Fixes

* allow mocks during destroy ([7fa8ac9](https://github.com/eGainDev/analytics-infrastructure-live/commit/7fa8ac9ade9d16061b7ecbced78cfc3c8d1cfcb2))
## [4.3.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.1...v4.3.2) (2024-07-09)

### Bug Fixes

* Merge pull request [#92](https://github.com/eGainDev/analytics-infrastructure-live/issues/92) from eGainDev/beta ([b24662d](https://github.com/eGainDev/analytics-infrastructure-live/commit/b24662d5ac6ef1f5a9de022cb72325a97c024d2f))

## [4.3.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.0...v4.3.1) (2024-07-09)

### Bug Fixes

* downgrade to python 3.11 ([e8925e0](https://github.com/eGainDev/analytics-infrastructure-live/commit/e8925e0beb5303bb527d891af0f7eda608e607bc))

## [4.3.1-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.3.0...v4.3.1-beta.1) (2024-07-09)

### Bug Fixes

* downgrade to python 3.11 ([e8925e0](https://github.com/eGainDev/analytics-infrastructure-live/commit/e8925e0beb5303bb527d891af0f7eda608e607bc))

## [4.3.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.2.0...v4.3.0) (2024-07-08)

### Features

* ECR scan results are collected and attached to Release ([9608b75](https://github.com/eGainDev/analytics-infrastructure-live/commit/9608b75ec2c4e3174d632ad10b7cd52945e6c2a1))

### Bug Fixes

* naming convensions ([fc426fd](https://github.com/eGainDev/analytics-infrastructure-live/commit/fc426fde5b493dcd2eb9ea26a7ac8da717192894))

## [4.3.0-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.2.0...v4.3.0-beta.1) (2024-07-08)

### Features

* ECR scan results are collected and attached to Release ([9608b75](https://github.com/eGainDev/analytics-infrastructure-live/commit/9608b75ec2c4e3174d632ad10b7cd52945e6c2a1))

### Bug Fixes

* naming convensions ([fc426fd](https://github.com/eGainDev/analytics-infrastructure-live/commit/fc426fde5b493dcd2eb9ea26a7ac8da717192894))

## [4.2.0-beta.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.2.0-beta.1...v4.2.0-beta.2) (2024-07-08)

### Features

* ECR scan results are collected and attached to Release ([9608b75](https://github.com/eGainDev/analytics-infrastructure-live/commit/9608b75ec2c4e3174d632ad10b7cd52945e6c2a1))

### Bug Fixes

* naming convensions ([fc426fd](https://github.com/eGainDev/analytics-infrastructure-live/commit/fc426fde5b493dcd2eb9ea26a7ac8da717192894))

## [4.2.0](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.1.0...v4.2.0) (2024-07-03)


### Features

* Build rigel configuration ([#84](https://github.com/eGainDev/analytics-infrastructure-live/issues/84)) ([577a078](https://github.com/eGainDev/analytics-infrastructure-live/commit/577a078741fa29319ac7703875552106880a4518))
* Build rigel configuration 2 ([#85](https://github.com/eGainDev/analytics-infrastructure-live/issues/85)) ([c5cac41](https://github.com/eGainDev/analytics-infrastructure-live/commit/c5cac41a3daefde09f91fdbc8cd08dfddf0ce7ef))
* testing with scott ([c48835d](https://github.com/eGainDev/analytics-infrastructure-live/commit/c48835dbadc6abc900e73607a0357d252028b4e7))


### Bug Fixes

* adding family name to service modules to be used for task def ([#73](https://github.com/eGainDev/analytics-infrastructure-live/issues/73)) ([4c431c2](https://github.com/eGainDev/analytics-infrastructure-live/commit/4c431c271126319b30fefe4b3e4e30f0ff2e042b))
* corrected local variable references ([#60](https://github.com/eGainDev/analytics-infrastructure-live/issues/60)) ([64e85dc](https://github.com/eGainDev/analytics-infrastructure-live/commit/64e85dc8f091bde753171453580ce69899dde67a))
* increasing cpu/mem to fill ec2 instance ([8adf67a](https://github.com/eGainDev/analytics-infrastructure-live/commit/8adf67a0d834ca1935f4fc577c681aba956a67fc))
* setting min size on asg ([#79](https://github.com/eGainDev/analytics-infrastructure-live/issues/79)) ([093a869](https://github.com/eGainDev/analytics-infrastructure-live/commit/093a8695b53b906f827c24c1913771da7edf47eb))
* updated QA oidc configuration ([#76](https://github.com/eGainDev/analytics-infrastructure-live/issues/76)) ([b535d8a](https://github.com/eGainDev/analytics-infrastructure-live/commit/b535d8afb948a37f1a060cef3348d52a9f8bc8f2))
* updating beta with version 4.1 ([c99cee2](https://github.com/eGainDev/analytics-infrastructure-live/commit/c99cee205e866f288b11df8d4eb57abf369e03d6))

## [4.2.0-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.1.1-beta.3...v4.2.0-beta.1) (2024-07-03)


### Features

* Build rigel configuration ([#84](https://github.com/eGainDev/analytics-infrastructure-live/issues/84)) ([577a078](https://github.com/eGainDev/analytics-infrastructure-live/commit/577a078741fa29319ac7703875552106880a4518))
* Build rigel configuration 2 ([#85](https://github.com/eGainDev/analytics-infrastructure-live/issues/85)) ([c5cac41](https://github.com/eGainDev/analytics-infrastructure-live/commit/c5cac41a3daefde09f91fdbc8cd08dfddf0ce7ef))
* testing with scott ([c48835d](https://github.com/eGainDev/analytics-infrastructure-live/commit/c48835dbadc6abc900e73607a0357d252028b4e7))


### Bug Fixes

* increasing cpu/mem to fill ec2 instance ([8adf67a](https://github.com/eGainDev/analytics-infrastructure-live/commit/8adf67a0d834ca1935f4fc577c681aba956a67fc))

### [4.1.1-beta.3](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.1.1-beta.2...v4.1.1-beta.3) (2024-07-01)


### Bug Fixes

* setting min size on asg ([#79](https://github.com/eGainDev/analytics-infrastructure-live/issues/79)) ([093a869](https://github.com/eGainDev/analytics-infrastructure-live/commit/093a8695b53b906f827c24c1913771da7edf47eb))

### [4.1.1-beta.2](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.1.1-beta.1...v4.1.1-beta.2) (2024-06-28)


### Bug Fixes

* updated QA oidc configuration ([#76](https://github.com/eGainDev/analytics-infrastructure-live/issues/76)) ([b535d8a](https://github.com/eGainDev/analytics-infrastructure-live/commit/b535d8afb948a37f1a060cef3348d52a9f8bc8f2))

### [4.1.1-beta.1](https://github.com/eGainDev/analytics-infrastructure-live/compare/v4.1.0...v4.1.1-beta.1) (2024-06-27)


### Bug Fixes

* adding family name to service modules to be used for task def ([#73](https://github.com/eGainDev/analytics-infrastructure-live/issues/73)) ([4c431c2](https://github.com/eGainDev/analytics-infrastructure-live/commit/4c431c271126319b30fefe4b3e4e30f0ff2e042b))
* corrected local variable references ([#60](https://github.com/eGainDev/analytics-infrastructure-live/issues/60)) ([64e85dc](https://github.com/eGainDev/analytics-infrastructure-live/commit/64e85dc8f091bde753171453580ce69899dde67a))
* updating beta with version 4.1 ([c99cee2](https://github.com/eGainDev/analytics-infrastructure-live/commit/c99cee205e866f288b11df8d4eb57abf369e03d6))
