# Generating CA certificates for Nifi

Nifi uses a CA certificate to create and issue individual certificates to each node in the cluster. We must provide the
CA certificate to each node during its startup. The identical CA certificate must be used on all nodes.

The nifi-cert.pem and nifi-key.key files should be ASCII-armored (Base64-encoded ASCII) files containing the CA public certificate and private key respectively.

 1. Generate the private key

```
openssl genpkey -algorithm RSA -out nifi-key.key
```

2. Generate the public key

```
openssl req -new -x509 -key nifi-key.key -sha256 -days 3650 -out nifi-cert.pem -subj "/CN=localhost"
```
