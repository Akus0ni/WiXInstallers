# SSH Config

If using Putty, you need to convert the PEM files to PPK

## Putty (Windows)
1. Download Putty and puttygen
1. Use puttygen to convert .PEM file to .PPK file.
1.Start puttygen and select “Load”
1.Select your .PEM file.
1.Putty will convert the .PEM format to .PPK format.
1.Select “Save Private Key” A passphrase is not required but can be used if additional security is required.


## EC2 Connect

Get the ec2 instance ids

goto ecs cluster
goto infrastrure
under container instances you will see our ec2 instances listed
copy the ids - you should have 7 in total

e.g. i-0ec3980edb8768eb3 etc...

![](images/ssh/ec2_instances.png)

Open Putty
Create a session for each one for future use

hostname = ec2-user@[instance_id]
example, ec2-user@i-0ec3980edb8768eb3
port 22

![alt text](images/ssh/putty.png)

under Connection/SSH/Auth/Credentials settings, add your private key. The PPK file which you converted at the top of this document

![alt text](images/ssh/private_key.png)

Now setup the EC2 Connect tunnel to allow us access to our private subnets

under Connection/Proxy
enter the following command:

```
aws ec2-instance-connect open-tunnel --instance-id %host --profile [aws_profile]
```

where [aws_profile] is the name of your AWS credentials profile.

![alt text](images/ssh/tunnel.png)

Save this session. And repeat for all the EC2 instance IDs.


You should now be able to connect

![alt text](images/ssh/connect.png)


# WinSCP

## Import your sites from Putty


Note: you might also want to setup SSH & SFTP to use `sudo`

SFTP is `/usr/libexec/openssh/sftp-server` for Amazon Linux AMI

![alt text](images/ssh/shell.png)
![alt text](images/ssh/sudo.png)
