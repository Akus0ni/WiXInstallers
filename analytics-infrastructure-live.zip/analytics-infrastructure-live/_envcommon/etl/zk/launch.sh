Content-Type: multipart/mixed; boundary="//"
MIME-Version: 1.0

--//
Content-Type: text/cloud-config; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="cloud-config.txt"

#cloud-config
cloud_final_modules:
- [scripts-user, always]

--//
Content-Type: text/x-shellscript; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="userdata.txt"

#!/bin/bash
echo "Running user-data"

echo "join the ECS cluster"
cat <<'EOF' >> /etc/ecs/ecs.config
ECS_CLUSTER=${ecs_cluster_id}
ECS_INSTANCE_ATTRIBUTES={"instance_type": "zookeeper"}
ECS_CONTAINER_STOP_TIMEOUT=2
EOF

TOKEN=`curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 120"`

echo "getting availablity zone"
abzone=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone) # editorconfig-checker-disable-line
echo $abzone
echo "getting instance id"
instanceid=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id)
echo $instanceid

nifi_data="/zookeeper_data"

echo "create mount point root at $nifi_data"
[ -d $nifi_data ] || mkdir $nifi_data

mountVolume() {
    echo "getting available ebs volume-id for $1 in $2"
    ebsvolume=$(aws ec2 describe-volumes --filters Name=tag-key,Values=$1 Name=availability-zone,Values=`echo $2` Name=tag:Environment,Values=${environment} --query 'Volumes[*].[VolumeId, State==`available`]' --output text  | grep True | awk '{print $1}' | head -n 1) # editorconfig-checker-disable-line
    echo $ebsvolume

    if [ -n "$ebsvolume" ]; then
    echo "attaching ebs $ebsvolume to $3"
    aws ec2 attach-volume --volume-id `echo $ebsvolume` --instance-id `echo $instanceid` --device $3

    echo "wait for volumes to attach"
    sleep 10

    # Check if the block device has a filesystem
    if file -sL $3 | grep -q "filesystem"; then
      echo "Filesystem already exists on $3"
    else
      echo "No filesystem detected on $3, creating one..."

      # Example: Creating an xfs filesystem
      mkfs -t xfs $3

      echo "Filesystem created on $3"
    fi

    echo "create mount points"
    [ -d $4 ] || mkdir $4

    echo "mount ebs $3 on $4"
    mount $3 $4
    fi
}

#           tags-value            zone    device     mount
mountVolume "zookeeper_data"      $abzone "/dev/${device_id_prefix}df" "$nifi_data/data"
mountVolume "zookeeper_datalog"   $abzone "/dev/${device_id_prefix}dg" "$nifi_data/datalog"
mountVolume "zookeeper_logs"      $abzone "/dev/${device_id_prefix}dh" "$nifi_data/logs"
mountVolume "zookeeper_conf"      $abzone "/dev/${device_id_prefix}di" "$nifi_data/conf"

echo "set permissions at $nifi_data"
chown -R ec2-user:ec2-user $nifi_data

echo "Done user-data"
--//--
