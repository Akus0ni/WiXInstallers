#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Exony.Database.ClusterConfiguration.ChangeRequests;
    using Exony.Database.ClusterConfiguration.ChangeRequests.Add;
    using Exony.Database.ClusterConfiguration.ChangeRequests.Remove;
    using Exony.Database.ClusterConfiguration.ChangeRequests.SetProperty;

    /// <summary>
    /// Manages changes made to a cluster configuration model
    /// </summary>
    public class ClusterConfigurationChangeManager
    {
        #region Delegates

        /// <summary>
        /// Event delegate for change request events
        /// </summary>
        public delegate void ClusterChangeRequestEvent(object sender, IClusterChangeRequest request);

        /// <summary>
        /// Event delegate for change events
        /// </summary>
        public delegate void ClusterChangeEvent(object sender);

        /// <summary>
        /// Delegate for committing changes
        /// </summary>
        public delegate void CommitChangesDelegate(IEnumerable<IClusterChangeRequest> requests);

        #endregion

        #region Events

        /// <summary>
        /// Fired when a change is added to this manager
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ClusterChangeRequestEvent ChangeAdded;

        /// <summary>
        /// Fired when a change is removed from this manager
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ClusterChangeRequestEvent ChangeRemoved;

        /// <summary>
        /// Fired when all changes are purged
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ClusterChangeEvent Purged;

        #endregion

        #region Fields

        /// <summary>
        /// The cluster configuration model being managed
        /// </summary>
        private readonly ClusterConfiguration model;

        /// <summary>
        /// The changes that are pending on this hierarchy
        /// </summary>
        private readonly Stack<ChangeRequestHarness> pendingChanges = new Stack<ChangeRequestHarness>();

        /// <summary>
        /// The changes that have been undone (for redo)
        /// </summary>
        private readonly Stack<ChangeRequestHarness> redoStack = new Stack<ChangeRequestHarness>();

        /// <summary>
        /// Keep a reference to removed items for revert
        /// </summary>
        private readonly IDictionary<Guid, IClusterObject> removedResources = new Dictionary<Guid, IClusterObject>();

        /// <summary>
        /// Indicates if transient field changes should be tracked
        /// </summary>
        private readonly bool trackTransientFieldChanges;

        /// <summary>
        /// Are we reverting?
        /// </summary>
        private bool reverting;

        /// <summary>
        /// Are we suspended?
        /// </summary>
        private bool suspended;

        /// <summary>
        /// Has this object been closed
        /// </summary>
        private bool closed;

        /// <summary>
        /// Count of non-transient changes
        /// </summary>
        private int nonTransientChangeCount;

        /// <summary>
        /// The current checkpoint number
        /// </summary>
        private int currentCheckpointNumber;

        #endregion

        #region Construction

        /// <summary>
        /// Create a cluster configuration change manager for the specified model
        /// </summary>
        public ClusterConfigurationChangeManager(ClusterConfiguration model, bool trackTransientFieldChanges = true)
        {
            this.model = model;
            this.trackTransientFieldChanges = trackTransientFieldChanges;
            this.model.ItemPropertyChangedEvent += model_ItemPropertyChanged;
            this.model.ItemAdded += model_ItemAdded;
            this.model.ItemRemoved += model_ItemRemoved;
        }

        #endregion

        #region Properties

        /// <summary>
        /// The count of pending changes on this manager
        /// </summary>
        public int ChangeRequestCount
        {
            get
            {
                return this.pendingChanges.Count;
            }
        }

        /// <summary>
        /// The count of changes that can be reapplied
        /// </summary>
        public int RedoRequestCount
        {
            get
            {
                return this.redoStack.Count;
            }
        }

        /// <summary>
        /// Count of non-transient changes
        /// </summary>
        public int NonTransientChangeCount
        {
            get { return this.nonTransientChangeCount; }
        }

        /// <summary>
        /// The current checkpoint number
        /// </summary>
        public int CurrentCheckpointNumber
        {
            get { return this.currentCheckpointNumber; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Release event handlers from this instance
        /// </summary>
        public void Close()
        {
            CheckDisposed();

            this.model.ItemPropertyChangedEvent -= model_ItemPropertyChanged;
            this.model.ItemAdded -= model_ItemAdded;
            this.model.ItemRemoved -= model_ItemRemoved;

            this.closed = true;
        }

        /// <summary>
        /// Validate object state
        /// </summary>
        private void CheckDisposed()
        {
            if (this.closed)
            {
                throw new ObjectDisposedException("Object has been closed!");
            }
        }

        /// <summary>
        /// Write current change requests back to the database
        /// </summary>
        public void SaveChanges(CommitChangesDelegate callback)
        {
            CheckDisposed();

            callback(this.pendingChanges.Reverse().Select(p => p.Request));

            // All changes have now been applied so clear list
            this.pendingChanges.Clear();
            this.redoStack.Clear();
        }

        /// <summary>
        /// Redo undone changes
        /// </summary>
        public void RedoChanges()
        {
            RedoChanges(Int32.MaxValue);
        }

        /// <summary>
        /// Redo the specified number of undone changes
        /// </summary>
        /// <param name="count">The number of changes to redo</param>
        public void RedoChanges(int count)
        {
            CheckDisposed();

            for (int i = 0; i < count; i++)
            {
                if (this.redoStack.Count <= 0)
                {
                    break;
                }

                IClusterChangeRequest request = this.redoStack.Pop().Request;

                // Redo will automatically refire model events and repopulate pending change list
                request.ApplyChange(this.model);
            }
        }

        /// <summary>
        /// Purge changes
        /// </summary>
        public void PurgeChanges()
        {
            UndoChanges(Int32.MaxValue);
            this.pendingChanges.Clear();
            this.redoStack.Clear();
            this.removedResources.Clear();

            if (this.Purged != null)
            {
                this.Purged(this);
            }
        }

        /// <summary>
        /// Revert all changes created since this change manager was activated
        /// </summary>
        public void UndoChanges()
        {
            UndoChanges(Int32.MaxValue);
        }

        /// <summary>
        /// Revert the specified number of changes
        /// </summary>
        /// <param name="count">The number of changes to revert</param>
        public void UndoChanges(int count)
        {
            CheckDisposed();

            this.reverting = true;

            try
            {
                for (int i = 0; i < count; i++)
                {
                    if (this.pendingChanges.Count <= 0)
                    {
                        break;
                    }

                    IClusterChangeRequest request = this.pendingChanges.Pop().Request;

                    request.RevertChange(this.model);

                    if (request is SetPropertyChangeRequest)
                    {
                        SetPropertyChangeRequest spcr = (SetPropertyChangeRequest)request;

                        if (!spcr.Transient)
                        {
                            this.nonTransientChangeCount--;
                        }
                    }

                    this.redoStack.Push(new ChangeRequestHarness(request, this.currentCheckpointNumber));
                    FireChangeRemoved(request);
                }
            }
            finally
            {
                this.reverting = false;
            }
        }

        /// <summary>
        /// Suspend change tracking
        /// </summary>
        public void Suspend()
        {
            this.suspended = true;
        }

        /// <summary>
        /// Resume change tracking
        /// </summary>
        public void Resume()
        {
            this.suspended = false;
        }

        #endregion

        #region Event Firing

        /// <summary>
        /// Fire a change added event to any listeners
        /// </summary>
        private void FireChangeAdded(IClusterChangeRequest request)
        {
            if (this.ChangeAdded != null)
            {
                this.ChangeAdded(this, request);
            }
        }

        /// <summary>
        /// Fire a change removed event to any listeners
        /// </summary>
        private void FireChangeRemoved(IClusterChangeRequest request)
        {
            if (this.ChangeRemoved != null)
            {
                this.ChangeRemoved(this, request);
            }
        }

        #endregion

        #region Event Handling

        /// <summary>
        /// Invoked when a property is changed on any of the items in the model
        /// </summary>
        private void model_ItemPropertyChanged(object sender, IClusterObject source, string propertyName, object oldValue, object newValue)
        {
            // Ignore events whilst reverting changes
            if (this.reverting || this.suspended)
            {
                return;
            }

            ClusterFieldAttribute cfa = AttributeHelper.GetPropertyLevelAttribute<ClusterFieldAttribute>(source, propertyName);

            // We aren't interested in non-state changes as the persistance managers don't require them
            if (cfa == null)
            {
                return;
            }

            // Don't record updates that don't change anything
            if (Equals(oldValue, newValue))
            {
                return;
            }

            // Currently don't support undo/redo for object references
            if (oldValue != null &&
                !(oldValue.GetType().IsValueType || oldValue.GetType().Equals(typeof(string))))
            {
                return;
            }

            if (newValue != null &&
                !(newValue.GetType().IsValueType || newValue.GetType().Equals(typeof(string))))
            {
                return;
            }

            SetPropertyChangeRequest request;

            if (source is ILogicalResource)
            {
                request = new SetLogicalResourcePropertyChangeRequest((ILogicalResource)source, propertyName, oldValue, newValue);
            }
            else if (source is IPhysicalConnection)
            {
                request = new SetPhysicalConnectionPropertyChangeRequest((IPhysicalConnection)source, propertyName, oldValue, newValue);
            }
            else if (source is IPhysicalConnectionStatus)
            {
                request = new SetPhysicalConnectionStatusPropertyChangeRequest((IPhysicalConnectionStatus)source, propertyName, oldValue, newValue);
            }
            else if (source is IPhysicalResource)
            {
                request = new SetPhysicalResourcePropertyChangeRequest((IPhysicalResource)source, propertyName, oldValue, newValue);
            }
            else if (source is IPhysicalResourceComponent)
            {
                request = new SetPhysicalResourceComponentPropertyChangeRequest((IPhysicalResourceComponent)source, propertyName, oldValue, newValue);
            }
            else if (source is IPhysicalServer)
            {
                request = new SetPhysicalServerPropertyChangeRequest((IPhysicalServer)source, propertyName, oldValue, newValue);
            }
            else if (source is ILogicalResourceTypeGroup)
            {
                request = new SetLogicalResourceTypeGroupPropertyChangeRequest((ILogicalResourceTypeGroup)source, propertyName, oldValue, newValue);
            }
            else if (source is ILogicalResourceType)
            {
                request = new SetLogicalResourceTypePropertyChangeRequest((ILogicalResourceType)source, propertyName, oldValue, newValue);
            }
            else if (source is IPhysicalConnectionType)
            {
                request = new SetPhysicalConnectionTypePropertyChangeRequest((IPhysicalConnectionType)source, propertyName, oldValue, newValue);
            }
            else if (source is IPhysicalResourceComponentType)
            {
                request = new SetPhysicalResourceComponentTypePropertyChangeRequest((IPhysicalResourceComponentType)source, propertyName, oldValue, newValue);
            }
            else if (source is ILogicalResourceFolderMapping)
            {
                request = new SetLogicalResourceFolderMappingPropertyChangeRequest((ILogicalResourceFolderMapping)source, propertyName, oldValue, newValue);
            }
            else if (source is ILogicalResourceFolderItemMapping)
            {
                request = new SetLogicalResourceFolderItemMappingPropertyChangeRequest((ILogicalResourceFolderItemMapping)source, propertyName, oldValue, newValue);
            }
            else if (source is ILogicalResourceEntityTypeMapping)
            {
                request = new SetLogicalResourceEntityTypeMappingPropertyChangeRequest((ILogicalResourceEntityTypeMapping)source, propertyName, oldValue, newValue);
            }
            else if (source is ILogicalResourceMember)
            {
                request = new SetLogicalResourceMemberPropertyChangeRequest((ILogicalResourceMember)source, propertyName, oldValue, newValue);
            }
            else
            {
                throw new ApplicationException("Unsupported cluster object type detected");
            }

            if (!request.Transient)
            {
                this.nonTransientChangeCount++;
            }

            // If we are not tracking transient changes and this is one then just ignore
            if (request.Transient && !this.trackTransientFieldChanges)
            {
                return;
            }

            this.pendingChanges.Push(new ChangeRequestHarness(request, this.currentCheckpointNumber));
            FireChangeAdded(request);
        }

        /// <summary>
        /// Invoked when an item is removed from the model
        /// </summary>
        private void model_ItemRemoved(object sender, IClusterObject item)
        {
            // Ignore events whilst reverting changes
            if (this.reverting || this.suspended)
            {
                return;
            }

            IClusterChangeRequest request;

            if (item is ILogicalResource)
            {
                request = new RemoveLogicalResourceChangeRequest((ILogicalResource)item);
            }
            else if (item is IPhysicalConnection)
            {
                request = new RemovePhysicalConnectionChangeRequest((IPhysicalConnection)item);
            }
            else if (item is IPhysicalResource)
            {
                request = new RemovePhysicalResourceChangeRequest((IPhysicalResource)item);
            }
            else if (item is IPhysicalResourceComponent)
            {
                request = new RemovePhysicalResourceComponentChangeRequest((IPhysicalResourceComponent)item);
            }
            else if (item is IPhysicalServer)
            {
                request = new RemovePhysicalServerChangeRequest((IPhysicalServer)item);
            }
            else if (item is ILogicalResourceTypeGroup)
            {
                request = new RemoveLogicalResourceTypeGroupChangeRequest((ILogicalResourceTypeGroup)item);
            }
            else if (item is ILogicalResourceType)
            {
                request = new RemoveLogicalResourceTypeChangeRequest((ILogicalResourceType)item);
            }
            else if (item is IPhysicalConnectionType)
            {
                request = new RemovePhysicalConnectionTypeChangeRequest((IPhysicalConnectionType)item);
            }
            else if (item is IPhysicalResourceComponentType)
            {
                request = new RemovePhysicalResourceComponentTypeChangeRequest((IPhysicalResourceComponentType)item);
            }
            else if (item is ILogicalResourceFolderMapping)
            {
                request = new RemoveLogicalResourceFolderMappingChangeRequest((ILogicalResourceFolderMapping)item);
            }
            else if (item is ILogicalResourceFolderItemMapping)
            {
                request = new RemoveLogicalResourceFolderItemMappingChangeRequest((ILogicalResourceFolderItemMapping)item);
            }
            else if (item is ILogicalResourceEntityTypeMapping)
            {
                request = new RemoveLogicalResourceEntityTypeMappingChangeRequest((ILogicalResourceEntityTypeMapping)item);
            }
            else if (item is ILogicalResourceMember)
            {
                request = new RemoveLogicalResourceMemberChangeRequest((ILogicalResourceMember)item);
            }
            else
            {
                throw new ApplicationException("Unsupported cluster object type detected");
            }

            this.nonTransientChangeCount++;
            this.pendingChanges.Push(new ChangeRequestHarness(request, this.currentCheckpointNumber));
            FireChangeAdded(request);
        }

        /// <summary>
        /// Invoked when an item is added to the model
        /// </summary>
        private void model_ItemAdded(object sender, IClusterObject item)
        {
            // Ignore events whilst reverting changes
            if (this.reverting || this.suspended)
            {
                return;
            }

            IClusterChangeRequest request;

            if (item is ILogicalResource)
            {
                request = new AddLogicalResourceChangeRequest((ILogicalResource)item);
            }
            else if (item is IPhysicalConnection)
            {
                request = new AddPhysicalConnectionChangeRequest((IPhysicalConnection)item);
            }
            else if (item is IPhysicalResource)
            {
                request = new AddPhysicalResourceChangeRequest((IPhysicalResource)item);
            }
            else if (item is IPhysicalResourceComponent)
            {
                request = new AddPhysicalResourceComponentChangeRequest((IPhysicalResourceComponent)item);
            }
            else if (item is IPhysicalServer)
            {
                request = new AddPhysicalServerChangeRequest((IPhysicalServer)item);
            }
            else if (item is ILogicalResourceTypeGroup)
            {
                request = new AddLogicalResourceTypeGroupChangeRequest((ILogicalResourceTypeGroup)item);
            }
            else if (item is ILogicalResourceType)
            {
                request = new AddLogicalResourceTypeChangeRequest((ILogicalResourceType)item);
            }
            else if (item is IPhysicalConnectionType)
            {
                request = new AddPhysicalConnectionTypeChangeRequest((IPhysicalConnectionType)item);
            }
            else if (item is IPhysicalResourceComponentType)
            {
                request = new AddPhysicalResourceComponentTypeChangeRequest((IPhysicalResourceComponentType)item);
            }
            else if (item is ILogicalResourceFolderMapping)
            {
                request = new AddLogicalResourceFolderMappingChangeRequest((ILogicalResourceFolderMapping)item);
            }
            else if (item is ILogicalResourceFolderItemMapping)
            {
                request = new AddLogicalResourceFolderItemMappingChangeRequest((ILogicalResourceFolderItemMapping)item);
            }
            else if (item is ILogicalResourceEntityTypeMapping)
            {
                request = new AddLogicalResourceEntityTypeMappingChangeRequest((ILogicalResourceEntityTypeMapping)item);
            }
            else if (item is ILogicalResourceMember)
            {
                request = new AddLogicalResourceMemberChangeRequest((ILogicalResourceMember)item);
            }
            else
            {
                throw new ApplicationException("Unsupported cluster object type detected");
            }

            this.nonTransientChangeCount++;
            this.pendingChanges.Push(new ChangeRequestHarness(request, this.currentCheckpointNumber));
            FireChangeAdded(request);
        }

        #endregion

        #region Checkpoint Support

        /// <summary>
        /// Create a checkpoint against the model
        /// </summary>
        public int CreateCheckpoint()
        {
            // No point creating a new checkpoint if nothinng has changed since the last one
            if (ChangeCountSinceLastCheckpoint <= 0)
            {
                return this.currentCheckpointNumber;
            }

            // Increment snapshot to next value
            this.currentCheckpointNumber = this.currentCheckpointNumber + 1;
            return this.currentCheckpointNumber;
        }

        /// <summary>
        /// Revert to the specified checkpoint
        /// </summary>
        public void RevertToCheckpoint(int checkpointNumber)
        {
            CheckDisposed();

            if (checkpointNumber > currentCheckpointNumber)
            {
                throw new ArgumentException("Checkpoint has already been reverted", "checkpointNumber");
            }

            if (checkpointNumber < 0)
            {
                throw new ArgumentException("Inavlid checkpoint number", "checkpointNumber");
            }

            this.reverting = true;

            try
            {
                if (this.pendingChanges.Count <= 0)
                {
                    return;
                }

                ChangeRequestHarness harness;

                // Loop round all changes that occurred after the specified snapshot was taken
                int maxPending = this.pendingChanges.Count;

                for (int i = 0; i < maxPending; i++)
                {
                    harness = this.pendingChanges.Peek();

                    // Have we undone everything back to the checkpoint
                    if (harness.CheckpointNumber < checkpointNumber)
                    {
                        break;
                    }

                    this.pendingChanges.Pop();

                    // Revert the change
                    harness.Request.RevertChange(this.model);

                    if (harness.Request is SetPropertyChangeRequest)
                    {
                        SetPropertyChangeRequest spcr = (SetPropertyChangeRequest)harness.Request;

                        if (!spcr.Transient)
                        {
                            this.nonTransientChangeCount--;
                        }
                    }

                    FireChangeRemoved(harness.Request);
                }

                // Purge any redo entries relating to changes after this checkpoint
                int maxRedo = this.redoStack.Count;

                for (int i = 0; i < maxRedo; i++)
                {
                    harness = this.redoStack.Peek();

                    // Have we undone everything back to the checkpoint
                    if (harness.CheckpointNumber < checkpointNumber)
                    {
                        break;
                    }

                    this.redoStack.Pop();
                }

                // Set the current checkpoint back
                this.currentCheckpointNumber = checkpointNumber;
            }
            finally
            {
                this.reverting = false;
            }
        }

        /// <summary>
        /// The number of changes since the last checkpoint
        /// </summary>
        public int ChangeCountSinceLastCheckpoint
        {
            get { return this.pendingChanges.Where(pc => pc.CheckpointNumber == this.currentCheckpointNumber).Count(); }
        }

        #endregion

        #region Inner Classes

        /// <summary>
        /// Represents a change request along with snapshot number
        /// </summary>
        private class ChangeRequestHarness
        {
            /// <summary>
            /// Default constructor
            /// </summary>
            public ChangeRequestHarness(IClusterChangeRequest request, int checkpointNumber)
            {
                this.Request = request;
                this.CheckpointNumber = checkpointNumber;
            }

            public IClusterChangeRequest Request { get; private set; }

            public int CheckpointNumber { get; private set; }
        }

        #endregion
    }
}
