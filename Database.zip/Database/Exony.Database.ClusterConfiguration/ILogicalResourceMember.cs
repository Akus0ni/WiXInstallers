#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    /// <summary>
    /// Interface for all logical resource member implementations
    /// </summary>
    public interface ILogicalResourceMember : IClusterObject
    {
        /// <summary>
        /// The parent resource
        /// </summary>
        ILogicalResource ParentResource { get; set; }

        /// <summary>
        /// The child resource
        /// </summary>
        ILogicalResource ChildResource { get; set; }
    }
}
