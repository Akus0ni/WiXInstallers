#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.ComponentModel;

    using Exony.Database.ClusterConfiguration.Icm;

    /// <summary>
    /// Represents the status of a connection from TB_CLU_CONNECTION_STATUS
    /// </summary>
    public enum ConnectionStatus
    {
        Unavailable = 'I',
        Available = 'A',
    }

    /// <summary>
    /// ICM Deployment types
    /// </summary>
    [Flags]
    public enum IcmDeploymentType
    {
        None = 0,

        // Core types
        Standard = 1 << 0,
        CCE = 1 << 1,
        PackagedCCELab2000 = CCE | 1 << 21, //CCE updated to this as of 11.5.
        HCS = 1 << 2,
        ICM = 1 << 3,
        NAM = 1 << 4, //Deprecated as of 11.5.
        UCCE = 1 << 5,
        IVRICM = 1 << 6,

        // Derived types
        HCS1000 = HCS | 1 << 7,
        HCS2000 = HCS1000 | 1 << 22, //HCS1000 updated to this as of 11.5.
        HCS500 = HCS | 1 << 8,
        ICMRogger = ICM | 1 << 9,
        ICMRouterLogger = ICM | 1 << 10,
        NAMRogger = NAM | 1 << 11,  //Deprecated as of 11.5.
        PackagedCCELab = CCE | 1 << 12,
        UCCE12000 = UCCE | 1 << 13,
        UCCE4000 = UCCE | 1 << 14,
        UCCE450 = UCCE | 1 << 15,
        UCCEPROGGER = UCCE450 | 1 << 23, //UCCE450 updated to this as of 11.5.
        UCCE8000 = UCCE | 1 << 16,
        HCS4000 = HCS | 1 << 17,
        HCS12000 = HCS | 1 << 18,
        UCCE24000 = UCCE | 1 << 19, // New in 12.0
        HCS24000 = HCS | 1 << 20, // New in 12.0
        UCCE2000 = UCCE | 1 << 24,
        PackagedCCE4000 = CCE | 1 << 25,
        PackagedCCE12000 = CCE | 1 << 26

    }

    /// <summary>
    /// ICM Deployment types
    /// </summary>
    [Flags]
    public enum EgainDeploymentType
    {
        NonIntegrated = 1,
        CCEIntegrated = 2,
        // ReSharper disable once InconsistentNaming
        CCXIntegrated = 3
    }

    /// <summary>
    /// The eGain product types
    /// </summary>
    [Flags]
    public enum EgainProductType
    {
        /// <summary>
        /// The standard
        /// </summary>
        Standard = 1,

        /// <summary>
        /// ECE
        /// </summary>
        EnterpriseChatEmail = 2,

        /// <summary>
        /// Splus
        /// </summary>
        Splus = 3
    }

    /// <summary>
    /// Unified Configuration Web Services requirement on the ICM.
    /// </summary>
    [Flags]
    public enum UnifiedConfigRequirement
    {
        No,
        Optional,
        Required
    }

    [Flags]
    public enum PasswordType
    {
        MD5 = 1,
        SHA256 = 2
    }

    /// <summary>
    /// Wrapper for basic equipment information
    /// </summary>
    [Serializable]
    public class DeploymentInformation
    {
        public DeploymentInformation()
        {
            IcmDeploymentType = IcmDeploymentType.None;
            Version = string.Empty;
            IcmType = string.Empty;
            IcmMode = 0;
        }

        public IcmDeploymentType IcmDeploymentType { get; set; }

        public string Version { get; set; }

        public string IcmType { get; set; }

        public int IcmMode { get; set; }
    }

    /// <summary>
    /// Collection of static methods for converting database status flags to typesafe enums
    /// </summary>
    public static class ClusterEnumTools
    {
        /// <summary>
        /// Converts a database STATUS flag from TB_CLU_CONNECTION_STATUS to a typesafe enum
        /// </summary>
        public static ConnectionStatus GetConnectionStatus(string status)
        {
            switch (status)
            {
                case "I":
                    return ConnectionStatus.Unavailable;
                case "A":
                    return ConnectionStatus.Available;
                default:
                    throw new ArgumentException("Specified connection status is invalid");
            }
        }

        /// <summary>
        /// Converts a ConnectionStatus enum to a datbase character
        /// </summary>
        public static string GetConnectionStatusString(ConnectionStatus status)
        {
            switch (status)
            {
                case ConnectionStatus.Unavailable:
                    return "I";
                case ConnectionStatus.Available:
                    return "A";
                default:
                    throw new ArgumentException("Specified connection status is invalid");
            }
        }

        /// <summary>
        /// Converts a database DeploymentType to a typesafe enum
        /// </summary>
        public static IcmDeploymentType GetDeploymentType(string deploymentTypeString)
        {
            if (string.IsNullOrEmpty(deploymentTypeString))
            {
                return IcmDeploymentType.None;
            }

            IcmDeploymentType type = (IcmDeploymentType)Enum.Parse(typeof(IcmDeploymentType), deploymentTypeString);

            return type;
        }

        /// <summary>
        /// Converts a database eGain DeploymentType to a typesafe enum
        /// </summary>
        public static EgainDeploymentType GetEgainDeploymentType(string deploymentTypeString)
        {
            if (string.IsNullOrEmpty(deploymentTypeString))
            {
                return EgainDeploymentType.NonIntegrated;
            }

            EgainDeploymentType type = (EgainDeploymentType)Enum.Parse(typeof(EgainDeploymentType), deploymentTypeString);

            return type;
        }

        /// <summary>
        /// Converts a database eGain ProductType to a typesafe enum
        /// </summary>
        public static EgainProductType GetEgainProductType(string productTypeString)
        {
            if (string.IsNullOrEmpty(productTypeString))
            {
                return EgainProductType.Standard;
            }

            EgainProductType type = (EgainProductType)Enum.Parse(typeof(EgainProductType), productTypeString);

            return type;
        }

        /// <summary>
        /// Converts a the deployment type ICM integer value retrieved via the web service to the enum.
        /// </summary>
        public static IcmDeploymentType GetDeploymentType(int deploymentTypeIcmValue, int icmMajorVersion, int icmMinorVersion)
        {
            IcmDeploymentType result;

            switch (deploymentTypeIcmValue)
            {
                case 1:
                    //Deprecated as of 11.5
                    result = IcmDeploymentType.NAM;
                    break;
                case 2:
                    //Contact Director
                    result = IcmDeploymentType.IVRICM;
                    break;
                case 3:
                    //Deprecated as of 11.5
                    result = IcmDeploymentType.NAMRogger;
                    break;
                case 4:
                    result = IcmDeploymentType.ICMRouterLogger;
                    break;
                case 5:
                    result = IcmDeploymentType.UCCE8000;
                    break;
                case 6:
                    result = IcmDeploymentType.UCCE12000;
                    break;
                case 7:
                    //Packaged CCE: 2000 Agents
                    result = (icmMajorVersion >= 11 && icmMinorVersion >= 5) || icmMajorVersion >= 187 ? IcmDeploymentType.PackagedCCELab2000 : IcmDeploymentType.CCE;
                    break;
                case 8:
                    result = IcmDeploymentType.ICMRogger;
                    break;
                case 9:
                    result = IcmDeploymentType.UCCE4000;
                    break;
                case 10:
                    result = IcmDeploymentType.PackagedCCELab;
                    break;
                case 11:
                    // HCS1000 has been deprecated for version above 11.5.
                    result = (icmMajorVersion >= 11 && icmMinorVersion >= 5) || icmMajorVersion >= 187 ? IcmDeploymentType.HCS2000 : IcmDeploymentType.HCS1000;
                    break;
                case 12:
                    //Deprecated as of 11.5
                    result = IcmDeploymentType.HCS500;
                    break;
                case 13:
                    // UCCE: Progger (Lab Only)
                    result = (icmMajorVersion >= 11 && icmMinorVersion >= 5) || icmMajorVersion >= 187 ? IcmDeploymentType.UCCEPROGGER : IcmDeploymentType.UCCE450;
                    break;
                case 14:
                    result = IcmDeploymentType.HCS4000;
                    break;
                case 15:
                    result = IcmDeploymentType.HCS12000;
                    break;
                case 16:
                    result = IcmDeploymentType.UCCE2000;
                    break;
                case 17:
                    result = IcmDeploymentType.PackagedCCE4000;
                    break;
                case 18:
                    result = IcmDeploymentType.PackagedCCE12000;
                    break;
                case 19: // New in 12.0
                    result = IcmDeploymentType.UCCE24000;
                    break;
                case 20: // New in 12.0
                    result = IcmDeploymentType.HCS24000;
                    break;
                default:
                    //0: No deployment type specified
                    result = IcmDeploymentType.Standard;
                    break;
            }

            return result;
        }

        /// <summary>
        /// Converts a DeploymentType enum to a database string
        /// </summary>
        public static string GetDeploymentTypeString(IcmDeploymentType deploymentType)
        {
            string deploymentTypeString = Enum.GetName(typeof(IcmDeploymentType), deploymentType);

            return deploymentTypeString;
        }

        /// <summary>
        /// Converts a eGain DeploymentType enum to a database string
        /// </summary>
        public static string GetEgainDeploymentTypeString(EgainDeploymentType deploymentType)
        {
            string deploymentTypeString = Enum.GetName(typeof(EgainDeploymentType), deploymentType);

            return deploymentTypeString;
        }

        /// <summary>
        /// Converts a eGain ProductType enum to a database string
        /// </summary>
        public static string GetEgainProductTypeString(EgainProductType productType)
        {
            string productTypeString = Enum.GetName(typeof(EgainProductType), productType);

            return productTypeString;
        }

        /// <summary>
        /// Returns an enumeration to signal whether this specific deployment configuration requires full, partial or no unified configuration support.
        /// </summary>
        public static UnifiedConfigRequirement IsUnifiedWebServicesRequired(IcmDeploymentType deploymentType)
        {
            if (deploymentType == IcmDeploymentType.NAM
                || deploymentType == IcmDeploymentType.NAMRogger
                || deploymentType == IcmDeploymentType.IVRICM
                || deploymentType == IcmDeploymentType.ICMRouterLogger
                || deploymentType == IcmDeploymentType.ICMRogger)
            {
                return UnifiedConfigRequirement.No;
            }

            if ((deploymentType & IcmDeploymentType.UCCE) == IcmDeploymentType.UCCE)
            {
                return UnifiedConfigRequirement.Optional;
            }

            // Default to required
            return UnifiedConfigRequirement.Required;
        }

        /// <summary>
        /// Returns an enumeration to signal whether this specific version/deployment configuration requires full, partial or no unified configuration support.
        /// </summary>
        public static UnifiedConfigRequirement IsUnifiedWebServicesRequired(IcmVersion version, IcmDeploymentType deploymentType)
        {
            if (version >= IcmVersion.VERSION_9_0)
            {
                return IsUnifiedWebServicesRequired(deploymentType);
            }

            return UnifiedConfigRequirement.No;
        }
    }
}
