﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Interface for all cluster field metadata implementations.
    /// </summary>
    internal interface IClusterFieldMetadata
    {
        /// <summary>
        /// Name of the field
        /// </summary>
        string FieldName { get; }

        /// <summary>
        /// Name of the property.
        /// </summary>
        string PropertyName { get; }

        /// <summary>
        /// Is the field encrypted?
        /// </summary>
        bool Encrypted { get; }

        /// <summary>
        /// Ignores database operation for the attribute.
        /// </summary>
        bool IgnoreOnCreate { get; }

        /// <summary>
        /// Indicates if this is a transient field - i.e. a field that is used to store transient state for a service
        /// Transient fields are handled differently when loading/saving the model dependentent on the model load type
        /// </summary>
        bool Transient { get; }

        /// <summary>
        /// Where is the data stored?
        /// </summary>
        ClusterFieldStorageType StorageType { get; }

        /// <summary>
        /// Is this field stored in secrets manager.
        /// </summary>
        bool Secret { get; }

        /// <summary>
        /// Indicates if this type has a default value specified.
        /// </summary>
        bool HasDefaultValue { get; }

        /// <summary>
        /// The deafult value (if specified).
        /// </summary>
        object DefaultValue { get; }

        /// <summary>
        /// Data type of the field.
        /// </summary>
        Type DataType { get; }

        /// <summary>
        /// Regular expression for determining if value should be 
        /// stored in remote secrets manager. Only used if Secret = true.
        /// </summary>
        Regex SecretRegex { get; }

        /// <summary>
        /// Check if the specified field value should be treated as a secret.
        /// </summary>
        bool TreatValueAsSecret(object value);
    }
}
