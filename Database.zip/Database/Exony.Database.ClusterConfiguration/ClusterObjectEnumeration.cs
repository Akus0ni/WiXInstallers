#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Reflection;

    using Exony.ComponentModel;

    public abstract class ClusterObjectEnumeration : ClusterObject
    {
        #region Constants

        /// <summary>
        /// Max length of name field
        /// </summary>
        public const int NAME_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of internal name field
        /// </summary>
        public const int INTERNAL_NAME_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of description field
        /// </summary>
        public const int DESCRIPTION_MAX_LENGTH = 500;

        #endregion

        #region Fields

        /// <summary>
        /// Name for this cluster object
        /// </summary>
        protected string name = string.Empty;

        /// <summary>
        /// Internal ame for this cluster object
        /// </summary>
        private string internalName = string.Empty;

        /// <summary>
        /// Description for this cluster object
        /// </summary>
        private string description = string.Empty;

        #endregion

        #region Construction

        /// <summary>
        /// Constructs a LogicalResourceType with the specified master configuration
        /// </summary>
        protected ClusterObjectEnumeration(ClusterConfiguration configuration)
            : this(configuration, Guid.NewGuid())
        {
        }

        /// <summary>
        /// Constructs a LogicalResourceType with the specified master configuration and id
        /// </summary>
        protected ClusterObjectEnumeration(ClusterConfiguration configuration, Guid id)
            : base(configuration, id)
        {
        }

        #endregion

        #region Implementation of IPhysicalConnectionType

        /// <summary>
        /// Name for this cluster object
        /// </summary>
        [GlobalisedCategory("Exony.Database.ClusterConfiguration", "String_Category_General", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDisplayName("Exony.Database.ClusterConfiguration", "String_ClusterObjectEnumeration_Name_DisplayName", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDescription("Exony.Database.ClusterConfiguration", "String_ClusterObjectEnumeration_Name_Description", "Exony.Database.ClusterConfiguration.Resources")]
        [ClusterField(FieldName = "NAME")]
        [ClusterConfigVisibility(ClusterConfigVisibility.Basic | ClusterConfigVisibility.Advanced)]
        public virtual string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                ValidateName(value);
                object oldValue = this.name;
                this.name = value;
                FirePropertyChanged(MethodBase.GetCurrentMethod().PropertyName(), oldValue, value);
            }
        }

        /// <summary>
        /// Description for this cluster object
        /// </summary>
        [GlobalisedCategory("Exony.Database.ClusterConfiguration", "String_Category_General", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDisplayName("Exony.Database.ClusterConfiguration", "String_ClusterObjectEnumeration_Description_DisplayName", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDescription("Exony.Database.ClusterConfiguration", "String_ClusterObjectEnumeration_Description_Description", "Exony.Database.ClusterConfiguration.Resources")]
        [ClusterField(FieldName = "DESCRIPTION")]
        [ClusterConfigVisibility(ClusterConfigVisibility.Basic | ClusterConfigVisibility.Advanced)]
        public virtual string Description
        {
            get
            {
                return this.description;
            }

            set
            {
                if (value != null && value.Length > DESCRIPTION_MAX_LENGTH)
                {
                    throw new ArgumentException(string.Format(Resources.String_Error_Max_String_Length_Exceeded, DESCRIPTION_MAX_LENGTH), "value");
                }

                object oldValue = this.description;
                this.description = value ?? string.Empty;
                FirePropertyChanged(MethodBase.GetCurrentMethod().PropertyName(), oldValue, value);
            }
        }

        /// <summary>
        /// Internal name for this cluster object
        /// </summary>
        [GlobalisedCategory("Exony.Database.ClusterConfiguration", "String_Category_General", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDisplayName("Exony.Database.ClusterConfiguration", "String_ClusterObjectEnumeration_InternalName_DisplayName", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDescription("Exony.Database.ClusterConfiguration", "String_ClusterObjectEnumeration_InternalName_Description", "Exony.Database.ClusterConfiguration.Resources")]
        [ClusterField(FieldName = "INTERNAL_NAME")]
        [ClusterConfigVisibility(ClusterConfigVisibility.Basic | ClusterConfigVisibility.Advanced)]
        public string InternalName
        {
            get
            {
                return this.internalName;
            }

            set
            {
                value = value.ToUpperInvariant();
                ValidateInternalName(value);
                object oldValue = this.name;
                this.internalName = value;
                FirePropertyChanged(MethodBase.GetCurrentMethod().PropertyName(), oldValue, value);
            }
        }

        [ClusterConfigVisibility(ClusterConfigVisibility.Hidden)]
        [ClusterField(FieldName = null)]
        public override bool Enabled
        {
            get { return true; }
            set { }
        }

        #endregion

        #region Non State Properties

        /// <summary>
        /// Get a display name for this object
        /// </summary>
        public override string DisplayName
        {
            get { return this.Name; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Check if the specified name is valid
        /// </summary>
        protected virtual void ValidateName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentException(Resources.String_Error_String_Cannot_Be_Null_Or_Empty, "name");
            }

            if (name.Length > NAME_MAX_LENGTH)
            {
                throw new ArgumentException(string.Format(Resources.String_Error_Max_String_Length_Exceeded, NAME_MAX_LENGTH), "name");
            }
        }

        /// <summary>
        /// Check if the specified internal name is valid
        /// </summary>
        protected virtual void ValidateInternalName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentException(Resources.String_Error_String_Cannot_Be_Null_Or_Empty, "name");
            }

            if (name.Length > INTERNAL_NAME_MAX_LENGTH)
            {
                throw new ArgumentException(string.Format(Resources.String_Error_Max_String_Length_Exceeded, NAME_MAX_LENGTH), "name");
            }
        }

        /// <summary>
        /// Display this enumeration as a string
        /// </summary>
        public override string ToString()
        {
            return this.InternalName;
        }

        #endregion
    }
}
