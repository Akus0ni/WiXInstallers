#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps

{
    using System;

    /// <summary>
    /// Standard exception thrown when executing a cluster configuration change step via a change model.
    /// </summary>
    [Serializable]
    public class StepExecutionException : Exception
    {
        public StepExecutionException(string message)
            : base(message)
        {
        }

        public StepExecutionException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
