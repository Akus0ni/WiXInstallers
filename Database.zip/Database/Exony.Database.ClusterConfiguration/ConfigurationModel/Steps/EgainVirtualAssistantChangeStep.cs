﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Diagnostics;
    using Exony.Extensions;
    using System;
    using System.Linq;

    public class EgainVirtualAssistantChangeStep : RunWizardChangeStep
    {
        #region Properties

        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum Mode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public Mode ModeType { get; set; }

        /// <summary>
        /// Getter Setter for resource name
        /// </summary
        public string ResourceName { get; set; }

        /// <summary>
        /// Getter Setter for new resource name.
        /// </summary
        public string NewResourceName { get; set; }

        /// <summary>
        /// Getter Setter for server name.
        /// </summary
        public string ServerName { get; set; }

        /// <summary>
        /// Getter Setter for server address.
        /// </summary
        public string ServerAddress { get; set; }

        /// <summary>
        /// Getter Setter for catalogue name.
        /// </summary
        public string CatalogueName { get; set; }

        /// <summary>
        /// Getter Setter for driver.
        /// </summary
        public string Driver { get; set; }

        /// <summary>
        /// Getter Setter for port number.
        /// </summary
        public int? PortNumber { get; set; }

        /// <summary>
        /// Getter Setter for user name.
        /// </summary
        public string UserName { get; set; }

        /// <summary>
        /// Getter Setter for password.
        /// </summary
        public string Password { get; set; }

        /// <summary>
        /// Getter Setter for SslEnabled.
        /// </summary
        public bool? SslEnabled { get; set; }

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Methods

        /// <summary>
        /// Override Execute() with egain virtual assistant server wizard process.
        /// </summary
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running Egain Virtual Assistant Wizard -- Resource Name [{this.ResourceName}] -- Mode [{ this.ModeType}]");

            ClusterConfiguration clusterConfiguration = context.Manager.Configuration;
            EgainVirtualAssistantConfigurationOptions options = new EgainVirtualAssistantConfigurationOptions();

            options.ResourceName = this.ResourceName;

            if (this.ModeType == EgainVirtualAssistantChangeStep.Mode.Remove)
            {
                options.ConfigurationMode = EgainPostgreConnectionConfigurationMode.Remove;

                ILogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).FirstOrDefault();
                options.ResourceId = lr.Id;
            }
            else if (this.ModeType == EgainVirtualAssistantChangeStep.Mode.Add)
            {
                options.ConfigurationMode = EgainPostgreConnectionConfigurationMode.Add;

                options.Server.ServerName = this.ServerName;
                options.Server.ServerAddress = this.ServerAddress;
                options.DbCatalog = this.CatalogueName;
                options.ConnectionDriver = this.Driver;
                options.PortNumber = Convert.ToUInt16(this.PortNumber.Value);
                options.DbUserID = this.UserName;
                options.DbPassword = this.Password.ConvertToSecureString();

                if (this.SslEnabled.HasValue)
                {
                    if (this.SslEnabled.Value)
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Require;
                    }
                    else
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Allow;
                    }
                }
                else
                {
                    options.SslMode = EgainPostgreConnectionSslMode.Require;
                }

                string connectionString = EgainVirtualAssistantSetup.GetConnectionString(options);
                options.PostgreVersion = EgainVirtualAssistantSetup.ServerVersion(connectionString);
                options.ConnectedMediatorResourceId = clusterConfiguration.ExonyMediatorServiceLogicalResources.FirstOrDefault().Id;
                options.Version = GetEgainDbVersion(connectionString);
            }
            else if (this.ModeType == EgainVirtualAssistantChangeStep.Mode.Update)
            {
                options.ConfigurationMode = EgainPostgreConnectionConfigurationMode.Update;

                //Load existing egain virtual assistant logical resource using resource name from cluster and populate options with it to avoid null value being passed.
                EgainVirtualAssistantLogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).OfType<EgainVirtualAssistantLogicalResource>().FirstOrDefault();

                if (lr == null)
                {
                    log.Error($"Invalid Resource Name [{this.ResourceName}]");
                    throw new StepExecutionException($"Invalid Resource Name [{this.ResourceName}]");
                }

                options = new EgainVirtualAssistantConfigurationOptions(lr);

                if (this.NewResourceName != null)
                {
                    options.ResourceName = this.NewResourceName;
                }

                if (this.ServerName != null)
                {
                    options.Server.ServerName = this.ServerName;
                }

                if (string.IsNullOrEmpty(options.Server.ServerName))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ServerName].");
                }

                if (this.ServerAddress != null)
                {
                    options.Server.ServerAddress = this.ServerAddress;
                }

                if (string.IsNullOrEmpty(options.Server.ServerAddress))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ServerAddress].");
                }

                if (this.CatalogueName != null)
                {
                    options.DbCatalog = this.CatalogueName;
                }

                if (string.IsNullOrEmpty(options.DbCatalog))
                {
                    throw new StepExecutionException($"Can not update with null or empty [DbCatalog].");
                }

                if (this.Driver != null)
                {
                    options.ConnectionDriver = this.Driver;
                }

                if (string.IsNullOrEmpty(options.ConnectionDriver))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ConnectionDriver].");
                }

                if (this.PortNumber.HasValue)
                {
                    if (this.PortNumber.Value < 0)
                    {
                        throw new StepExecutionException($"Can not update with negative port number [PortNumber].");
                    }

                    options.PortNumber = Convert.ToUInt16(this.PortNumber.Value);
                }

                if (this.UserName != null)
                {
                    options.DbUserID = this.UserName;
                }

                if (string.IsNullOrEmpty(options.DbUserID))
                {
                    throw new StepExecutionException($"Can not update with null or empty [DbUserID].");
                }

                if (this.Password != null)
                {
                    options.DbPassword = this.Password.ConvertToSecureString();
                }

                if (string.IsNullOrEmpty(options.DbPassword.ConvertToUnsecureString()))
                {
                    throw new StepExecutionException($"Can not update with null or empty [DbPassword].");
                }

                if (this.SslEnabled.HasValue)
                {
                    if (this.SslEnabled.Value)
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Require;
                    }
                    else
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Allow;
                    }
                }

                string connectionString = EgainVirtualAssistantSetup.GetConnectionString(options);
                options.PostgreVersion = EgainVirtualAssistantSetup.ServerVersion(connectionString);
                options.ConnectedMediatorResourceId = clusterConfiguration.ExonyMediatorServiceLogicalResources.FirstOrDefault().Id;
                options.Version = GetEgainDbVersion(connectionString);
            }
            else
            {
                throw new StepExecutionException("Invalid mode type!");
            }

            try
            {
                bool successful = EgainVirtualAssistantSetup.ConfigureEgainVirtualAssistant(clusterConfiguration, options, true, out SetupResult[] warningsAndErrors);

                if (successful)
                {
                    log.Info("Egain virtual assistant wizard executed successfully.");
                }
                else
                {
                    log.Info("Egain virtual assistant wizard failed.");
                    throw new StepExecutionException("Egain virtual assistant wizard failed.");
                }
            }
            catch (Exception e)
            {
                log.Error("Egain virtual assistant wizard failed.", e);
                throw new StepExecutionException("Egain virtual assistant wizard failed.", e);
            }
        }

        /// <summary>
        /// Get egain database version.
        /// </summary>
        private static string GetEgainDbVersion(string connectionString)
        {
            string versionQuery = "SELECT * FROM egva.egva_release_info WHERE seq_id = (SELECT MAX(seq_id) FROM egva.egva_release_info)";

            return EgainPostgreConnectionSetup.GetValue(connectionString, versionQuery,
                    dbReader =>
                    {
                        int majorVersion = dbReader.GetFieldValue<int>(dbReader.GetOrdinal("major_version"));
                        int minorVersion = dbReader.GetFieldValue<int>(dbReader.GetOrdinal("minor_version"));
                        int servicePack = dbReader.GetFieldValue<int>(dbReader.GetOrdinal("service_pack"));

                        return $"{majorVersion}.{minorVersion}.{servicePack}";
                    }, "Unknown");
        }

        #endregion
    }
}
