﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Reflection;
    using System.Runtime.Serialization;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Database.Common;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.Common.Folders;
    using Exony.Diagnostics;

    public class ManageTenantChangeStep : AbstractClusterConfigurationChangeStep
    {
        #region Properties

        /// <summary>
        /// Enum for mode for manage tenant.
        /// </summary>
        public enum Mode
        {
            Add
        }

        /// <summary>
        /// Getter Setter tenant property dictionary.
        /// </summary>
        public IDictionary<string, object> TenantProperties = new Dictionary<string, object>();

        /// <summary>
        /// Getter Setter for folder name.
        /// </summary>
        public string TenantName { get; set; }

        /// <summary>
        /// Getter Setter for folder description.
        /// </summary>
        public string TenantDescription { get; set; }

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Methods

        /// <summary>
        /// Overriden Execute Method.
        /// </summary>
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running Tenant Manager Wizard [Creating Tenant [{this.TenantName}] under ROOT.]");

            Guid folderId = context.DataAdapter.AddTenant(this.TenantName, this.TenantDescription);

            DatabaseXmlData createDataXml = new DatabaseXmlData();
            createDataXml.SetValue("PATH", $"/{this.TenantName}");
            context.DataAdapter.WriteAuditEvent("FOLDER_CREATED", null, folderId, null, null, createDataXml);

            if (this.TenantProperties.Count > 0)
            {
                context.DataAdapter.AddPropertiesToTenant(folderId, this.TenantProperties);
            }
        }

        #endregion
    }
}