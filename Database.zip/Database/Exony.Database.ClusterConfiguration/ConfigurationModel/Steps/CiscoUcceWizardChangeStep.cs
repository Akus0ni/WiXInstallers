﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Diagnostics;
    using Exony.Extensions;
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;

    public class CiscoUcceWizardChangeStep : RunWizardChangeStep
    {
        #region Properties

        /// <summary>
        /// Wizard Mode Enum.
        /// </summary>
        public enum Mode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Wizard Mode.
        /// </summary>
        public Mode ModeType { get; set; }

        /// <summary>
        /// System Type Enum.
        /// </summary>
        public enum Type
        {
            SingleSided,
            DualSided
        }

        /// <summary>
        /// System Type.
        /// </summary>
        public Type SystemType { get; set; }

        /// <summary>
        /// Resource Name.
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// New Resource Name used to update.
        /// </summary>
        public string NewResourceName { get; set; }

        /// <summary>
        /// Hds required?
        /// </summary>
        public bool? HdsRequired { get; set; }

        /// <summary>
        /// Dds required?
        /// </summary>
        public bool? DdsRequired { get; set; }

        /// <summary>
        /// Is provisoinable?
        /// </summary>
        public bool? Provisionable { get; set; }

        /// <summary>
        /// Primary AW Server name.
        /// </summary>
        public string PrimaryAwServerName { get; set; }

        /// <summary>
        /// Primary Aw Server Address.
        /// </summary>
        public string PrimaryAwServerAddress { get; set; }

        /// <summary>
        /// Is integrated security?
        /// </summary>
        public bool? DbIntegratedSecurity { get; set; }

        /// <summary>
        /// Db user id.
        /// </summary>
        public string DbUserId { get; set; }

        /// <summary>
        /// Db password.
        /// </summary>
        public string DbPassword { get; set; }

        /// <summary>
        /// Secondary AW server name.
        /// </summary>
        public string SecondaryAwServerName { get; set; }

        /// <summary>
        /// Secondary AW server address.
        /// </summary>
        public string SecondaryAwServerAddress { get; set; }

        /// <summary>
        /// Primary Hds server name.
        /// </summary>
        public string PrimaryHdsServerName { get; set; }

        /// <summary>
        /// Primary Hds server address.
        /// </summary>
        public string PrimaryHdsServerAddress { get; set; }

        /// <summary>
        /// Secondary Hds server name.
        /// </summary>
        public string SecondaryHdsServerName { get; set; }

        /// <summary>
        /// Secondary Hds server address.
        /// </summary>
        public string SecondaryHdsServerAddress { get; set; }

        /// <summary>
        /// Primary Dds server name.
        /// </summary>
        public string PrimaryDdsServerName { get; set; }

        /// <summary>
        /// Primary Dds server address.
        /// </summary>
        public string PrimaryDdsServerAddress { get; set; }

        /// <summary>
        /// Secondary Dds server name.
        /// </summary>
        public string SecondaryDdsServerName { get; set; }

        /// <summary>
        /// Secondary Dds server address.
        /// </summary>
        public string SecondaryDdsServerAddress { get; set; }

        /// <summary>
        /// Primary unified config url.
        /// </summary>
        public string PrimaryUnifiedConfigUrl { get; set; }

        /// <summary>
        /// Primary unified config user.
        /// </summary>
        public string PrimaryUnifiedConfigUser { get; set; }

        /// <summary>
        /// Primary unified config password.
        /// </summary>
        public string PrimaryUnifiedConfigPassword { get; set; }

        /// <summary>
        /// Primary unified config timeout.
        /// </summary>
        public int? PrimaryUnifiedConfigTimeout { get; set; }

        /// <summary>
        /// Primary con api local port.
        /// </summary>
        public int? PrimaryConapiLocalPort { get; set; }

        /// <summary>
        /// Primary con api local registry port.
        /// </summary>
        public int? PrimaryConapiLocalRegistryPort { get; set; }

        /// <summary>
        /// Primary con api remote registry port.
        /// </summary>
        public int? PrimaryConapiRemoteRegistryPort { get; set; }

        /// <summary>
        /// Secondary unified config url.
        /// </summary>
        public string SecondaryUnifiedConfigUrl { get; set; }

        /// <summary>
        /// Secondary unified config user.
        /// </summary>
        public string SecondaryUnifiedConfigUser { get; set; }

        /// <summary>
        /// Secondary unified config password.
        /// </summary>
        public string SecondaryUnifiedConfigPassword { get; set; }

        /// <summary>
        /// Secondary unified config timeout.
        /// </summary>
        public int? SecondaryUnifiedConfigTimeout { get; set; }

        /// <summary>
        /// Secondary con api local port.
        /// </summary>
        public int? SecondaryConapiLocalPort { get; set; }

        /// <summary>
        /// Secondary con api local registry port.
        /// </summary>
        public int? SecondaryConapiLocalRegistryPort { get; set; }

        /// <summary>
        /// Secondary con api registry port.
        /// </summary>
        public int? SecondaryConapiRemoteRegistryPort { get; set; }

        /// <summary>
        /// Con api application name.
        /// </summary>
        public string ConapiApplicationName { get; set; }

        /// <summary>
        /// Con api application key.
        /// </summary>
        public string ConapiApplicationKey { get; set; }

        /// <summary>
        /// Multimedia support.
        /// </summary>
        public bool? MultiMediaSupport { get; set; }

        /// <summary>
        /// Purge items on delete.
        /// </summary>
        public bool? PurgeItemsOnDelete { get; set; }

        /// <summary>
        /// Script support.
        /// </summary>
        public bool? ScriptSupport { get; set; }

        /// <summary>
        /// Script lock user name.
        /// </summary>
        public string ScriptLockUserName { get; set; }

        /// <summary>
        /// Supervisor AD integration.
        /// </summary>
        public bool? SupervisorActiveDirectoryIntegration { get; set; }

        /// <summary>
        /// Global catalog domain or server.
        /// </summary>
        public string GlobalCatalogDomainOrServer { get; set; }

        /// <summary>
        /// Domain Integration.
        /// </summary>
        public bool? UseDomainIntegration { get; set; }

        /// <summary>
        /// Anonymous domain.
        /// </summary>
        public bool? DomainControllerAnonymous { get; set; }

        /// <summary>
        /// Delegation domain.
        /// </summary>
        public bool? DomainControllerDelegation { get; set; }

        /// <summary>
        /// Domain controller use encryption.
        /// </summary>
        public bool? DomainControllerUseEncryption { get; set; }

        /// <summary>
        /// Server bind.
        /// </summary>
        public bool? DomainControllerServerBind { get; set; }

        /// <summary>
        /// Fast bind.
        /// </summary>
        public bool? DomainControllerFastBind { get; set; }

        /// <summary>
        /// Read only server.
        /// </summary>
        public bool? DomainControllerReadOnlyServer { get; set; }

        /// <summary>
        /// Domain controller use SSL.
        /// </summary>
        public bool? DomainControllerUseSsl { get; set; }

        /// <summary>
        /// Secure authentication.
        /// </summary>
        public bool? DomainControllerSecureAuthentication { get; set; }

        /// <summary>
        /// Domain controller sealing.
        /// </summary>
        public bool? DomainControllerSealing { get; set; }

        /// <summary>
        /// Domain controller signing.
        /// </summary>
        public bool? DomainControllerSigning { get; set; }

        /// <summary>
        /// Domain controller user name.
        /// </summary>
        public string DomainControllerUserName { get; set; }

        /// <summary>
        /// Domain controller password.
        /// </summary>
        public string DomainControllerPassword { get; set; }

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Methods

        /// <summary>
        /// Execute step.
        /// </summary>
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running Cisco UCCE Wizard -- Resource Name [{this.ResourceName}] -- Mode [{ this.ModeType}]");

            ClusterConfiguration clusterConfiguration = context.Manager.Configuration;
            IcmConfigurationOptions options = new IcmConfigurationOptions();

            options.ResourceName = this.ResourceName;

            if (this.ModeType == CiscoUcceWizardChangeStep.Mode.Remove)
            {
                options.ConfigurationMode = CiscoIcmConfigurationMode.Remove;

                ILogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).FirstOrDefault();
                options.ResourceId = lr.Id;
            }
            else if (this.ModeType == CiscoUcceWizardChangeStep.Mode.Add)
            {
                //General details.
                options.ConfigurationMode = CiscoIcmConfigurationMode.Add;
                options.RedundancyType = this.SystemType == CiscoUcceWizardChangeStep.Type.SingleSided ? CiscoIcmRedundancyType.SingleSided : CiscoIcmRedundancyType.DualSided;

                //Setup database details.
                options.IntegratedSecurity = this.DbIntegratedSecurity ?? true;
                options.UserID = !options.IntegratedSecurity ? this.DbUserId : string.Empty;
                options.Password = !options.IntegratedSecurity ? this.DbPassword.ConvertToSecureString() : string.Empty.ConvertToSecureString();

                //Setup AW details for primary and secondary server.
                options.PrimaryAwServer.ServerName = this.PrimaryAwServerName;
                options.PrimaryAwServer.ServerAddress = this.PrimaryAwServerAddress;
                options.SecondaryAwServer.ServerName = options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryAwServerName : string.Empty;
                options.SecondaryAwServer.ServerAddress = options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryAwServerAddress : string.Empty;
                options.ConnectedDataImportResourceId = clusterConfiguration.ExonyDataPipelineServiceLogicalResource.FirstOrDefault().Id;

                //Setup Hds details for primary and secondary server.
                options.HdsRequired = this.HdsRequired ?? false;
                options.PrimaryHdsServer.ServerName = options.HdsRequired ? this.PrimaryHdsServerName : string.Empty;
                options.PrimaryHdsServer.ServerAddress = options.HdsRequired ? this.PrimaryHdsServerAddress : string.Empty;
                options.SecondaryHdsServer.ServerName = options.HdsRequired && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryHdsServerName : string.Empty;
                options.SecondaryHdsServer.ServerAddress = options.HdsRequired && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryHdsServerAddress : string.Empty;
                options.ConnectedMediatorResourceId = options.HdsRequired ? clusterConfiguration.ExonyMediatorServiceLogicalResources.FirstOrDefault().Id : Guid.Empty;

                //Setup Dds details for primary and secondary server.
                options.DdsRequired = (this.HdsRequired ?? false) && (this.DdsRequired ?? false);
                options.PrimaryDdsServer.ServerName = options.DdsRequired ? this.PrimaryDdsServerName : string.Empty;
                options.PrimaryDdsServer.ServerAddress = options.DdsRequired ? this.PrimaryDdsServerAddress : string.Empty;
                options.SecondaryDdsServer.ServerName = options.DdsRequired && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryDdsServerName : string.Empty;
                options.SecondaryDdsServer.ServerAddress = options.DdsRequired && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryDdsServerAddress : string.Empty;
                options.ConnectedDdsMediatorResourceId = options.DdsRequired ? clusterConfiguration.ExonyMediatorServiceLogicalResources.FirstOrDefault().Id : Guid.Empty;

                //Setup Provisioning for primary and secondary server.
                options.Provisionable = this.Provisionable ?? false;

                if (options.Provisionable && this.PrimaryUnifiedConfigUrl != null)
                {
                    options.PrimaryUnifiedConfigUrl = ValidateUnifiedConfigUrl(this.PrimaryUnifiedConfigUrl);
                }
                else if (options.Provisionable && this.PrimaryUnifiedConfigUrl == null)
                {
                    options.PrimaryUnifiedConfigUrl = BuildDefaultUnifiedConfigUrl(this.PrimaryAwServerAddress);
                }
                
                options.PrimaryUnifiedConfigUser = options.Provisionable ? this.PrimaryUnifiedConfigUser : string.Empty;
                options.PrimaryUnifiedConfigPassword = options.Provisionable ? this.PrimaryUnifiedConfigPassword.ConvertToSecureString() : string.Empty.ConvertToSecureString();
                options.PrimaryUnifiedConfigTimeout = options.Provisionable ? this.PrimaryUnifiedConfigTimeout.ToString() : string.Empty;
                options.PrimaryConapiLocalRegistryPort = options.Provisionable ? Convert.ToUInt16(this.PrimaryConapiLocalRegistryPort) : Convert.ToUInt16(null);
                options.PrimaryConapiRemoteRegistryPort = options.Provisionable ? Convert.ToUInt16(this.PrimaryConapiRemoteRegistryPort) : Convert.ToUInt16(null);
                options.PrimaryConapiLocalPort = options.Provisionable ? Convert.ToUInt16(this.PrimaryConapiLocalPort) : Convert.ToUInt16(null);

                if (options.Provisionable && this.SecondaryUnifiedConfigUrl != null)
                {
                    options.SecondaryUnifiedConfigUrl = ValidateUnifiedConfigUrl(this.SecondaryUnifiedConfigUrl);
                }
                else if (options.Provisionable && this.SecondaryUnifiedConfigUrl == null)
                {
                    options.SecondaryUnifiedConfigUrl = BuildDefaultUnifiedConfigUrl(this.SecondaryAwServerAddress);
                }

                options.SecondaryUnifiedConfigUser = options.Provisionable && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryUnifiedConfigUser : string.Empty;
                options.SecondaryUnifiedConfigPassword = options.Provisionable && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryUnifiedConfigPassword.ConvertToSecureString() : string.Empty.ConvertToSecureString();
                options.SecondaryUnifiedConfigTimeout = options.Provisionable && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? this.SecondaryUnifiedConfigTimeout.ToString() : string.Empty;
                options.SecondaryConapiLocalRegistryPort = options.Provisionable && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? Convert.ToUInt16(this.SecondaryConapiLocalRegistryPort) : Convert.ToUInt16(null);
                options.SecondaryConapiRemoteRegistryPort = options.Provisionable && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? Convert.ToUInt16(this.SecondaryConapiRemoteRegistryPort) : Convert.ToUInt16(null);
                options.SecondaryConapiLocalPort = options.Provisionable && options.RedundancyType == CiscoIcmRedundancyType.DualSided ? Convert.ToUInt16(this.SecondaryConapiLocalPort) : Convert.ToUInt16(null);

                //Setup common provisioning data.
                options.ConapiApplicationName = options.Provisionable ? this.ConapiApplicationName : string.Empty;
                options.ConapiApplicationKey = options.Provisionable ? this.ConapiApplicationKey : string.Empty;
                options.MultiMediaSupport = options.Provisionable && (this.MultiMediaSupport?? false);
                options.PurgeItemsOnDelete = options.Provisionable && (this.PurgeItemsOnDelete ?? false);
                options.ScriptProvisioningEnabled = options.Provisionable && (this.ScriptSupport ?? false);
                options.ScriptLockUserName = options.ScriptProvisioningEnabled ? this.ScriptLockUserName : string.Empty;
                options.SupervisorDomainAccountRequired = options.Provisionable && (this.SupervisorActiveDirectoryIntegration ?? false);
                options.GlobalCatalogDomainOrServer = options.SupervisorDomainAccountRequired ? this.GlobalCatalogDomainOrServer : string.Empty;
                options.UseDomainIntegration = options.Provisionable && (this.UseDomainIntegration ?? false);
                options.DomainControllerAnonymous = options.UseDomainIntegration && (this.DomainControllerAnonymous ?? false);
                options.DomainControllerDelegation = options.UseDomainIntegration && (this.DomainControllerDelegation ?? false);
                options.DomainControllerUseEncryption = options.UseDomainIntegration && (this.DomainControllerUseEncryption ?? false);
                options.DomainControllerServerBind = options.UseDomainIntegration && (this.DomainControllerServerBind ?? false);
                options.DomainControllerFastBind = options.UseDomainIntegration && (this.DomainControllerFastBind ?? false);
                options.DomainControllerReadOnlyServer = options.UseDomainIntegration && (this.DomainControllerReadOnlyServer ?? false);
                options.DomainControllerUseSsl = options.UseDomainIntegration && (this.DomainControllerUseSsl ?? false);
                options.DomainControllerSecureAuthentication = options.UseDomainIntegration && (this.DomainControllerSecureAuthentication ?? false);
                options.DomainControllerSealing = options.UseDomainIntegration && options.DomainControllerSecureAuthentication && (this.DomainControllerSealing ?? false);
                options.DomainControllerSigning = options.UseDomainIntegration && options.DomainControllerSecureAuthentication && (this.DomainControllerSigning ?? false);
                options.DomainControllerUserName = options.UseDomainIntegration && options.DomainControllerSecureAuthentication ? this.DomainControllerUserName : string.Empty;
                options.DomainControllerPassword = options.UseDomainIntegration && options.DomainControllerSecureAuthentication ? this.DomainControllerPassword.ConvertToSecureString() : string.Empty.ConvertToSecureString();
                
                //Complete Icm configuration.
                string catalog = IcmSetup.RetrieveIcmInstanceNames(GetDbConnectionString(this)).FirstOrDefault();
                options = IcmSetup.CompleteConfiguration(options, catalog);
            }
            else if (this.ModeType == CiscoUcceWizardChangeStep.Mode.Update)
            {
                options.ConfigurationMode = CiscoIcmConfigurationMode.Update;

                //Load existing cisco ucce logical resource using resource name from cluster and populate options with it to avoid null value being passed.
                CiscoIcmLogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).OfType<CiscoIcmLogicalResource>().FirstOrDefault();

                if (lr == null)
                {
                    log.Error($"Invalid Resource Name [{this.ResourceName}]");
                    throw new StepExecutionException($"Invalid Resource Name [{this.ResourceName}]");
                }

                options = new IcmConfigurationOptions(lr);

                if (this.NewResourceName != null)
                {
                    options.ResourceName = this.NewResourceName;
                }

                if (this.HdsRequired.HasValue)
                {
                    options.HdsRequired = this.HdsRequired.Value;
                }

                if (this.DdsRequired.HasValue)
                {
                    options.DdsRequired = this.DdsRequired.Value;
                }

                if (this.Provisionable.HasValue)
                {
                    options.Provisionable = this.Provisionable.Value;
                }

                if (this.DbIntegratedSecurity.HasValue)
                {
                    options.IntegratedSecurity = this.DbIntegratedSecurity.Value;
                }

                //Update database integrated security, db user and db password as needed.
                if (!options.IntegratedSecurity)
                {
                    if (this.DbUserId != null)
                    {
                        options.UserID = this.DbUserId;
                    }

                    if (string.IsNullOrEmpty(options.UserID))
                    {
                        throw new StepExecutionException($"[Integrated Security] is being set to [false] but no [DB User] is passed. Please pass via config file.");
                    }

                    if (this.DbPassword != null)
                    {
                        options.Password = this.DbPassword.ConvertToSecureString();
                    }

                    if (string.IsNullOrEmpty(options.Password.ConvertToUnsecureString()))
                    {
                        throw new StepExecutionException($"[Integrated Security] is being set to [false] but no [DB Password] is passed. Please pass via config file.");
                    }
                }

                //Update common provisioning data for system.
                if (options.Provisionable)
                {
                    if (this.ConapiApplicationName != null)
                    {
                        options.ConapiApplicationName = this.ConapiApplicationName;
                    }

                    if (string.IsNullOrEmpty(options.ConapiApplicationName))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [ConapiApplicationName]. Please pass via config file.");
                    }

                    if (this.ConapiApplicationKey != null)
                    {
                        options.ConapiApplicationKey = this.ConapiApplicationKey;
                    }

                    if (string.IsNullOrEmpty(options.ConapiApplicationKey))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [ConapiApplicationKey]. Please pass via config file.");
                    }

                    if (this.MultiMediaSupport.HasValue)
                    {
                        options.MultiMediaSupport = this.MultiMediaSupport.Value;
                    }

                    if (this.PurgeItemsOnDelete.HasValue)
                    {
                        options.PurgeItemsOnDelete = this.PurgeItemsOnDelete.Value;
                    }

                    if (this.ScriptSupport.HasValue)
                    {
                        options.ScriptProvisioningEnabled = this.ScriptSupport.Value;
                    }

                    if (options.ScriptProvisioningEnabled)
                    {
                        if (this.ScriptLockUserName != null)
                        {
                            options.ScriptLockUserName = this.ScriptLockUserName;
                        }

                        if (string.IsNullOrEmpty(options.ScriptLockUserName))
                        {
                            throw new StepExecutionException($"Can not enable [ScriptProvisioning] with null or empty [ScriptLockUserName]. Please pass via config file.");
                        }
                    }

                    if (this.SupervisorActiveDirectoryIntegration.HasValue)
                    {
                        options.SupervisorDomainAccountRequired = this.SupervisorActiveDirectoryIntegration.Value;
                    }

                    if (options.SupervisorDomainAccountRequired)
                    {
                        if (this.GlobalCatalogDomainOrServer != null)
                        {
                            options.GlobalCatalogDomainOrServer = this.GlobalCatalogDomainOrServer;
                        }

                        if (string.IsNullOrEmpty(options.GlobalCatalogDomainOrServer))
                        {
                            throw new StepExecutionException($"Can not enable [SupervisorActiveDirectoryIntegration] with null or empty [GlobalCatalogDomainOrServer]. Please pass via config file.");
                        }

                        if (this.UseDomainIntegration.HasValue)
                        {
                            options.UseDomainIntegration = this.UseDomainIntegration.Value;
                        }

                        if (options.UseDomainIntegration)
                        {
                            if (this.DomainControllerAnonymous.HasValue)
                            {
                                options.DomainControllerAnonymous = this.DomainControllerAnonymous.Value;
                            }

                            if (this.DomainControllerDelegation.HasValue)
                            {
                                options.DomainControllerDelegation = this.DomainControllerDelegation.Value;
                            }

                            if (this.DomainControllerUseEncryption.HasValue)
                            {
                                options.DomainControllerUseEncryption = this.DomainControllerUseEncryption.Value;
                            }

                            if (this.DomainControllerServerBind.HasValue)
                            {
                                options.DomainControllerServerBind = this.DomainControllerServerBind.Value;
                            }

                            if (this.DomainControllerFastBind.HasValue)
                            {
                                options.DomainControllerFastBind = this.DomainControllerFastBind.Value;
                            }

                            if (this.DomainControllerReadOnlyServer.HasValue)
                            {
                                options.DomainControllerReadOnlyServer = this.DomainControllerReadOnlyServer.Value;
                            }

                            if (this.DomainControllerUseSsl.HasValue)
                            {
                                options.DomainControllerUseSsl = this.DomainControllerUseSsl.Value;
                            }

                            if (this.DomainControllerSecureAuthentication.HasValue)
                            {
                                options.DomainControllerSecureAuthentication = this.DomainControllerSecureAuthentication.Value;
                            }

                            if (options.DomainControllerSecureAuthentication)
                            {
                                if (this.DomainControllerSealing.HasValue)
                                {
                                    options.DomainControllerSealing = this.DomainControllerSealing.Value;
                                }

                                if (this.DomainControllerSigning.HasValue)
                                {
                                    options.DomainControllerSigning = this.DomainControllerSigning.Value;
                                }

                                if (this.DomainControllerUserName != null)
                                {
                                    options.DomainControllerUserName = this.DomainControllerUserName;
                                }

                                if (string.IsNullOrEmpty(options.DomainControllerUserName))
                                {
                                    throw new StepExecutionException($"[DomainControllerSecureAuthentication] is being set to [true] but no [Domain Controller User] is passed. Please pass via config file.");
                                }

                                if (this.DomainControllerPassword != null)
                                {
                                    options.DomainControllerPassword = this.DomainControllerPassword.ConvertToSecureString();
                                }

                                if (string.IsNullOrEmpty(options.DomainControllerPassword.ConvertToUnsecureString()))
                                {
                                    throw new StepExecutionException($"[DomainControllerSecureAuthentication] is being set to [true] but no [Domain Controller Password] is passed. Please pass via config file.");
                                }
                            }
                        }
                    }
                    else if (options.SupervisorDomainAccountRequired == false)
                    {
                        options.UseDomainIntegration = false;
                    }
                }

                //Update redundancy type.
                if (this.SystemType == CiscoUcceWizardChangeStep.Type.SingleSided)
                {
                    options.RedundancyType = CiscoIcmRedundancyType.SingleSided;
                }
                else
                {
                    options.RedundancyType = CiscoIcmRedundancyType.DualSided;
                }

                //Primary aw data
                if (this.PrimaryAwServerName != null)
                {
                    options.PrimaryAwServer.ServerName = this.PrimaryAwServerName;
                }

                if (string.IsNullOrEmpty(options.PrimaryAwServer.ServerName))
                {
                    throw new StepExecutionException($"[PrimaryAwServerName] can not be empty or null. Please pass via config file.");
                }

                if (this.PrimaryAwServerAddress != null)
                {
                    options.PrimaryAwServer.ServerAddress = this.PrimaryAwServerAddress;
                }

                if (string.IsNullOrEmpty(options.PrimaryAwServer.ServerAddress))
                {
                    throw new StepExecutionException($"[PrimaryAwServerAddress] can not be empty or null. Please pass via config file.");
                }

                //Primary hds data.
                if (options.HdsRequired)
                {
                    if (this.PrimaryHdsServerName != null)
                    {
                        options.PrimaryHdsServer.ServerName = this.PrimaryHdsServerName;
                    }

                    if (string.IsNullOrEmpty(options.PrimaryHdsServer.ServerName))
                    {
                        throw new StepExecutionException($"[PrimaryHdsServerName] can not be empty or null. Please pass via config file.");
                    }

                    if (this.PrimaryHdsServerAddress != null)
                    {
                        options.PrimaryHdsServer.ServerAddress = this.PrimaryHdsServerAddress;
                    }

                    if (string.IsNullOrEmpty(options.PrimaryHdsServer.ServerAddress))
                    {
                        throw new StepExecutionException($"[PrimaryHdsServerAddress] can not be empty or null. Please pass via config file.");
                    }
                }

                //Primary dds data.
                if (options.DdsRequired)
                {
                    if (!options.HdsRequired)
                    {
                        throw new StepExecutionException($"[Dds] can not be defined without [Hds].");
                    }

                    if (this.PrimaryDdsServerName != null)
                    {
                        options.PrimaryDdsServer.ServerName = this.PrimaryDdsServerName;
                    }

                    if (string.IsNullOrEmpty(options.PrimaryDdsServer.ServerName))
                    {
                        throw new StepExecutionException($"[PrimaryDdsServerName] can not be empty or null. Please pass via config file.");
                    }

                    if (this.PrimaryDdsServerAddress != null)
                    {
                        options.PrimaryDdsServer.ServerAddress = this.PrimaryDdsServerAddress;
                    }

                    if (string.IsNullOrEmpty(options.PrimaryDdsServer.ServerAddress))
                    {
                        throw new StepExecutionException($"[PrimaryDdsServerAddress] can not be empty or null. Please pass via config file.");
                    }
                }

                //Primary provisioning data.
                if (options.Provisionable)
                {
                    if (this.PrimaryUnifiedConfigUrl != null)
                    {
                        options.PrimaryUnifiedConfigUrl = ValidateUnifiedConfigUrl(this.PrimaryUnifiedConfigUrl);
                    }

                    if (string.IsNullOrEmpty(options.PrimaryUnifiedConfigUrl) && options.PrimaryAwServer.ServerAddress == null)
                    {
                        throw new StepExecutionException($"[PrimaryUnifiedConfigUrl] can not be empty or null. Please pass via config file.");
                    }
                    else
                    {
                        options.PrimaryUnifiedConfigUrl = BuildDefaultUnifiedConfigUrl(options.PrimaryAwServer.ServerAddress);
                    }

                    if (this.PrimaryUnifiedConfigUser != null)
                    {
                        options.PrimaryUnifiedConfigUser = this.PrimaryUnifiedConfigUser;
                    }

                    if (string.IsNullOrEmpty(options.PrimaryUnifiedConfigUser))
                    {
                        throw new StepExecutionException($"[PrimaryUnifiedConfigUser] can not be empty or null. Please pass via config file.");
                    }

                    if (this.PrimaryUnifiedConfigPassword != null)
                    {
                        options.PrimaryUnifiedConfigPassword = this.PrimaryUnifiedConfigPassword.ConvertToSecureString();
                    }

                    if (string.IsNullOrEmpty(options.PrimaryUnifiedConfigPassword.ConvertToUnsecureString()))
                    {
                        throw new StepExecutionException($"[PrimaryConapiRemoteRegistryPort] can not be empty or null. Please pass via config file.");
                    }

                    if (this.PrimaryUnifiedConfigTimeout.HasValue)
                    {
                        if (this.PrimaryUnifiedConfigTimeout.Value >= 0)
                        {
                            options.PrimaryUnifiedConfigTimeout = this.PrimaryUnifiedConfigTimeout.Value.ToString();
                        }
                        else
                        {
                            throw new StepExecutionException($"[PrimaryUnifiedConfigTimeout] can not be negative.");
                        }
                    }

                    if (Convert.ToInt32(options.PrimaryUnifiedConfigTimeout) < 0 || string.IsNullOrEmpty(options.PrimaryUnifiedConfigTimeout))
                    {
                        throw new StepExecutionException($"[PrimaryUnifiedConfigTimeout] can not be negative, null or empty.");
                    }

                    if (this.PrimaryConapiRemoteRegistryPort.HasValue)
                    {
                        if (this.PrimaryConapiRemoteRegistryPort.Value >= 0)
                        {
                            options.PrimaryConapiRemoteRegistryPort = Convert.ToUInt16(this.PrimaryConapiRemoteRegistryPort.Value);
                        }
                        else
                        {
                            throw new StepExecutionException($"[PrimaryConapiRemoteRegistryPort] can not be negative.");
                        }
                    }

                    if (options.PrimaryConapiRemoteRegistryPort < 0)
                    {
                        throw new StepExecutionException($"[PrimaryConapiRemoteRegistryPort] can not be negative.");
                    }

                    if (this.PrimaryConapiLocalRegistryPort.HasValue)
                    {
                        if (this.PrimaryConapiLocalRegistryPort >= 0)
                        {
                            options.PrimaryConapiLocalRegistryPort = Convert.ToUInt16(this.PrimaryConapiLocalRegistryPort.Value);
                        }
                        else
                        {
                            throw new StepExecutionException($"[PrimaryConapiLocalRegistryPort] can not be negative.");
                        }
                    }

                    if (options.PrimaryConapiLocalRegistryPort < 0)
                    {
                        throw new StepExecutionException($"[PrimaryConapiLocalRegistryPort] can not be negative.");
                    }

                    if (this.PrimaryConapiLocalPort.HasValue)
                    {
                        if (this.PrimaryConapiLocalPort.Value >= 0)
                        {
                            options.PrimaryConapiLocalPort = Convert.ToUInt16(this.PrimaryConapiLocalPort.Value);
                        }
                    }

                    if (options.PrimaryConapiLocalPort < 0)
                    {
                        throw new StepExecutionException($"[PrimaryConapiLocalPort] can not be negative.");
                    }
                }

                //Process secondary ucce data.
                if (options.RedundancyType == CiscoIcmRedundancyType.DualSided)
                {
                    //Secondary aw data
                    if (this.SecondaryAwServerName != null)
                    {
                        options.SecondaryAwServer.ServerName = this.SecondaryAwServerName;
                    }

                    if (string.IsNullOrEmpty(options.SecondaryAwServer.ServerName))
                    {
                        throw new StepExecutionException($"[SecondaryAwServerName] can not be empty or null. Please pass via config file.");
                    }

                    if (this.SecondaryAwServerAddress != null)
                    {
                        options.SecondaryAwServer.ServerAddress = this.SecondaryAwServerAddress;
                    }

                    if (string.IsNullOrEmpty(options.SecondaryAwServer.ServerAddress))
                    {
                        throw new StepExecutionException($"[SecondaryAwServerAddress] can not be empty or null. Please pass via config file.");
                    }

                    //Secondary hds data.
                    if (options.HdsRequired)
                    {
                        if (this.SecondaryHdsServerName != null)
                        {
                            options.SecondaryHdsServer.ServerName = this.SecondaryHdsServerName;
                        }

                        if (string.IsNullOrEmpty(options.SecondaryHdsServer.ServerName))
                        {
                            throw new StepExecutionException($"[SecondaryHdsServerName] can not be empty or null. Please pass via config file.");
                        }

                        if (this.SecondaryHdsServerAddress != null)
                        {
                            options.SecondaryHdsServer.ServerAddress = this.SecondaryHdsServerAddress;
                        }

                        if (string.IsNullOrEmpty(options.SecondaryHdsServer.ServerAddress))
                        {
                            throw new StepExecutionException($"[SecondaryHdsServerAddress] can not be empty or null. Please pass via config file.");
                        }
                    }

                    //Secondary dds data.
                    if (options.DdsRequired)
                    {
                        if (!options.HdsRequired)
                        {
                            throw new StepExecutionException($"[Dds] can not be defined without [Hds].");
                        }

                        if (this.SecondaryDdsServerName != null)
                        {
                            options.SecondaryDdsServer.ServerName = this.SecondaryDdsServerName;
                        }

                        if (string.IsNullOrEmpty(options.SecondaryDdsServer.ServerName))
                        {
                            throw new StepExecutionException($"[SecondaryDdsServerName] can not be empty or null. Please pass via config file.");
                        }

                        if (this.SecondaryDdsServerAddress != null)
                        {
                            options.SecondaryDdsServer.ServerAddress = this.SecondaryDdsServerAddress;
                        }

                        if (string.IsNullOrEmpty(options.SecondaryDdsServer.ServerAddress))
                        {
                            throw new StepExecutionException($"[SecondaryDdsServerAddress] can not be empty or null. Please pass via config file.");
                        }
                    }

                    //Secondary provisioning data.
                    if (options.Provisionable)
                    {
                        if (this.SecondaryUnifiedConfigUrl != null)
                        {
                            options.SecondaryUnifiedConfigUrl = ValidateUnifiedConfigUrl(this.SecondaryUnifiedConfigUrl);
                        }

                        if (string.IsNullOrEmpty(options.SecondaryUnifiedConfigUrl) && options.SecondaryAwServer.ServerAddress == null)
                        {
                            throw new StepExecutionException($"[SecondaryUnifiedConfigUrl] can not be empty or null. Please pass via config file.");
                        }
                        else
                        {
                            options.SecondaryUnifiedConfigUrl = BuildDefaultUnifiedConfigUrl(options.SecondaryAwServer.ServerAddress);
                        }

                        if (this.SecondaryUnifiedConfigUser != null)
                        {
                            options.SecondaryUnifiedConfigUser = this.SecondaryUnifiedConfigUser;
                        }

                        if (string.IsNullOrEmpty(options.SecondaryUnifiedConfigUser))
                        {
                            throw new StepExecutionException($"[SecondaryUnifiedConfigUser] can not be empty or null. Please pass via config file.");
                        }

                        if (this.SecondaryUnifiedConfigPassword != null)
                        {
                            options.SecondaryUnifiedConfigPassword = this.SecondaryUnifiedConfigPassword.ConvertToSecureString();
                        }

                        if (string.IsNullOrEmpty(options.SecondaryUnifiedConfigPassword.ConvertToUnsecureString()))
                        {
                            throw new StepExecutionException($"[SecondaryConapiRemoteRegistryPort] can not be empty or null. Please pass via config file.");
                        }

                        if (this.SecondaryUnifiedConfigTimeout.HasValue)
                        {
                            if (this.SecondaryUnifiedConfigTimeout.Value >= 0)
                            {
                                options.SecondaryUnifiedConfigTimeout = this.SecondaryUnifiedConfigTimeout.Value.ToString();
                            }
                            else
                            {
                                throw new StepExecutionException($"[SecondaryUnifiedConfigTimeout] can not be negative.");
                            }
                        }

                        if (Convert.ToInt32(options.SecondaryUnifiedConfigTimeout) < 0 || string.IsNullOrEmpty(options.SecondaryUnifiedConfigTimeout))
                        {
                            throw new StepExecutionException($"[PrimaryUnifiedConfigTimeout] can not be negative, null or empty.");
                        }

                        if (this.SecondaryConapiRemoteRegistryPort.HasValue)
                        {
                            if (this.SecondaryConapiRemoteRegistryPort.Value >= 0)
                            {
                                options.SecondaryConapiRemoteRegistryPort = Convert.ToUInt16(this.SecondaryConapiRemoteRegistryPort.Value);
                            }
                            else
                            {
                                throw new StepExecutionException($"[SecondaryConapiRemoteRegistryPort] can not be negative.");
                            }
                        }

                        if (options.SecondaryConapiRemoteRegistryPort < 0)
                        {
                            throw new StepExecutionException($"[SecondaryConapiRemoteRegistryPort] can not be negative.");
                        }

                        if (this.SecondaryConapiLocalRegistryPort.HasValue)
                        {
                            if (this.SecondaryConapiLocalRegistryPort.Value >= 0)
                            {
                                options.SecondaryConapiLocalRegistryPort = Convert.ToUInt16(this.SecondaryConapiLocalRegistryPort.Value);
                            }
                            else
                            {
                                throw new StepExecutionException($"[SecondaryConapiLocalRegistryPort] can not be negative.");
                            }
                        }

                        if (options.SecondaryConapiLocalRegistryPort < 0)
                        {
                            throw new StepExecutionException($"[SecondaryConapiLocalRegistryPort] can not be negative.");
                        }

                        if (this.SecondaryConapiLocalPort.HasValue)
                        {
                            if (this.SecondaryConapiLocalPort.Value >= 0)
                            {
                                options.SecondaryConapiLocalPort = Convert.ToUInt16(this.SecondaryConapiLocalPort.Value);
                            }
                            else
                            {
                                throw new StepExecutionException($"[SecondaryConapiLocalPort] can not be negative.");
                            }
                        }

                        if (options.SecondaryConapiLocalPort < 0)
                        {
                            throw new StepExecutionException($"[SecondaryConapiLocalPort] can not be negative.");
                        }
                    }
                }
            }
            else
            {
                throw new StepExecutionException("Invalid mode type!");
            }

            try
            {
                bool successful = IcmSetup.ConfigureIcm(clusterConfiguration, options, true, out SetupResult[] warningsAndErrors);

                if (successful)
                {
                    log.Info("Cisco UCCE wizard executed successfully.");
                }
                else
                {
                    log.Info("Cisco UCCE wizard failed.");
                    throw new StepExecutionException("Cisco UCCE wizard failed.");
                }
            }
            catch (Exception e)
            {
                log.Error("Cisco UCCE wizard failed.", e);
                throw new StepExecutionException("Cisco UCCE wizard failed.", e);
            }
        }

        /// <summary>
        /// Get database string.
        /// </summary>
        private static string GetDbConnectionString(CiscoUcceWizardChangeStep ciscoUcceWizardChangeStep)
        {
            SqlConnectionStringBuilder builder;

            if ((bool)ciscoUcceWizardChangeStep.DbIntegratedSecurity)
            {
                builder = new SqlConnectionStringBuilder
                {
                    IntegratedSecurity = (bool)ciscoUcceWizardChangeStep.DbIntegratedSecurity,
                    DataSource = ciscoUcceWizardChangeStep.PrimaryAwServerAddress
                };
            }
            else
            {
                builder = new SqlConnectionStringBuilder
                {
                    IntegratedSecurity = (bool)ciscoUcceWizardChangeStep.DbIntegratedSecurity,
                    UserID = ciscoUcceWizardChangeStep.DbUserId,
                    Password = ciscoUcceWizardChangeStep.DbPassword,
                    DataSource = ciscoUcceWizardChangeStep.PrimaryAwServerAddress
                };
            }

            return builder.ToString();
        }

        /// <summary>
        /// Build default unified config url.
        /// </summary>
        private static string BuildDefaultUnifiedConfigUrl(string awServerAddress)
        {
            UriBuilder uriBuilder = new UriBuilder();
            uriBuilder.Scheme = "https";
            uriBuilder.Host = awServerAddress;
            uriBuilder.Path = "unifiedconfig/config/";
            Uri uri = uriBuilder.Uri;

            return uri.ToString();
        }

        /// <summary>
        /// Validate Unified config url.
        /// </summary>
        private static string ValidateUnifiedConfigUrl(string url)
        {
            bool validUrl = Uri.TryCreate(url, UriKind.Absolute, out Uri uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

            if (validUrl)
            {
                return uriResult.ToString();
            }
            else
            {
                throw new StepExecutionException($"Invalid Primary or Secondary Unified Config URL format.");
            }
        }

        #endregion
    }
}