﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    /// <summary>
    /// Cluster configuration change step interface.
    /// </summary>
    public interface IClusterConfigurationChangeStep
    {
        /// <summary>
        /// All the wizard will implement this interface and override Execute().
        /// </summary>
        void Execute(IClusterConfigurationChangeExecutionContext context);
    }
}
