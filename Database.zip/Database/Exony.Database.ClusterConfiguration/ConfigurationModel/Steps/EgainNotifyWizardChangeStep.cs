﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Diagnostics;
    using Exony.Extensions;
    using System;
    using System.Linq;

    public class EgainNotifyWizardChangeStep : RunWizardChangeStep
    {
        #region Properties

        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum Mode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public Mode ModeType { get; set; }

        /// <summary>
        /// Getter Setter for resource name
        /// </summary
        public string ResourceName { get; set; }

        /// <summary>
        /// Getter Setter for new resource name.
        /// </summary
        public string NewResourceName { get; set; }

        /// <summary>
        /// Getter Setter for server name.
        /// </summary
        public string ServerName { get; set; }

        /// <summary>
        /// Getter Setter for server address.
        /// </summary
        public string ServerAddress { get; set; }

        /// <summary>
        /// Getter Setter for catalogue name.
        /// </summary
        public string CatalogueName { get; set; }

        /// <summary>
        /// Getter Setter for driver.
        /// </summary
        public string Driver { get; set; }

        /// <summary>
        /// Getter Setter for port number.
        /// </summary
        public int? PortNumber { get; set; }

        /// <summary>
        /// Getter Setter for user name.
        /// </summary
        public string UserName { get; set; }

        /// <summary>
        /// Getter Setter for password.
        /// </summary
        public string Password { get; set; }

        /// <summary>
        /// Getter Setter for SslEnabled.
        /// </summary
        public bool? SslEnabled { get; set; }

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Methods

        /// <summary>
        /// Override Execute() with egain notify server wizard process.
        /// </summary
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running Egain Notify Wizard -- Resource Name [{this.ResourceName}] -- Mode [{ this.ModeType}]");

            ClusterConfiguration clusterConfiguration = context.Manager.Configuration;
            EgainNotifyConfigurationOptions options = new EgainNotifyConfigurationOptions();

            options.ResourceName = this.ResourceName;

            if (this.ModeType == EgainNotifyWizardChangeStep.Mode.Remove)
            {
                options.ConfigurationMode = EgainPostgreConnectionConfigurationMode.Remove;

                ILogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).FirstOrDefault();
                options.ResourceId = lr.Id;
            }
            else if (this.ModeType == EgainNotifyWizardChangeStep.Mode.Add)
            {
                options.ConfigurationMode = EgainPostgreConnectionConfigurationMode.Add;

                options.Server.ServerName = this.ServerName;
                options.Server.ServerAddress = this.ServerAddress;
                options.DbCatalog = this.CatalogueName;
                options.ConnectionDriver = this.Driver;
                options.PortNumber = Convert.ToUInt16(this.PortNumber.Value);
                options.DbUserID = this.UserName;
                options.DbPassword = this.Password.ConvertToSecureString();

                if (this.SslEnabled.HasValue)
                {
                    if (this.SslEnabled.Value)
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Require;
                    }
                    else
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Allow;
                    }
                }
                else
                {
                    options.SslMode = EgainPostgreConnectionSslMode.Require;
                }

                options.PostgreVersion = EgainPostgreConnectionSetup.ServerVersion(EgainPostgreConnectionSetup.GetConnectionString(options));
                options.ConnectedMediatorResourceId = clusterConfiguration.ExonyMediatorServiceLogicalResources.FirstOrDefault().Id;
                options.Version = string.Empty;
            }
            else if (this.ModeType == EgainNotifyWizardChangeStep.Mode.Update)
            {
                options.ConfigurationMode = EgainPostgreConnectionConfigurationMode.Update;

                //Load existing egain notify logical resource using resource name from cluster and populate options with it to avoid null value being passed.
                EgainNotifyLogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).OfType<EgainNotifyLogicalResource>().FirstOrDefault();

                if (lr == null)
                {
                    log.Error($"Invalid Resource Name [{this.ResourceName}]");
                    throw new StepExecutionException($"Invalid Resource Name [{this.ResourceName}]");
                }

                options = new EgainNotifyConfigurationOptions(lr);

                if (this.NewResourceName != null)
                {
                    options.ResourceName = this.NewResourceName;
                }

                if (string.IsNullOrEmpty(options.ResourceName))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ResourceName].");
                }

                if (this.ServerName != null)
                {
                    options.Server.ServerName = this.ServerName;
                }

                if (string.IsNullOrEmpty(options.Server.ServerName))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ServerName].");
                }

                if (this.ServerAddress != null)
                {
                    options.Server.ServerAddress = this.ServerAddress;
                }

                if (string.IsNullOrEmpty(options.Server.ServerAddress))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ServerAddress].");
                }

                if (this.CatalogueName != null)
                {
                    options.DbCatalog = this.CatalogueName;
                }

                if (string.IsNullOrEmpty(options.DbCatalog))
                {
                    throw new StepExecutionException($"Can not update with null or empty [DbCatalog].");
                }

                if (this.Driver != null)
                {
                    options.ConnectionDriver = this.Driver;
                }

                if (string.IsNullOrEmpty(options.ConnectionDriver))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ConnectionDriver].");
                }

                if (this.PortNumber.HasValue)
                {
                    options.PortNumber = Convert.ToUInt16(this.PortNumber.Value);
                }

                if (options.PortNumber < 0)
                {
                    throw new StepExecutionException($"Can not update with negative port number [PortNumber].");
                }

                if (this.UserName != null)
                {
                    options.DbUserID = this.UserName;
                }

                if (string.IsNullOrEmpty(options.DbUserID))
                {
                    throw new StepExecutionException($"Can not update with null or empty [DbUserID].");
                }

                if (this.Password != null)
                {
                    options.DbPassword = this.Password.ConvertToSecureString();
                }

                if (string.IsNullOrEmpty(options.DbPassword.ConvertToUnsecureString()))
                {
                    throw new StepExecutionException($"Can not update with null or empty [DbPassword].");
                }

                if (this.SslEnabled.HasValue)
                {
                    if (this.SslEnabled.Value)
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Require;
                    }
                    else
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Allow;
                    }
                }

                options.PostgreVersion = EgainPostgreConnectionSetup.ServerVersion(EgainPostgreConnectionSetup.GetConnectionString(options));
                options.ConnectedMediatorResourceId = clusterConfiguration.ExonyMediatorServiceLogicalResources.FirstOrDefault().Id;
                options.Version = string.Empty;
            }
            else
            {
                throw new StepExecutionException("Invalid mode type!");
            }

            try
            {
                bool successful = EgainNotifySetup.ConfigureEgainNotify(clusterConfiguration, options, true, out SetupResult[] warningsAndErrors);

                if (successful)
                {
                    log.Info("Egain notify wizard executed successfully.");
                }
                else
                {
                    log.Info("Egain notify wizard failed.");
                    throw new StepExecutionException("Egain notify wizard failed.");
                }
            }
            catch (Exception e)
            {
                log.Error("Egain notify wizard failed.", e);
                throw new StepExecutionException("Egain notify wizard failed.", e);
            }
        }

        #endregion
    }
}
