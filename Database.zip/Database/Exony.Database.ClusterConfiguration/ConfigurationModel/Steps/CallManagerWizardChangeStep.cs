﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Security;
    using Exony.Database.ClusterConfiguration.CallManager;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Database.Common.Enumerations;
    using Exony.Diagnostics;
    using Exony.Extensions;

    /// <summary>
    /// CallManager Wizard Execution class.
    /// </summary>
    public class CallManagerWizardChangeStep : RunWizardChangeStep
    {
        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum Mode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public Mode ModeType { get; set; }

        /// <summary>
        /// Resource Name.
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// New Resource Name.
        /// </summary>
        public string NewResourceName { get; set; }

        /// <summary>
        /// Server Name.
        /// </summary>
        public string ServerName { get; set; }

        /// <summary>
        /// Server address.
        /// </summary>
        public string ServerAddress { get; set; }

        /// <summary>
        /// CallManager version
        /// </summary>
        public String Version { get; set; }

        /// <summary>
        /// Web service URL
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// Web service user name
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Web service password
        /// </summary>
        public String Password { get; set; }

        /// <summary>
        /// Web service command timeout
        /// </summary>
        public int Timeout { get; set; }

        /// <summary>
        /// The name of the Icms linked to this CallManager
        /// </summary>
        public List<string> LinkedIcmResourceNames { get; set; }
		
		/// <summary>
        /// Validates if the property exists in update mode.
        /// </summary>
        public HashSet<string> propertyExistValidator = new HashSet<string>();

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        /// <summary>
        /// Override Execute() with call Manager wizard process.
        /// </summary>
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running CallManager Wizard -- Resource Name [{this.ResourceName}] -- Mode [{ this.ModeType}]");

            ClusterConfiguration clusterConfiguration = context.Manager.Configuration;

            CallManagerConfigurationOptions options = new CallManagerConfigurationOptions();

            options.ResourceName = this.ResourceName;

            if (this.ModeType == CallManagerWizardChangeStep.Mode.Remove)
            {
                options.ConfigurationMode = CiscoCallManagerConfigurationMode.Remove;
               
                ILogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).FirstOrDefault();

                if (lr == null)
                {
                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                }

                options.ResourceId = lr.Id;
            }
            else if (this.ModeType == CallManagerWizardChangeStep.Mode.Update)
            {
                options.ConfigurationMode = CiscoCallManagerConfigurationMode.Update;

                CiscoCallManagerLogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).
                    OfType<CiscoCallManagerLogicalResource>().FirstOrDefault();

                if (lr == null)
                {
                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                }

                options = new CallManagerConfigurationOptions(lr);

                if (!String.IsNullOrEmpty(this.NewResourceName))
                {
                    options.ResourceName = this.NewResourceName;
                }

                if (!String.IsNullOrEmpty(this.ServerName))
                {
                    options.PrimaryServer.ServerName = this.ServerName;
                }

                if (!String.IsNullOrEmpty(this.ServerAddress))
                {
                    options.PrimaryServer.ServerAddress = this.ServerAddress;
                }

                if (propertyExistValidator.Contains("url"))
                {
                    options.Url = this.Url;
                }

                if (!String.IsNullOrEmpty(this.UserName))
                {
                    options.UserName = this.UserName;
                }

                if (!String.IsNullOrEmpty(this.Password))
                {
                    options.Password = this.Password.ConvertToSecureString();
                }

                if (propertyExistValidator.Contains("timeout"))
                {
                    options.Timeout = this.Timeout.ToString();
                }

                if (propertyExistValidator.Contains("linkedIcmResourceNames"))
                {
                    options.LinkedIcmResourceIds = GetLinkedIcmResourceIds(clusterConfiguration);
                }

                if (!String.IsNullOrEmpty(this.Version))
                {
                    try
                    {
                        options.Version = CallManager.CallManagerVersion.Parse(this.Version);
                    }
                    catch (Exception ex)
                    {
                        log.Error($"Invalid CallManager Version : {this.Version}", ex);
                        throw new StepExecutionException($"Invalid CallManager Version : {this.Version}", ex);
                    }
                }
            }
            else if (this.ModeType == CallManagerWizardChangeStep.Mode.Add)
            {
                options.ConfigurationMode = CiscoCallManagerConfigurationMode.Add;

                options.PrimaryServer.ServerName = this.ServerName;
                options.PrimaryServer.ServerAddress = this.ServerAddress;
                options.Url = this.Url;
                options.UserName = this.UserName;
                options.Password = this.Password.ConvertToSecureString();
                options.Timeout = this.Timeout.ToString();
                options.LinkedIcmResourceIds = GetLinkedIcmResourceIds(clusterConfiguration);

                try
                {
                    options.Version = CallManager.CallManagerVersion.Parse(this.Version);
                }
                catch (Exception ex)
                {
                    log.Error($"Invalid CallManager Version : {this.Version}", ex);
                    throw new StepExecutionException($"Invalid CallManager Version : {this.Version}", ex);
                }
            }
            else
            {
                throw new StepExecutionException("Invalid Mode type!");
            }

            try
            {
                bool successful = CallManagerSetup.ConfigureCallManager(clusterConfiguration, options, true, out SetupResult[] warningsAndErrors);
               
                if (successful)
                {
                    log.Info("CallManager wizard executed successfully");
                }
                else
                {
                    log.Error("CallManager wizard failed");
                    throw new StepExecutionException("CallManager wizard failed");
                }
            }
            catch (Exception ex)
            {
                log.Error("CallManager wizard failed", ex);
                throw new StepExecutionException("CallManager wizard failed", ex);
            }
        }

        /// <summary>
        /// Returns the resource Id(s) of the Icm that are to be linked to the CallManager.
        /// </summary>
        private List<Guid> GetLinkedIcmResourceIds(ClusterConfiguration clusterConfiguration)
        {
            HashSet<Guid> linkedIcmResourceIds = new HashSet<Guid>();

            if (this.LinkedIcmResourceNames == null)
            {
                return linkedIcmResourceIds.ToList();
            }

            foreach (String currentResourceName in this.LinkedIcmResourceNames)
            {
                if (String.IsNullOrWhiteSpace(currentResourceName))
                {
                    continue;
                }

                ILogicalResource icmLogicalResource = clusterConfiguration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm)
                    && lr.Name.Equals(currentResourceName)).FirstOrDefault();

                if (icmLogicalResource == null)
                {
                    throw new StepExecutionException($"Specified ICM resource name [{currentResourceName}] could not be found");
                }

                linkedIcmResourceIds.Add(icmLogicalResource.Id);
            }

            return linkedIcmResourceIds.ToList();
        }
    }
}


