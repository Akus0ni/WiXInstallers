﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

using Exony.Database.ClusterConfiguration;
using System;

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Security;
    using Exony.Database.ClusterConfiguration.Avaya;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Database.Common.Enumerations;
    using Exony.Diagnostics;
    using Exony.Extensions;

    /// <summary>
    /// Avaya Wizard Execution class.
    /// </summary>
    public class AvayaWizardChangeStep : RunWizardChangeStep
    {
        #region properties
        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum Mode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public Mode ModeType { get; set; }

        /// <summary>
        /// Resource Name.
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// New Resource Name.
        /// </summary>
        public string NewResourceName { get; set; }

        /// <summary>
        /// Avaya version
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Server Name of Avaya.
        /// </summary>
        public string ServerName { get; set; }

        /// <summary>
        /// Server address of Avaya.
        /// </summary>
        public string ServerAddress { get; set; }

        /// <summary>
        /// UserName of Avaya.
        /// </summary>
        public string UserName { get;  set; }

        /// <summary>
        /// Password of Avaya.
        /// </summary>
        public string Password { get;  set; }

        /// <summary>
        /// Instance Name of Avaya server.
        /// </summary>
        public string InstanceName { get; set; }

        /// <summary>
        /// Protocol of Avaya server.
        /// </summary>
        public string Protocol { get; set; }

        /// <summary>
        /// Informix catalog
        /// </summary>
        public string Catalog { get; set; }

        /// <summary>
        /// Validates if the property exists in update mode.
        /// </summary>
        public ISet<string> FieldsToUpdate = new HashSet<string>();

        /// <summary>
        /// The id of the connected mediator resource for import.
        /// </summary>
        public string ConnectedMediatorResourceName { get; set; }

        /// <summary>
        /// The timezone display name for the avaya server.
        /// </summary>
        public string TimeZoneDisplayName { get; set; }

        /// <summary>
        /// The service number.
        /// </summary>
        public int Service { get; set; }

        /// <summary>
        /// The timezone Id.
        /// </summary>
        public string TimeZoneId { get; private set; }

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        /// <summary>
        /// Override Execute() with Avaya wizard process.
        /// </summary>

        #endregion

        #region Methods

        /// <summary>
        /// Execute step.
        /// </summary>
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running Avaya Wizard -- Resource Name [{this.ResourceName}] -- Mode [{ this.ModeType}]");

            ClusterConfiguration clusterConfiguration = context.Manager.Configuration;

            AvayaConfigurationOptions configAvayaOptions = new AvayaConfigurationOptions();

            if (this.ModeType == AvayaWizardChangeStep.Mode.Remove)
            {
                configAvayaOptions.ConfigurationMode = AvayaConfigurationMode.Remove;

                ILogicalResource avayaLogicalResource = clusterConfiguration.LogicalResources.
                    Where(res => res.Name == this.ResourceName).FirstOrDefault();

                if (avayaLogicalResource == null)
                {
                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                }

                configAvayaOptions.ResourceId = avayaLogicalResource.Id;
            }
            else if (this.ModeType == AvayaWizardChangeStep.Mode.Add)
            {
                configAvayaOptions.ConfigurationMode = AvayaConfigurationMode.Add;

                configAvayaOptions.ResourceName = this.ResourceName;

                try
                {
                    configAvayaOptions.Version = Convert.ToInt32(AvayaVersion.Parse(this.Version));
                }
                catch (Exception ex)
                {
                    log.Error($"Invalid Avaya Version : {this.Version}", ex);
                    throw new StepExecutionException($"Invalid Avaya Version : {this.Version}", ex);
                }

                this.TimeZoneId = GetTimeZoneId();

                if (this.TimeZoneId == null)
                {
                    log.Error($"Invalid TimeZone Name : {this.TimeZoneDisplayName}");
                    throw new StepExecutionException($"Invalid TimeZone Name : {this.TimeZoneDisplayName}");
                }

                configAvayaOptions.TimezonId = this.TimeZoneId;
                configAvayaOptions.PrimaryServer.ServerName = this.ServerName;
                configAvayaOptions.PrimaryServer.ServerAddress = this.ServerAddress;
                configAvayaOptions.InstanceName = this.InstanceName;

                if (this.Protocol != null)
                {
                    bool validProtocol = true;

                    validProtocol = AvayaProtocol.Parse(this.Protocol);

                    if (!validProtocol)
                    {
                        log.Error($"Invalid Protocol : {this.Protocol}");
                        throw new StepExecutionException($"Invalid Protocol : {this.Protocol}");
                    }
                }

                configAvayaOptions.Protocol = this.Protocol;

                configAvayaOptions.Service = this.Service;
                configAvayaOptions.UserName = this.UserName;
                configAvayaOptions.Password = this.Password.ConvertToSecureString();
                configAvayaOptions.Catalog = this.Catalog;
                configAvayaOptions.ConnectedMediatorResourceId = GetConnectedMediatorResourceId(clusterConfiguration);
            }
            else if (this.ModeType == AvayaWizardChangeStep.Mode.Update)
            {
                AvayaCmsLogicalResource logicalResourceToUpdate = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).
                    OfType<AvayaCmsLogicalResource>().FirstOrDefault();

                if (logicalResourceToUpdate == null)
                {
                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                }

                configAvayaOptions = new AvayaConfigurationOptions(logicalResourceToUpdate);

                configAvayaOptions.ConfigurationMode = AvayaConfigurationMode.Update;

                if (logicalResourceToUpdate == null)
                {
                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                }

                if (this.FieldsToUpdate.Contains(nameof(this.NewResourceName)))
                {
                    configAvayaOptions.ResourceName = this.NewResourceName;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Version)))
                {
                    try
                    {
                        configAvayaOptions.Version = Convert.ToInt32(AvayaVersion.Parse(this.Version));
                    }
                    catch (Exception ex)
                    {
                        log.Error($"Invalid Avaya Version : {this.Version}", ex);
                        throw new StepExecutionException($"Invalid Avaya Version : {this.Version}", ex);
                    }
                }

                if (this.FieldsToUpdate.Contains(nameof(this.TimeZoneDisplayName)))
                {
                    this.TimeZoneId = GetTimeZoneId();

                    if (this.TimeZoneId == null)
                    {
                        log.Error($"Invalid TimeZone Name : {this.TimeZoneDisplayName}");
                        throw new StepExecutionException($"Invalid TimeZone Display Name : {this.TimeZoneDisplayName}");
                    }

                    configAvayaOptions.TimezonId = this.TimeZoneId;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.ServerName)))
                {
                    configAvayaOptions.PrimaryServer.ServerName = this.ServerName;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.ServerAddress)))
                {
                    configAvayaOptions.PrimaryServer.ServerAddress = this.ServerAddress;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.InstanceName)))
                {
                    configAvayaOptions.InstanceName = this.InstanceName;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Protocol)))
                {
                    if (this.Protocol != null)
                    {
                        bool validProtocol = true;

                        validProtocol = AvayaProtocol.Parse(this.Protocol);

                        if (!validProtocol)
                        {
                            log.Error($"Invalid Protocol : {this.Protocol}");
                            throw new StepExecutionException($"Invalid Protocol : {this.Protocol}");
                        }
                    }
                    
                    configAvayaOptions.Protocol = this.Protocol;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Service)))
                {
                    configAvayaOptions.Service = this.Service;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.UserName)))
                {
                    configAvayaOptions.UserName = this.UserName;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Password)))
                {
                    configAvayaOptions.Password = this.Password.ConvertToSecureString();
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Catalog)))
                {
                    configAvayaOptions.Catalog = this.Catalog;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.ConnectedMediatorResourceName)))
                {
                    configAvayaOptions.ConnectedMediatorResourceId = this.GetConnectedMediatorResourceId(clusterConfiguration);
                }
            }
            else
            {
                throw new StepExecutionException("Invalid Mode type!");
            }

            bool successful = false;

            try
            {
                successful = AvayaSetup.ConfigureAvaya(clusterConfiguration, configAvayaOptions, true, out SetupResult[] warningsAndErrors);

                if (successful)
                {
                    log.Info("Avaya wizard executed successfully");
                }
                else
                {
                    log.Error("Avaya wizard execution has failed");
                    throw new StepExecutionException("Avaya wizard execution has failed");
                }
            }
            catch (Exception ex)
            {
                log.Error("Avaya wizard execution has failed", ex);
                throw new StepExecutionException("Avaya wizard execution has failed", ex);
            }
        }

        /*
         * Gets the mediator resource id from the mediator resource name. 
         */
        private Guid? GetConnectedMediatorResourceId(ClusterConfiguration clusterConfiguration)
        {
            if (!String.IsNullOrWhiteSpace(this.ConnectedMediatorResourceName))
            {
                ILogicalResource mediatorLogicalResource = clusterConfiguration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyMediatorService)
                    && lr.Name.Equals(this.ConnectedMediatorResourceName)).FirstOrDefault();

                if (mediatorLogicalResource == null)
                {
                    throw new StepExecutionException($"Specified mediator resource name [{this.ConnectedMediatorResourceName}] could not be found");
                }

                return mediatorLogicalResource.Id;
            }

            return null;
        }

        /*
         * Gets the time zone Id from the display name. 
         */
        private string GetTimeZoneId()
        {
            string requiredId = null;

            foreach (TimeZoneInfo tzInfo in TimeZoneInfo.GetSystemTimeZones()) {

                if (String.Equals(this.TimeZoneDisplayName, tzInfo.DisplayName))
                {
                    requiredId = tzInfo.Id;
                }
            }

            return requiredId;
        }
    }
        #endregion
}


