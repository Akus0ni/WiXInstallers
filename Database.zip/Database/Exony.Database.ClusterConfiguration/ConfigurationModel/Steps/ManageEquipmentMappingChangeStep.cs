﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Database.Common;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.Common.Folders;
    using Exony.Diagnostics;
    using static Exony.Database.ClusterConfiguration.ConfigurationModel.DbDataAdapter;

    public class ManageEquipmentMappingChangeStep : AbstractClusterConfigurationChangeStep
    {
        #region Properties

        /// <summary>
        /// Enum for mode of equipment mapping.
        /// </summary>
        public enum Mode
        {
            Add
        }

        /// <summary>
        /// Getter setter resource name.
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// Getter setter for tenant name.
        /// </summary>
        public string TenantName { get; set; }

        /// <summary>
        /// Getter setter for defaultimport location.
        /// </summary>
        public bool DefaultImportLocation { get; set; }

        /// <summary>
        /// Getter setter for remote tenant Id.
        /// </summary>
        public string RemoteTMTenantId { get; set; }

        /// <summary>
        /// Logger for this class.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Methods

        /// <summary>
        /// Override execute to map equipment.
        /// </summary>
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Mapping equipment for tenant [{this.TenantName}] on resource [{this.ResourceName}].");
            context.Manager.Save();
            context.Manager.Refresh(false);
            ClusterConfiguration clusterConfiguration = context.Manager.Configuration; 
            ILogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).FirstOrDefault();
            
            if (lr == null)
            {
                throw new ArgumentException($"Could not find logical resource [{this.ResourceName}].");
            }

            string fullPath = $"/{this.TenantName}";
            Folder folder = context.DataAdapter.GetFolderByPath(fullPath);

            ImportRuleFolderMapping folderMapping = new ImportRuleFolderMapping(lr, folder);
            folderMapping.Enabled = true;

            
            switch (lr.ResourceType.InternalName)
            {
                case WellKnownClusterResourceTypes.EgainVirtualAssistantServer:
                    //Default Import location will always be false for VA.
                    folderMapping.DefaultImportLocation = false;
                    this.ExecuteVaTenantFolderMapping(context, lr, folder, folderMapping);

                    break;
                default:
                    if (DefaultImportLocation)
                    {
                        folderMapping.DefaultImportLocation = true;
                        ILogicalResourceFolderMapping resourceMapping = LogicalResourceFolderMappingFactory.CreateLogicalResourceFolderMapping(
                        LogicalResourceFolderMappingType.ImportRule, folderMapping.LogicalResource, folder, Guid.Empty);
                        resourceMapping.Enabled = true;
                        resourceMapping = folderMapping;

                        clusterConfiguration.ImportClusterObject(resourceMapping, false);
                        log.Info("Equipment Mapping [Success].");
                    }
                    break;
            }
        }

        private void ExecuteVaTenantFolderMapping(IClusterConfigurationChangeExecutionContext context, ILogicalResource lr, Folder folder, ImportRuleFolderMapping folderMapping)
        {
            if (string.IsNullOrEmpty(this.RemoteTMTenantId))
            {
                throw new ArgumentException("Tenant Account Id must be specified.");
            }
            //set dimension type to tenant.
            DimensionType dimensionType = DimensionType.Tenant;
            
            ILogicalResourceFolderMapping lrfm = lr.FolderMappings.Where(res => res.FolderId.Equals(folder.Id)).FirstOrDefault();
            //validate if folder mapping is already there then skip the mapping.
            if (lrfm != null && lrfm is ImportRuleFolderMapping && ((ImportRuleFolderMapping)lrfm).RemoteTenantBusinessUrn != null)
            {
                log.Warning(string.Format("The customer resource mapping is already present for the provided tenant [{0}]. Skipping the mapping for Tenant Account Id [{1}]", this.TenantName, this.RemoteTMTenantId));
                return;
            }

            //get the connection string to VA db
            var options = new EgainVirtualAssistantConfigurationOptions(lr as EgainVirtualAssistantLogicalResource);
            string connectionString = EgainVirtualAssistantSetup.GetConnectionString(options);
            //fetch the data from VA db
            DataTable sourceResult = context.DataAdapter.GetTenantDetailsFromVaSource(connectionString, this.RemoteTMTenantId);
            decimal tenantPkey1 = -1;
            string tenantName = string.Empty;
            string description = string.Empty;
            DataRow tenantDetails = sourceResult.AsEnumerable().FirstOrDefault();
            if (tenantDetails != null)
            {
                tenantPkey1 = Convert.ToDecimal((long)tenantDetails["tenant_id"]);
                tenantName = (string)tenantDetails["username"];
                description = (tenantDetails["description"] as string) ?? string.Empty;
            }
            //if no results found on the source VA db then log an error.
            if (tenantPkey1 == -1)
            {
                log.Error(string.Format("No matching tenant with account id [{0}] found.", this.RemoteTMTenantId));
                return;
            }

            //fetch the tenant dimension if already imported from va to analytics db.
            ResourceTenantInfo resourceTenantInfo = context.DataAdapter.LoadResourceForVaTenant(lr.Id, dimensionType, tenantPkey1, tenantName);

            //if not imported then try importing dimension from VA server
            if (resourceTenantInfo == null)
            {
                //back dated effective from date.
                DateTime effectiveFrom = new DateTime(2000, 1, 1);
                
                //Get the default folder and owner ids if present for this cluster resource.
                Guid defaultFolderId;
                Guid? defaultOwnerId = null;
                context.DataAdapter.GetDefaultFolderAndOwnerIds(lr.Id, out defaultFolderId, out defaultOwnerId);

                // Insert the tenant dimension..
                int tenantDimUrn = context.DataAdapter.InsertTenantDim(tenantName, description, effectiveFrom, defaultFolderId, defaultOwnerId);
                int tenantPkeyMapUrn = context.DataAdapter.InsertTenantDimPkeyMap(lr.Id, tenantDimUrn, tenantName, description, tenantPkey1, effectiveFrom);

                //Add these to the ResourceTenantInfo object created above
                resourceTenantInfo = new ResourceTenantInfo()
                {
                    BusinessUrn = tenantDimUrn,
                    InternalName = tenantName,
                    DimensionType = DimensionType.Tenant
                };
            }
            
            //if(resourceTenantInfo.BusinessUrn != null)
            {
                //perform the equipment mapping.
                folderMapping.RemoteTenantBusinessUrn = resourceTenantInfo.BusinessUrn;
                ILogicalResourceFolderMapping resourceMapping = LogicalResourceFolderMappingFactory.CreateLogicalResourceFolderMapping(
            LogicalResourceFolderMappingType.ImportRule, folderMapping.LogicalResource, folder, Guid.Empty);
                resourceMapping.Enabled = true;
                resourceMapping = folderMapping;

                context.Manager.Configuration.ImportClusterObject(resourceMapping, false);
                log.Info("Equipment Mapping [Success].");
            }
        }

        private bool IsBowWaveImport(IClusterConfigurationChangeExecutionContext context, DateTime createdDate)
        {
            int bowWaveDuration = TypeConversion.ConvertType<int>(context.DataAdapter.FetchPropertyDetails("PROP_BOW_WAVE_DURATION_HOURS"));
            DateTime endOfBowWavePeriod = createdDate + TimeSpan.FromHours(bowWaveDuration);
            bool isBowWave = endOfBowWavePeriod > DateTime.UtcNow;
            return isBowWave;
        }
        #endregion
    }
}
