﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Diagnostics;
    using Exony.Extensions;

    /// <summary>
    /// Egain Wizard Execution class.
    /// </summary>
    public class EgainWizardChangeStep : RunWizardChangeStep
    {
        #region Properties

        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum Mode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public Mode ModeType { get; set; }

        /// <summary>
        /// Resource Name.
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// New Resource Name used to update.
        /// </summary>
        public string NewResourceName { get; set; }

        /// <summary>
        /// Server Name.
        /// </summary>
        public string ServerName { get; set; }

        /// <summary>
        /// Server address.
        /// </summary>
        public string ServerAddress { get; set; }

        /// <summary>
        /// Active DB catalog.
        /// </summary>
        public string ActiveDbCatalog { get; set; }

        /// <summary>
        /// Active DB user id.
        /// </summary>
        public string ActiveDbUserId { get; set; }

        /// <summary>
        /// Active DB password.
        /// </summary>
        public string ActiveDbPassword { get; set; }

        /// <summary>
        /// Active DB integrated security flag.
        /// </summary>
        public bool? ActiveIntegratedSecurity { get; set; }

        /// <summary>
        /// The Generative AI configuration flag
        /// </summary>
        public bool? IsAiComponentConfigured { get; set; }

        /// <summary>
        /// The Generative AI Server Name
        /// </summary>
        public string AiComponentServerName { get; set; }

        /// <summary>
        /// The Generative AI Server Address
        /// </summary>
        public string AiComponentServerAddress { get; set; }

        /// <summary>
        /// The Generative AI Db Catalogue Name
        /// </summary>
        public string AiDbCatalogueName { get; set; }

        /// <summary>
        /// The Generative AI Database User Name
        /// </summary>
        public string AiDbUserName { get; set; }

        /// <summary>
        /// The Generative AI Database Password
        /// </summary>
        public string AiDbPassword { get; set; }

        /// <summary>
        /// The Generative AI Database Connection Port
        /// </summary>
        public int? AiDbConnectionPort { get; set; }

        /// <summary>
        /// The Generative AI Database Driver
        /// </summary>
        public string AiDbDriver { get; set; }

        /// <summary>
        /// The Generative AI Database SSL Enabled flag
        /// </summary>
        public bool? AiDbSslEnabled { get; set; }

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Methods

        /// <summary>
        /// Override Execute() with egain server wizard process.
        /// </summary>
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running Egain Wizard -- Resource Name [{this.ResourceName}] -- Mode [{ this.ModeType}]");

            ClusterConfiguration clusterConfiguration = context.Manager.Configuration;
            EgainConfigurationOptions options = new EgainConfigurationOptions();

            options.ResourceName = this.ResourceName;

            if (this.ModeType == EgainWizardChangeStep.Mode.Remove)
            {
                options.ConfigurationMode = EgainConfigurationMode.Remove;

                ILogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).FirstOrDefault();
                options.ResourceId = lr.Id;
            }
            else if (this.ModeType == EgainWizardChangeStep.Mode.Add)
            {
                options.ConfigurationMode = EgainConfigurationMode.Add;
                options.ActiveDbPrimaryServer.ServerName = this.ServerName;
                options.ActiveDbPrimaryServer.ServerAddress = this.ServerAddress;
                options.ActiveDbCatalog = this.ActiveDbCatalog;
                options.ActiveIntegratedSecurity = this.ActiveIntegratedSecurity ?? true;
                options.IsAiComponentConfigured = this.IsAiComponentConfigured ?? false;

                //Check for integrated sql connection.
                if (!options.ActiveIntegratedSecurity)
                {
                    options.ActiveDbUserID = this.ActiveDbUserId;
                    options.ActiveDbPassword = this.ActiveDbPassword.ConvertToSecureString();
                } 
                else
                {
                    options.ActiveDbUserID = String.Empty;
                    options.ActiveDbPassword = String.Empty.ConvertToSecureString();
                }

                //Check for AI component configuration.
                if(options.IsAiComponentConfigured)
                {
                    options.Server.ServerName = this.AiComponentServerName;
                    options.Server.ServerAddress = this.AiComponentServerAddress;
                    options.DbCatalog = this.AiDbCatalogueName;
                    options.DbUserID = this.AiDbUserName;
                    options.DbPassword.SetString(this.AiDbPassword);
                    options.PortNumber = Convert.ToUInt16(this.AiDbConnectionPort);
                    options.ConnectionDriver = this.AiDbDriver;
                    if (this.AiDbSslEnabled.HasValue)
                    {
                        if (this.AiDbSslEnabled.Value)
                        {
                            options.SslMode = EgainPostgreConnectionSslMode.Require;
                        }
                        else
                        {
                            options.SslMode = EgainPostgreConnectionSslMode.Allow;
                        }
                    }
                    else
                    {
                        options.SslMode = EgainPostgreConnectionSslMode.Require;
                    }
                    options.PostgreVersion = EgainPostgreConnectionSetup.ServerVersion(EgainPostgreConnectionSetup.GetConnectionString(options));
                }

                options = EgainSetup.CompleteConfiguration(options);
            }
            else if (this.ModeType == EgainWizardChangeStep.Mode.Update)
            {
                options.ConfigurationMode = EgainConfigurationMode.Update;

                //Load existing egain logical resource using resource name from cluster and populate options with it to avoid null value being passed.
                EgainLogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).OfType<EgainLogicalResource>().FirstOrDefault();

                if (lr == null)
                {
                    log.Error($"Invalid Resource Name [{this.ResourceName}]");
                    throw new StepExecutionException($"Invalid Resource Name [{this.ResourceName}]");
                }

                options = new EgainConfigurationOptions(lr);

                if (this.NewResourceName != null)
                {
                    options.ResourceName = this.NewResourceName;
                }

                if (this.ServerName != null)
                {
                    options.ActiveDbPrimaryServer.ServerName = this.ServerName;
                }

                if (string.IsNullOrEmpty(options.ActiveDbPrimaryServer.ServerName))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ActiveDbPrimaryServerName].");
                }

                if (this.ServerAddress != null)
                {
                    options.ActiveDbPrimaryServer.ServerAddress = this.ServerAddress;
                }

                if (string.IsNullOrEmpty(options.ActiveDbPrimaryServer.ServerAddress))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ActiveDbPrimaryServerAddress].");
                }

                if (this.ActiveDbCatalog != null)
                {
                    options.ActiveDbCatalog = this.ActiveDbCatalog;
                }

                if (string.IsNullOrEmpty(options.ActiveDbCatalog))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ActiveDbCatalog].");
                }

                if (this.ActiveIntegratedSecurity.HasValue)
                {
                    options.ActiveIntegratedSecurity = this.ActiveIntegratedSecurity.Value;
                }

                if (!options.ActiveIntegratedSecurity)
                {
                    if (this.ActiveDbUserId != null)
                    {
                        options.ActiveDbUserID = this.ActiveDbUserId;
                    }

                    if (string.IsNullOrEmpty(options.ActiveDbUserID))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [ActiveDbUserID].");
                    }

                    if (this.ActiveDbPassword != null)
                    {
                        options.ActiveDbPassword = this.ActiveDbPassword.ConvertToSecureString();
                    }

                    if (string.IsNullOrEmpty(options.ActiveDbPassword.ConvertToUnsecureString()))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [ActiveDbPassword].");
                    }
                }

                if (this.IsAiComponentConfigured.HasValue)
                {
                    options.IsAiComponentConfigured = this.IsAiComponentConfigured.Value;
                }

                if(this.IsAiComponentConfigured.Value)
                {
                    if (this.AiComponentServerName != null)
                    {
                        options.Server.ServerName = this.AiComponentServerName;
                    }

                    if (string.IsNullOrEmpty(options.Server.ServerName))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [aiComponentServerName].");
                    }

                    if (this.AiComponentServerAddress != null)
                    {
                        options.Server.ServerAddress = this.AiComponentServerAddress;
                    }

                    if (string.IsNullOrEmpty(options.Server.ServerAddress))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [aiComponentServerAddress].");
                    }

                    if (this.AiDbCatalogueName != null)
                    {
                        options.DbCatalog = this.AiDbCatalogueName;
                    }

                    if (string.IsNullOrEmpty(options.DbCatalog))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [aiDbCatalogueName].");
                    }

                    if (this.AiDbDriver != null)
                    {
                        options.ConnectionDriver = this.AiDbDriver;
                    }

                    if (string.IsNullOrEmpty(options.ConnectionDriver))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [aiDbDriver].");
                    }

                    if (this.AiDbConnectionPort.HasValue)
                    {
                        options.PortNumber = Convert.ToUInt16(this.AiDbConnectionPort.Value);
                    }

                    if (options.PortNumber < 0)
                    {
                        throw new StepExecutionException($"Can not update with negative port number [aiDbConnectionPort].");
                    }

                    if (this.AiDbUserName != null)
                    {
                        options.DbUserID = this.AiDbUserName;
                    }

                    if (string.IsNullOrEmpty(options.DbUserID))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [aiDbUserName].");
                    }

                    if (this.AiDbPassword != null)
                    {
                        options.DbPassword = this.AiDbPassword.ConvertToSecureString();
                    }

                    if (string.IsNullOrEmpty(options.DbPassword.ConvertToUnsecureString()))
                    {
                        throw new StepExecutionException($"Can not update with null or empty [aiDbPassword].");
                    }

                    if (this.AiDbSslEnabled.HasValue)
                    {
                        if (this.AiDbSslEnabled.Value)
                        {
                            options.SslMode = EgainPostgreConnectionSslMode.Require;
                        }
                        else
                        {
                            options.SslMode = EgainPostgreConnectionSslMode.Allow;
                        }
                    }
                    options.PostgreVersion = EgainPostgreConnectionSetup.ServerVersion(EgainPostgreConnectionSetup.GetConnectionString(options));
                }

                options = EgainSetup.CompleteConfiguration(options);
            }
            else
            {
                throw new StepExecutionException("Invalid mode type!");
            }

            try
            {
                bool successful = EgainSetup.ConfigureEgain(clusterConfiguration, options, true, out SetupResult[] warningsAndErrors);

                if (successful)
                {
                    log.Info("Egain wizard execution complete.");
                }
                else
                {
                    log.Info("Egain wizard failed.");
                    throw new StepExecutionException("Egain wizard failed.");
                }
            }
            catch (Exception e)
            {
                log.Error("Egain wizard failed.", e);
                throw new StepExecutionException("Egain wizard failed.", e);
            }
        }

        #endregion
    }
}