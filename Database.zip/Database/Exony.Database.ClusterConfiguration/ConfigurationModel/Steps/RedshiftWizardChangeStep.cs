﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Diagnostics;
    using Exony.Extensions;
    using System;
    using System.Linq;

    public class RedshiftWizardChangeStep : RunWizardChangeStep
    {
        #region Properties

        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum Mode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public Mode ModeType { get; set; }

        /// <summary>
        /// Getter Setter for resource name
        /// </summary
        public string ResourceName { get; set; }

        /// <summary>
        /// Getter Setter for new resource name.
        /// </summary
        public string NewResourceName { get; set; }

        /// <summary>
        /// Getter Setter for server name.
        /// </summary
        public string ServerName { get; set; }

        /// <summary>
        /// Getter Setter for server address.
        /// </summary
        public string ServerAddress { get; set; }

        /// <summary>
        /// Getter Setter for catalogue name.
        /// </summary
        public string CatalogueName { get; set; }

        /// <summary>
        /// Getter Setter for driver.
        /// </summary
        public string Driver { get; set; }

        /// <summary>
        /// Getter Setter for port number.
        /// </summary
        public int? PortNumber { get; set; }

        /// <summary>
        /// Getter Setter for user name.
        /// </summary
        public string UserName { get; set; }

        /// <summary>
        /// Getter Setter for password.
        /// </summary
        public string Password { get; set; }

        /// <summary>
        /// Getter Setter for IsIAMBasedAuthentication.
        /// </summary
        public bool? IsIAMBasedAuthentication { get; set; }

        /// <summary>
        /// Getter Setter for TenantName.
        /// </summary
        public string TenantName { get; set; }

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Methods

        /// <summary>
        /// Override Execute() with redshift server wizard process.
        /// </summary
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running Redshift Wizard -- Resource Name [{this.ResourceName}] -- Mode [{ this.ModeType}]");

            ClusterConfiguration clusterConfiguration = context.Manager.Configuration;
            RedshiftConnectionConfigurationOptions options = new RedshiftConnectionConfigurationOptions();

            options.ResourceName = this.ResourceName;

            if (this.ModeType == RedshiftWizardChangeStep.Mode.Remove)
            {
                options.ConfigurationMode = RedshiftConnectionConfigurationMode.Remove;

                ILogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).FirstOrDefault();
                options.ResourceId = lr.Id;
            }
            else if (this.ModeType == RedshiftWizardChangeStep.Mode.Add)
            {
                options.ConfigurationMode = RedshiftConnectionConfigurationMode.Add;

                options.Server.ServerName = this.ServerName;
                options.Server.ServerAddress = this.ServerAddress;
                options.DbCatalog = this.CatalogueName;
                options.ConnectionDriver = this.Driver;
                options.PortNumber = Convert.ToUInt16(this.PortNumber.Value);
                options.DbUserID = this.UserName;
                options.DbPassword = this.Password.ConvertToSecureString();

                if (this.IsIAMBasedAuthentication.HasValue)
                {
                    options.IsIamBasedAuthentication = this.IsIAMBasedAuthentication.Value;
                }
                else
                {
                    throw new StepExecutionException($"Can not add with null or empty [isIAMBasedAuthentication].");
                }
                options.TenantId = this.GetTenantID(context.Manager is SqlPersistanceManager ? ((SqlPersistanceManager)context.Manager).DbConnectionString : null);
                options.RedshiftVersion = RedshiftConnectionSetup.ServerVersion(RedshiftConnectionSetup.GetConnectionString(options, false));

            }
            else if (this.ModeType == RedshiftWizardChangeStep.Mode.Update)
            {
                options.ConfigurationMode = RedshiftConnectionConfigurationMode.Update;

                //Load existing redshift Db logical resource using resource name from cluster and populate options with it to avoid null value being passed.
                RedshiftDatabaseLogicalResource lr = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).OfType<RedshiftDatabaseLogicalResource>().FirstOrDefault();

                if (lr == null)
                {
                    log.Error($"Invalid Resource Name [{this.ResourceName}]");
                    throw new StepExecutionException($"Invalid Resource Name [{this.ResourceName}]");
                }

                options = new RedshiftConnectionConfigurationOptions(lr);

                if (this.NewResourceName != null)
                {
                    options.ResourceName = this.NewResourceName;
                }

                if (string.IsNullOrEmpty(options.ResourceName))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ResourceName].");
                }

                if (this.ServerName != null)
                {
                    options.Server.ServerName = this.ServerName;
                }

                if (string.IsNullOrEmpty(options.Server.ServerName))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ServerName].");
                }

                if (this.ServerAddress != null)
                {
                    options.Server.ServerAddress = this.ServerAddress;
                }

                if (string.IsNullOrEmpty(options.Server.ServerAddress))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ServerAddress].");
                }

                if (this.CatalogueName != null)
                {
                    options.DbCatalog = this.CatalogueName;
                }

                if (string.IsNullOrEmpty(options.DbCatalog))
                {
                    throw new StepExecutionException($"Can not update with null or empty [DbCatalog].");
                }

                if (this.Driver != null)
                {
                    options.ConnectionDriver = this.Driver;
                }

                if (string.IsNullOrEmpty(options.ConnectionDriver))
                {
                    throw new StepExecutionException($"Can not update with null or empty [ConnectionDriver].");
                }

                if (this.PortNumber.HasValue)
                {
                    options.PortNumber = Convert.ToUInt16(this.PortNumber.Value);
                }

                if (options.PortNumber < 0)
                {
                    throw new StepExecutionException($"Can not update with negative port number [PortNumber].");
                }

                if (this.UserName != null)
                {
                    options.DbUserID = this.UserName;
                }

                //if (string.IsNullOrEmpty(options.DbUserID))
                //{
                //    throw new StepExecutionException($"Can not update with null or empty [DbUserID].");
                //}

                if (this.Password != null)
                {
                    options.DbPassword = this.Password.ConvertToSecureString();
                }

                //if (string.IsNullOrEmpty(options.DbPassword.ConvertToUnsecureString()))
                //{
                //    throw new StepExecutionException($"Can not update with null or empty [DbPassword].");
                //}

                if (this.IsIAMBasedAuthentication.HasValue)
                {
                    if (this.IsIAMBasedAuthentication.Value)
                    {
                        options.IsIamBasedAuthentication = true;
                    }
                    else
                    {
                        options.IsIamBasedAuthentication = false;
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(options.DbUserID) && !string.IsNullOrEmpty(options.DbPassword.ConvertToUnsecureString()))
                    {
                        options.IsIamBasedAuthentication = false;
                    }
                    else
                    {
                        options.IsIamBasedAuthentication = true;
                    }
                }

                if (!string.IsNullOrEmpty(TenantName))
                {
                    options.TenantId = this.GetTenantID(context.Manager is SqlPersistanceManager ? ((SqlPersistanceManager)context.Manager).DbConnectionString : null);
                }

                options.RedshiftVersion = RedshiftConnectionSetup.ServerVersion(RedshiftConnectionSetup.GetConnectionString(options, false));
            }
            else
            {
                throw new StepExecutionException("Invalid mode type!");
            }

            try
            {
                bool successful = RedshiftConnectionSetup.ConfigureRedshift(clusterConfiguration, options, true, out SetupResult[] warningsAndErrors);

                if (successful)
                {
                    log.Info("Redshift wizard executed successfully.");
                }
                else
                {
                    log.Info("Redshift wizard failed.");
                    throw new StepExecutionException("Redshift wizard failed.");
                }
            }
            catch (Exception e)
            {
                log.Error("Redshift wizard failed.", e);
                throw new StepExecutionException("Redshift wizard failed.", e);
            }
        }

        private Guid? GetTenantID(string connString)
        {
            if (!string.IsNullOrEmpty(this.TenantName) && !string.IsNullOrEmpty(connString))
            {
                Guid? tenantId = null;
                // Get All the tenants from the database.
                var tenants = SqlPersistanceManager.GetAllTenants(connString);

                // Get the tenant id from the tenant name.
                tenantId = tenants.Where(t => t.Name == this.TenantName)?.Select(t => t.Id)?.FirstOrDefault();

                return tenantId;
            }
            return null;
        }

        #endregion
    }
}
