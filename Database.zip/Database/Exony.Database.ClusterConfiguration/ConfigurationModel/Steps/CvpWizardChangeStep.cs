﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Steps
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Security;
    using Exony.Database.ClusterConfiguration.Cvp;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.PhysicalConnections;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Database.Common.Enumerations;
    using Exony.Diagnostics;
    using Exony.Extensions;

    /// <summary>
    /// Cvp Wizard Execution class.
    /// </summary>
    public class CvpWizardChangeStep : RunWizardChangeStep
    {
        #region properties
        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum Mode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public Mode ModeType { get; set; }

        /// <summary>
        /// Resource Name.
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// New Resource Name.
        /// </summary>
        public string NewResourceName { get; set; }

        /// <summary>
        /// Cvp version
        /// </summary>
        public String Version { get; set; }

        /// <summary>
        /// Server Name of Cvp.
        /// </summary>
        public string ServerName { get; set; }

        /// <summary>
        /// Server address of Cvp.
        /// </summary>
        public string ServerAddress { get; set; }

        /// <summary>
        /// UserName of Cvp.
        /// </summary>
        public string UserName { get;  set; }

        /// <summary>
        /// Password of Cvp.
        /// </summary>
        public string Password { get;  set; }

        /// <summary>
        ///Url of Cvp.
        /// </summary>
        public string Url
        { get; set; }

        /// <summary>
        ///Timeout.
        /// </summary>
        public int? Timeout { get;  set; }

        /// <summary>
        /// The list of CallServers.
        /// </summary>
        public List<CallServer> CallServers {get; set;}

        /// <summary>
        /// The list of Reporting Servers.
        /// </summary>
        public List<ReportingServer> ReportingServers {get; set;}

        /// <summary>
        /// Validates if the property exists in update mode.
        /// </summary>
        public ISet<string> FieldsToUpdate = new HashSet<string>();
        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        /// <summary>
        /// Override Execute() with Cvp wizard process.
        /// </summary>

        #endregion

        #region Methods

        /// <summary>
        /// Execute step.
        /// </summary>
        public override void Execute(IClusterConfigurationChangeExecutionContext context)
        {
            log.Info($"Running Cvp Wizard -- Resource Name [{this.ResourceName}] -- Mode [{ this.ModeType}]");

            ClusterConfiguration clusterConfiguration = context.Manager.Configuration;

            CvpConfigurationOptions configureOperationConsoleoptions = new CvpConfigurationOptions();

            List<CvpConfigurationOptions> cvpConfigOptions = new List<CvpConfigurationOptions>();

            Guid opsConsoleResourceId;
            
            if (this.ModeType == CvpWizardChangeStep.Mode.Remove)
            {
                configureOperationConsoleoptions.ConfigurationMode = CiscoCvpConfigurationMode.Remove;
               
                ILogicalResource operationsConsoleLogicalResource = clusterConfiguration.LogicalResources.
                    Where(res => res.Name == this.ResourceName).FirstOrDefault();

                if (operationsConsoleLogicalResource == null)
                {
                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                }

                List<ILogicalResource> childServersToRemove =
                    operationsConsoleLogicalResource.ChildResourceMembers.Where(lr => lr.ChildResource.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpCallServer) ||
                        lr.ChildResource.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpReportingServer)).
                            Select(lr => lr.ChildResource).ToList();

                foreach (ILogicalResource resources in childServersToRemove)
                {
                    CvpConfigurationOptions configToRemoveChildMembers = new CvpConfigurationOptions(resources);

                    configToRemoveChildMembers.ConfigurationMode = CiscoCvpConfigurationMode.Remove;

                    cvpConfigOptions.Add(configToRemoveChildMembers);
                }

                configureOperationConsoleoptions.ResourceId = operationsConsoleLogicalResource.Id;

                try
                {
                    opsConsoleResourceId = CvpSetup.ConfigureOperationsConsole(clusterConfiguration, configureOperationConsoleoptions);

                }
                catch (Exception ex)
                {
                    log.Error("OperationsConsole configuration failed, Cvp wizard setup failed", ex);
                    throw new StepExecutionException("Cvp wizard failed", ex);
                }

                if (opsConsoleResourceId == Guid.Empty)
                {
                    log.Info("OperationsConsole successfully removed");
                }
            }
            else if (this.ModeType == CvpWizardChangeStep.Mode.Add)
            {
                configureOperationConsoleoptions.ConfigurationMode = CiscoCvpConfigurationMode.Add;

                configureOperationConsoleoptions.ResourceName = this.ResourceName;
                configureOperationConsoleoptions.PrimaryServer.ServerName = this.ServerName;
                configureOperationConsoleoptions.PrimaryServer.ServerAddress = this.ServerAddress;
                configureOperationConsoleoptions.UserName = this.UserName;
                configureOperationConsoleoptions.Password = this.Password.ConvertToSecureString();
                configureOperationConsoleoptions.Url = this.Url;
                configureOperationConsoleoptions.Timeout = this.Timeout.ToString();

                try
                {
                    CvpVersion.Parse(this.Version);
                }
                catch (Exception ex)
                {
                    log.Error($"Invalid Cvp Version : {this.Version}", ex);
                    throw new StepExecutionException($"Invalid Cvp Version : {this.Version}", ex);
                }

                configureOperationConsoleoptions.Version = this.Version;

                try
                {
                    opsConsoleResourceId = CvpSetup.ConfigureOperationsConsole(clusterConfiguration, configureOperationConsoleoptions);

                } catch (Exception ex)
                {
                    log.Error("OperationsConsole configuration failed, Cvp wizard setup failed", ex);
                    throw new StepExecutionException("Cvp wizard failed", ex);
                }

                if (this.CallServers != null)
                {
                    foreach (CallServer callServer in this.CallServers)
                    {
                        CvpConfigurationOptions configureCallServerOptions = new CvpConfigurationOptions();

                        configureCallServerOptions.ParentId = opsConsoleResourceId;

                        configureCallServerOptions.ServerType = CiscoCvpServerType.CallServer;

                        configureCallServerOptions.ResourceName = callServer.ResourceName;
                        configureCallServerOptions.PrimaryServer.ServerName = callServer.ServerName;
                        configureCallServerOptions.PrimaryServer.ServerAddress = callServer.ServerAddress;
                        configureCallServerOptions.LinkedIcmResourceId = callServer.GetLinkedIcmResourceIds(clusterConfiguration);
                        configureCallServerOptions.LinkedCvpReportingServerResourceId = callServer.GetLinkedCvpReportingServerResourceId(clusterConfiguration);

                        cvpConfigOptions.Add(configureCallServerOptions);
                    }
                }
                if (this.ReportingServers != null)
                {
                    foreach (ReportingServer reportingServer in this.ReportingServers)
                    {
                        CvpConfigurationOptions configureReportingServerOptions = new CvpConfigurationOptions();

                        configureReportingServerOptions.ParentId = opsConsoleResourceId;

                        configureReportingServerOptions.ServerType = CiscoCvpServerType.ReportingServer;

                        configureReportingServerOptions.ResourceName = reportingServer.ResourceName;
                        configureReportingServerOptions.PrimaryServer.ServerName = reportingServer.ServerName;
                        configureReportingServerOptions.PrimaryServer.ServerAddress = reportingServer.ServerAddress;
                        configureReportingServerOptions.InstanceName = reportingServer.InstanceName;
                        configureReportingServerOptions.Service = reportingServer.Service;

                        if (reportingServer.Protocol != null)
                        {
                            bool validProtocol = true;

                            validProtocol = ReportingProtocol.Parse(reportingServer.Protocol);

                            if (!validProtocol)
                            {
                                log.Error($"Invalid Protocol : {reportingServer.Protocol}");
                                throw new StepExecutionException($"Invalid Protocol : {reportingServer.Protocol}");
                            }
                        }
                        configureReportingServerOptions.Protocol = reportingServer.Protocol;

                        configureReportingServerOptions.CoreCatalog = reportingServer.CoreCatalog;
                        configureReportingServerOptions.CallbackCatalog = reportingServer.CallbackCatalog;
                        configureReportingServerOptions.UserName = reportingServer.UserName;
                        configureReportingServerOptions.Password = reportingServer.Password.ConvertToSecureString();
                        configureReportingServerOptions.LinkedCvpCallServerResourceIds = reportingServer.GetLinkedCallServerResourceIds(clusterConfiguration);
                        configureReportingServerOptions.ConnectedMediatorResourceId = reportingServer.GetConnectedMediatorResourceId(clusterConfiguration);

                        try
                        {
                            CvpSetup.CompleteConfiguration(configureReportingServerOptions);
                        }
                        catch (Exception ex)
                        {
                            log.Error("Reporting Server connection failed", ex);
                            throw new StepExecutionException("Reporting Server connection failed", ex);
                        }

                        cvpConfigOptions.Add(configureReportingServerOptions);
                    }
                }
            }
            else if (this.ModeType == CvpWizardChangeStep.Mode.Update)
            {
                configureOperationConsoleoptions.ConfigurationMode = CiscoCvpConfigurationMode.Update;

                CiscoCvpOperationsConsoleLogicalResource operationConsoleLogicalResource = clusterConfiguration.LogicalResources.Where(res => res.Name == this.ResourceName).
                    OfType<CiscoCvpOperationsConsoleLogicalResource>().FirstOrDefault();

                if (operationConsoleLogicalResource == null)
                {
                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                }

                IPhysicalResource physicalResource = operationConsoleLogicalResource.PhysicalResources.FirstOrDefault();

                if (physicalResource != null)
                {
                    var component = physicalResource.Components.FirstOrDefault();

                    if (component != null)
                    {
                        configureOperationConsoleoptions.PrimaryServer.ServerName = component.Server.ServerName;
                        configureOperationConsoleoptions.PrimaryServer.ServerAddress = component.Server.DefaultAddress;

                        WebServicePhysicalConnection webservice = (WebServicePhysicalConnection)component.InboundConnections.FirstOrDefault(s => s.ConnectionType.InternalName == WellKnownConnectionTypes.WebService);

                        if (webservice != null)
                        {
                            configureOperationConsoleoptions.Url = webservice.Url.Replace(PhysicalConnection.SINK_SERVER_MACRO, component.Server.DefaultAddress);
                            configureOperationConsoleoptions.UserName = webservice.UserName;
                            configureOperationConsoleoptions.Password = webservice.Password.ConvertToSecureString();
                            configureOperationConsoleoptions.Timeout = webservice.CommandTimeout.ToString();
                        }
                    }
                }

                configureOperationConsoleoptions.ResourceName = operationConsoleLogicalResource.Name;

                configureOperationConsoleoptions.Version = operationConsoleLogicalResource.Version;

                configureOperationConsoleoptions.ResourceId = operationConsoleLogicalResource.Id;

                if (this.FieldsToUpdate.Contains(nameof(this.NewResourceName)))
                {
                    configureOperationConsoleoptions.ResourceName = this.NewResourceName;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Url)))
                {
                    configureOperationConsoleoptions.Url = this.Url;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.UserName)))
                {
                    configureOperationConsoleoptions.UserName = this.UserName;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Password)))
                {
                    configureOperationConsoleoptions.Password = this.Password.ConvertToSecureString();
                }

                if (this.FieldsToUpdate.Contains(nameof(this.ServerName)))
                {
                    configureOperationConsoleoptions.PrimaryServer.ServerName = this.ServerName;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.ServerAddress)))
                {
                    configureOperationConsoleoptions.PrimaryServer.ServerAddress = this.ServerAddress;
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Timeout)))
                {
                    configureOperationConsoleoptions.Timeout = this.Timeout.ToString();
                }

                if (this.FieldsToUpdate.Contains(nameof(this.Version)))
                {
                    try
                    {
                        CvpVersion.Parse(this.Version);
                    }
                    catch (Exception ex)
                    {
                        log.Error($"Invalid Cvp Version : {this.Version}", ex);
                        throw new StepExecutionException($"Invalid Cvp Version : {this.Version}", ex);
                    }

                    configureOperationConsoleoptions.Version = this.Version;
                }

                try
                {
                    opsConsoleResourceId = CvpSetup.ConfigureOperationsConsole(clusterConfiguration, configureOperationConsoleoptions);
                }
                catch (Exception ex)
                {
                    log.Error("OperationsConsole configuration failed, Cvp wizard setup failed", ex);
                    throw new StepExecutionException("Cvp wizard failed", ex);
                }

                List<ILogicalResource> callServers =
                        operationConsoleLogicalResource.ChildResourceMembers.Where(lr => lr.ChildResource.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpCallServer)).
                            Select(lr => lr.ChildResource).ToList();

                if (this.FieldsToUpdate.Contains(nameof(this.CallServers)))
                {
                    if (this.CallServers != null)
                    {
                        foreach (CallServer callServer in this.CallServers)
                        {
                            CvpConfigurationOptions configureCallServerUpdateOptions = new CvpConfigurationOptions();

                            if (callServer.ModeType == CallServer.updateMode.Add)
                            {
                                configureCallServerUpdateOptions.ParentId = operationConsoleLogicalResource.Id;

                                configureCallServerUpdateOptions.ServerType = CiscoCvpServerType.CallServer;

                                configureCallServerUpdateOptions.ResourceName = callServer.ResourceName;
                                configureCallServerUpdateOptions.PrimaryServer.ServerName = callServer.ServerName;
                                configureCallServerUpdateOptions.PrimaryServer.ServerAddress = callServer.ServerAddress;
                                configureCallServerUpdateOptions.LinkedIcmResourceId = callServer.GetLinkedIcmResourceIds(clusterConfiguration);
                                configureCallServerUpdateOptions.LinkedCvpReportingServerResourceId = callServer.GetLinkedCvpReportingServerResourceId(clusterConfiguration);

                                cvpConfigOptions.Add(configureCallServerUpdateOptions);
                            }
                            else if (callServer.ModeType == CallServer.updateMode.Remove)
                            {
                                ILogicalResource logicalResourceToRemove = callServers.
                                    Where(res => res.Name == callServer.ResourceName &&
                                        res.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpCallServer)).FirstOrDefault();

                                if (logicalResourceToRemove == null)
                                {
                                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                                }

                                configureCallServerUpdateOptions = new CvpConfigurationOptions(logicalResourceToRemove);

                                configureCallServerUpdateOptions.ConfigurationMode = CiscoCvpConfigurationMode.Remove;

                                cvpConfigOptions.Add(configureCallServerUpdateOptions);
                            }
                            else if (callServer.ModeType == CallServer.updateMode.Update)
                            {
                                ILogicalResource logicalResourceToUpdate = callServers.
                                    Where(res => res.Name == callServer.ResourceName &&
                                        res.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpCallServer)).FirstOrDefault(); //add an xtra filter that internal name is reporting server

                                if (logicalResourceToUpdate == null)
                                {
                                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                                }

                                configureCallServerUpdateOptions = new CvpConfigurationOptions(logicalResourceToUpdate);

                                configureCallServerUpdateOptions.ConfigurationMode = CiscoCvpConfigurationMode.Update;

                                if (callServer.FieldsToUpdate.Contains(nameof(callServer.NewResourceName)))
                                {
                                    configureCallServerUpdateOptions.ResourceName = callServer.NewResourceName;
                                }

                                if (callServer.FieldsToUpdate.Contains(nameof(callServer.ServerName)))
                                {
                                    configureCallServerUpdateOptions.PrimaryServer.ServerName = callServer.ServerName;
                                }

                                if (callServer.FieldsToUpdate.Contains(nameof(callServer.ServerAddress)))
                                {
                                    configureCallServerUpdateOptions.PrimaryServer.ServerAddress = callServer.ServerAddress;
                                }

                                if (callServer.FieldsToUpdate.Contains(nameof(callServer.LinkedIcmResourceName)))
                                {
                                    configureCallServerUpdateOptions.LinkedIcmResourceId = callServer.GetLinkedIcmResourceIds(clusterConfiguration);
                                }

                                if (callServer.FieldsToUpdate.Contains(nameof(callServer.LinkedCvpReportingServerResourceName)))
                                {
                                    configureCallServerUpdateOptions.LinkedCvpReportingServerResourceId = callServer.GetLinkedCvpReportingServerResourceId(clusterConfiguration);
                                }

                                cvpConfigOptions.Add(configureCallServerUpdateOptions);
                            }
                            else
                            {
                                throw new StepExecutionException("Invalid callServer updateMode type!");
                            }
                        }
                    }
                    else
                    {
                        List<ILogicalResource> callServersToRemove = callServers.
                            Where(res =>
                            res.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpCallServer)).ToList();

                        foreach (LogicalResource callServer in callServersToRemove)
                        {
                            CvpConfigurationOptions configureUpdateCallServerOptions = new CvpConfigurationOptions();

                            configureUpdateCallServerOptions = new CvpConfigurationOptions(callServer);

                            configureUpdateCallServerOptions.ConfigurationMode = CiscoCvpConfigurationMode.Remove;

                            cvpConfigOptions.Add(configureUpdateCallServerOptions);
                        }
                    }
                }

                if (this.FieldsToUpdate.Contains("reportingServers"))
                {
                    List<ILogicalResource> reportingServers =
                            operationConsoleLogicalResource.ChildResourceMembers.Where(
                                lr => lr.ChildResource.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpReportingServer)).
                                    Select(lr => lr.ChildResource).ToList();

                    if (this.ReportingServers != null)
                    {
                        foreach (ReportingServer reportingServer in this.ReportingServers)
                        {
                            CvpConfigurationOptions configureUpdateReportingServerOptions = new CvpConfigurationOptions();

                            if (reportingServer.ModeType == ReportingServer.updateMode.Add)
                            {
                                configureUpdateReportingServerOptions.ParentId = operationConsoleLogicalResource.Id;

                                configureUpdateReportingServerOptions.ConfigurationMode = CiscoCvpConfigurationMode.Add;

                                configureUpdateReportingServerOptions.ServerType = CiscoCvpServerType.ReportingServer;

                                configureUpdateReportingServerOptions.ResourceName = reportingServer.ResourceName;
                                configureUpdateReportingServerOptions.PrimaryServer.ServerName = reportingServer.ServerName;
                                configureUpdateReportingServerOptions.PrimaryServer.ServerAddress = reportingServer.ServerAddress;
                                configureUpdateReportingServerOptions.InstanceName = reportingServer.InstanceName;
                                configureUpdateReportingServerOptions.Service = reportingServer.Service;

                                if (reportingServer.Protocol != null)
                                {
                                    bool validProtocol = true;

                                    validProtocol = ReportingProtocol.Parse(reportingServer.Protocol);

                                    if (!validProtocol)
                                    {
                                        log.Error($"Invalid Protocol : {reportingServer.Protocol}");
                                        throw new StepExecutionException($"Invalid Protocol : {reportingServer.Protocol}");
                                    }
                                }

                                configureUpdateReportingServerOptions.Protocol = reportingServer.Protocol; 

                                configureUpdateReportingServerOptions.CoreCatalog = reportingServer.CoreCatalog;
                                configureUpdateReportingServerOptions.CallbackCatalog = reportingServer.CallbackCatalog;
                                configureUpdateReportingServerOptions.UserName = reportingServer.UserName;
                                configureUpdateReportingServerOptions.Password = reportingServer.Password.ConvertToSecureString();
                                configureUpdateReportingServerOptions.LinkedCvpCallServerResourceIds = reportingServer.GetLinkedCallServerResourceIds(clusterConfiguration);
                                configureUpdateReportingServerOptions.ConnectedMediatorResourceId = reportingServer.GetConnectedMediatorResourceId(clusterConfiguration);

                                try
                                {
                                    CvpSetup.CompleteConfiguration(configureUpdateReportingServerOptions);
                                }
                                catch (Exception ex)
                                {
                                    log.Error("Reporting Server connection failed", ex);
                                    throw new StepExecutionException("Reporting Server connection failed", ex);
                                }

                                cvpConfigOptions.Add(configureUpdateReportingServerOptions);
                            }
                            else if (reportingServer.ModeType == ReportingServer.updateMode.Remove)
                            {
                                ILogicalResource logicalResourceToRemove = reportingServers.
                                    Where(res => res.Name == reportingServer.ResourceName).FirstOrDefault();

                                if (logicalResourceToRemove == null)
                                {
                                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                                }

                                configureUpdateReportingServerOptions = new CvpConfigurationOptions(logicalResourceToRemove);

                                configureUpdateReportingServerOptions.ConfigurationMode = CiscoCvpConfigurationMode.Remove;

                                cvpConfigOptions.Add(configureUpdateReportingServerOptions);
                            }
                            else if (reportingServer.ModeType == ReportingServer.updateMode.Update)
                            {
                                ILogicalResource logicalResourceToUpdate = reportingServers.
                                    Where(res => res.Name == reportingServer.ResourceName).FirstOrDefault();

                                if (logicalResourceToUpdate == null)
                                {
                                    log.Error($"Invalid Resource Name : {this.ResourceName}");
                                    throw new StepExecutionException($"Invalid Resource Name : {this.ResourceName}");
                                }

                                configureUpdateReportingServerOptions = new CvpConfigurationOptions(logicalResourceToUpdate);

                                configureUpdateReportingServerOptions.ConfigurationMode = CiscoCvpConfigurationMode.Update;

                                configureUpdateReportingServerOptions.ServerType = CiscoCvpServerType.ReportingServer;

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.NewResourceName)))
                                {
                                    configureUpdateReportingServerOptions.ResourceName = reportingServer.NewResourceName;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.ServerName)))
                                {
                                    configureUpdateReportingServerOptions.PrimaryServer.ServerName = reportingServer.ServerName;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.ServerAddress)))
                                {
                                    configureUpdateReportingServerOptions.PrimaryServer.ServerAddress = reportingServer.ServerAddress;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.InstanceName)))
                                {
                                    configureUpdateReportingServerOptions.InstanceName = reportingServer.InstanceName;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.Protocol)))
                                {
                                    if (reportingServer.Protocol != null)
                                    {
                                        bool validProtocol = true;

                                        validProtocol = ReportingProtocol.Parse(reportingServer.Protocol);

                                        if (!validProtocol)
                                        {
                                            log.Error($"Invalid Protocol : {reportingServer.Protocol}");
                                            throw new StepExecutionException($"Invalid Protocol : {reportingServer.Protocol}");
                                        }
                                    }

                                    configureUpdateReportingServerOptions.Protocol = reportingServer.Protocol;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.Service)))
                                { 
                                    configureUpdateReportingServerOptions.Service = reportingServer.Service;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.UserName)))
                                {
                                    configureUpdateReportingServerOptions.UserName = reportingServer.UserName;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.Password)))
                                {
                                    configureUpdateReportingServerOptions.Password = reportingServer.Password.ConvertToSecureString();
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.CoreCatalog)))
                                {
                                    configureUpdateReportingServerOptions.CoreCatalog = reportingServer.CoreCatalog;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.CallbackCatalog)))
                                {
                                    configureUpdateReportingServerOptions.CallbackCatalog = reportingServer.CallbackCatalog;
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.LinkedCvpCallServerResourceNames)))
                                {
                                    configureUpdateReportingServerOptions.LinkedCvpCallServerResourceIds = reportingServer.GetLinkedCallServerResourceIds(clusterConfiguration);
                                }

                                if (reportingServer.FieldsToUpdate.Contains(nameof(reportingServer.ConnectedMediatorResourceName)))
                                {
                                    configureUpdateReportingServerOptions.ConnectedMediatorResourceId = reportingServer.GetConnectedMediatorResourceId(clusterConfiguration);
                                }

                                try
                                {
                                    CvpSetup.CompleteConfiguration(configureUpdateReportingServerOptions);
                                }
                                catch (Exception ex)
                                {
                                    log.Error("Reporting Server connection failed", ex);
                                    throw new StepExecutionException("Reporting Server connection failed", ex);
                                }

                                cvpConfigOptions.Add(configureUpdateReportingServerOptions);
                            }
                            else
                            {
                                throw new StepExecutionException("Invalid callServer updateMode type!");
                            }
                        }
                    }
                    else
                    {
                        List<ILogicalResource> reportingServersToRemove = reportingServers.
                            Where(res => res.ResourceType.InternalName.Equals(
                                WellKnownClusterResourceTypes.CiscoCvpReportingServer)).ToList();

                        foreach (LogicalResource reportingServer in reportingServers)
                        {
                            CvpConfigurationOptions configureUpdateReportingServerOptions = new CvpConfigurationOptions();

                            configureUpdateReportingServerOptions = new CvpConfigurationOptions(reportingServer);

                            configureUpdateReportingServerOptions.ConfigurationMode = CiscoCvpConfigurationMode.Remove;

                            cvpConfigOptions.Add(configureUpdateReportingServerOptions);
                        }
                    }
                }
            }
            else
            {
                throw new StepExecutionException("Invalid Mode type!");
            }

            foreach (CvpConfigurationOptions options in cvpConfigOptions)
            {
                bool successful = false;

                try
                {
                    successful = CvpSetup.ConfigureCvp(clusterConfiguration, options, true, out SetupResult[] warningsAndErrors);

                    if (successful)
                    {
                        log.Info($"[{options.PrimaryServer.ServerName}] server executed successfully");
                    }
                    else
                    {
                        log.Error($"[{options.PrimaryServer.ServerName}] server execution failed");
                        log.Error("Cvp wizard failed");
                        throw new StepExecutionException("Cvp wizard failed");
                    }
                }
                catch (Exception ex)
                {
                    log.Error("Cvp wizard failed", ex);
                    throw new StepExecutionException("Cvp wizard failed", ex);
                }
            }

            log.Info("Cvp wizard executed successfully");
        }

        #endregion
    }
}


