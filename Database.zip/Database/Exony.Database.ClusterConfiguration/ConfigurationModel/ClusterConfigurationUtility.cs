﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Cluster configuration Utility.
    /// </summary>
    public class ClusterConfigurationUtility
    {
        /// <summary>
        /// Configure cluster configuration change model.
        /// </summary>
        public static void Configure(IPersistanceManager manager, string configPath, IDataAdapter dataAdapter)
        {
            Configure(manager, ConfigurationModelLoader.LoadModelFromFile(configPath), dataAdapter);
        }

        /// <summary>
        /// Execute steps.
        /// </summary>
        private static void Configure(IPersistanceManager manager, ClusterConfigurationChangeModel model, IDataAdapter dataAdapter)
        {
            IClusterConfigurationChangeExecutionContext context = new ClusterConfigurationChangeExecutionContext(manager, dataAdapter);

            foreach (IClusterConfigurationChangeStep currentStep in model.Steps)
            {
                currentStep.Execute(context);
            }
            //Validation check to validate before peristing the data.
            List<IClusterValidationResult> validationResults = manager.Configuration.Validate().ToList();
            if (validationResults.Count(cvr => cvr.Severity == ClusterValidationSeverity.Error) > 0)
            {
                StringBuilder sb = new StringBuilder();
                foreach (IClusterValidationResult r in validationResults)
                {
                    if (r.Severity == ClusterValidationSeverity.Error)
                    {
                        sb.Append(r.Message + "\n");
                    }
                }
                throw new StepExecutionException(sb.ToString());
            }
            context.Manager.Save();
        }
    }
}
