﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel
{
    using System;

    /// <summary>
    /// Cluster configuration Context.
    /// </summary>
    public class ClusterConfigurationChangeExecutionContext : IClusterConfigurationChangeExecutionContext
    {
        /// <summary>
        /// Constructor for cluster context.
        /// </summary>
        public ClusterConfigurationChangeExecutionContext(IPersistanceManager manager, IDataAdapter dataAdapter)
        {
            this.Manager = manager;
            this.DataAdapter = dataAdapter;
        }

        /// <summary>
        /// Get persistance manager.
        /// </summary>
        public IPersistanceManager Manager { get; }

        /// <summary>
        /// Get data adapter.
        /// </summary>
        public IDataAdapter DataAdapter { get; }
    }
}
