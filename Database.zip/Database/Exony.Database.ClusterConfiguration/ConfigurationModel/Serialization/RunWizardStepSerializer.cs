﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using Exony.Database.ClusterConfiguration.Cvp;
    using Exony.Database.ClusterConfiguration.Setup;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Text.Json;
    using System.Threading.Tasks;
    using static System.Text.Json.JsonElement;

    internal class RunWizardStepSerializer
    {
        #region Process Wizards

        /// <summary>
        /// If step type is run wizard, call this method.
        /// </summary>
        public static RunWizardChangeStep ProcessRunWizardStep(JsonElement stepData, int stepIndex)
        {
            string wizardType = ConfigurationModelLoaderUtility.ReadStringValue(stepData, "wizardType", stepIndex);

            JsonElement wizardData = stepData.GetProperty("wizardData");

            RunWizardChangeStep wizardStep;

            switch (wizardType)
            {
                case "egainServer":
                    wizardStep = ProcessEgainServerRunWizardStep(wizardData, stepIndex);
                    break;
                case "callManagerServer":
                    wizardStep = ProcessCallManagerServerRunWizardStep(wizardData, stepIndex);
                    break;
                case "ciscoUcceServer":
                    wizardStep = ProcessCiscoUcceServerRunWizardStep(wizardData, stepIndex);
                    break;
                case "egainNotifyServer":
                    wizardStep = ProcessEgainNotifyServerRunWizardStep(wizardData, stepIndex);
                    break;
                case "egainVirtualAssistantServer":
                    wizardStep = ProcessEgainVirtualAssistantServerRunWizardStep(wizardData, stepIndex);
                    break;
                case "cvpServer":
                    wizardStep = ProcessCvpServerRunWizardStep(wizardData, stepIndex);
                    break;
                case "avayaServer":
                    wizardStep = ProcessAvayaServerRunWizardStep(wizardData, stepIndex);
                    break;
                case "redshiftServer":
                    wizardStep = ProcessRedshiftServerRunWizardStep(wizardData, stepIndex);
                    break;
                default:
                    throw new SerializationException($"Invalid wizard type [{wizardType}] at step index {stepIndex}");
            }

            return wizardStep;
        }

        #endregion

        #region Avaya Server

        /// <summary>
        /// If wizard type is Avaya server, call this method.
        /// </summary>

        private static RunWizardChangeStep ProcessAvayaServerRunWizardStep(JsonElement wizardData, int stepIndex)
        {
            AvayaWizardChangeStep avayaWizard = new AvayaWizardChangeStep();

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "mode", stepIndex);

            try
            {
                avayaWizard.ModeType = (AvayaWizardChangeStep.Mode)Enum.Parse(typeof(AvayaWizardChangeStep.Mode), mode);
            }
            catch
            {
                throw new SerializationException($"Invalid mode [{mode}] for step index {stepIndex}");
            }

            avayaWizard.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "resourceName", stepIndex);

            if (avayaWizard.ModeType == AvayaWizardChangeStep.Mode.Add)
            {
                avayaWizard.Version = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "version", stepIndex);
                avayaWizard.TimeZoneDisplayName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "timezoneDisplayName", stepIndex);
                avayaWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                avayaWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                avayaWizard.InstanceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "instanceName", null, stepIndex);
                avayaWizard.Protocol = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "protocol", null, stepIndex);
                avayaWizard.Service = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "service", 1526, stepIndex);
                avayaWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                avayaWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                avayaWizard.Catalog = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "catalogue", null, stepIndex);
                
                avayaWizard.ConnectedMediatorResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "connectedMediatorResourceName", null, stepIndex);
            }
            else if (avayaWizard.ModeType == AvayaWizardChangeStep.Mode.Update)
            {
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "newResourceName"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.NewResourceName));
                    avayaWizard.NewResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "newResourceName", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "version"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.Version));
                    avayaWizard.Version = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "version", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "timezoneDisplayName"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.TimeZoneDisplayName));
                    avayaWizard.TimeZoneDisplayName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "timezoneDisplayName", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverName"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.ServerName));
                    avayaWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverAddress"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.ServerAddress));
                    avayaWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "instanceName"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.InstanceName));
                    avayaWizard.InstanceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "instanceName", null, stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "protocol"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.Protocol));
                    avayaWizard.Protocol = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "protocol", null, stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "service"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.Service));
                    avayaWizard.Service = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "service", 1526, stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "userName"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.UserName));
                    avayaWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "password"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.Password));
                    avayaWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "catalogue"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.Catalog));
                    avayaWizard.Catalog = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "catalogue", null, stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "connectedMediatorResourceName"))
                {
                    avayaWizard.FieldsToUpdate.Add(nameof(avayaWizard.ConnectedMediatorResourceName));
                    avayaWizard.ConnectedMediatorResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "connectedMediatorResourceName", null, stepIndex);
                }
            }

            return avayaWizard;
        }

        #endregion

        #region Egain Server

        /// <summary>
        /// If wizard type is egain server, call this method.
        /// </summary>
        private static EgainWizardChangeStep ProcessEgainServerRunWizardStep(JsonElement wizardData, int stepIndex)
        {
            EgainWizardChangeStep egainWizard = new EgainWizardChangeStep();

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "mode", stepIndex);

            try
            {
                egainWizard.ModeType = (EgainWizardChangeStep.Mode)Enum.Parse(typeof(EgainWizardChangeStep.Mode), mode);
            }
            catch
            {
                throw new SerializationException($"Invalid mode [{mode}] for step index {stepIndex}");
            }

            egainWizard.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "resourceName", stepIndex);

            if (egainWizard.ModeType == EgainWizardChangeStep.Mode.Add)
            {
                egainWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);

                egainWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);

                egainWizard.ActiveDbCatalog = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "activeDbCatalog", stepIndex);

                egainWizard.ActiveIntegratedSecurity = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "activeIntegratedSecurity", true, stepIndex);

                if (!egainWizard.ActiveIntegratedSecurity.Value)
                {
                    egainWizard.ActiveDbUserId = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "activeDbUserId", stepIndex);
                    egainWizard.ActiveDbPassword = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "activeDbPassword", stepIndex);
                }

                egainWizard.IsAiComponentConfigured = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "isAiComponentConfigured", false, stepIndex);

                if (egainWizard.IsAiComponentConfigured.Value)
                {
                    egainWizard.AiComponentServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiComponentServerName", stepIndex);
                    egainWizard.AiComponentServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiComponentServerAddress", stepIndex);
                    egainWizard.AiDbCatalogueName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiDbCatalogueName", stepIndex);
                    egainWizard.AiDbDriver = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiDbDriver", stepIndex);
                    egainWizard.AiDbConnectionPort = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "aiDbConnectionPort", 5432, stepIndex);
                    egainWizard.AiDbUserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiDbUserName", stepIndex);
                    egainWizard.AiDbPassword = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiDbPassword", stepIndex);
                    egainWizard.AiDbSslEnabled = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "aiDbSslEnabled", true, stepIndex);
                }
            }
            else if (egainWizard.ModeType == EgainWizardChangeStep.Mode.Update)
            {
                egainWizard.NewResourceName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "newResourceName") 
                    ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "newResourceName", stepIndex) : null;
                egainWizard.ServerName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverName") 
                    ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex) : null;
                egainWizard.ServerAddress = ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverAddress") 
                    ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex) : null;
                egainWizard.ActiveDbCatalog = ConfigurationModelLoaderUtility.HasProperty(wizardData, "activeDbCatalog") 
                    ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "activeDbCatalog", stepIndex) : null;

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "activeIntegratedSecurity"))
                {
                    egainWizard.ActiveIntegratedSecurity = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "activeIntegratedSecurity", stepIndex);
                }
                else
                {
                    egainWizard.ActiveIntegratedSecurity = null;
                }

                if (egainWizard.ActiveIntegratedSecurity.HasValue)
                {
                    if (!egainWizard.ActiveIntegratedSecurity.Value)
                    {
                        egainWizard.ActiveDbUserId = ConfigurationModelLoaderUtility.HasProperty(wizardData, "activeDbUserId") ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "activeDbUserId", stepIndex) : null;
                        egainWizard.ActiveDbPassword = ConfigurationModelLoaderUtility.HasProperty(wizardData, "activeDbPassword") ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "activeDbPassword", stepIndex) : null;
                    }
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "isAiComponentConfigured"))
                {
                    egainWizard.IsAiComponentConfigured = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "isAiComponentConfigured", stepIndex);
                }
                else
                {
                    egainWizard.IsAiComponentConfigured = null;
                }

                if (egainWizard.IsAiComponentConfigured.HasValue)
                {
                    if (egainWizard.IsAiComponentConfigured.Value)
                    {
                        egainWizard.AiComponentServerName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "aiComponentServerName") ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiComponentServerName", stepIndex) : null;
                        egainWizard.AiComponentServerAddress = ConfigurationModelLoaderUtility.HasProperty(wizardData, "aiComponentServerAddress") ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiComponentServerAddress", stepIndex) : null;
                        egainWizard.AiDbCatalogueName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "aiDbCatalogueName") ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiDbCatalogueName", stepIndex) : null;
                        egainWizard.AiDbDriver = ConfigurationModelLoaderUtility.HasProperty(wizardData, "aiDbDriver") ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiDbDriver", stepIndex) : null;
                        if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "portNumber"))
                        {
                            egainWizard.AiDbConnectionPort = ConfigurationModelLoaderUtility.ReadIntegerValue(wizardData, "aiDbConnectionPort", stepIndex);
                        }
                        else
                        {
                            egainWizard.AiDbConnectionPort = null;
                        }
                        egainWizard.AiDbUserName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "aiDbUserName") ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiDbUserName", stepIndex) : null;
                        egainWizard.AiDbPassword = ConfigurationModelLoaderUtility.HasProperty(wizardData, "aiDbPassword") ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "aiDbPassword", stepIndex) : null;
                        if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "aiDbSslEnabled"))
                        {
                            egainWizard.AiDbSslEnabled = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "aiDbSslEnabled", stepIndex);
                        }
                        else
                        {
                            egainWizard.AiDbSslEnabled = null;
                        }
                    }
                }

            }

            return egainWizard;
        }

        #endregion

        #region CallManager Server

        /// <summary>
        /// If wizard type is CallManager server, call this method.
        /// </summary>
        private static CallManagerWizardChangeStep ProcessCallManagerServerRunWizardStep(JsonElement wizardData, int stepIndex)
        {
            CallManagerWizardChangeStep callManagerWizard = new CallManagerWizardChangeStep();

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "mode", stepIndex);

            try
            {
                callManagerWizard.ModeType = (CallManagerWizardChangeStep.Mode)Enum.Parse(typeof(CallManagerWizardChangeStep.Mode), mode);
            }
            catch
            {
                throw new SerializationException($"Invalid mode [{mode}] for step index {stepIndex}");
            }

            callManagerWizard.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "resourceName", stepIndex);

            if (callManagerWizard.ModeType == CallManagerWizardChangeStep.Mode.Add)
            { 
                callManagerWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                callManagerWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                callManagerWizard.Version = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "version", stepIndex);
                callManagerWizard.Url = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "url", null, stepIndex);
                callManagerWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                callManagerWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                callManagerWizard.Timeout = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "timeout", 120, stepIndex);
                callManagerWizard.LinkedIcmResourceNames = ConfigurationModelLoaderUtility.ReadArrayOfStringValue(wizardData, "linkedIcmResourceNames", stepIndex);
            }
            else if (callManagerWizard.ModeType == CallManagerWizardChangeStep.Mode.Update)
            {
                callManagerWizard.NewResourceName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "newResourceName")
                   ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "newResourceName", stepIndex) : null;
                callManagerWizard.ServerName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverName")
                   ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex) : null;
                callManagerWizard.ServerAddress = ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverAddress")
                   ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex) : null;
                callManagerWizard.Version = ConfigurationModelLoaderUtility.HasProperty(wizardData, "version")
                   ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "version", stepIndex) : null;

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "url"))
                {
                    callManagerWizard.propertyExistValidator.Add("url");
                    callManagerWizard.Url = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "url", null, stepIndex);
                }

                callManagerWizard.UserName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "userName")
                   ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex) : null;
                callManagerWizard.Password = ConfigurationModelLoaderUtility.HasProperty(wizardData, "password")
                   ? ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex) : null;

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "timeout"))
                {
                    callManagerWizard.propertyExistValidator.Add("timeout");
                    callManagerWizard.Timeout = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "timeout", 120, stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "linkedIcmResourceNames"))
                {
                    callManagerWizard.propertyExistValidator.Add("linkedIcmResourceNames");
                    callManagerWizard.LinkedIcmResourceNames = ConfigurationModelLoaderUtility.ReadArrayOfStringValue(wizardData, "linkedIcmResourceNames", stepIndex);
                }
            }

            return callManagerWizard;
        }

        #endregion

        #region CvpServer

        /// <summary>
        /// If wizard type is Cvp server, call this method.
        /// </summary>
        private static CvpWizardChangeStep ProcessCvpServerRunWizardStep(JsonElement wizardData, int stepIndex)
        {
            CvpWizardChangeStep cvpWizard = new CvpWizardChangeStep();

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "mode", stepIndex);

            try
            {
                cvpWizard.ModeType = (CvpWizardChangeStep.Mode)Enum.Parse(typeof(CvpWizardChangeStep.Mode), mode);
            }
            catch
            {
                throw new SerializationException($"Invalid mode [{mode}] for step index {stepIndex}");
            }

            cvpWizard.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "resourceName", stepIndex);

            if (cvpWizard.ModeType == CvpWizardChangeStep.Mode.Add)
            {
                cvpWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                cvpWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                cvpWizard.Version = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "version", stepIndex);
                cvpWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                cvpWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                cvpWizard.Url = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "url", null, stepIndex);
                cvpWizard.Timeout = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "timeout", 120, stepIndex);

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "callServers"))
                {
                    JsonElement callServers = wizardData.GetProperty("callServers");

                    ArrayEnumerator callServerEnumerator = callServers.EnumerateArray();

                    List<CallServer> callServer = new List<CallServer>();

                    while (callServerEnumerator.MoveNext())
                    {
                        CallServer callSvr = new CallServer();

                        callSvr.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "resourceName", stepIndex);
                        callSvr.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "serverName", stepIndex);
                        callSvr.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "serverAddress", stepIndex);
                        callSvr.LinkedIcmResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(callServerEnumerator.Current, "linkedIcmResourceName", null, stepIndex);
                        callSvr.LinkedCvpReportingServerResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(callServerEnumerator.Current, "linkedCvpReportingServerResourceName", null, stepIndex);

                        callServer.Add(callSvr);
                    }

                    cvpWizard.CallServers = callServer;
                }
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "reportingServers"))
                {
                    JsonElement reportingServer = wizardData.GetProperty("reportingServers");

                    ArrayEnumerator reportServerEnumerator = reportingServer.EnumerateArray();

                    List<ReportingServer> reprtServer = new List<ReportingServer>();

                    while (reportServerEnumerator.MoveNext())
                    {
                        ReportingServer reportSvr = new ReportingServer();

                        reportSvr.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "resourceName", stepIndex);
                        reportSvr.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "serverName", stepIndex);
                        reportSvr.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "serverAddress", stepIndex);
                        reportSvr.InstanceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "instanceName", null, stepIndex);
                        reportSvr.Protocol = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "protocol", null, stepIndex);
                        reportSvr.Service = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(reportServerEnumerator.Current, "service", 1526, stepIndex);
                        reportSvr.UserName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "userName", stepIndex);
                        reportSvr.Password = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "password", stepIndex);
                        reportSvr.CoreCatalog = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "coreDatabase", null, stepIndex);
                        reportSvr.CallbackCatalog = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "catalogueDatabase", null, stepIndex);
                        reportSvr.LinkedCvpCallServerResourceNames = ConfigurationModelLoaderUtility.ReadArrayOfStringValue(reportServerEnumerator.Current, "linkedCvpCallServerResourceNames", stepIndex);
                        reportSvr.ConnectedMediatorResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "connectedMediatorResourceName", null, stepIndex);

                        reprtServer.Add(reportSvr);
                    }

                    cvpWizard.ReportingServers = reprtServer;
                }
            }
            else if (cvpWizard.ModeType == CvpWizardChangeStep.Mode.Update)
            {
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "newResourceName"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.NewResourceName));
                    cvpWizard.NewResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "newResourceName", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "userName"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.UserName));
                    cvpWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "password"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.Password));
                    cvpWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverName"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.ServerName));
                    cvpWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverAddress"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.ServerAddress));
                    cvpWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "version"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.Version));
                    cvpWizard.Version = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "version", stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "timeout"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.Timeout));
                    cvpWizard.Timeout = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "timeout", 120, stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "url"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.Url));
                    cvpWizard.Url = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "url", null, stepIndex);
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "callServers"))
                {
                    cvpWizard.FieldsToUpdate.Add(nameof(cvpWizard.CallServers));

                    JsonElement callServers = wizardData.GetProperty("callServers");

                    List<CallServer> callServer = new List<CallServer>();

                    if (!callServers.ValueKind.Equals(JsonValueKind.Null))
                    {
                        ArrayEnumerator callServerEnumerator = callServers.EnumerateArray();

                        while (callServerEnumerator.MoveNext())
                        {
                            CallServer callSvr = new CallServer();

                            string updateMode = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "updateMode", stepIndex);

                            try
                            {
                                callSvr.ModeType = (CallServer.updateMode)Enum.Parse(typeof(CallServer.updateMode), updateMode);
                            }
                            catch
                            {
                                throw new SerializationException($"Invalid mode [{updateMode}] for step index {stepIndex}");
                            }

                            callSvr.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "resourceName", stepIndex);

                            if (callSvr.ModeType == CallServer.updateMode.Add)
                            {
                                callSvr.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "serverName", stepIndex);
                                callSvr.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "serverAddress", stepIndex);
                                callSvr.LinkedIcmResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(callServerEnumerator.Current, "linkedIcmResourceName", null, stepIndex);
                                callSvr.LinkedCvpReportingServerResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(callServerEnumerator.Current, "linkedCvpReportingServerResourceName", null, stepIndex);
                            }
                            else if (callSvr.ModeType == CallServer.updateMode.Update)
                            {

                                if (ConfigurationModelLoaderUtility.HasProperty(callServerEnumerator.Current, "newResourceName"))
                                {
                                    callSvr.FieldsToUpdate.Add(nameof(callSvr.NewResourceName));
                                    callSvr.NewResourceName = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "newResourceName", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(callServerEnumerator.Current, "serverName"))
                                {
                                    callSvr.FieldsToUpdate.Add(nameof(callSvr.ServerName));
                                    callSvr.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "serverName", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(callServerEnumerator.Current, "serverAddress"))
                                {
                                    callSvr.FieldsToUpdate.Add(nameof(callSvr.ServerAddress));
                                    callSvr.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(callServerEnumerator.Current, "serverAddress", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(callServerEnumerator.Current, "linkedIcmResourceName"))
                                {
                                    callSvr.FieldsToUpdate.Add(nameof(callSvr.LinkedIcmResourceName));
                                    callSvr.LinkedIcmResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(callServerEnumerator.Current, "linkedIcmResourceName", null, stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(callServerEnumerator.Current, "linkedCvpReportingServerResourceName"))
                                {
                                    callSvr.FieldsToUpdate.Add(nameof(callSvr.LinkedCvpReportingServerResourceName));
                                    callSvr.LinkedCvpReportingServerResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(callServerEnumerator.Current, "linkedCvpReportingServerResourceName", null, stepIndex);
                                }
                            }

                            callServer.Add(callSvr);
                        }

                        cvpWizard.CallServers = callServer;
                    }
                    else
                    {
                        cvpWizard.CallServers = null;
                    }
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "reportingServers"))
                {
                    cvpWizard.FieldsToUpdate.Add("reportingServers");

                    JsonElement reportingServer = wizardData.GetProperty("reportingServers");

                    List<ReportingServer> reprtServer = new List<ReportingServer>();

                    if (!reportingServer.ValueKind.Equals(JsonValueKind.Null))
                    {
                        ArrayEnumerator reportServerEnumerator = reportingServer.EnumerateArray();

                        while (reportServerEnumerator.MoveNext())
                        {
                            ReportingServer reportSvr = new ReportingServer();

                            string updateMode = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "updateMode", stepIndex);

                            try
                            {
                                reportSvr.ModeType = (ReportingServer.updateMode)Enum.Parse(typeof(ReportingServer.updateMode), updateMode);
                            }
                            catch
                            {
                                throw new SerializationException($"Invalid mode [{updateMode}] for step index {stepIndex}");
                            }

                            reportSvr.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "resourceName", stepIndex);

                            if (reportSvr.ModeType == ReportingServer.updateMode.Add)
                            {
                                reportSvr.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "serverName", stepIndex);
                                reportSvr.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "serverAddress", stepIndex);
                                reportSvr.InstanceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "instanceName", null, stepIndex);
                                reportSvr.Protocol = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "protocol",null, stepIndex);
                                reportSvr.Service = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(reportServerEnumerator.Current, "service", 1526, stepIndex);
                                reportSvr.UserName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "userName", stepIndex);
                                reportSvr.Password = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "password", stepIndex);
                                reportSvr.CoreCatalog = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "coreDatabase", null, stepIndex);
                                reportSvr.CallbackCatalog = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "catalogueDatabase", null, stepIndex);
                                reportSvr.LinkedCvpCallServerResourceNames = ConfigurationModelLoaderUtility.ReadArrayOfStringValue(reportServerEnumerator.Current, "linkedCvpCallServerResourceNames", stepIndex);
                                reportSvr.ConnectedMediatorResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "connectedMediatorResourceName", null, stepIndex);
                            }
                            else if (reportSvr.ModeType == ReportingServer.updateMode.Update)
                            {
                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "newResourceName"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.NewResourceName));
                                    reportSvr.NewResourceName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "newResourceName", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "serverName"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.ServerName));
                                    reportSvr.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "serverName", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "serverAddress"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.ServerAddress));
                                    reportSvr.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "serverAddress", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "instanceName"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.InstanceName));
                                    reportSvr.InstanceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "instanceName", null, stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "protocol"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.Protocol));
                                    reportSvr.Protocol = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "protocol", null, stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "service"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.Service));
                                    reportSvr.Service = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(reportServerEnumerator.Current, "service", 1526, stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "userName"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.UserName));
                                    reportSvr.UserName = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "userName", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "password"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.Password));
                                    reportSvr.Password = ConfigurationModelLoaderUtility.ReadStringValue(reportServerEnumerator.Current, "password", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "coreDatabase"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.CoreCatalog));
                                    reportSvr.CoreCatalog = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "coreDatabase", null, stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "catalogueDatabase"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.CallbackCatalog));
                                    reportSvr.CallbackCatalog = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "catalogueDatabase", null, stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "linkedCvpCallServerResourceNames"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.LinkedCvpCallServerResourceNames));
                                    reportSvr.LinkedCvpCallServerResourceNames = ConfigurationModelLoaderUtility.ReadArrayOfStringValue(reportServerEnumerator.Current, "linkedCvpCallServerResourceNames", stepIndex);
                                }

                                if (ConfigurationModelLoaderUtility.HasProperty(reportServerEnumerator.Current, "connectedMediatorResourceName"))
                                {
                                    reportSvr.FieldsToUpdate.Add(nameof(reportSvr.ConnectedMediatorResourceName));
                                    reportSvr.ConnectedMediatorResourceName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(reportServerEnumerator.Current, "connectedMediatorResourceName", null, stepIndex);
                                }
                            }

                            reprtServer.Add(reportSvr);
                        }

                        cvpWizard.ReportingServers = reprtServer;
                    }
                    else
                    {
                        cvpWizard.ReportingServers = null;
                    }
                }
            }

            return cvpWizard;
        }

        #endregion

        #region Cisco UCCE Server

        /// <summary>
        /// If wizard type is cisco ucce server, call this method.
        /// </summary>
        private static CiscoUcceWizardChangeStep ProcessCiscoUcceServerRunWizardStep(JsonElement wizardData, int stepIndex)
        {
            CiscoUcceWizardChangeStep ciscoWizard = new CiscoUcceWizardChangeStep();

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "mode", stepIndex);

            try
            {
                ciscoWizard.ModeType = (CiscoUcceWizardChangeStep.Mode)Enum.Parse(typeof(CiscoUcceWizardChangeStep.Mode), mode);
            }
            catch
            {
                throw new SerializationException($"Invalid mode [{mode}] for step index {stepIndex}");
            }

            ciscoWizard.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "resourceName", stepIndex);

            if (ciscoWizard.ModeType == CiscoUcceWizardChangeStep.Mode.Add)
            {
                bool hdsRequired = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "hdsRequired", false, stepIndex);
                ciscoWizard.HdsRequired = hdsRequired;

                bool ddsRequired = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "ddsRequired", false, stepIndex);
                ciscoWizard.DdsRequired = ddsRequired;

                bool provisionable = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "provisionable", false, stepIndex);
                ciscoWizard.Provisionable = provisionable;

                bool isDualSided = ConfigurationModelLoaderUtility.HasProperty(wizardData, "secondarySystemData");
                bool isCommonSystemDataDefined = ConfigurationModelLoaderUtility.HasProperty(wizardData, "commonSystemData");

                if (isCommonSystemDataDefined)
                {
                    JsonElement commonSystemData = wizardData.GetProperty("commonSystemData");
                    bool isDatabaseDataDefined = ConfigurationModelLoaderUtility.HasProperty(commonSystemData, "database");

                    if (isDatabaseDataDefined)
                    {
                        JsonElement databaseData = commonSystemData.GetProperty("database");
                        ciscoWizard.DbIntegratedSecurity = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(databaseData, "dbIntegratedSecurity", true, stepIndex);

                        if (!ciscoWizard.DbIntegratedSecurity.Value)
                        {
                            ciscoWizard.DbUserId = ConfigurationModelLoaderUtility.ReadStringValue(databaseData, "dbUserId", stepIndex);
                            ciscoWizard.DbPassword = ConfigurationModelLoaderUtility.ReadStringValue(databaseData, "dbPassword", stepIndex);
                        }
                    }
                    else
                    {
                        ciscoWizard.DbIntegratedSecurity = true;
                    }

                    if (provisionable)
                    {
                        bool isProvisioningDataDefined = ConfigurationModelLoaderUtility.HasProperty(commonSystemData, "provisioning");

                        if (isProvisioningDataDefined)
                        {
                            JsonElement provisioningData = commonSystemData.GetProperty("provisioning");

                            ciscoWizard.ConapiApplicationName = ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "conapiApplicationName", stepIndex);

                            ciscoWizard.ConapiApplicationKey = ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "conapiApplicationKey", stepIndex);

                            ciscoWizard.MultiMediaSupport = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(provisioningData, "multiMediaSupport", false, stepIndex);

                            ciscoWizard.PurgeItemsOnDelete = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(provisioningData, "purgeItemsOnDelete", false, stepIndex);

                            ciscoWizard.ScriptSupport = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(provisioningData, "scriptSupport", false, stepIndex);

                            if (ciscoWizard.ScriptSupport.Value)
                            {
                                ciscoWizard.ScriptLockUserName = ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "scriptLockUserName", stepIndex);
                            }

                            ciscoWizard.SupervisorActiveDirectoryIntegration = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(provisioningData, "supervisorActiveDirectoryIntegration", false, stepIndex);
                            ciscoWizard.UseDomainIntegration = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "domainIntegration");

                            if (ciscoWizard.SupervisorActiveDirectoryIntegration.Value && ciscoWizard.UseDomainIntegration.Value)
                            {
                                JsonElement domainIntegrationData = provisioningData.GetProperty("domainIntegration");
                                ciscoWizard.GlobalCatalogDomainOrServer = ConfigurationModelLoaderUtility.ReadStringValue(domainIntegrationData, "globalCatalogDomainOrServer", stepIndex);
                                ciscoWizard.DomainControllerAnonymous = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerAnonymous", false, stepIndex);
                                ciscoWizard.DomainControllerDelegation = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerDelegation", false, stepIndex);
                                ciscoWizard.DomainControllerUseEncryption = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerUseEncryption", false, stepIndex);
                                ciscoWizard.DomainControllerServerBind = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerServerBind", false, stepIndex);
                                ciscoWizard.DomainControllerFastBind = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerFastBind", false, stepIndex);
                                ciscoWizard.DomainControllerReadOnlyServer = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerReadOnlyServer", false, stepIndex);
                                ciscoWizard.DomainControllerUseSsl = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerUseSsl", false, stepIndex);
                                ciscoWizard.DomainControllerSecureAuthentication = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerSecureAuthentication", false, stepIndex);

                                if (ciscoWizard.DomainControllerSecureAuthentication == true)
                                {
                                    ciscoWizard.DomainControllerSealing = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerSealing", false, stepIndex);
                                    ciscoWizard.DomainControllerSigning = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerSigning", false, stepIndex);

                                    ciscoWizard.DomainControllerUserName = ConfigurationModelLoaderUtility.ReadStringValue(domainIntegrationData, "domainControllerUserName", stepIndex);
                                    ciscoWizard.DomainControllerPassword = ConfigurationModelLoaderUtility.ReadStringValue(domainIntegrationData, "domainControllerPassword", stepIndex);
                                }
                            }
                            else if (ciscoWizard.SupervisorActiveDirectoryIntegration == true && ciscoWizard.UseDomainIntegration == false)
                            {
                                throw new SerializationException($"[SupervisorActiveDirectoryIntegration] is [{ciscoWizard.SupervisorActiveDirectoryIntegration}], must provide domain integration data at step {stepIndex}.");
                            }
                            else if (ciscoWizard.SupervisorActiveDirectoryIntegration == false && ciscoWizard.UseDomainIntegration == true)
                            {
                                throw new SerializationException($"[SupervisorActiveDirectoryIntegration] is [{ciscoWizard.SupervisorActiveDirectoryIntegration}], must be true to use domain integration data at step {stepIndex}.");
                            }
                        }
                        else
                        {
                            throw new SerializationException($"Provisionable flag is set to [{provisionable}] but provisioning data is not defined at step {stepIndex}. Please refer to documentation for more details.");
                        }
                    }
                }
                else
                {
                    ciscoWizard.DbIntegratedSecurity = true;

                    if (provisionable)
                    {
                        throw new SerializationException($"Provisionable flag is set to [{provisionable}] but provisioning data is not defined at step {stepIndex}. Please refer to documentation for more details.");
                    }
                }

                if (isDualSided)
                {
                    ciscoWizard.SystemType = CiscoUcceWizardChangeStep.Type.DualSided;
                    ProcessUccePrimarySystemData(ciscoWizard.ModeType, ciscoWizard, wizardData, hdsRequired, ddsRequired, provisionable, stepIndex);
                    ProcessUcceSecondarySystemData(ciscoWizard.ModeType, ciscoWizard, wizardData, hdsRequired, ddsRequired, provisionable, stepIndex);
                }
                else
                {
                    ciscoWizard.SystemType = CiscoUcceWizardChangeStep.Type.SingleSided;
                    ProcessUccePrimarySystemData(ciscoWizard.ModeType, ciscoWizard, wizardData, hdsRequired, ddsRequired, provisionable, stepIndex);
                }
            }
            else if (ciscoWizard.ModeType == CiscoUcceWizardChangeStep.Mode.Update)
            {
                ciscoWizard.NewResourceName = ConfigurationModelLoaderUtility.HasProperty(wizardData, "newResourceName") ? 
                    ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "newResourceName", stepIndex) : null;

                //Hds update.
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "hdsRequired"))
                {
                    ciscoWizard.HdsRequired = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "hdsRequired", stepIndex);
                }
                else
                {
                    ciscoWizard.HdsRequired = null;
                }

                //Dds update.
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "ddsRequired"))
                {
                    ciscoWizard.DdsRequired = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "ddsRequired", stepIndex);
                }
                else
                {
                    ciscoWizard.DdsRequired = null;
                }

                //Provisioning update.
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "provisionable"))
                {
                    ciscoWizard.Provisionable = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "provisionable", stepIndex);
                }
                else
                {
                    ciscoWizard.Provisionable = null;
                }

                //Check redundancy type for system.
                bool isDualSided = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "dualSided", stepIndex);

                if (isDualSided)
                {
                    ciscoWizard.SystemType = CiscoUcceWizardChangeStep.Type.DualSided;
                }
                else
                {
                    ciscoWizard.SystemType = CiscoUcceWizardChangeStep.Type.SingleSided;
                }

                //Check for common system data.
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "commonSystemData"))
                {
                    JsonElement commonSystemData = wizardData.GetProperty("commonSystemData");

                    //Check for common data base data.
                    if (ConfigurationModelLoaderUtility.HasProperty(commonSystemData, "database"))
                    {
                        JsonElement databaseData = commonSystemData.GetProperty("database");
                        bool IsIntegratedSecurityTypeRedefined = ConfigurationModelLoaderUtility.HasProperty(databaseData, "dbIntegratedSecurity");

                        if (ConfigurationModelLoaderUtility.HasProperty(databaseData, "dbIntegratedSecurity"))
                        {
                            ciscoWizard.DbIntegratedSecurity = ConfigurationModelLoaderUtility.ReadBooleanValue(databaseData, "dbIntegratedSecurity", stepIndex);
                        }
                        else
                        {
                            ciscoWizard.DbIntegratedSecurity = null;
                        }

                        if (ciscoWizard.DbIntegratedSecurity == false)
                        {
                            ciscoWizard.DbUserId = ConfigurationModelLoaderUtility.HasProperty(databaseData, "dbUserId") 
                                ? ConfigurationModelLoaderUtility.ReadStringValue(databaseData, "dbUserId", stepIndex) : null;
                            ciscoWizard.DbPassword = ConfigurationModelLoaderUtility.HasProperty(databaseData, "dbPassword") 
                                ? ConfigurationModelLoaderUtility.ReadStringValue(databaseData, "dbPassword", stepIndex) : null;
                        }
                    }

                    //Check for common provisioning data.
                    if (ConfigurationModelLoaderUtility.HasProperty(commonSystemData, "provisioning"))
                    {
                        JsonElement provisioningData = commonSystemData.GetProperty("provisioning");

                        ciscoWizard.ConapiApplicationName = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "conapiApplicationName")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "conapiApplicationName", stepIndex) : null;
                        ciscoWizard.ConapiApplicationKey = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "conapiApplicationKey")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "conapiApplicationKey", stepIndex) : null;

                        if (ConfigurationModelLoaderUtility.HasProperty(provisioningData, "multiMediaSupport"))
                        {
                            ciscoWizard.MultiMediaSupport = ConfigurationModelLoaderUtility.ReadBooleanValue(provisioningData, "multiMediaSupport", stepIndex);
                        }
                        else
                        {
                            ciscoWizard.MultiMediaSupport = null;
                        }

                        if (ConfigurationModelLoaderUtility.HasProperty(provisioningData, "purgeItemsOnDelete"))
                        {
                            ciscoWizard.PurgeItemsOnDelete = ConfigurationModelLoaderUtility.ReadBooleanValue(provisioningData, "purgeItemsOnDelete", stepIndex);
                        }
                        else
                        {
                            ciscoWizard.PurgeItemsOnDelete = null;
                        }

                        if (ConfigurationModelLoaderUtility.HasProperty(provisioningData, "scriptSupport"))
                        {
                            ciscoWizard.ScriptSupport = ConfigurationModelLoaderUtility.ReadBooleanValue(provisioningData, "scriptSupport", stepIndex);

                            if (ciscoWizard.ScriptSupport == true)
                            {
                                ciscoWizard.ScriptLockUserName = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "scriptLockUserName")
                                    ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "scriptLockUserName", stepIndex) : null;
                            }
                        }
                        else
                        {
                            ciscoWizard.ScriptSupport = null;
                        }

                        if (ConfigurationModelLoaderUtility.HasProperty(provisioningData, "supervisorActiveDirectoryIntegration"))
                        {
                            ciscoWizard.SupervisorActiveDirectoryIntegration = ConfigurationModelLoaderUtility.ReadBooleanValue(provisioningData, "supervisorActiveDirectoryIntegration", stepIndex);

                            if (ciscoWizard.SupervisorActiveDirectoryIntegration == false)
                            {
                                ciscoWizard.UseDomainIntegration = false;
                            }
                        }
                        else
                        {
                            ciscoWizard.SupervisorActiveDirectoryIntegration = null;
                        }

                        bool useDomainIntegrationDefined = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "domainIntegration");

                        if (useDomainIntegrationDefined == false)
                        {
                            ciscoWizard.UseDomainIntegration = null;
                        }
                        else
                        {
                            ciscoWizard.UseDomainIntegration = true;
                        }

                        if (ciscoWizard.UseDomainIntegration == true)
                        {
                            JsonElement domainIntegrationData = provisioningData.GetProperty("domainIntegration");

                            ciscoWizard.GlobalCatalogDomainOrServer = ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "globalCatalogDomainOrServer") ?
                                ConfigurationModelLoaderUtility.ReadStringValue(domainIntegrationData, "globalCatalogDomainOrServer", stepIndex) : null;

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerAnonymous"))
                            {
                                ciscoWizard.DomainControllerAnonymous = ConfigurationModelLoaderUtility.ReadBooleanValue(domainIntegrationData, "domainControllerAnonymous", stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerAnonymous = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerDelegation"))
                            {
                                ciscoWizard.DomainControllerDelegation = ConfigurationModelLoaderUtility.ReadBooleanValue(domainIntegrationData, "domainControllerDelegation", stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerDelegation = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerUseEncryption"))
                            {
                                ciscoWizard.DomainControllerUseEncryption = ConfigurationModelLoaderUtility.ReadBooleanValue(domainIntegrationData, "domainControllerUseEncryption", stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerUseEncryption = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerServerBind"))
                            {
                                ciscoWizard.DomainControllerServerBind = ConfigurationModelLoaderUtility.ReadBooleanValue(domainIntegrationData, "domainControllerServerBind", stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerServerBind = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerFastBind"))
                            {
                                ciscoWizard.DomainControllerFastBind = ConfigurationModelLoaderUtility.ReadBooleanValue(domainIntegrationData, "domainControllerFastBind", stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerFastBind = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerReadOnlyServer"))
                            {
                                ciscoWizard.DomainControllerReadOnlyServer = ConfigurationModelLoaderUtility.ReadBooleanValue(domainIntegrationData, "domainControllerReadOnlyServer", stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerReadOnlyServer = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerUseSsl"))
                            {
                                ciscoWizard.DomainControllerUseSsl = ConfigurationModelLoaderUtility.ReadBooleanValue(domainIntegrationData, "domainControllerUseSsl", stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerUseSsl = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerSecureAuthentication"))
                            {
                                ciscoWizard.DomainControllerSecureAuthentication = ConfigurationModelLoaderUtility.ReadBooleanValue(domainIntegrationData, "domainControllerSecureAuthentication", stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerSecureAuthentication = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerSealing"))
                            {
                                ciscoWizard.DomainControllerSealing = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerSealing", false, stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerSealing = null;
                            }

                            if (ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerSigning"))
                            {
                                ciscoWizard.DomainControllerSigning = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(domainIntegrationData, "domainControllerSigning", false, stepIndex);
                            }
                            else
                            {
                                ciscoWizard.DomainControllerSigning = null;
                            }

                            ciscoWizard.DomainControllerUserName = ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerUserName") ?
                                ConfigurationModelLoaderUtility.ReadStringValue(domainIntegrationData, "domainControllerUserName", stepIndex) : null;
                            ciscoWizard.DomainControllerPassword = ConfigurationModelLoaderUtility.HasProperty(domainIntegrationData, "domainControllerPassword") ?
                                ConfigurationModelLoaderUtility.ReadStringValue(domainIntegrationData, "domainControllerPassword", stepIndex) : null;
                        }
                    }
                }
                else
                {
                    //Common system data not defined, database setting unchanged.
                    ciscoWizard.DbIntegratedSecurity = null;
                }

                if (ciscoWizard.SystemType == CiscoUcceWizardChangeStep.Type.DualSided)
                {
                    ProcessUccePrimarySystemData(ciscoWizard.ModeType, ciscoWizard, wizardData, ciscoWizard.HdsRequired, ciscoWizard.DdsRequired, ciscoWizard.Provisionable, stepIndex);
                    ProcessUcceSecondarySystemData(ciscoWizard.ModeType, ciscoWizard, wizardData, ciscoWizard.HdsRequired, ciscoWizard.DdsRequired, ciscoWizard.Provisionable, stepIndex);
                }
                else
                {
                    ProcessUccePrimarySystemData(ciscoWizard.ModeType, ciscoWizard, wizardData, ciscoWizard.HdsRequired, ciscoWizard.DdsRequired, ciscoWizard.Provisionable, stepIndex);
                }
            }

            return ciscoWizard;
        }

        /// <summary>
        /// Process secondary system ucce data.
        /// </summary>
        private static void ProcessUcceSecondarySystemData(CiscoUcceWizardChangeStep.Mode mode, CiscoUcceWizardChangeStep ciscoWizard, JsonElement wizardData, bool? hdsRequired, bool? ddsRequired, bool? provisionable, int stepIndex)
        {
            bool isSecondarySystemDataDefined = ConfigurationModelLoaderUtility.HasProperty(wizardData, "secondarySystemData");

            if (mode == CiscoUcceWizardChangeStep.Mode.Add)
            {
                if (isSecondarySystemDataDefined)
                {
                    JsonElement secondarySystemData = wizardData.GetProperty("secondarySystemData");

                    bool isAwDefined = ConfigurationModelLoaderUtility.HasProperty(secondarySystemData, "aw");

                    if (isAwDefined)
                    {
                        JsonElement awData = secondarySystemData.GetProperty("aw");
                        ciscoWizard.SecondaryAwServerName = ConfigurationModelLoaderUtility.ReadStringValue(awData, "serverName", stepIndex);
                        ciscoWizard.SecondaryAwServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(awData, "serverAddress", stepIndex);
                    }
                    else
                    {
                        throw new SerializationException($"[Secondary UCCE AW Data] is not defined at step {stepIndex}. Please refer to documentation for more details.");
                    }

                    if (hdsRequired == true)
                    {
                        bool hdsDefined = ConfigurationModelLoaderUtility.HasProperty(secondarySystemData, "hds");

                        if (hdsDefined)
                        {
                            JsonElement hdsData = secondarySystemData.GetProperty("hds");
                            ciscoWizard.SecondaryHdsServerName = ConfigurationModelLoaderUtility.ReadStringValue(hdsData, "serverName", stepIndex);
                            ciscoWizard.SecondaryHdsServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(hdsData, "serverAddress", stepIndex);
                        }
                        else
                        {
                            throw new SerializationException($"Hds flag is true but [Secondary UCCE HDS Data] is not defined at step {stepIndex}. Please refer to documentation for more details.");
                        }
                    }

                    if (ddsRequired == true)
                    {
                        if (hdsRequired == false)
                        {
                            throw new SerializationException($"[Secondary UCCE HDS Data] must be defined for [Secondary UCCE DDS Data] to work at step {stepIndex}. Please refer to documentation for more details.");
                        }

                        bool ddsDefined = ConfigurationModelLoaderUtility.HasProperty(secondarySystemData, "dds");

                        if (ddsDefined)
                        {
                            JsonElement ddsData = secondarySystemData.GetProperty("dds");
                            ciscoWizard.SecondaryDdsServerName = ConfigurationModelLoaderUtility.ReadStringValue(ddsData, "serverName", stepIndex);
                            ciscoWizard.SecondaryDdsServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(ddsData, "serverAddress", stepIndex);
                        }
                        else
                        {
                            throw new SerializationException($"Dds flag is true but [Secondary UCCE DDS Data] is not defined at step {stepIndex}. Please refer to documentation for more details.");
                        }
                    }

                    if (provisionable == true)
                    {
                        bool isProvisioningDefined = ConfigurationModelLoaderUtility.HasProperty(secondarySystemData, "provisioning");

                        if (isProvisioningDefined)
                        {
                            JsonElement provisioningData = secondarySystemData.GetProperty("provisioning");
                            ciscoWizard.SecondaryUnifiedConfigUrl = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(provisioningData, "unifiedConfigUrl", null, stepIndex);
                            ciscoWizard.SecondaryUnifiedConfigUser = ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigUser", stepIndex);
                            ciscoWizard.SecondaryUnifiedConfigPassword = ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigPassword", stepIndex);
                            ciscoWizard.SecondaryUnifiedConfigTimeout = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(provisioningData, "unifiedConfigTimeout", 120, stepIndex);

                            if (ciscoWizard.SecondaryUnifiedConfigTimeout < 0)
                            {
                                throw new SerializationException($"[Secondary Unified Timeout] can not be negative at step {stepIndex}.");
                            }

                            ciscoWizard.SecondaryConapiLocalRegistryPort = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(provisioningData, "conapiLocalRegistryPort", 2099, stepIndex);
                            ciscoWizard.SecondaryConapiRemoteRegistryPort = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(provisioningData, "conapiRemoteRegistryPort", 2099, stepIndex);
                            ciscoWizard.SecondaryConapiLocalPort = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(provisioningData, "conapiLocalPort", 0, stepIndex);
                        }
                        else
                        {
                            throw new SerializationException($"Provisionable flag is true but [Secondary UCCE Provisioning Data] is not defined at step {stepIndex}. Please refer to documentation for more details.");
                        }
                    }
                }
            }
            else if (mode == CiscoUcceWizardChangeStep.Mode.Update)
            {
                if (isSecondarySystemDataDefined)
                {
                    JsonElement secondarySystemData = wizardData.GetProperty("secondarySystemData");
                    
                    //Read secondary aws data.
                    if (ConfigurationModelLoaderUtility.HasProperty(secondarySystemData, "aw"))
                    {
                        JsonElement awData = secondarySystemData.GetProperty("aw");

                        ciscoWizard.SecondaryAwServerName = ConfigurationModelLoaderUtility.HasProperty(awData, "serverName")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(awData, "serverName", stepIndex) : null;

                        ciscoWizard.SecondaryAwServerAddress = ConfigurationModelLoaderUtility.HasProperty(awData, "serverAddress")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(awData, "serverAddress", stepIndex) : null;
                    }

                    //Read secondary hds data.
                    if (ConfigurationModelLoaderUtility.HasProperty(secondarySystemData, "hds"))
                    {
                        JsonElement hdsData = secondarySystemData.GetProperty("hds");

                        ciscoWizard.SecondaryHdsServerName = ConfigurationModelLoaderUtility.HasProperty(hdsData, "serverName")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(hdsData, "serverName", stepIndex) : null;

                        ciscoWizard.SecondaryHdsServerAddress = ConfigurationModelLoaderUtility.HasProperty(hdsData, "serverAddress")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(hdsData, "serverAddress", stepIndex) : null;
                    }

                    //Read secondary dds data.
                    if (ConfigurationModelLoaderUtility.HasProperty(secondarySystemData, "dds"))
                    {
                        JsonElement ddsData = secondarySystemData.GetProperty("dds");

                        ciscoWizard.SecondaryDdsServerName = ConfigurationModelLoaderUtility.HasProperty(ddsData, "serverName")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(ddsData, "serverName", stepIndex) : null;

                        ciscoWizard.SecondaryDdsServerAddress = ConfigurationModelLoaderUtility.HasProperty(ddsData, "serverAddress")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(ddsData, "serverAddress", stepIndex) : null;
                    }

                    //Read secondary provisioning data.
                    if (ConfigurationModelLoaderUtility.HasProperty(secondarySystemData, "provisioning"))
                    {
                        JsonElement provisioningData = secondarySystemData.GetProperty("provisioning");

                        ciscoWizard.SecondaryUnifiedConfigUrl = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "unifiedConfigUrl")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigUrl", stepIndex) : null;

                        ciscoWizard.SecondaryUnifiedConfigUser = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "unifiedConfigUser")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigUser", stepIndex) : null;

                        ciscoWizard.SecondaryUnifiedConfigPassword = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "unifiedConfigPassword")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigPassword", stepIndex) : null;

                        ciscoWizard.SecondaryUnifiedConfigTimeout = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "unifiedConfigTimeout")
                            ? ConfigurationModelLoaderUtility.ReadIntegerValue(provisioningData, "unifiedConfigTimeout", stepIndex) : (int?)null;

                        if (ciscoWizard.SecondaryUnifiedConfigTimeout < 0)
                        {
                            throw new SerializationException($"[Secondary Unified Timeout] can not be negative at step {stepIndex}.");
                        }

                        ciscoWizard.SecondaryConapiLocalRegistryPort = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "conapiLocalRegistryPort")
                            ? ConfigurationModelLoaderUtility.ReadIntegerValue(provisioningData, "conapiLocalRegistryPort", stepIndex) : (int?)null;

                        ciscoWizard.SecondaryConapiRemoteRegistryPort = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "conapiRemoteRegistryPort")
                            ? ConfigurationModelLoaderUtility.ReadIntegerValue(provisioningData, "conapiRemoteRegistryPort", stepIndex) : (int?)null;

                        ciscoWizard.SecondaryConapiLocalPort = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "conapiLocalPort")
                            ? ConfigurationModelLoaderUtility.ReadIntegerValue(provisioningData, "conapiLocalPort", stepIndex) : (int?)null;
                    }
                }
                else if (!isSecondarySystemDataDefined && (hdsRequired == true || ddsRequired == true || provisionable == true))
                {
                    throw new SerializationException($"Secondary UCCE system data is not defined but one of Hds, Dds or Provisionable flag is set to [True] for step {stepIndex}. Please refer to documentation for more details.");
                }
            }
        }

        /// <summary>
        /// Process primary system ucce data.
        /// </summary>
        private static void ProcessUccePrimarySystemData(CiscoUcceWizardChangeStep.Mode mode, CiscoUcceWizardChangeStep ciscoWizard, JsonElement wizardData, bool? hdsRequired, bool? ddsRequired, bool? provisionable, int stepIndex)
        {
            bool isPrimarySystemDataDefined = ConfigurationModelLoaderUtility.HasProperty(wizardData, "primarySystemData");

            if (mode == CiscoUcceWizardChangeStep.Mode.Add)
            {
                if (isPrimarySystemDataDefined)
                {
                    JsonElement primarySystemData = wizardData.GetProperty("primarySystemData");

                    bool isAwDefined = ConfigurationModelLoaderUtility.HasProperty(primarySystemData, "aw");

                    if (isAwDefined)
                    {
                        JsonElement awData = primarySystemData.GetProperty("aw");
                        ciscoWizard.PrimaryAwServerName = ConfigurationModelLoaderUtility.ReadStringValue(awData, "serverName", stepIndex);
                        ciscoWizard.PrimaryAwServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(awData, "serverAddress", stepIndex);
                    }
                    else
                    {
                        throw new SerializationException($"[Primary UCCE AW Data] is not defined at step {stepIndex}. Please refer to documentation for more details.");
                    }

                    if (hdsRequired == true)
                    {
                        bool hdsDefined = ConfigurationModelLoaderUtility.HasProperty(primarySystemData, "hds");

                        if (hdsDefined)
                        {
                            JsonElement hdsData = primarySystemData.GetProperty("hds");
                            ciscoWizard.PrimaryHdsServerName = ConfigurationModelLoaderUtility.ReadStringValue(hdsData, "serverName", stepIndex);
                            ciscoWizard.PrimaryHdsServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(hdsData, "serverAddress", stepIndex);
                        }
                        else
                        {
                            throw new SerializationException($"Hds flag is true but [Primary UCCE HDS Data] is not defined at step {stepIndex}. Please refer to documentation for more details.");
                        }
                    }

                    if (ddsRequired == true)
                    {
                        if (hdsRequired == false)
                        {
                            throw new SerializationException($"[Primary UCCE HDS Data] must be defined for [Primary UCCE DDS Data] to work at step {stepIndex}. Please refer to documentation for more details.");
                        }

                        bool ddsDefined = ConfigurationModelLoaderUtility.HasProperty(primarySystemData, "dds");

                        if (ddsDefined)
                        {
                            JsonElement ddsData = primarySystemData.GetProperty("dds");
                            ciscoWizard.PrimaryDdsServerName = ConfigurationModelLoaderUtility.ReadStringValue(ddsData, "serverName", stepIndex);
                            ciscoWizard.PrimaryDdsServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(ddsData, "serverAddress", stepIndex);
                        }
                        else
                        {
                            throw new SerializationException($"Dds flag is true but [Primary UCCE DDS Data] is not defined at step {stepIndex}. Please refer to documentation for more details.");
                        }
                    }

                    if (provisionable == true)
                    {
                        bool isProvisioningDefined = ConfigurationModelLoaderUtility.HasProperty(primarySystemData, "provisioning");

                        if (isProvisioningDefined)
                        {
                            JsonElement provisioningData = primarySystemData.GetProperty("provisioning");
                            ciscoWizard.PrimaryUnifiedConfigUrl = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(provisioningData, "unifiedConfigUrl", null, stepIndex);
                            ciscoWizard.PrimaryUnifiedConfigUser = ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigUser", stepIndex);
                            ciscoWizard.PrimaryUnifiedConfigPassword = ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigPassword", stepIndex);
                            ciscoWizard.PrimaryUnifiedConfigTimeout = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(provisioningData, "unifiedConfigTimeout", 120, stepIndex);

                            if (ciscoWizard.PrimaryUnifiedConfigTimeout < 0)
                            {
                                throw new SerializationException($"[Primary Unified Timeout] can not be negative at step {stepIndex}.");
                            }

                            ciscoWizard.PrimaryConapiLocalRegistryPort = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(provisioningData, "conapiLocalRegistryPort", 2099, stepIndex);
                            ciscoWizard.PrimaryConapiRemoteRegistryPort = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(provisioningData, "conapiRemoteRegistryPort", 2099, stepIndex);
                            ciscoWizard.PrimaryConapiLocalPort = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(provisioningData, "conapiLocalPort", 0, stepIndex);
                        }
                        else
                        {
                            throw new SerializationException($"Provisionable flag is true but [Primary UCCE Provisioning Data] is not defined at step {stepIndex}. Please refer to documentation for more details.");
                        }
                    }
                }
                else
                {
                    throw new SerializationException($"[Primary System Data] is not defined at step {stepIndex} which is must define. Please refer to documentation for more details.");
                }
            }
            else if (mode == CiscoUcceWizardChangeStep.Mode.Update)
            {
                if (isPrimarySystemDataDefined)
                {
                    JsonElement primarySystemData = wizardData.GetProperty("primarySystemData");

                    //Read primary aws data.
                    if (ConfigurationModelLoaderUtility.HasProperty(primarySystemData, "aw"))
                    {
                        JsonElement awData = primarySystemData.GetProperty("aw");
                        
                        ciscoWizard.PrimaryAwServerName = ConfigurationModelLoaderUtility.HasProperty(awData, "serverName") 
                            ? ConfigurationModelLoaderUtility.ReadStringValue(awData, "serverName", stepIndex) : null;

                        ciscoWizard.PrimaryAwServerAddress = ConfigurationModelLoaderUtility.HasProperty(awData, "serverAddress") 
                            ? ConfigurationModelLoaderUtility.ReadStringValue(awData, "serverAddress", stepIndex) : null;
                    }

                    //Read primary hds data.
                    if (ConfigurationModelLoaderUtility.HasProperty(primarySystemData, "hds"))
                    {
                        JsonElement hdsData = primarySystemData.GetProperty("hds");

                        ciscoWizard.PrimaryHdsServerName = ConfigurationModelLoaderUtility.HasProperty(hdsData, "serverName")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(hdsData, "serverName", stepIndex) : null;

                        ciscoWizard.PrimaryHdsServerAddress = ConfigurationModelLoaderUtility.HasProperty(hdsData, "serverAddress")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(hdsData, "serverAddress", stepIndex) : null;
                    }

                    //Read primary dds data.
                    if (ConfigurationModelLoaderUtility.HasProperty(primarySystemData, "dds"))
                    {
                        JsonElement ddsData = primarySystemData.GetProperty("dds");

                        ciscoWizard.PrimaryDdsServerName = ConfigurationModelLoaderUtility.HasProperty(ddsData, "serverName")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(ddsData, "serverName", stepIndex) : null;

                        ciscoWizard.PrimaryDdsServerAddress = ConfigurationModelLoaderUtility.HasProperty(ddsData, "serverAddress")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(ddsData, "serverAddress", stepIndex) : null;
                    }

                    //Read primary provisioning data.
                    if (ConfigurationModelLoaderUtility.HasProperty(primarySystemData, "provisioning"))
                    {
                        JsonElement provisioningData = primarySystemData.GetProperty("provisioning");

                        ciscoWizard.PrimaryUnifiedConfigUrl = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "unifiedConfigUrl")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigUrl", stepIndex) : null;

                        ciscoWizard.PrimaryUnifiedConfigUser = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "unifiedConfigUser")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigUser", stepIndex) : null;

                        ciscoWizard.PrimaryUnifiedConfigPassword = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "unifiedConfigPassword")
                            ? ConfigurationModelLoaderUtility.ReadStringValue(provisioningData, "unifiedConfigPassword", stepIndex) : null;

                        ciscoWizard.PrimaryUnifiedConfigTimeout = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "unifiedConfigTimeout")
                            ? ConfigurationModelLoaderUtility.ReadIntegerValue(provisioningData, "unifiedConfigTimeout", stepIndex) : (int?)null;

                        if (ciscoWizard.PrimaryUnifiedConfigTimeout < 0)
                        {
                            throw new SerializationException($"[Primary Unified Timeout] can not be negative at step {stepIndex}.");
                        }

                        ciscoWizard.PrimaryConapiLocalRegistryPort = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "conapiLocalRegistryPort")
                            ? ConfigurationModelLoaderUtility.ReadIntegerValue(provisioningData, "conapiLocalRegistryPort", stepIndex) : (int?)null;

                        ciscoWizard.PrimaryConapiRemoteRegistryPort = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "conapiRemoteRegistryPort")
                            ? ConfigurationModelLoaderUtility.ReadIntegerValue(provisioningData, "conapiRemoteRegistryPort", stepIndex) : (int?)null;

                        ciscoWizard.PrimaryConapiLocalPort = ConfigurationModelLoaderUtility.HasProperty(provisioningData, "conapiLocalPort")
                            ? ConfigurationModelLoaderUtility.ReadIntegerValue(provisioningData, "conapiLocalPort", stepIndex) : (int?)null;
                    }
                }
                else if (!isPrimarySystemDataDefined && (hdsRequired == true || ddsRequired == true || provisionable == true))
                {
                    throw new SerializationException($"Primary UCCE system data is not defined but one of Hds, Dds or Provisionable flag is set to [True] for step {stepIndex}. Please refer to documentation for more details.");
                }
            }
        }

        #endregion

        #region Egain Notify Server

        /// <summary>
        /// If wizard type is egain notify server, call this method.
        /// </summary>
        private static EgainNotifyWizardChangeStep ProcessEgainNotifyServerRunWizardStep(JsonElement wizardData, int stepIndex)
        {
            EgainNotifyWizardChangeStep egainNotifyWizard = new EgainNotifyWizardChangeStep();

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "mode", stepIndex);

            try
            {
                egainNotifyWizard.ModeType = (EgainNotifyWizardChangeStep.Mode)Enum.Parse(typeof(EgainNotifyWizardChangeStep.Mode), mode);
            }
            catch
            {
                throw new SerializationException($"Invalid mode [{mode}] for step index {stepIndex}");
            }

            egainNotifyWizard.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "resourceName", stepIndex);

            if (egainNotifyWizard.ModeType == EgainNotifyWizardChangeStep.Mode.Add)
            {
                egainNotifyWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                egainNotifyWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                egainNotifyWizard.CatalogueName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "catalogueName", stepIndex);
                egainNotifyWizard.Driver = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "driver", stepIndex);
                egainNotifyWizard.PortNumber = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "portNumber", 5432, stepIndex);
                egainNotifyWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                egainNotifyWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                egainNotifyWizard.SslEnabled = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "sslEnabled", true, stepIndex);
            }
            else if (egainNotifyWizard.ModeType == EgainNotifyWizardChangeStep.Mode.Update)
            {
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "newResourceName"))
                {
                    egainNotifyWizard.NewResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "newResourceName", stepIndex);
                }
                else
                {
                    egainNotifyWizard.NewResourceName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverName"))
                {
                    egainNotifyWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                }
                else
                {
                    egainNotifyWizard.ServerName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverAddress"))
                {
                    egainNotifyWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                }
                else
                {
                    egainNotifyWizard.ServerAddress = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "catalogueName"))
                {
                    egainNotifyWizard.CatalogueName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "catalogueName", stepIndex);
                }
                else
                {
                    egainNotifyWizard.CatalogueName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "driver"))
                {
                    egainNotifyWizard.Driver = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "driver", stepIndex);
                }
                else
                {
                    egainNotifyWizard.Driver = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "portNumber"))
                {
                    egainNotifyWizard.PortNumber = ConfigurationModelLoaderUtility.ReadIntegerValue(wizardData, "portNumber", stepIndex);
                }
                else
                {
                    egainNotifyWizard.PortNumber = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "userName"))
                {
                    egainNotifyWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                }
                else
                {
                    egainNotifyWizard.UserName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "password"))
                {
                    egainNotifyWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                }
                else
                {
                    egainNotifyWizard.Password = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "sslEnabled"))
                {
                    egainNotifyWizard.SslEnabled = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "sslEnabled", stepIndex);
                }
                else
                {
                    egainNotifyWizard.SslEnabled = null;
                }
            }

            return egainNotifyWizard;
        }

        #endregion

        #region Egain Virtual Assistant Server

        /// <summary>
        /// If wizard type is egain virtual assistant server, call this method.
        /// </summary>
        private static EgainVirtualAssistantChangeStep ProcessEgainVirtualAssistantServerRunWizardStep(JsonElement wizardData, int stepIndex)
        {
            EgainVirtualAssistantChangeStep virtualAssistantWizard = new EgainVirtualAssistantChangeStep();

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "mode", stepIndex);

            try
            {
                virtualAssistantWizard.ModeType = (EgainVirtualAssistantChangeStep.Mode)Enum.Parse(typeof(EgainVirtualAssistantChangeStep.Mode), mode);
            }
            catch
            {
                throw new SerializationException($"Invalid mode [{mode}] for step index {stepIndex}");
            }

            virtualAssistantWizard.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "resourceName", stepIndex);

            if (virtualAssistantWizard.ModeType == EgainVirtualAssistantChangeStep.Mode.Add)
            {
                virtualAssistantWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                virtualAssistantWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                virtualAssistantWizard.CatalogueName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "catalogueName", stepIndex);
                virtualAssistantWizard.Driver = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "driver", stepIndex);
                virtualAssistantWizard.PortNumber = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "portNumber", 5432, stepIndex);
                virtualAssistantWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                virtualAssistantWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                virtualAssistantWizard.SslEnabled = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "sslEnabled", true, stepIndex);
            }
            else if (virtualAssistantWizard.ModeType == EgainVirtualAssistantChangeStep.Mode.Update)
            {
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "newResourceName"))
                {
                    virtualAssistantWizard.NewResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "newResourceName", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.NewResourceName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverName"))
                {
                    virtualAssistantWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.ServerName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverAddress"))
                {
                    virtualAssistantWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.ServerAddress = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "catalogueName"))
                {
                    virtualAssistantWizard.CatalogueName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "catalogueName", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.CatalogueName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "driver"))
                {
                    virtualAssistantWizard.Driver = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "driver", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.Driver = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "portNumber"))
                {
                    virtualAssistantWizard.PortNumber = ConfigurationModelLoaderUtility.ReadIntegerValue(wizardData, "portNumber", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.PortNumber = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "userName"))
                {
                    virtualAssistantWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.UserName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "password"))
                {
                    virtualAssistantWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.Password = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "sslEnabled"))
                {
                    virtualAssistantWizard.SslEnabled = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "sslEnabled", stepIndex);
                }
                else
                {
                    virtualAssistantWizard.SslEnabled = null;
                }
            }

            return virtualAssistantWizard;
        }

        #endregion

        #region Redshift Server

        /// <summary>
        /// If wizard type is redshift server, call this method.
        /// </summary>
        private static RedshiftWizardChangeStep ProcessRedshiftServerRunWizardStep(JsonElement wizardData, int stepIndex)
        {
            RedshiftWizardChangeStep redshiftWizard = new RedshiftWizardChangeStep();

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "mode", stepIndex);

            try
            {
                redshiftWizard.ModeType = (RedshiftWizardChangeStep.Mode)Enum.Parse(typeof(RedshiftWizardChangeStep.Mode), mode);
            }
            catch
            {
                throw new SerializationException($"Invalid mode [{mode}] for step index {stepIndex}");
            }

            redshiftWizard.ResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "resourceName", stepIndex);

            if (redshiftWizard.ModeType == RedshiftWizardChangeStep.Mode.Add)
            {
                redshiftWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                redshiftWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                redshiftWizard.CatalogueName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "catalogueName", "master", stepIndex);
                redshiftWizard.Driver = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "driver", stepIndex);
                redshiftWizard.PortNumber = ConfigurationModelLoaderUtility.ReadIntegerValueOrDefault(wizardData, "portNumber", 5439, stepIndex);
                redshiftWizard.IsIAMBasedAuthentication = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(wizardData, "isIAMBasedAuthentication", true, stepIndex);
                if(redshiftWizard.IsIAMBasedAuthentication == false)
                {
                    redshiftWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                    redshiftWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                }
                redshiftWizard.TenantName = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(wizardData, "tenantName", null, stepIndex);
            }
            else if (redshiftWizard.ModeType == RedshiftWizardChangeStep.Mode.Update)
            {
                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "newResourceName"))
                {
                    redshiftWizard.NewResourceName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "newResourceName", stepIndex);
                }
                else
                {
                    redshiftWizard.NewResourceName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverName"))
                {
                    redshiftWizard.ServerName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverName", stepIndex);
                }
                else
                {
                    redshiftWizard.ServerName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "serverAddress"))
                {
                    redshiftWizard.ServerAddress = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "serverAddress", stepIndex);
                }
                else
                {
                    redshiftWizard.ServerAddress = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "catalogueName"))
                {
                    redshiftWizard.CatalogueName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "catalogueName", stepIndex);
                }
                else
                {
                    redshiftWizard.CatalogueName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "driver"))
                {
                    redshiftWizard.Driver = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "driver", stepIndex);
                }
                else
                {
                    redshiftWizard.Driver = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "tenantName"))
                {
                    redshiftWizard.TenantName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "tenantName", stepIndex);
                }
                else
                {
                    redshiftWizard.TenantName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "portNumber"))
                {
                    redshiftWizard.PortNumber = ConfigurationModelLoaderUtility.ReadIntegerValue(wizardData, "portNumber", stepIndex);
                }
                else
                {
                    redshiftWizard.PortNumber = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "userName"))
                {
                    redshiftWizard.UserName = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "userName", stepIndex);
                }
                else
                {
                    redshiftWizard.UserName = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "password"))
                {
                    redshiftWizard.Password = ConfigurationModelLoaderUtility.ReadStringValue(wizardData, "password", stepIndex);
                }
                else
                {
                    redshiftWizard.Password = null;
                }

                if (ConfigurationModelLoaderUtility.HasProperty(wizardData, "isIAMBasedAuthentication"))
                {
                    redshiftWizard.IsIAMBasedAuthentication = ConfigurationModelLoaderUtility.ReadBooleanValue(wizardData, "isIAMBasedAuthentication", stepIndex);
                }
                else
                {
                    redshiftWizard.IsIAMBasedAuthentication = null;
                }
            }

            return redshiftWizard;
        }

        #endregion

    }
}
