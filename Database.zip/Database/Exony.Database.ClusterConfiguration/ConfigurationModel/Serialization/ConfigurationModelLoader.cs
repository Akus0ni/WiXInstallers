﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text.Json;
    using System.Collections.Generic;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Diagnostics;
    using System.Runtime.Serialization;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;

    public class ConfigurationModelLoader
    {
        /// <summary>
        /// Logger for this class.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        /// <summary>
        /// Will load the model from file, for now a Json file.
        /// </summary>
        public static ClusterConfigurationChangeModel LoadModelFromFile(string filePath)
        {
            ArgumentValidation.CheckForEmptyString(filePath, nameof(filePath));
            ClusterConfigurationChangeModel model = new ClusterConfigurationChangeModel();

            string json = null;

            try
            {
                json = File.ReadAllText(filePath);
            }
            catch (FileNotFoundException fnfe)
            {
                log.Error("File path  doesnt exist", fnfe);
                throw new FileNotFoundException();
            }

            try
            {
                using (JsonDocument doc = JsonDocument.Parse(json))
                {
                    JsonElement steps = doc.RootElement;
                    JsonElement stepsArray = steps.GetProperty("steps");

                    int stepsCount = stepsArray.GetArrayLength();

                    for (int stepIndex = 0; stepIndex < stepsCount; stepIndex++)
                    {
                        string stepType = ConfigurationModelLoaderUtility.ReadStringValue(stepsArray[stepIndex], "stepType", stepIndex);

                        JsonElement stepData = stepsArray[stepIndex].GetProperty("stepData");

                        IClusterConfigurationChangeStep currentStep;

                        if (stepType.Equals("runWizard"))
                        {
                            currentStep = RunWizardStepSerializer.ProcessRunWizardStep(stepData, stepIndex);
                            model.AddStep(currentStep);
                        }
                        else if (stepType.Equals("manageTenant"))
                        {
                            currentStep = ManageTenantStepSerializer.ProcessManageTenantStep(stepData, stepIndex);
                            model.AddStep(currentStep);
                        }
                        else if (stepType.Equals("manageEquipmentMapping"))
                        {
                            currentStep = ManageEquipmentMappingStepSerializer.ProcessEquipmentMappingStep(stepData, stepIndex);
                            model.AddStep(currentStep);
                        }
                        else
                        {
                            throw new SerializationException($"Invalid step type [{stepType}] at step index {stepIndex}");
                        }
                    }
                }

                return model;
            }
            catch (Exception e)
            {
                log.Error("Failed to parse the json document", e);
                throw new SerializationException("Failed to parse the json document");

            }
        }
    }
}
