﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Text.Json;
    using static System.Text.Json.JsonElement;

    internal class ConfigurationModelLoaderUtility
    {
        #region Mandatory Fields Validator Methods

        /// <summary>
        /// Reads string Value from the json. Cannot be null, empty and anything apart from string.
        /// </summary>
        public static string ReadStringValue(JsonElement jsonElement, string propertyName, int stepIndex)
        {
            bool propertyExist = jsonElement.TryGetProperty(propertyName, out JsonElement value);

            if (propertyExist)
            {
                try
                {
                    string stringValue = value.GetString();

                    if (stringValue == null || String.IsNullOrWhiteSpace(stringValue))
                    {
                        throw new SerializationException($"Missing property value for [{propertyName}] at step index [{stepIndex}].");
                    }
                    else
                    {
                        return stringValue;
                    }
                }
                catch (InvalidOperationException)
                {
                    throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
                }
            }
            else
            {
                throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
            }
        }

        /// <summary>
        /// Reads boolean Value from the json. Cannot be null and anything apart from boolean.
        /// </summary>
        public static bool ReadBooleanValue(JsonElement jsonElement, string propertyName, int stepIndex)
        {
            bool propertyExist = jsonElement.TryGetProperty(propertyName, out JsonElement value);

            if (propertyExist)
            {
                try
                {
                    return value.GetBoolean();
                }
                catch (InvalidOperationException)
                {
                    throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
                }
            }
            else
            {
                throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
            }
        }

        /// <summary>
        /// Reads integer value from the json. Cannot be null and anything apart from integer.
        /// </summary>
        public static int ReadIntegerValue(JsonElement jsonElement, string propertyName, int stepIndex)
        {
            bool propertyExist = jsonElement.TryGetProperty(propertyName, out JsonElement value);

            if (propertyExist)
            {
                try
                {
                    return value.GetInt32();
                }
                catch (InvalidOperationException)
                {
                    throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
                }
            }
            else
            {
                throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
            }
        }

        #endregion

        #region General Methods

        /// <summary>
        /// Check if given element (json array, json object, json key) exists or not.
        /// </summary>
        public static bool HasProperty(JsonElement jsonElement, string propertyName)
        {
            return jsonElement.TryGetProperty(propertyName, out JsonElement value);
        }

        #endregion

        #region Optional Fields Validator Methods

        /// <summary>
        /// Reads string value from the json. If it is null or empty returns default value that is set.Cannot be anything apart from string
        /// </summary>
        public static string ReadStringValueOrDefault(JsonElement jsonElement, string propertyName, string defaultValue, int stepIndex)
        {
            bool propertyExist = jsonElement.TryGetProperty(propertyName, out JsonElement value);

            if (propertyExist)
            {
                try
                {
                    string stringValue = value.GetString();

                    if (String.IsNullOrWhiteSpace(stringValue)) {

                        return defaultValue;
                    }

                    return stringValue;

                } catch (InvalidOperationException)
                {
                    throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
                }

            }
            else
            {
                return defaultValue;
            }
        }

        /// <summary>
        /// Reads string array value from the json. If it is null or empty returns default value that is set.Cannot be anything apart from string
        /// </summary>
        public static List<string> ReadArrayOfStringValue(JsonElement jsonElement, string propertyName, int stepIndex)
        {
            bool propertyExist = jsonElement.TryGetProperty(propertyName, out JsonElement value);

            List<string> stringData = new List<string>();

            if (propertyExist && !value.ValueKind.Equals(JsonValueKind.Null))
            {
                try
                {
                    ArrayEnumerator stringEnumerator = value.EnumerateArray();

                    while (stringEnumerator.MoveNext())
                    {
                        string data = stringEnumerator.Current.GetString();

                        if (String.IsNullOrWhiteSpace(data))
                        {
                            throw new InvalidOperationException($"Empty or null string not allowed inside the array.");

                        }

                        stringData.Add(stringEnumerator.Current.GetString());
                    }
                }
                catch (InvalidOperationException)
                {
                    throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
                }

                return stringData;
            }
            else
            {
                return new List<string>();
            }
        }

        /// <summary>
        /// Reads int array value from the json. If it is null or empty returns default value that is set.Cannot be anything apart from string
        /// </summary>
        public static List<int> ReadArrayOfIntegerValue(JsonElement jsonElement, string propertyName, int stepIndex)
        {
            bool propertyExist = jsonElement.TryGetProperty(propertyName, out JsonElement value);

            List<int> intData = new List<int>();

            if (propertyExist && !value.ValueKind.Equals(JsonValueKind.Null))
            {
                try
                {
                    ArrayEnumerator intEnumerator = value.EnumerateArray();

                    while (intEnumerator.MoveNext())
                    {
                        intData.Add(intEnumerator.Current.GetInt32());
                    }
                }
                catch (InvalidOperationException)
                {
                    throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
                }
                return intData;
            }
            else
            {
                return new List<int>();
            }
        }

        /// <summary>
        /// Reads integer value from the json. If it is null returns default value that is set. Cannot be anything apart from integer.
        /// </summary>
        public static int ReadIntegerValueOrDefault(JsonElement jsonElement, string propertyName, int defaultValue, int stepIndex)
        {
            bool propertyExist = jsonElement.TryGetProperty(propertyName, out JsonElement value);

            if (propertyExist && !value.ValueKind.Equals(JsonValueKind.Null))
            {
                try
                {
                    return value.GetInt32();
                }
                catch (InvalidOperationException)
                {
                    throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
                }  
            }
            else
            {
                return defaultValue;
            }
        }

        /// <summary>
        /// Reads boolean value from the json. If it is null returns default value that is set. Cannot be anything apart from boolean.
        /// </summary>
        public static bool ReadBooleanValueOrDefault(JsonElement jsonElement, string propertyName, bool defaultValue, int stepIndex)
        {
            bool propertyExist = jsonElement.TryGetProperty(propertyName, out JsonElement value);

            if (propertyExist && !value.ValueKind.Equals(JsonValueKind.Null))
            {
                try
                {
                    return value.GetBoolean();
                }
                catch (InvalidOperationException)
                {
                    throw new SerializationException($"Invalid property value for [{propertyName}] at step index [{stepIndex}].");
                }
            }
            else
            {
                return defaultValue;
            }
        }

        #endregion
    }
}
