﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Text.Json;
    using System.Threading.Tasks;

    internal class ManageTenantStepSerializer
    {
        #region Methods

        /// <summary>
        /// Process manage tenant step.
        /// </summary>
        public static ManageTenantChangeStep ProcessManageTenantStep(JsonElement stepData, int stepIndex)
        {
            ManageTenantChangeStep manageTenant;

            string mode = ConfigurationModelLoaderUtility.ReadStringValue(stepData, "mode", stepIndex);

            Enum tenantConfigMode = Enum.Parse(typeof(ManageTenantChangeStep.Mode), mode) as Enum;

            if (ManageTenantChangeStep.Mode.Add.Equals(tenantConfigMode))
            {
                manageTenant = ProcessAddTenantChangeStep(stepData, stepIndex);
            }
            else
            {
                throw new SerializationException($"Invalid mode [{mode}] for step [managerTenant] at step index {stepIndex}");
            }

            return manageTenant;
        }

        /// <summary>
        /// Process add tenant step.
        /// </summary>
        private static ManageTenantChangeStep ProcessAddTenantChangeStep(JsonElement stepData, int stepIndex)
        {
            ManageTenantChangeStep manager = new ManageTenantChangeStep();

            manager.TenantName = ConfigurationModelLoaderUtility.ReadStringValue(stepData, "tenantName", stepIndex);
            manager.TenantDescription = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(stepData, "tenantDescription", "", stepIndex);

            if (ConfigurationModelLoaderUtility.HasProperty(stepData, "properties"))
            {
                JsonElement propertiesElement = stepData.GetProperty("properties");

                var iterator = propertiesElement.EnumerateObject();

                foreach (JsonProperty currentField in iterator)
                {
                    manager.TenantProperties.Add(currentField.Name, currentField.Value.ToString());
                }
            }
            
            return manager;
        }

        #endregion
    }
}
