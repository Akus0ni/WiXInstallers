﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Text.Json;
    using System.Threading.Tasks;

    internal class ManageEquipmentMappingStepSerializer
    {
        #region Methods

        /// <summary>
        /// Process equipment mapping.
        /// </summary>
        public static ManageEquipmentMappingChangeStep ProcessEquipmentMappingStep(JsonElement stepData, int stepIndex)
        {
            string mode = ConfigurationModelLoaderUtility.ReadStringValue(stepData, "mode", stepIndex);

            ManageEquipmentMappingChangeStep equipmentMap;

            Enum equipmentConfigMode = Enum.Parse(typeof(ManageEquipmentMappingChangeStep.Mode), mode) as Enum;

            if (ManageEquipmentMappingChangeStep.Mode.Add.Equals(equipmentConfigMode))
            {
                equipmentMap = ProcessAddEquipmentMappingChangeStep(stepData, stepIndex);
            }
            else
            {
                throw new SerializationException($"Inavlid mode [{mode}] for step [manageEquipmentMapping] at step index {stepIndex}");
            }

            return equipmentMap;
        }

        /// <summary>
        /// Process add equipment mapping.
        /// </summary>
        private static ManageEquipmentMappingChangeStep ProcessAddEquipmentMappingChangeStep(JsonElement stepData, int stepIndex)
        {
            ManageEquipmentMappingChangeStep map = new ManageEquipmentMappingChangeStep();

            string resourceName = ConfigurationModelLoaderUtility.ReadStringValue(stepData, "resourceName", stepIndex);
            string tenantName = ConfigurationModelLoaderUtility.ReadStringValue(stepData, "tenantName", stepIndex);
            bool defaultImportLocation = ConfigurationModelLoaderUtility.ReadBooleanValueOrDefault(stepData, "defaultImportLocation", true, stepIndex);
            string remoteTMTenantId = ConfigurationModelLoaderUtility.ReadStringValueOrDefault(stepData, "remoteTMTenantId", string.Empty,stepIndex);

            map.TenantName = tenantName;
            map.ResourceName = resourceName;
            map.DefaultImportLocation = defaultImportLocation;
            map.RemoteTMTenantId = remoteTMTenantId;

            return map;
        }

        #endregion
    }
}
