﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel
{
    /// <summary>
    /// Cluster configuration change context interface.
    /// </summary>
    public interface IClusterConfigurationChangeExecutionContext
    {
        /// <summary>
        /// Get  persistance manager.
        /// </summary>
        IPersistanceManager Manager { get; }

        /// <summary>
        /// Get data adapter.
        /// </summary>
        IDataAdapter DataAdapter { get; }
    }
}
