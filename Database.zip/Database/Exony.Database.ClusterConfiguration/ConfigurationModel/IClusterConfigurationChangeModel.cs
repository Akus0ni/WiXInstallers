﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel
{
    using System.Collections.Generic;

    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;

    /// <summary>
    /// Cluster Configuration Change Model Interface.
    /// </summary>
    public interface IClusterConfigurationChangeModel
    {
        /// <summary>
        /// Enumerator of type Cluster Configuration Change Step interface.
        /// </summary>
        IEnumerable<IClusterConfigurationChangeStep> Steps { get; }

        /// <summary>
        /// Add step to the List of cluster configuration change step.
        /// </summary>
        void AddStep(IClusterConfigurationChangeStep step);

        /// <summary>
        /// Remove step.
        /// </summary>
        bool RemoveStep(IClusterConfigurationChangeStep step);
    }
}
