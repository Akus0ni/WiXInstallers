﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Odbc;
    using System.Data.SqlClient;
    using System.Data.SqlTypes;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Reflection;
    using System.Security;
    using System.Text;
    using System.Threading.Tasks;
    using Exony.Database.Common;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.Common.Folders;
    using Exony.Diagnostics;

    public class DbDataAdapter : IDataAdapter
    {
        #region Fields

        /// <summary>
        /// Data base connection string.
        /// </summary>
        private string dbConnectionString;

        /// <summary>
        /// Audit session id
        /// </summary>
        private Guid auditSessionId;

        /// <summary>
        /// Audit session id for Data Import
        /// </summary>
        private Guid auditSessionIdForDI;

        /// <summary>
        /// System Logger.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Constructor

        /// <summary>
        /// Class constructor.
        /// </summary>
        public DbDataAdapter(String dbConnectionString)
        {
            this.dbConnectionString = dbConnectionString;
        }

        #endregion

        #region Public APIs

        /// <summary>
        /// Audit Changes
        /// </summary>
        public void WriteAuditEvent(string eventDescription, string eventRawDescription = null, Guid? guidVal1 = null, Guid? guidVal2 = null, FieldChangeXmlData fieldChangeData = null, DatabaseXmlData xmlData = null, int? intVal1 = null, int? intVal2 = null)
        {
            if (this.auditSessionId == Guid.Empty)
            {
                log.Info($"Audit session guid id is empty, generating a new session id.");
                this.auditSessionId = CreateAuditSessionId();
            }

            using (SqlConnection connection = new SqlConnection(this.dbConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = connection.CreateCommand())
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.ap_adm01_audit_event";

                    cmd.Parameters.Add(new SqlParameter("@SessionId", SqlDbType.UniqueIdentifier) { Value = this.auditSessionId });
                    cmd.Parameters.Add(new SqlParameter("@AuditTypeName", SqlDbType.NVarChar, 50) { Value = AuditType.Generic.InternalName });
                    cmd.Parameters.Add(new SqlParameter("@GuidVal1", SqlDbType.UniqueIdentifier) { Value = guidVal1 });
                    cmd.Parameters.Add(new SqlParameter("@GuidVal2", SqlDbType.UniqueIdentifier) { Value = guidVal2 });
                    cmd.Parameters.Add(new SqlParameter("@IntVal1", SqlDbType.Int) { Value = intVal1 });
                    cmd.Parameters.Add(new SqlParameter("@IntVal2", SqlDbType.Int) { Value = intVal2 });
                    cmd.Parameters.Add(new SqlParameter("@EventOutcome", SqlDbType.Char) { Value = 'S' });
                    cmd.Parameters.Add(new SqlParameter("@EventDescription", SqlDbType.NVarChar, 500) { Value = eventDescription });
                    cmd.Parameters.Add(new SqlParameter("@EventRawDescription", SqlDbType.NVarChar, 500) { Value = eventRawDescription });
                    cmd.Parameters.Add(new SqlParameter("@FieldChangeXmlData", SqlDbType.Xml) { Value = fieldChangeData?.GetDatabaseString() });
                    cmd.Parameters.Add(new SqlParameter("@XmlData", SqlDbType.Xml) { Value = xmlData?.GetDatabaseString() });
                    cmd.Parameters.Add(new SqlParameter("@AuditUrn", SqlDbType.BigInt) { Direction = ParameterDirection.Output });

                    cmd.ExecuteNonQuery();
                }

                connection.Close();
            }
        }

        /// <summary>
        /// Retrieve folder by path.
        /// </summary>
        public Folder GetFolderByPath(string path)
        {
            IDictionary<Guid, Folder> foldersById = new Dictionary<Guid, Folder>();

            using (SqlConnection connection = new SqlConnection(this.dbConnectionString))
            {
                connection.Open();
                Folder root = FolderUtil.GetFoldersById(connection, 30, out foldersById);
                connection.Close();
            }

            Folder folder = foldersById.Values.FirstOrDefault(res => res.FullPath.Equals(path, StringComparison.InvariantCultureIgnoreCase));

            if (folder == null)
            {
                throw new ArgumentException($"Could not find folder [{path}].");
            }

            return folder;
        }

        /// <summary>
        /// Add tenant.
        /// </summary>
        public Guid AddTenant(string tenantName, string tenantDescription)
        {
            using (SqlConnection connection = new SqlConnection(this.dbConnectionString))
            {
                connection.Open();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 30;
                command.CommandText = "dbo.ap_sec01_add_tenant";
                command.Parameters.AddWithValue("@AuditUser", "System");
                command.Parameters.AddWithValue("@Path", "");
                command.Parameters.AddWithValue("@Name", tenantName);
                command.Parameters.AddWithValue("@Description", tenantDescription ?? string.Empty);
                command.Parameters.AddWithValue("@XmlData", DBNull.Value);
                command.Parameters.AddWithValue("@System", false);

                SqlParameter folderIdParam = command.CreateParameter();
                folderIdParam.SqlDbType = SqlDbType.UniqueIdentifier;
                folderIdParam.ParameterName = "@OwnerId";
                folderIdParam.Direction = ParameterDirection.InputOutput;
                folderIdParam.Value = DBNull.Value;
                command.Parameters.Add(folderIdParam);
                command.ExecuteNonQuery();

                Guid folderId = (Guid)folderIdParam.Value;

                if (folderId != null)
                {
                    log.Info("Tenant created.");
                }

                connection.Close();

                return folderId;
            }
        }

        /// <summary>
        /// Add properties to tenant.
        /// </summary>
        public void AddPropertiesToTenant(Guid tenantFolderId, IDictionary<string, object> tenantProperties)
        {
            log.Info($"Adding properties to tenant [{tenantFolderId}]");

            TenantProperties properties = new TenantProperties(this.dbConnectionString);
            Type type = properties.GetType();
            properties.Load(tenantFolderId);

            foreach (KeyValuePair<string, object> propertySet in tenantProperties)
            {
                PropertyInfo property = type.GetProperty(propertySet.Key);

                try
                {
                    var value = TypeConversion.ConvertType(propertySet.Value, property.PropertyType);
                    property.SetValue(properties, value);
                }
                catch (Exception)
                {
                    log.Error($"Unable to set [{propertySet.Value}] to [{propertySet.Key}], it is an invalid property.");
                    throw new ArgumentException($"Unable to set [{propertySet.Value}] to [{propertySet.Key}], it is an invalid property.");
                }
            }

            properties.Save(tenantFolderId);
            log.Info($"Properties added to [{tenantFolderId}].");
        }

        /// <summary>
        /// Load remote tenants from the db for the Virtual Assistant
        /// </summary>
        /// <param name="resourceId">The resource identifier.</param>
        /// <param name="type">The type.</param>
        /// <param name="tenantId">The tenant id in the source db.</param>
        /// <param name="tenantName">The tenant name in the source db.</param>
        /// <returns>Loads Resource tenant mapping info</returns>
        [SuppressMessage("Microsoft.Security", "CA2100:Review SQL queries for security vulnerabilities")]
        public ResourceTenantInfo LoadResourceForVaTenant(Guid resourceId, DimensionType type, decimal tenantId, string tenantName)
        {
            if (type == null)
            {
                return null;
            }

            // check if the table name for the type is valid
            if (!SanitizeSql.IsSqlObjectNameValid(type.PrimaryViewName))
            {
                throw new SecurityException(string.Format("SQL Injection Detected: Table/View name [{0}] is not valid", type.PrimaryViewName));
            }

            ResourceTenantInfo result = new ResourceTenantInfo();

            try
            {
                using (SqlConnection connection = new SqlConnection(this.dbConnectionString))
                {
                    connection.Open();

                    // If type is null load remote tenant mapping
                    string commandText = @"IF EXISTS (
        SELECT *
        FROM [sys].[sysobjects]
        WHERE id = OBJECT_ID(@Name)
        )
BEGIN
    SELECT ITEM_BIZ_URN, NAME, PKEY_XML_DATA, TENANT_BIZ_URN, PKEY_EFFECTIVE_FROM, PKEY_EFFECTIVE_TO, PKEY_MAP_URN, INTERNAL_NAME, DESCRIPTION, PKEY_CHANGE_STAMP FROM " + type.PrimaryViewName + @"_PKEY WHERE CLUSTER_RESOURCE_ID = @ResourceId AND PKEY1 = @PKey1 AND INTERNAL_NAME = @TenantName AND STATUS <> 'D';
END;";

                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.Text;
                        command.CommandText = commandText;
                        command.Parameters.Add(new SqlParameter("Name", type.PrimaryViewName));
                        command.Parameters.Add(new SqlParameter("ResourceId", resourceId));
                        command.Parameters.Add(new SqlParameter("PKey1", tenantId));
                        command.Parameters.Add(new SqlParameter("TenantName", tenantName));

                        using (IDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string displayName = (string)reader["NAME"];
                                int urn = (int)reader["ITEM_BIZ_URN"];
                                DatabaseXmlData xmlData = new DatabaseXmlData(reader["PKEY_XML_DATA"] as string);
                                int tenantBizUrn = (int)reader["TENANT_BIZ_URN"];
                                DateTime effectiveFrom = (DateTime)reader["PKEY_EFFECTIVE_FROM"];
                                DateTime effectiveTo = (DateTime)reader["PKEY_EFFECTIVE_TO"];
                                int pkeyMapUrn = (int)reader["PKEY_MAP_URN"];
                                string internalName = (string)reader["INTERNAL_NAME"];
                                string description = (string)reader["DESCRIPTION"];
                                int pkeyChangeStamp = (int)reader["PKEY_CHANGE_STAMP"];

                                ResourceTenantInfo info = new ResourceTenantInfo
                                {
                                    DisplayName = displayName,
                                    BusinessUrn = urn,
                                    ResourceId = resourceId,
                                    DimensionType = type,
                                    PkeyXmlData = xmlData,
                                    TenantBizUrn = tenantBizUrn,
                                    PkeyEffectiveFrom = effectiveFrom,
                                    PkeyEffectiveTo = effectiveTo,
                                    PkeyMapUrn = pkeyMapUrn,
                                    InternalName = internalName,
                                    Description = description,
                                    PkeyChangeStamp = pkeyChangeStamp
                                };
                                result = info;
                            }
                            else
                            {
                                result = null;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(string.Format("Failed to load resources of type {0}", type.Name), ex);
            }

            return result;
        }

        /// <summary>
        /// Insert Tenant dimension
        /// </summary>
        /// <param name="tenantName">The name of the dimension to be inserted.</param>
        /// <param name="description">The description of the dimension to be inserted</param>
        /// <returns>The Item Urn of the dimension inserted</returns>
        public int InsertTenantDim(string tenantName, string description, DateTime effectiveFrom, Guid? folderId, Guid? ownerId)
        {
            if (this.auditSessionIdForDI == Guid.Empty)
            {
                log.Info($"Session guid id is empty, generating a new session id.");
                this.auditSessionIdForDI = CreateAuditSessionId(true);
            }
            using (SqlConnection connection = new SqlConnection(this.dbConnectionString))
            {
                connection.Open();

                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "dbo.ap_dim01_add_tenant";

                    // Return value of sproc
                    SqlParameter returnValueParam = new SqlParameter("@ReturnValue", SqlDbType.Int);
                    returnValueParam.Direction = ParameterDirection.ReturnValue;
                    command.Parameters.Add(returnValueParam);

                    // Web Session ID
                    SqlParameter sessionIDParam = new SqlParameter("@SessionID", SqlDbType.UniqueIdentifier);
                    sessionIDParam.Value = this.auditSessionIdForDI;
                    command.Parameters.Add(sessionIDParam);

                    // Name
                    SqlParameter nameParam = new SqlParameter("@Name", SqlDbType.NVarChar, 100);
                    nameParam.Value = (tenantName as object) ?? DBNull.Value;
                    command.Parameters.Add(nameParam);

                    // Description
                    SqlParameter descriptionParam = new SqlParameter("@Description", SqlDbType.NVarChar, 500);
                    descriptionParam.Value = description;
                    command.Parameters.Add(descriptionParam);

                    // Folder Id
                    SqlParameter folderIDParam = new SqlParameter("@FolderID", SqlDbType.UniqueIdentifier);
                    folderIDParam.Value = folderId;
                    command.Parameters.Add(folderIDParam);

                    // Owner Id
                    SqlParameter ownerIDParam = new SqlParameter("@OwnerID", SqlDbType.UniqueIdentifier);
                    ownerIDParam.Value = ownerId;
                    command.Parameters.Add(ownerIDParam);


                    // Effective from
                    SqlParameter effectiveFromParam = new SqlParameter("@EffectiveFrom", SqlDbType.DateTime);
                    effectiveFromParam.Value = effectiveFrom;
                    command.Parameters.Add(effectiveFromParam);

                    // Item Urn OUTPUT
                    SqlParameter identityParam = new SqlParameter("@ItemUrn", SqlDbType.Int);
                    identityParam.Direction = ParameterDirection.Output;
                    command.Parameters.Add(identityParam);

                    // Execute command
                    command.ExecuteNonQuery();

                    // Handle outputs
                    return (int)identityParam.Value;
                }
            }
        }


        public int InsertTenantDimPkeyMap(Guid clusterResourceId, int itemBizUrn, string tenantName, string description, decimal tenantId, DateTime effectiveFrom)
        {
            if (this.auditSessionIdForDI == Guid.Empty)
            {
                log.Info($"Session guid id is empty, generating a new session id.");
                this.auditSessionIdForDI = CreateAuditSessionId();
            }

            using (SqlConnection connection = new SqlConnection(this.dbConnectionString))
            {
                connection.Open();

                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "dbo.ap_dim01_add_tenant_pkey";

                    // Return value of sproc
                    SqlParameter returnValueParam = new SqlParameter("@ReturnValue", SqlDbType.Int);
                    returnValueParam.Direction = ParameterDirection.ReturnValue;
                    command.Parameters.Add(returnValueParam);

                    // Web Session ID
                    SqlParameter sessionIDParam = new SqlParameter("@SessionID", SqlDbType.UniqueIdentifier);
                    sessionIDParam.Value = this.auditSessionIdForDI;
                    command.Parameters.Add(sessionIDParam);

                    // Cluster Resource Id
                    SqlParameter clusterResourceIdParam = new SqlParameter("@ClusterResourceId", SqlDbType.UniqueIdentifier);
                    clusterResourceIdParam.Value = clusterResourceId;
                    command.Parameters.Add(clusterResourceIdParam);

                    // Item Business Urn
                    SqlParameter itemBizUrnParam = new SqlParameter("@ItemBusinessUrn", SqlDbType.Int);
                    itemBizUrnParam.Value = itemBizUrn;
                    command.Parameters.Add(itemBizUrnParam);

                    // Effective from
                    SqlParameter effectiveFromParam = new SqlParameter("@EffectiveFrom", SqlDbType.DateTime);
                    effectiveFromParam.Value = effectiveFrom;
                    command.Parameters.Add(effectiveFromParam);

                    // Effective to
                    SqlParameter effectiveToParam = new SqlParameter("@EffectiveTo", SqlDbType.DateTime);
                    effectiveToParam.Value = new DateTime(2079, 6, 6);
                    command.Parameters.Add(effectiveToParam);

                    // PKey 1
                    SqlParameter pKey1Param = new SqlParameter("@Pkey1", SqlDbType.NVarChar, 100);
                    pKey1Param.Value = tenantId;
                    command.Parameters.Add(pKey1Param);

                    // Internal Name
                    SqlParameter internalNameParam = new SqlParameter("@InternalName", SqlDbType.NVarChar, 100);
                    internalNameParam.Value = tenantName;
                    command.Parameters.Add(internalNameParam);

                    // Description
                    SqlParameter descriptionParam = new SqlParameter("@Description", SqlDbType.NVarChar, 500);
                    descriptionParam.Value = description;
                    command.Parameters.Add(descriptionParam);

                    // Item Urn OUTPUT
                    SqlParameter identityParam = new SqlParameter("@PKeyMapUrn", SqlDbType.Int);
                    identityParam.Direction = ParameterDirection.Output;
                    command.Parameters.Add(identityParam);

                    // Status
                    SqlParameter statusParam = new SqlParameter("@Status", SqlDbType.Char, 1);
                    statusParam.Direction = ParameterDirection.Output;
                    command.Parameters.Add(statusParam);

                    // Execute command
                    command.ExecuteNonQuery();

                    // Handle outputs
                    return (int)identityParam.Value;
                }
            }
        }

        /// <summary>
        /// Fetches Remote Tenant Details from source
        /// </summary>
        public DataTable GetTenantDetailsFromVaSource(string odbcConnString, string tenantAccountId)
        {
            DataTable sourceResult = new DataTable();
            try
            {
                using (OdbcConnection connection = new OdbcConnection(odbcConnString))
                {
                    connection.Open();
                    using (OdbcCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.Text;
                        command.CommandText = "select tenant_id, company AS username, description from egva.egva_tenant where account_id = CAST(? AS VARCHAR) and is_current";
                        command.Parameters.Add("@accountid", OdbcType.VarChar).Value = tenantAccountId;
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            if (reader != null)
                            {
                                sourceResult.Load(reader);
                            }
                        }
                    }
                    connection.Close();
                }
            }
            catch(Exception ex)
            {
                log.Error(ex.Message);
            }
            
            return sourceResult;
        }

        /// <summary>
        /// fetches property value of the given property key from TB_ADM_PROPERTY table
        /// </summary>
        public string FetchPropertyDetails(string propertyKey)
        {
            using (SqlConnection connection = new SqlConnection(this.dbConnectionString))
            {
                connection.Open();
                string commandText = @"SELECT PROPERTY_VALUE FROM TB_ADM_PROPERTY WHERE PROPERTY_KEY=@PropertyKey";

                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = commandText;
                    command.Parameters.Add(new SqlParameter("PropertyKey", propertyKey));

                    return TypeConversion.ConvertType<string>(command.ExecuteScalar());
                }
            }
        }

        /// <summary>
        /// Fetches default Folder and Owner Id for the specified cluster resource Id.
        /// </summary>
        public void GetDefaultFolderAndOwnerIds(Guid clusterId, out Guid defaultFolderId, out Guid? defaultOwnerId)
        {
            Guid internalDefaultFolderId = Guid.Empty;
            Guid? internalDefaultOwnerId = null;
            using (SqlConnection connection = new SqlConnection(this.dbConnectionString))
            {
                connection.Open();

                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "dbo.ap_imp01_get_default_folder_owner";

                    command.Parameters.AddWithValue("@ClusterResourceId", clusterId);
                    command.Parameters.Add("@DefaultFolderId", SqlDbType.UniqueIdentifier).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@DefaultOwnerId", SqlDbType.UniqueIdentifier).Direction = ParameterDirection.Output;

                    command.ExecuteScalar();

                    internalDefaultFolderId = (command.Parameters["@DefaultFolderId"].Value as Guid?) ?? clusterId;
                    internalDefaultOwnerId = command.Parameters["@DefaultOwnerId"].Value as Guid?;
                }
            }
            defaultFolderId = internalDefaultFolderId;
            defaultOwnerId = internalDefaultOwnerId;
        }
        #endregion

        #region Private APIs

        /// <summary>
        /// Create audit session.
        /// </summary>
        private Guid CreateAuditSessionId(bool isSystemUser = false)
        {
            SqlConnection con = new SqlConnection(this.dbConnectionString);

            try
            {
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "dbo.ap_adm01_create_new_session";

                    if(isSystemUser)
                    {
                        cmd.Parameters.AddWithValue("@SessionUserName", "System");
                        cmd.Parameters.AddWithValue("@SessionUserId", new Guid("{00000003-0000-0000-0000-000000000006}"));
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@SessionUserName", $"{Environment.UserDomainName}\\{Environment.UserName}");
                    }
                    cmd.Parameters.AddWithValue("@SessionUserAgent", $"Cluster Configuration Command Line Utility");
                    cmd.Parameters.AddWithValue("@SessionType", SessionType.ConfigurationManager.InternalName);
                    cmd.Parameters.AddWithValue("@SessionComputer", Environment.MachineName);
                    cmd.Parameters.AddWithValue("@SessionClientComputer", Environment.MachineName);
                    cmd.Parameters.AddWithValue("@ReuseExistingSession", true);

                    SqlParameter sessionIdParam = cmd.CreateParameter();
                    sessionIdParam.ParameterName = "@SessionId";
                    sessionIdParam.Direction = ParameterDirection.Output;
                    sessionIdParam.SqlDbType = SqlDbType.UniqueIdentifier;

                    cmd.Parameters.Add(sessionIdParam);
                    cmd.ExecuteNonQuery();

                    return (Guid)sessionIdParam.Value;
                }
            }

            finally
            {
                con.Close();
            }
        }

        #endregion

        #region ResourceTenantInfo class

        /// <summary>
        /// Class resource tenant info
        /// </summary>
        public class ResourceTenantInfo
        {
            /// <summary>
            /// Gets or sets the display name.
            /// </summary>
            /// <value>
            /// The display name.
            /// </value>
            public string DisplayName { get; set; }

            /// <summary>
            /// Gets or sets the resource identifier.
            /// </summary>
            /// <value>
            /// The resource identifier.
            /// </value>
            public Guid ResourceId { get; set; }

            /// <summary>
            /// Gets or sets the business urn.
            /// </summary>
            /// <value>
            /// The business urn.
            /// </value>
            public int BusinessUrn { get; set; }

            /// <summary>
            /// Gets or sets the type of the dimension.
            /// </summary>
            /// <value>
            /// The type of the dimension.
            /// </value>
            public DimensionType DimensionType { get; set; }

            /// <summary>
            /// Stores pkey xml data
            /// </summary>
            public DatabaseXmlData PkeyXmlData { get; set; }

            /// <summary>
            /// Stores remote tenant biz urn for this resource
            /// </summary>
            public int TenantBizUrn { get; set; }

            /// <summary>
            /// Stores pkey effective from date
            /// </summary>
            public DateTime PkeyEffectiveFrom { get; set; }

            /// <summary>
            /// Stores pkey effective to date
            /// </summary>
            public DateTime PkeyEffectiveTo { get; set; }

            /// <summary>
            /// Stores pkey map urn
            /// </summary>
            public int PkeyMapUrn { get; set; }

            /// <summary>
            /// Stores internal name
            /// </summary>
            public string InternalName { get; set; }

            /// <summary>
            /// Stores pkey description
            /// </summary>
            public string Description { get; set; }

            /// <summary>
            /// Stores change stamp
            /// </summary>
            public int PkeyChangeStamp { get; set; }
        }

        #endregion
    }
}
