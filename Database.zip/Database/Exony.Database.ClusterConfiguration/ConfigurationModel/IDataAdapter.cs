﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ConfigurationModel
{
    using Exony.Database.Common;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.Common.Folders;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using static Exony.Database.ClusterConfiguration.ConfigurationModel.DbDataAdapter;

    public interface IDataAdapter
    {
        /// <summary>
        /// Retrieve a folder based on its path.
        /// </summary>
        Folder GetFolderByPath(string path);

        /// <summary>
        /// Write audit event.
        /// </summary>
        void WriteAuditEvent(string eventDescription, string eventRawDescription = null, Guid? guidVal1 = null, Guid? guidVal2 = null, FieldChangeXmlData fieldChangeData = null, DatabaseXmlData xmlData = null, int? intVal1 = null, int? intVal2 = null);
        
        /// <summary>
        /// Add tenant.
        /// </summary>
        Guid AddTenant(string tenantName, string tenantDescription);

        /// <summary>
        /// Add properties to tenant.
        /// </summary>
        void AddPropertiesToTenant(Guid tenantFolderId, IDictionary<string, object> tenantProperties);

        /// <summary>
        /// Load remote tenants from the db for the Virtual Assistant
        /// </summary>
        ResourceTenantInfo LoadResourceForVaTenant(Guid resourceId, DimensionType type, decimal tenantId, string tenantName);

        /// <summary>
        /// Insert Tenant dimension
        /// </summary>
        int InsertTenantDim(string tenantName, string description, DateTime effectiveFrom, Guid? folderId, Guid? ownerId);

        /// <summary>
        /// Insert Tenant Pkey Map
        /// </summary>
        int InsertTenantDimPkeyMap(Guid clusterResourceId, int itemBizUrn, string tenantName, string description, decimal tenantId, DateTime effectiveFrom);

        /// <summary>
        /// Fetches Remote Tenant Details from source
        /// </summary>
        DataTable GetTenantDetailsFromVaSource(string odbcConnString, string tenantAccountId);

        /// <summary>
        /// Fetches property value of the given property key from TB_ADM_PROPERTY table
        /// </summary>
        string FetchPropertyDetails(string propertyKey);

        /// <summary>
        /// Fetches default Folder and Owner Id for the specified cluster resource Id.
        /// </summary>
        void GetDefaultFolderAndOwnerIds(Guid clusterId, out Guid defaultFolderId, out Guid? defaultOwnerId);
    }
}
