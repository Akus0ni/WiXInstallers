#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System.Collections.Generic;

    /// <summary>
    /// Interface for objects that support the cisco diagnostic portal web service
    /// </summary>
    public interface IDiagnosticPortalSupport : IPhysicalResourceComponent
    {
        /// <summary>
        /// The diagnostic portal port.
        /// </summary>
        string DiagnosticPortalServicePort { get; }

        /// <summary>
        /// The service endpoint url
        /// </summary>
        string DiagnosticPortalServiceUrl { get; }

        /// <summary>
        /// The log components that relate to this item
        /// </summary>
        IEnumerable<string> DiagnosticPortalLogComponentFilter { get; }

        /// <summary>
        /// The trace components that relate to this item
        /// </summary>
        IEnumerable<string> DiagnosticPortalTraceComponentFilter { get; }

        /// <summary>
        /// The service user name
        /// </summary>
        string DiagnosticPortalUserName { get; set; }

        /// <summary>
        /// The service password
        /// </summary>
        string DiagnosticPortalPassword { get; set; }
    }
}
