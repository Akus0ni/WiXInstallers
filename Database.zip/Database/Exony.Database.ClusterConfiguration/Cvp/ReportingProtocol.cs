#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Cvp
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Supported Reporting server Protocols.
    /// </summary>
    public class ReportingProtocol
    {
        #region Fields

        /// <summary>
        /// Hashset to lookup the protocol.
        /// </summary>
        private static ISet<string> Protocols = new HashSet<string>();

        /// <summary>
        /// Array that holds the protocol values.
        /// </summary>
        private static string[] ProtocolItems = {
            "drsocssl",
            "group",
            "olipcnmp",
            "olsocspx",
            "olsocssl",
            "olsoctcp",
            "onipcnmp",
            "onsocspx",
            "onsocssl",
            "onsoctcp",
            "seipcpip",
            "sesocspx",
            "sesoctcp"
        };

        #endregion

        #region Static constructor

        /// <summary>
        /// Static constructor that adds protocols to the Hashset.
        /// </summary>
        static ReportingProtocol()
        {
            foreach (string pro in ProtocolItems)
            {
                Protocols.Add(pro);
            }
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Checks if the protocol input is valid.
        /// </summary>
        public static bool Parse(string protocol)
        {
            if (Protocols.Contains(protocol))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }
}
