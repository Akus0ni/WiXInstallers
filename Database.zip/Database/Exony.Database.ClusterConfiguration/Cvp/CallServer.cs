﻿using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
using Exony.Database.Common.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exony.Database.ClusterConfiguration.Cvp
{
    /// <summary>
    /// Cvp Call server Execution class.
    /// </summary>
    public class CallServer
    {
        #region Properties

        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum updateMode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public updateMode ModeType { get; set; }
        /// <summary>
        /// Resource Name.
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// New Resource Name.
        /// </summary>
        public string NewResourceName { get; set; }

        /// <summary>
        /// Server Name of Call server.
        /// </summary>
        public string ServerName { get; set; }

        /// <summary>
        /// Server address of Call server.
        /// </summary>
        public string ServerAddress { get; set; }

        /// <summary>
        /// The name of the Icms linked to this Cvp.
        /// </summary>
        public string LinkedIcmResourceName { get; set; }

        /// <summary>
        /// The name of the Icms linked to this Cvp.
        /// </summary>
        public string LinkedCvpReportingServerResourceName { get; set; }

        /// <summary>
        /// Validates if the property exists in update mode.
        /// </summary>
        public HashSet<string> FieldsToUpdate = new HashSet<string>();

        #endregion

        #region Methods

        /// <summary>
        /// Returns the resource Id(s) of the Icm that is to be linked to the CallServer.
        /// </summary>
        public Guid? GetLinkedIcmResourceIds(ClusterConfiguration clusterConfiguration)
        {
            if (!String.IsNullOrWhiteSpace(this.LinkedIcmResourceName))
            {
                ILogicalResource icmLogicalResource = clusterConfiguration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm)
                    && lr.Name.Equals(this.LinkedIcmResourceName)).FirstOrDefault();

                if (icmLogicalResource == null)
                {
                    throw new StepExecutionException($"Specified ICM resource name [{this.LinkedIcmResourceName}] could not be found");
                }

                return icmLogicalResource.Id;
            }

            return null;
        }

        /// <summary>
        /// Returns the resource Id(s) of the reporting server that is to be linked to a single CallServer.
        /// </summary>
        public Guid? GetLinkedCvpReportingServerResourceId(ClusterConfiguration clusterConfiguration)
        {
            if (!String.IsNullOrWhiteSpace(this.LinkedCvpReportingServerResourceName))
            {
                ILogicalResource cvpReportingServerResource = clusterConfiguration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpReportingServer)
                    && lr.Name.Equals(this.LinkedCvpReportingServerResourceName)).FirstOrDefault();

                if (cvpReportingServerResource == null)
                {
                    throw new StepExecutionException($"Specified ICM resource name [{this.LinkedCvpReportingServerResourceName}] could not be found");
                }

                return cvpReportingServerResource.Id;
            }

            return null;
        }

        #endregion
    }
}
