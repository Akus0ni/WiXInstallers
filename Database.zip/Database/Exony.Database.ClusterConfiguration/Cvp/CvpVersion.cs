#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Cvp
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Supported cvp versions
    /// </summary>
    public class CvpVersion
    {
        #region Fields

        /// <summary>
        /// Display name for the cvp version
        /// </summary>
        private readonly string displayName;

        /// <summary>
        /// Folder name for the cvp version
        /// </summary>
        private readonly string folderName;

        /// <summary>
        /// Version number
        /// </summary>
        private readonly double version;

        /// <summary>
        /// All configured versions
        /// </summary>
        private static readonly IDictionary<string, CvpVersion> allVersionsByDisplayName = new Dictionary<string, CvpVersion>();

        #endregion

        #region Static Instances

        public static CvpVersion VERSION_7 = new CvpVersion("7", "Version7", 7);
        public static CvpVersion VERSION_8 = new CvpVersion("8", "Version8", 8);
        public static CvpVersion VERSION_9 = new CvpVersion("9", "Version9", 9);
        public static CvpVersion VERSION_10 = new CvpVersion("10", "Version10", 10);
        public static CvpVersion VERSION_11 = new CvpVersion("11", "Version11", 11);
        public static CvpVersion VERSION_115 = new CvpVersion("11.5", "Version115", 11.5);
        public static CvpVersion VERSION_116 = new CvpVersion("11.6", "Version116", 11.6);
        public static CvpVersion VERSION_12 = new CvpVersion("12", "Version12", 12);
        public static CvpVersion VERSION_125 = new CvpVersion("12.5", "Version125", 12.5);
        public static CvpVersion VERSION_126 = new CvpVersion("12.6", "Version126", 12.6);

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        private CvpVersion(string displayName, string folderName, double version)
        {
            this.displayName = displayName;
            this.folderName = folderName;
            this.version = version;

            allVersionsByDisplayName.Add(displayName, this);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Display name for the cvp version
        /// </summary>
        public string DisplayName
        {
            get
            {
                return this.displayName;
            }
        }

        /// <summary>
        /// Folder name for the cvp version
        /// </summary>
        public string FolderName
        {
            get
            {
                return this.folderName;
            }
        }

        /// <summary>
        /// Version number
        /// </summary>
        public double Version
        {
            get
            {
                return this.version;
            }
        }

        /// <summary>
        /// All configured versions
        /// </summary>
        public static IList<CvpVersion> AllVersions
        {
            get { return new List<CvpVersion>(allVersionsByDisplayName.Values); }
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Gets a cvp based on the displayName
        /// </summary>
        public static CvpVersion Parse(string version)
        {
            if (allVersionsByDisplayName.ContainsKey(version))
            {
                return allVersionsByDisplayName[version];
            }

            throw new ArgumentException("Specified callmanager version is invalid");
        }

        #endregion

        #region Operators

        public static bool operator >(CvpVersion x, CvpVersion y)
        {
            return x.Version > y.Version;
        }

        public static bool operator <(CvpVersion x, CvpVersion y)
        {
            return x.Version < y.Version;
        }

        public static bool operator <=(CvpVersion x, CvpVersion y)
        {
            return x.Version <= y.Version;
        }

        public static bool operator >=(CvpVersion x, CvpVersion y)
        {
            return x.Version >= y.Version;
        }

        #endregion
    }
}
