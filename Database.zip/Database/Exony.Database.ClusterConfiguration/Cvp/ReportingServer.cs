﻿using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
using Exony.Database.ClusterConfiguration.Setup;
using Exony.Database.Common.Enumerations;
using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace Exony.Database.ClusterConfiguration.Cvp
{
    /// <summary>
    /// Cvp Reporting server Execution class.
    /// </summary>
    public class ReportingServer
    {
        #region Properties

        /// <summary>
        /// Enum for wizard Mode.
        /// </summary>
        public enum updateMode
        {
            Add,
            Remove,
            Update
        }

        /// <summary>
        /// Getter Setter for enum Mode.
        /// </summary>
        public updateMode ModeType { get; set; }
        /// <summary>
        /// Resource Name.
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// New Resource Name.
        /// </summary>
        public string NewResourceName { get; set; }

        /// <summary>
        /// Server Name of Reporting server.
        /// </summary>
        public string ServerName { get; set; }

        /// <summary>
        /// Server address of Reporting server.
        /// </summary>
        public string ServerAddress { get; set; }

        /// <summary>
        /// Instance Name of Reporting server.
        /// </summary>
        public string InstanceName { get; set; }

        /// <summary>
        /// Protocol of Reporting server.
        /// </summary>
        public string Protocol { get; set; }

        /// <summary>
        /// Service No of Reporting server.
        /// </summary>
        public int Service { get; set; }

        /// <summary>
        /// User Name to access Reporting server.
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Password to access Reporting server.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// CoreCatalogue to access Reporting server.
        /// </summary>
        public string CoreCatalog { get; set; }

        /// <summary>
        /// Callback Catalogue to access Reporting server.
        /// </summary>
        public string CallbackCatalog { get; set; }

        /// <summary>
        /// Validates if the property exists in update mode.
        /// </summary>
        public HashSet<string> FieldsToUpdate = new HashSet<string>();

        /// <summary>
        /// The ids of the call servers that are connected to this reporting server
        /// A single reporting server may be connected to multiple call servers
        /// </summary>
        public List<string> LinkedCvpCallServerResourceNames { get; set; }

        /// <summary>
        /// The id of the connected mediator resource for import
        /// </summary>
        public string ConnectedMediatorResourceName { get; set; }
        #endregion

        /// <summary>
        /// Returns the resource Id(s) of the calls server that are to be linked to the reporting server.
        /// </summary>
        public List<Guid> GetLinkedCallServerResourceIds(ClusterConfiguration clusterConfiguration)
        {
            HashSet<Guid> linkedCallServerResourceIds = new HashSet<Guid>();

            if (this.LinkedCvpCallServerResourceNames == null)
            {
                return linkedCallServerResourceIds.ToList();
            }

            foreach (String currentResourceName in this.LinkedCvpCallServerResourceNames)
            {
                if (String.IsNullOrWhiteSpace(currentResourceName))
                {
                    continue;
                }

                ILogicalResource callServerLogicalResource = clusterConfiguration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpCallServer)
                    && lr.Name.Equals(currentResourceName)).FirstOrDefault();

                if (callServerLogicalResource == null)
                {
                    throw new StepExecutionException($"Specified call server resource name [{currentResourceName}] could not be found");
                }

                linkedCallServerResourceIds.Add(callServerLogicalResource.Id);
            }

            return linkedCallServerResourceIds.ToList();
        }

        /// <summary>
        /// Returns the resource Id(s) of the mediator server that is to be linked to the Reporting server.
        /// </summary>
        public Guid? GetConnectedMediatorResourceId(ClusterConfiguration clusterConfiguration)
        {
            if (!String.IsNullOrWhiteSpace(this.ConnectedMediatorResourceName))
            {
                ILogicalResource mediatorLogicalResource = clusterConfiguration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyMediatorService)
                    && lr.Name.Equals(this.ConnectedMediatorResourceName)).FirstOrDefault();

                if (mediatorLogicalResource == null)
                {
                    throw new StepExecutionException($"Specified ICM resource name [{this.ConnectedMediatorResourceName}] could not be found");
                }

                return mediatorLogicalResource.Id;
            }

            return null;
        }
    }
}
