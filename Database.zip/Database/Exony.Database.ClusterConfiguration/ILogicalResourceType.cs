#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System.Collections.Generic;

    using Exony.Database.ClusterConfiguration.Collections;

    public interface ILogicalResourceType : IClusterObject
    {
        /// <summary>
        /// Name for this cluster object
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Internal name for this cluster object
        /// </summary>
        string InternalName { get; set; }

        /// <summary>
        /// Description for this cluster object
        /// </summary>
        string Description { get; set; }

        /// <summary>
        /// The group for this resource type
        /// </summary>
        ILogicalResourceTypeGroup ResourceTypeGroup { get; set; }

        /// <summary>
        /// The default component type for this resource (if defined)
        /// </summary>
        IPhysicalResourceComponentType DefaultComponentType { get; }

        /// <summary>
        /// Component types supported by physical resources of this logical resource type
        /// </summary>
        PhysicalResourceComponentTypeCollection ComponentTypes { get; }

        /// <summary>
        /// Logical resources with this type
        /// </summary>
        IEnumerable<ILogicalResource> LogicalResources { get; }

        /// <summary>
        /// The minumum number of resources of this type that should exist in the system
        /// </summary>
        int MinResources { get; set; }

        /// <summary>
        /// The maximum number of resources of this type that should exist in the system
        /// </summary>
        int? MaxResources { get; set; }

        /// <summary>
        /// The minimum number of sides that each resource of this type should have
        /// </summary>
        int MinResourceInstances { get; set; }

        /// <summary>
        /// The maximum number of sides that each resource of this type should have
        /// </summary>
        int? MaxResourceInstances { get; set; }

        /// <summary>
        /// Indicates if the the system imports data from this resource type
        /// </summary>
        bool ImportSupported { get; set; }
    }
}
