#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;

    /// <summary>
    /// Defines the possible locations for cluster field storage
    /// </summary>
    public enum ClusterFieldStorageType
    {
        Standard,
        Xml
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class ClusterFieldAttribute : Attribute
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ClusterFieldAttribute()
        {
            this.StorageType = ClusterFieldStorageType.Standard;
        }

        /// <summary>
        /// Name of the field
        /// </summary>
        public string FieldName { get; set; }

        /// <summary>
        /// Is the field encrypted?
        /// </summary>
        public bool Encrypted { get; set; }

        /// <summary>
        /// Ignores database operation for the attribute.
        /// </summary>
        public bool IgnoreOnCreate { get; set; }

        /// <summary>
        /// Indicates if this is a transient field - i.e. a field that is used to store transient state for a service
        /// Transient fields are handled differently when loading/saving the model dependentent on the model load type
        /// </summary>
        public bool Transient { get; set; }

        /// <summary>
        /// Where is the data stored?
        /// </summary>
        public ClusterFieldStorageType StorageType { get; set; }

        /// <summary>
        /// Is this field stored in secrets manager.
        /// </summary>
        public bool Secret { get; set; }

        /// <summary>
        /// Regular expression for determining if value should be 
        /// stored in remote secrets manager. Only used if Secret = true.
        /// </summary>
        public string SecretRegex { get; set; }
    }
}
