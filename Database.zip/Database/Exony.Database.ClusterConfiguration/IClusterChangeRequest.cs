#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;

    /// <summary>
    /// Interface for all cluster change requests
    /// </summary>
    public interface IClusterChangeRequest
    {
        /// <summary>
        /// Primary key id for the cluster object
        /// </summary>
        Guid Id { get; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        void ApplyChange(ClusterConfiguration model);

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        void RevertChange(ClusterConfiguration model);
    }
}
