#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Delegate for hierarchy constraint events
    /// </summary>
    public delegate void ClusterObjectPropertyChangedEventDelegate(object sender, string propertyName, object oldValue, object newValue);

    /// <summary>
    /// Interface for all logical resource implementations
    /// </summary>
    public interface IClusterObject
    {
        /// <summary>
        /// Primary key id for this cluster object
        /// </summary>
        Guid Id { get; }

        /// <summary>
        /// Indicates if this cluster object is enabled
        /// </summary>
        bool Enabled { get; set; }

        /// <summary>
        /// Indicates if this cluster object is a system object
        /// </summary>
        bool System { get; set; }

        /// <summary>
        /// The master configuration for this cluster object
        /// </summary>
        ClusterConfiguration Configuration { get; }

        /// <summary>
        /// Fired when a property is changed
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        event ClusterObjectPropertyChangedEventDelegate PropertyChanged;

        /// <summary>
        /// Save this object's state
        /// </summary>
        IDictionary<string, object> SaveState();

        /// <summary>
        /// Load this object's state
        /// </summary>
        void LoadState(IDictionary<string, object> state);

        /// <summary>
        /// Validate this cluster object
        /// </summary>
        IEnumerable<IClusterValidationResult> Validate();

        /// <summary>
        /// Get the value of a property by name
        /// </summary>
        object GetPropertyValue(string propertyName);

        /// <summary>
        /// Set the value of a property by name
        /// </summary>
        void SetPropertyValue(string propertyName, object value);

        /// <summary>
        /// Get a display name for this object
        /// </summary>
        string DisplayName { get; }

        /// <summary>
        /// Set a cluster field based on it's cluster field name. Optional encrypted flag indicates if an encrypted value is being passed through.
        /// </summary>
        void SetClusterField(string name, object value, bool encrypted);

        /// <summary>
        /// Get a cluster field based on it's cluster field name.
        /// </summary>
        object GetClusterField(string name);

        /// <summary>
        /// Retrieve info for a cluster fields
        /// </summary>
        ClusterObjectFieldInfo GetClusterFieldInfo(string name);
    }

    /// <summary>
    /// Class definining properties for a cluster object field
    /// Allows future enhancement without changing interface
    /// </summary>
    public class ClusterObjectFieldInfo
    {
        public ClusterObjectFieldInfo(bool transient)
        {
            this.Transient = transient;
        }

        public bool Transient { get; private set; }
    }
}
