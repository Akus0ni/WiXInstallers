#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;

    [Flags]
    public enum ClusterConfigVisibility
    {
        Hidden = 0,
        Basic = 1,
        Advanced = 2,
        CloudOnly = 4
    }

    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public sealed class ClusterConfigVisibilityAttribute : Attribute
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ClusterConfigVisibilityAttribute(ClusterConfigVisibility visibility)
        {
            this.Visibility = visibility;
        }

        /// <summary>
        /// Visibility level
        /// </summary>
        public ClusterConfigVisibility Visibility { get; set; }
    }
}