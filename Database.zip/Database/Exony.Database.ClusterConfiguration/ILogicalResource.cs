#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Collections.Generic;

    using Exony.Database.ClusterConfiguration.Collections;

    /// <summary>
    /// Interface for all logical resource implementations
    /// </summary>
    public interface ILogicalResource : IClusterObject
    {
        /// <summary>
        /// Type information for this logical resource
        /// </summary>
        ILogicalResourceType ResourceType { get; }

        /// <summary>
        /// Optional version number for the logical resource, e.g. 5.0, 7.1 etc for CICM awdb logical resource
        /// </summary>
        string Version { get; set; }

        /// <summary>
        /// Name for this cluster object
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Description for this cluster object
        /// </summary>
        string Description { get; set; }

        /// <summary>
        /// Indicates whether the logical resource can be used for provisioning or not
        /// </summary>
        bool Provisionable { get; set; }

        /// <summary>
        /// When this logical resource was created.
        /// </summary>
        DateTime CreatedDate { get; }

        /// <summary>
        /// Integer alternate key for this logical resource
        /// </summary>
        int ResourceUrn { get; }

        /// <summary>
        /// The physical resource associated with this logical resource
        /// </summary>
        PhysicalResourceCollection PhysicalResources { get; }

        /// <summary>
        /// All resource members where this resource is the child
        /// </summary>
        LogicalResourceMemberCollection ParentResourceMembers { get; }

        /// <summary>
        /// All resource members where this resource is the parent
        /// </summary>
        LogicalResourceMemberCollection ChildResourceMembers { get; }

        /// <summary>
        /// Gets all physical resources for this logical resource where the publisher flag is set to true
        /// </summary>
        IEnumerable<IPhysicalResource> PhysicalResourcePublishers { get; }

        /// <summary>
        /// Gets all physical resources for this logical resource where the publisher flag is set to false
        /// </summary>
        IEnumerable<IPhysicalResource> PhysicalResourceSubscribers { get; }

        /// <summary>
        /// The folder mappings associated with this logical resource
        /// </summary>
        LogicalResourceFolderMappingCollection FolderMappings { get; }

        /// <summary>
        /// The entity type mappings associated with this logical resource
        /// </summary>
        LogicalResourceEntityTypeMappingCollection EntityTypeMappings { get; }

        /// <summary>
        /// Ensures that mappings exist for all database types
        /// </summary>
        void AddAllDatabaseTypeMappings();
    }
}
