#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System.Reflection;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Extension methods
    /// </summary>
    public static class Extensions
    {
        private static readonly Regex guidMatcher = new Regex("[{]?[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}[{]?");

        public static string PropertyName(this MethodBase methodBase)
        {
            return methodBase.Name.Replace("get_", string.Empty).Replace("set_", string.Empty);
        }

        public static bool IsGuid(this string str)
        {
            if (str == null || str.Length < 36)
            {
                return false;
            }

            return guidMatcher.IsMatch(str);
        }
    }
}
