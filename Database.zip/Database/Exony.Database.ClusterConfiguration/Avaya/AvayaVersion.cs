#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Avaya
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Supported Avaya versions
    /// </summary>
    public class AvayaVersion
    {
        #region Fields

        /// <summary>
        /// Display name for the Avaya version
        /// </summary>
        private readonly string displayName;

        /// <summary>
        /// Folder name for the Avaya version
        /// </summary>
        private readonly string folderName;

        /// <summary>
        /// Version number
        /// </summary>
        private readonly double version;

        /// <summary>
        /// All configured versions
        /// </summary>
        private static readonly IDictionary<string, AvayaVersion> allVersionsByDisplayName = new Dictionary<string, AvayaVersion>();

        #endregion

        #region Static Instances

        public static AvayaVersion VERSION_12 = new AvayaVersion("R12", "Version12", 12);
        public static AvayaVersion VERSION_13 = new AvayaVersion("R13", "Version13", 13);
        public static AvayaVersion VERSION_14 = new AvayaVersion("R14", "Version14", 14);
        public static AvayaVersion VERSION_15= new AvayaVersion("R15", "Version15", 15);
        public static AvayaVersion VERSION_16 = new AvayaVersion("R16", "Version16", 16);
        public static AvayaVersion VERSION_17 = new AvayaVersion("R17", "Version17", 17);

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        private AvayaVersion(string displayName, string folderName, double version)
        {
            this.displayName = displayName;
            this.folderName = folderName;
            this.version = version;

            allVersionsByDisplayName.Add(displayName, this);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Display name for the avaya version
        /// </summary>
        public string DisplayName
        {
            get
            {
                return this.displayName;
            }
        }

        /// <summary>
        /// Folder name for the avaya version
        /// </summary>
        public string FolderName
        {
            get
            {
                return this.folderName;
            }
        }

        /// <summary>
        /// Version number
        /// </summary>
        public double Version
        {
            get
            {
                return this.version;
            }
        }

        /// <summary>
        /// All configured versions
        /// </summary>
        public static IList<AvayaVersion> AllVersions
        {
            get { return new List<AvayaVersion>(allVersionsByDisplayName.Values); }
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Gets a avaya based on the displayName
        /// </summary>
        public static double Parse(string version)
        {
            if (allVersionsByDisplayName.ContainsKey(version))
            {
                return allVersionsByDisplayName[version].Version;
            }

            throw new ArgumentException("Specified avaya version is invalid");
        }

        #endregion

        #region Operators

        public static bool operator >(AvayaVersion x, AvayaVersion y)
        {
            return x.Version > y.Version;
        }

        public static bool operator <(AvayaVersion x, AvayaVersion y)
        {
            return x.Version < y.Version;
        }

        public static bool operator <=(AvayaVersion x, AvayaVersion y)
        {
            return x.Version <= y.Version;
        }

        public static bool operator >=(AvayaVersion x, AvayaVersion y)
        {
            return x.Version >= y.Version;
        }

        #endregion
    }
}
