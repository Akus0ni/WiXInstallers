#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System.Globalization;

    public class ClusterValidationResult : IClusterValidationResult
    {
        #region Fields

        /// <summary>
        /// The severity associated with this result
        /// </summary>
        private readonly ClusterValidationSeverity severity;

        /// <summary>
        /// The object that reported the validation failure
        /// </summary>
        private readonly IClusterObject affectedObject;

        /// <summary>
        /// Details about the validation failure
        /// </summary>
        private readonly string message;

        #endregion

        #region Construction

        public ClusterValidationResult(ClusterValidationSeverity severity, IClusterObject affectedObject, string message)
            : this(severity, affectedObject, message, new object[0])
        {
        }

        public ClusterValidationResult(ClusterValidationSeverity severity, IClusterObject affectedObject, string messageFormat, params object[] messageParams)
        {
            this.severity = severity;
            this.affectedObject = affectedObject;
            this.message = string.Format(CultureInfo.InvariantCulture, messageFormat, messageParams);
        }

        #endregion

        #region Implementation of IClusterValidationResult

        /// <summary>
        /// The severity associated with this result
        /// </summary>
        public ClusterValidationSeverity Severity
        {
            get { return this.severity; }
        }

        /// <summary>
        /// The object that reported the validation failure
        /// </summary>
        public IClusterObject AffectedObject
        {
            get { return this.affectedObject; }
        }

        /// <summary>
        /// Details about the validation failure
        /// </summary>
        public string Message
        {
            get { return this.message; }
        }

        #endregion
    }
}
