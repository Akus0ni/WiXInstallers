#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Remove
{
    using Exony.Database.ClusterConfiguration.ChangeRequests.Add;

    public class RemovePhysicalServerChangeRequest : RemoveItemChangeRequest
    {
        /// <summary>
        /// Add request
        /// </summary>
        private readonly AddPhysicalServerChangeRequest addRequest;

        /// <summary>
        /// Default constructor
        /// </summary>
        public RemovePhysicalServerChangeRequest(IPhysicalServer server)
            : base(server)
        {
            this.addRequest = new AddPhysicalServerChangeRequest(server);
        }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            this.addRequest.RevertChange(model);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            this.addRequest.ApplyChange(model);
        }
    }
}
