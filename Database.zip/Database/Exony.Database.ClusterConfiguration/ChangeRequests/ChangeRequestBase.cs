#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests
{
    using System;

    public abstract class ChangeRequestBase : IClusterChangeRequest
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        protected ChangeRequestBase(IClusterObject obj)
        {
            this.Id = obj.Id;
        }

        /// <summary>
        /// Primary key id for the cluster object
        /// </summary>
        public Guid Id { get; protected set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public abstract void ApplyChange(ClusterConfiguration model);

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public abstract void RevertChange(ClusterConfiguration model);
    }
}
