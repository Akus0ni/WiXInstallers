#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    using System;

    using Exony.Database.ClusterConfiguration.PhysicalResources;

    public class AddPhysicalResourceChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddPhysicalResourceChangeRequest(IPhysicalResource resource)
            : base(resource)
        {
            this.ResourceTypeInternalName = resource.LogicalResource.ResourceType.InternalName;
        }

        /// <summary>
        /// The internal name of the resource type
        /// </summary>
        public string ResourceTypeInternalName { get; private set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            Guid parentId = (Guid)this.State["RESOURCE_ID"];

            ILogicalResource parent = (ILogicalResource)model.GetClusterObjectById(parentId);

            IPhysicalResource pr = PhysicalResourceFactory.CreatePhysicalResource(parent, this.Id);
            pr.LoadState(this.State);
            parent.PhysicalResources.Add(pr);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            IPhysicalResource pr = (IPhysicalResource)model.GetClusterObjectById(this.Id);
            pr.LogicalResource.PhysicalResources.Remove(pr);
        }
    }
}
