#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    using Exony.Database.ClusterConfiguration.LogicalResources;

    public class AddLogicalResourceChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddLogicalResourceChangeRequest(ILogicalResource resource)
            : base(resource)
        {
            this.ResourceTypeInternalName = resource.ResourceType.InternalName;
        }

        /// <summary>
        /// The internal name of the resource type
        /// </summary>
        public string ResourceTypeInternalName { get; private set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            ILogicalResource lr = LogicalResourceFactory.CreateLogicalResource(this.ResourceTypeInternalName, model, this.Id);
            lr.LoadState(this.State);
            model.LogicalResources.Add(lr);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            ILogicalResource lr = (ILogicalResource)model.GetClusterObjectById(this.Id);
            model.LogicalResources.Remove(lr);
        }
    }
}
