#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests
{
    using System;
    using System.Linq;

    using Exony.Database.ClusterConfiguration.ChangeRequests.Add;
    using Exony.Database.Common.DataObjects.Resources;

    public class AddLogicalResourceFolderItemMappingChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddLogicalResourceFolderItemMappingChangeRequest(ILogicalResourceFolderItemMapping mapping)
            : base(mapping)
        {
            this.Item = mapping.Item;
            this.LogicalResourceFolderMappingId = mapping.LogicalResourceFolderMapping.Id;
            this.ClusterResourceId = mapping.LogicalResourceFolderMapping.ResourceId;
        }

        public Guid LogicalResourceFolderMappingId { get; private set; }

        /// <summary>
        /// The resource key of associated item
        /// </summary>
        public ResourceKey Item { get; private set; }

        /// <summary>
        /// The id of associated cluster resource
        /// </summary>
        public Guid ClusterResourceId { get; private set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            ILogicalResourceFolderMapping parent = (ILogicalResourceFolderMapping)model.GetClusterObjectById(this.LogicalResourceFolderMappingId);

            ILogicalResourceFolderItemMapping mapping = new LogicalResourceFolderItemMapping(parent, this.Item, this.Id);
            mapping.LoadState(this.State);
            parent.ResourceFolderItemMappings.Add(mapping);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            ILogicalResourceFolderMapping parent = (ILogicalResourceFolderMapping)model.GetClusterObjectById(this.LogicalResourceFolderMappingId);
            ILogicalResourceFolderItemMapping folderItemMapping = parent.ResourceFolderItemMappings.FirstOrDefault(fim => fim.Id == this.Id);
            parent.ResourceFolderItemMappings.Remove(folderItemMapping);
        }
    }
}
