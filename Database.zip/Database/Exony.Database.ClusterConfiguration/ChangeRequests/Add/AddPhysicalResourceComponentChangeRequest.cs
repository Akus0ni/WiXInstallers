#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    using System;

    using Exony.Database.ClusterConfiguration.PhysicalResourceComponents;

    public class AddPhysicalResourceComponentChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddPhysicalResourceComponentChangeRequest(IPhysicalResourceComponent comp)
            : base(comp)
        {
            this.ResourceTypeInternalName = comp.PhysicalResource.LogicalResource.ResourceType.InternalName;
            this.ComponentTypeInternalName = comp.ComponentType.InternalName;
        }

        /// <summary>
        /// The internal name of the resource type
        /// </summary>
        public string ResourceTypeInternalName { get; private set; }

        /// <summary>
        /// The internal name of the resource type
        /// </summary>
        public string ComponentTypeInternalName { get; private set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            Guid parentId = (Guid)this.State["RESOURCE_INSTANCE_ID"];

            IPhysicalResource parent = (IPhysicalResource)model.GetClusterObjectById(parentId);

            IPhysicalResourceComponent prc = PhysicalResourceComponentFactory.CreatePhysicalResourceComponent(parent, this.ComponentTypeInternalName, this.Id);
            prc.LoadState(this.State);
            parent.Components.Add(prc);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            IPhysicalResourceComponent prc = (IPhysicalResourceComponent)model.GetClusterObjectById(this.Id);
            prc.PhysicalResource.Components.Remove(prc);
        }
    }
}
