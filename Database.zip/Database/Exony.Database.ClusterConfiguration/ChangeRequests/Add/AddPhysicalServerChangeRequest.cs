#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    public class AddPhysicalServerChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddPhysicalServerChangeRequest(IPhysicalServer server)
            : base(server)
        {
        }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            IPhysicalServer s = new PhysicalServer(model, this.Id);
            s.LoadState(this.State);
            model.PhysicalServers.Add(s);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            IPhysicalServer s = (IPhysicalServer)model.GetClusterObjectById(this.Id);
            model.PhysicalServers.Remove(s);
        }
    }
}
