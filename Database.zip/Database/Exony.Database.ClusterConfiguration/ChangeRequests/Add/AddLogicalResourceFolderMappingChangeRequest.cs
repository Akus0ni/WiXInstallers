#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    using System;
    using System.Linq;

    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;

    public class AddLogicalResourceFolderMappingChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddLogicalResourceFolderMappingChangeRequest(ILogicalResourceFolderMapping mapping)
            : base(mapping)
        {
            this.ClusterResourceId = mapping.ResourceId;
            this.MappingType = (LogicalResourceFolderMappingType)mapping.Type;
        }

        public Guid ClusterResourceId { get; private set; }

        /// <summary>
        /// The type of the resource type
        /// </summary>
        public LogicalResourceFolderMappingType MappingType { get; private set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            Guid folderId = (Guid)this.State["FOLDER_ID"];
            var folder = model.Folders.Single(x => x.Id == folderId);

            ILogicalResource parent = (ILogicalResource)model.GetClusterObjectById(this.ClusterResourceId);

            ILogicalResourceFolderMapping mapping = LogicalResourceFolderMappingFactory.CreateLogicalResourceFolderMapping(this.MappingType, parent, folder, this.Id);
            mapping.LoadState(this.State);
            parent.FolderMappings.Add(mapping);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            ILogicalResourceFolderMapping mapping = (ILogicalResourceFolderMapping)model.GetClusterObjectById(this.Id);
            mapping.LogicalResource.FolderMappings.Remove(mapping);
        }
    }
}
