#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    using System;

    using Exony.Database.ClusterConfiguration.PhysicalConnections;

    public class AddPhysicalConnectionChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddPhysicalConnectionChangeRequest(IPhysicalConnection connection)
            : base(connection)
        {
            this.ConnectionTypeInternalName = connection.ConnectionType.InternalName;
            this.ConnectionStatus = connection.ConnectionStatus;
        }

        /// <summary>
        /// The internal name of the connection type
        /// </summary>
        public string ConnectionTypeInternalName { get; private set; }

        /// <summary>
        /// Holds the connection status information to be inserted to the separated table
        /// </summary>
        public IPhysicalConnectionStatus ConnectionStatus { get; private set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            Guid sinkId = (Guid)this.State["SINK_COMPONENT_ID"];
            Guid sourceId = (Guid)this.State["SOURCE_COMPONENT_ID"];

            IPhysicalResourceComponent sinkComponent = (IPhysicalResourceComponent)model.GetClusterObjectById(sinkId);
            IPhysicalResourceComponent sourceComponent = (IPhysicalResourceComponent)model.GetClusterObjectById(sourceId);

            IPhysicalConnection conn = PhysicalConnectionFactory.CreatePhysicalConnection(this.ConnectionTypeInternalName, sourceComponent, sinkComponent, this.Id);
            conn.LoadState(this.State);
            sourceComponent.OutboundConnections.Add(conn);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            IPhysicalConnection conn = (IPhysicalConnection)model.GetClusterObjectById(this.Id);
            conn.SourceComponent.OutboundConnections.Remove(conn);
        }
    }
}
