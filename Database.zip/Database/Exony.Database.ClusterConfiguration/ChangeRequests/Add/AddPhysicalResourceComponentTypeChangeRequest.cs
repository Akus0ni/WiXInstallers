#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    using System;

    public class AddPhysicalResourceComponentTypeChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Id of the parent type
        /// </summary>
        private readonly Guid logicalResourceTypeId;

        /// <summary>
        /// Default constructor
        /// </summary>
        public AddPhysicalResourceComponentTypeChangeRequest(IPhysicalResourceComponentType type)
            : base(type)
        {
            this.logicalResourceTypeId = type.ResourceType.Id;
        }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            ILogicalResourceType lrt = (ILogicalResourceType)model.GetClusterObjectById(this.logicalResourceTypeId);
            IPhysicalResourceComponentType type = new PhysicalResourceComponentType(lrt, this.Id);
            type.LoadState(this.State);
            lrt.ComponentTypes.Add(type);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            IPhysicalResourceComponentType type = (IPhysicalResourceComponentType)model.GetClusterObjectById(this.Id);
            type.ResourceType.ComponentTypes.Remove(type);
        }
    }
}
