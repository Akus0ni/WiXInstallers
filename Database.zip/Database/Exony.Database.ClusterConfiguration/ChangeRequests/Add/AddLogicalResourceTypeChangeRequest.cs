#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    public class AddLogicalResourceTypeChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddLogicalResourceTypeChangeRequest(ILogicalResourceType type)
            : base(type)
        {
        }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            ILogicalResourceType type = new LogicalResourceType(model, this.Id);
            type.LoadState(this.State);
            model.LogicalResourceTypes.Add(type);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            ILogicalResourceType type = (ILogicalResourceType)model.GetClusterObjectById(this.Id);
            model.LogicalResourceTypes.Remove(type);
        }
    }
}
