#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    public class AddLogicalResourceTypeGroupChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddLogicalResourceTypeGroupChangeRequest(ILogicalResourceTypeGroup group)
            : base(group)
        {
        }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            ILogicalResourceTypeGroup group = new LogicalResourceTypeGroup(model, this.Id);
            group.LoadState(this.State);
            model.LogicalResourceTypeGroups.Add(group);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            ILogicalResourceTypeGroup group = (ILogicalResourceTypeGroup)model.GetClusterObjectById(this.Id);
            model.LogicalResourceTypeGroups.Remove(group);
        }
    }
}
