#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    using System;

    public class AddLogicalResourceMemberChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddLogicalResourceMemberChangeRequest(ILogicalResourceMember member)
            : base(member)
        {
        }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            Guid parentResourceId = (Guid)this.State["PARENT_RESOURCE_ID"];
            Guid childResourceId = (Guid)this.State["CHILD_RESOURCE_ID"];

            ILogicalResource parent = (ILogicalResource)model.GetClusterObjectById(parentResourceId);
            ILogicalResource child = (ILogicalResource)model.GetClusterObjectById(childResourceId);

            ILogicalResourceMember member = new LogicalResourceMember(parent, child, this.Id);
            member.LoadState(this.State);
            parent.ChildResourceMembers.Add(member); // Other end added automatically
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            ILogicalResourceMember member = (ILogicalResourceMember)model.GetClusterObjectById(this.Id);

            member.ParentResource.ChildResourceMembers.Remove(member); // Other end removed automatically
        }
    }
}
