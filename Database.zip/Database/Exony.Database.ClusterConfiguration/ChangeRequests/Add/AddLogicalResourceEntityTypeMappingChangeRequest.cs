#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.Add
{
    using System;

    using Exony.Database.Common.Enumerations;

    public class AddLogicalResourceEntityTypeMappingChangeRequest : AddItemChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public AddLogicalResourceEntityTypeMappingChangeRequest(ILogicalResourceEntityTypeMapping mapping)
            : base(mapping)
        {
            this.ClusterResourceId = mapping.LogicalResource.Id;
            this.EntityTypeInternalName = mapping.EntityTypeInternalName;
        }

        public Guid ClusterResourceId { get; private set; }

        /// <summary>
        /// The internal name of the resource type
        /// </summary>
        public string EntityTypeInternalName { get; private set; }

        /// <summary>
        /// The remote equipment of the mapped items
        /// </summary>
        public Guid? SourceClusterResourceId { get; private set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            Guid parentId = (Guid)this.State["CLUSTER_RESOURCE_ID"];
            Guid entityTypeId = new Guid(this.State["ENTITY_TYPE_ID"].ToString());
            Guid? sourceClusterResourceId = this.State["SOURCE_CLUSTER_RESOURCE_ID"] as Guid?;

            ILogicalResource parent = (ILogicalResource)model.GetClusterObjectById(parentId);

            ILogicalResource sourceLogicalResource = sourceClusterResourceId.HasValue ? (ILogicalResource)model.GetClusterObjectById(sourceClusterResourceId.Value) : null;

            ILogicalResourceEntityTypeMapping mapping = new LogicalResourceEntityTypeMapping(parent, this.Id, ResourceTypeFactory.GetById(entityTypeId), sourceLogicalResource);
            mapping.LoadState(this.State);
            parent.EntityTypeMappings.Add(mapping);
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            ILogicalResourceEntityTypeMapping mapping = (ILogicalResourceEntityTypeMapping)model.GetClusterObjectById(this.Id);
            mapping.LogicalResource.EntityTypeMappings.Remove(mapping);
        }
    }
}
