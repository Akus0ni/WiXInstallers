#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.SetProperty
{
    public class SetPhysicalConnectionTypePropertyChangeRequest : SetPropertyChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SetPhysicalConnectionTypePropertyChangeRequest(IPhysicalConnectionType obj, string propertyName, object newValue, object oldValue)
            : base(obj, propertyName, newValue, oldValue)
        {
        }
    }
}
