#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.SetProperty
{
    using System;

    public class SetLogicalResourceFolderMappingPropertyChangeRequest : SetPropertyChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SetLogicalResourceFolderMappingPropertyChangeRequest(ILogicalResourceFolderMapping obj, string propertyName, object newValue, object oldValue)
            : base(obj, propertyName, newValue, oldValue)
        {
            this.ClusterResourceId = obj.ResourceId;
            this.MappingType = (LogicalResourceFolderMappingType)obj.Type;
        }

        public Guid ClusterResourceId { get; private set; }

        public LogicalResourceFolderMappingType MappingType { get; private set; }
    }
}
