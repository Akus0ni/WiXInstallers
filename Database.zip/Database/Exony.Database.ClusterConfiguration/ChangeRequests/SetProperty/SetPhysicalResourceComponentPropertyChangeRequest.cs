#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.SetProperty
{
    public class SetPhysicalResourceComponentPropertyChangeRequest : SetPropertyChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SetPhysicalResourceComponentPropertyChangeRequest(IPhysicalResourceComponent obj, string propertyName, object newValue, object oldValue)
            : base(obj, propertyName, newValue, oldValue)
        {
            this.ResourceTypeInternalName = obj.PhysicalResource.LogicalResource.ResourceType.InternalName;
            this.ComponentTypeInternalName = obj.ComponentType.InternalName;
        }

        /// <summary>
        /// The internal name of the resource type
        /// </summary>
        public string ResourceTypeInternalName { get; private set; }

        /// <summary>
        /// The internal name of the resource type
        /// </summary>
        public string ComponentTypeInternalName { get; private set; }
    }
}