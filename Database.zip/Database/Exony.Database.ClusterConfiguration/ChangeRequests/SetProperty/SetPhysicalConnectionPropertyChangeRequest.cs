#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

using System;

namespace Exony.Database.ClusterConfiguration.ChangeRequests.SetProperty
{
    public class SetPhysicalConnectionPropertyChangeRequest : SetPropertyChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SetPhysicalConnectionPropertyChangeRequest(IPhysicalConnection obj, string propertyName, object newValue, object oldValue)
            : base(obj, propertyName, newValue, oldValue)
        {
            this.ConnectionTypeInternalName = obj.ConnectionType.InternalName;
            this.SourceComponentId = obj.SourceComponent.Id;
            this.SinkComponentId = obj.SinkComponent.Id;
        }

        /// <summary>
        /// The source component id
        /// </summary>
        public Guid SourceComponentId { get; }

        /// <summary>
        /// The sink component id
        /// </summary>
        public Guid SinkComponentId { get; }

        /// <summary>
        /// The internal name of the connection type
        /// </summary>
        public string ConnectionTypeInternalName { get; private set; }
    }
}
