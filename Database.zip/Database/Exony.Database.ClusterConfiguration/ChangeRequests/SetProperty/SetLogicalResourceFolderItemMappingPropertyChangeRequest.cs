#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests
{
    using System;

    using Exony.Database.ClusterConfiguration.ChangeRequests.SetProperty;
    using Exony.Database.Common.DataObjects.Resources;

    public class SetLogicalResourceFolderItemMappingPropertyChangeRequest : SetPropertyChangeRequest
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public SetLogicalResourceFolderItemMappingPropertyChangeRequest(ILogicalResourceFolderItemMapping obj, string propertyName, object newValue, object oldValue)
            : base(obj, propertyName, newValue, oldValue)
        {
            this.Item = obj.Item;
            this.ClusterResourceId = obj.LogicalResourceFolderMapping.ResourceId;
        }

        /// <summary>
        /// The id of associated cluster resource
        /// </summary>
        public Guid ClusterResourceId { get; private set; }

        public ResourceKey Item { get; private set; }
    }
}
