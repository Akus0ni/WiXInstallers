#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ChangeRequests.SetProperty
{
    public abstract class SetPropertyChangeRequest : ChangeRequestBase
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        protected SetPropertyChangeRequest(IClusterObject obj, string propertyName, object oldValue, object newValue)
            : base(obj)
        {
            this.PropertyName = propertyName;
            this.NewValue = newValue;
            this.OldValue = oldValue;

            ClusterFieldAttribute cfa = AttributeHelper.GetPropertyLevelAttribute<ClusterFieldAttribute>(obj, propertyName);

            if (cfa != null)
            {
                this.Transient = cfa.Transient;
            }
        }

        /// <summary>
        /// Old value of the property
        /// </summary>
        public object OldValue { get; private set; }

        /// <summary>
        /// New value of the property
        /// </summary>
        public object NewValue { get; private set; }

        /// <summary>
        /// Name of the property that changed
        /// </summary>
        public string PropertyName { get; private set; }

        /// <summary>
        /// Is the property change transient
        /// </summary>
        public bool Transient { get; private set; }

        /// <summary>
        /// Apply this change to the supplied model
        /// </summary>
        public override void ApplyChange(ClusterConfiguration model)
        {
            IClusterObject obj = model.GetClusterObjectById(this.Id);

            if (obj != null)
            {
                obj.SetPropertyValue(this.PropertyName, this.NewValue);
            }
        }

        /// <summary>
        /// Revert this change from the supplied model
        /// </summary>
        public override void RevertChange(ClusterConfiguration model)
        {
            IClusterObject obj = model.GetClusterObjectById(this.Id);

            if (obj != null)
            {
                obj.SetPropertyValue(this.PropertyName, this.OldValue);
            }
        }
    }
}
