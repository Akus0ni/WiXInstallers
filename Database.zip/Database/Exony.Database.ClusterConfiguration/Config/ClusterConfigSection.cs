#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Config
{
    using System.Configuration;

    /// <summary>
    /// app.config section
    /// </summary>
    internal sealed class ClusterConfigSection : ConfigurationSection
    {
        private static readonly ClusterConfigSection empty = new ClusterConfigSection();
        private static readonly ClusterConfigSection settings = ConfigurationManager.GetSection("Exony.Database.ClusterConfiguration.Config") as ClusterConfigSection;

        public static ClusterConfigSection Settings
        {
            get
            {
                return settings ?? empty;
            }
        }

        [ConfigurationProperty("logicalResourcePlugins")]
        public PluginCollection LogicalResourcePlugins
        {
            get { return (PluginCollection)this["logicalResourcePlugins"]; }
        }

        [ConfigurationProperty("physicalResourcePlugins")]
        public PluginCollection PhysicalResourcePlugins
        {
            get { return (PluginCollection)this["physicalResourcePlugins"]; }
        }

        [ConfigurationProperty("physicalResourceComponentPlugins")]
        public PluginCollection PhysicalResourceComponentPlugins
        {
            get { return (PluginCollection)this["physicalResourceComponentPlugins"]; }
        }

        [ConfigurationProperty("physicalConnectionPlugins")]
        public PluginCollection PhysicalConnectionPlugins
        {
            get { return (PluginCollection)this["physicalConnectionPlugins"]; }
        }
    }
}
