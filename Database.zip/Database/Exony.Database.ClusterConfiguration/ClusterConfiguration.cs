#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Globalization;
    using System.Linq;
    using System.Reflection;
    using System.Xml;
    using System.Xml.Schema;
    using System.Xml.Serialization;

    using Exony.Database.ClusterConfiguration.Collections;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.ClusterConfiguration.PhysicalConnections;
    using Exony.Database.ClusterConfiguration.PhysicalResourceComponents;
    using Exony.Database.ClusterConfiguration.PhysicalResources;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.Common.Folders;
    using Exony.Security.Encryption;

    /// <summary>
    /// Top level cluster configuration model
    /// </summary>
    public class ClusterConfiguration : IXmlSerializable, ICloneable
    {
        #region Delegates

        /// <summary>
        /// Delegate for property change events
        /// </summary>
        public delegate void ItemPropertyChangedEventDelegate(object sender, IClusterObject source, string propertyName, object oldValue, object newValue);

        /// <summary>
        /// Delegate for item added events
        /// </summary>
        public delegate void ItemAddedEventDelegate(object sender, IClusterObject item);

        /// <summary>
        /// Delegate for item removed events
        /// </summary>
        public delegate void ItemRemovedEventDelegate(object sender, IClusterObject item);

        #endregion

        #region Events

        /// <summary>
        /// Fired when a property is changed
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ItemPropertyChangedEventDelegate ItemPropertyChangedEvent;

        /// <summary>
        /// Fired when an item is added
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ItemAddedEventDelegate ItemAdded;

        /// <summary>
        /// Fired when a property is changed
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ItemRemovedEventDelegate ItemRemoved;

        #endregion

        #region Fields

        private const string NewServerDefaultPrefix = "NewServer";

        /// <summary>
        /// The schema version for xml
        /// Update this value when changing the xml format/defaults/data
        /// </summary>
        public const int XmlSchemaVersion = 2;

        /// <summary>
        /// Default capacity for List performance
        /// </summary>
        private const int DefaultPhysicalResourcesCapacity = 200;

        /// <summary>
        /// Default capacity for List performance
        /// </summary>
        private const int DefaultPhysicalResourceComponentsCapacity = 200;

        /// <summary>
        /// Default capacity for List performance
        /// </summary>
        private const int DefaultPhysicalResourceComponentTypesCapacity = 200;

        /// <summary>
        /// Default capacity for List performance
        /// </summary>
        private const int DefaultLogicalResourceFolderMappingsCapacity = 200;

        /// <summary>
        /// Default capacity for List performance
        /// </summary>
        private const int DefaultLogicalResourceEntityTypeMappingsCapacity = 200;

        /// <summary>
        /// Default capacity for List performance
        /// </summary>
        private const int DefaultLogicalResourceMembersCapacity = 200;

        #endregion

        #region Construction/Disposal

        /// <summary>
        /// Default constructor
        /// </summary>
        public ClusterConfiguration()
        {
            // Default to user edit mode
            this.UserMode = true;

            this.LogicalResourceTypeGroups = new LogicalResourceTypeGroupCollection(this);
            this.LogicalResourceTypes = new LogicalResourceTypeCollection(this);
            this.PhysicalConnectionTypes = new PhysicalConnectionTypeCollection(this);
            this.LogicalResources = new LogicalResourceCollection(this);
            this.PhysicalServers = new PhysicalServerCollection(this);

            // Hook up event propogation
            this.LogicalResourceTypeGroups.ItemAdded += LogicalResourceTypeGroups_ItemAdded;
            this.LogicalResourceTypeGroups.ItemRemoved += LogicalResourceTypeGroups_ItemRemoved;

            this.LogicalResourceTypes.ItemAdded += LogicalResourceTypes_ItemAdded;
            this.LogicalResourceTypes.ItemRemoved += LogicalResourceTypes_ItemRemoved;

            this.PhysicalConnectionTypes.ItemAdded += PhysicalConnectionTypes_ItemAdded;
            this.PhysicalConnectionTypes.ItemRemoved += PhysicalConnectionTypes_ItemRemoved;

            this.LogicalResources.ItemAdded += LogicalResources_ItemAdded;
            this.LogicalResources.ItemRemoved += LogicalResources_ItemRemoved;

            this.PhysicalServers.ItemAdded += PhysicalServers_ItemAdded;
            this.PhysicalServers.ItemRemoved += PhysicalServers_ItemRemoved;
        }

        #endregion

        #region Properties

        /// <summary>
        /// All logical resource type groups
        /// </summary>
        public LogicalResourceTypeGroupCollection LogicalResourceTypeGroups { get; private set; }

        /// <summary>
        /// All logical resource types
        /// </summary>
        public LogicalResourceTypeCollection LogicalResourceTypes { get; private set; }

        /// <summary>
        /// All physical resource component types
        /// </summary>
        public PhysicalConnectionTypeCollection PhysicalConnectionTypes { get; private set; }

        /// <summary>
        /// All logical resources
        /// </summary>
        public LogicalResourceCollection LogicalResources { get; private set; }

        /// <summary>
        /// All defined physical servers
        /// </summary>
        public PhysicalServerCollection PhysicalServers { get; private set; }

        /// <summary>
        /// All defined physical connections
        /// </summary>
        public IEnumerable<IPhysicalConnection> PhysicalConnections
        {
            get
            {
                List<IPhysicalConnection> result = new List<IPhysicalConnection>();

                // Only consider source connections
                foreach (IPhysicalConnection pconn in
                    this.LogicalResources.SelectMany(lr => lr.PhysicalResources.SelectMany(pr => pr.Components)).SelectMany(prc => prc.OutboundConnections.Where(pconn => !result.Contains(pconn))))
                {
                    result.Add(pconn);
                }

                return result;
            }
        }

        /// <summary>
        /// All defined physical resources
        /// </summary>
        public IEnumerable<IPhysicalResource> PhysicalResources
        {
            get
            {
                List<IPhysicalResource> result = new List<IPhysicalResource>(DefaultPhysicalResourcesCapacity);
                foreach (ILogicalResource lr in this.LogicalResources)
                {
                    result.AddRange(lr.PhysicalResources);
                }

                return result;
            }
        }

        /// <summary>
        /// All defined physical resource components
        /// </summary>
        public IEnumerable<IPhysicalResourceComponent> PhysicalResourceComponents
        {
            get
            {
                List<IPhysicalResourceComponent> result = new List<IPhysicalResourceComponent>(DefaultPhysicalResourceComponentsCapacity);
                foreach (IPhysicalResource pr in this.PhysicalResources)
                {
                    result.AddRange(pr.Components);
                }

                return result;
            }
        }

        /// <summary>
        /// All defined physical resource component types
        /// </summary>
        public IEnumerable<IPhysicalResourceComponentType> PhysicalResourceComponentTypes
        {
            get
            {
                List<IPhysicalResourceComponentType> result = new List<IPhysicalResourceComponentType>(DefaultPhysicalResourceComponentTypesCapacity);
                foreach (ILogicalResourceType lrt in this.LogicalResourceTypes)
                {
                    result.AddRange(lrt.ComponentTypes);
                }

                return result;
            }
        }

        /// <summary>
        /// All defined logical resource folder mappings
        /// </summary>
        public IEnumerable<ILogicalResourceFolderMapping> LogicalResourceFolderMappings
        {
            get
            {
                List<ILogicalResourceFolderMapping> result = new List<ILogicalResourceFolderMapping>(DefaultLogicalResourceFolderMappingsCapacity);
                foreach (ILogicalResource lr in this.LogicalResources)
                {
                    result.AddRange(lr.FolderMappings);
                }

                return result;
            }
        }

        /// <summary>
        /// All defined logical resource folder item mappings
        /// </summary>
        public IEnumerable<ILogicalResourceFolderItemMapping> LogicalResourceFolderItemMappings
        {
            get
            {
                List<ILogicalResourceFolderItemMapping> result = new List<ILogicalResourceFolderItemMapping>(DefaultLogicalResourceFolderMappingsCapacity);
                foreach (ILogicalResourceFolderMapping lrfm in this.LogicalResourceFolderMappings)
                {
                    result.AddRange(lrfm.ResourceFolderItemMappings);
                }

                return result;
            }
        }

        public IEnumerable<Folder> Folders
        {
            get
            {
                return ProcessFolders(this.LogicalResources);
            }
        }

        // Internal for tests.
        internal static IEnumerable<Folder> ProcessFolders(IEnumerable<ILogicalResource> logicalResources)
        {
            return logicalResources.SelectMany(lr => lr.FolderMappings).SelectMany(f => f.Folder.GetParentFolders(true)).Distinct();
        }

        /// <summary>
        /// All defined logical resource entity type mappings
        /// </summary>
        public IEnumerable<ILogicalResourceEntityTypeMapping> LogicalResourceEntityTypeMappings
        {
            get
            {
                List<ILogicalResourceEntityTypeMapping> result = new List<ILogicalResourceEntityTypeMapping>(DefaultLogicalResourceEntityTypeMappingsCapacity);
                foreach (ILogicalResource lr in this.LogicalResources)
                {
                    result.AddRange(lr.EntityTypeMappings);
                }

                return result;
            }
        }

        /// <summary>
        /// All defined logical resource members
        /// </summary>
        public IEnumerable<ILogicalResourceMember> LogicalResourceMembers
        {
            get
            {
                List<ILogicalResourceMember> result = new List<ILogicalResourceMember>(DefaultLogicalResourceMembersCapacity);
                foreach (ILogicalResource lr in this.LogicalResources)
                {
                    result.AddRange(lr.ChildResourceMembers); // Only add one end
                }

                return result;
            }
        }

        /// <summary>
        /// All cluster objects in the model
        /// </summary>
        public IEnumerable<IClusterObject> ClusterObjects
        {
            get
            {
                IEnumerable<IClusterObject> clusterObjects = this.LogicalResourceTypeGroups.OfType<IClusterObject>().Union(
                    this.LogicalResourceTypes.OfType<IClusterObject>().Union(
                        this.PhysicalConnectionTypes.OfType<IClusterObject>().Union(
                            this.PhysicalResourceComponentTypes.OfType<IClusterObject>().Union(
                                this.LogicalResources.OfType<IClusterObject>().Union(
                                    this.PhysicalResources.OfType<IClusterObject>().Union(
                                        this.PhysicalConnections.OfType<IClusterObject>().Union(
                                            this.PhysicalServers.OfType<IClusterObject>().Union(
                                                this.LogicalResourceFolderMappings.OfType<IClusterObject>().Union(
                                                    this.LogicalResourceEntityTypeMappings.OfType<IClusterObject>().Union(
                                                        this.LogicalResourceMembers.OfType<IClusterObject>().Union(
                                                            this.PhysicalResourceComponents.OfType<IClusterObject>())))))))))));
                return clusterObjects;
            }
        }

        /// <summary>
        /// Indicates if the model is in user mode (i.e. user editing) or being progrmatically configured (e.g. by a loader)
        /// </summary>
        public bool UserMode { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Generate a unique physical server name
        /// </summary>
        public string GenerateUniquePhysicalServerName()
        {
            // Default name
            int typeCount =
                this.PhysicalServers.Count(ps => ps.ServerName.StartsWith(NewServerDefaultPrefix, StringComparison.InvariantCultureIgnoreCase));

            return string.Format("{0}{1}", NewServerDefaultPrefix, typeCount + 1);
        }

        /// <summary>
        /// Check if the specified server name appears to be auto generated
        /// </summary>
        public bool IsAutoGeneratedPhysicalServerName(string name)
        {
            return !string.IsNullOrEmpty(name) && name.StartsWith(NewServerDefaultPrefix);
        }

        /// <summary>
        /// Generate a unique logical resource name for the specified resource type
        /// </summary>
        public string GenerateUniqueLogicalResourceName(ILogicalResourceType resourceType)
        {
            // Default name
            int typeCount = this.LogicalResources.Count(lr => lr.ResourceType.Equals(resourceType));

            // Allow room for up to 999 resources of the same type
            string prefix = GenerateLogicalResourceNamePrefix(resourceType);

            return string.Format("{0} {1}", prefix, typeCount + 1);
        }

        /// <summary>
        /// Check if the specified logical resource name appears to be auto generated
        /// </summary>
        public bool IsAutoGeneratedLogicalResourceName(ILogicalResourceType resourceType, string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                return false;
            }

            string prefix = GenerateLogicalResourceNamePrefix(resourceType);

            return name.StartsWith(prefix);
        }

        /// <summary>
        /// Check if the specified logical resource name appears to be auto generated
        /// </summary>
        public bool IsAutoGeneratedLogicalResourceName(string resourceTypeInternalName, string name)
        {
            ILogicalResourceType resourceType =
                this.LogicalResourceTypes.First(lrt => lrt.InternalName.Equals(resourceTypeInternalName, StringComparison.InvariantCultureIgnoreCase));

            return IsAutoGeneratedLogicalResourceName(resourceType, name);
        }

        /// <summary>
        /// Generate the post-fix
        /// </summary>
        private static string GenerateLogicalResourceNamePrefix(ILogicalResourceType resourceType)
        {
            // Allow room for up to 999 resources of the same type
            string prefix = resourceType.Name.Length <= LogicalResource.NameMaxLength - 4
                                 ? resourceType.Name
                                 : resourceType.Name.Substring(0, LogicalResource.NameMaxLength - 4);

            return prefix;
        }

        /// <summary>
        /// Generate a unique logical resource name for the specified resource type
        /// </summary>
        public string GenerateUniqueLogicalResourceName(string resourceTypeInternalName)
        {
            ILogicalResourceType resourceType =
                this.LogicalResourceTypes.First(lrt => lrt.InternalName.Equals(resourceTypeInternalName, StringComparison.InvariantCultureIgnoreCase));

            return GenerateUniqueLogicalResourceName(resourceType);
        }

        /// <summary>
        /// Get an object by it's id
        /// </summary>
        public IClusterObject GetClusterObjectById(Guid id)
        {
            IClusterObject result = this.LogicalResourceTypeGroups.FirstOrDefault(obj => obj.Id == id) ??
                                    this.LogicalResourceTypes.FirstOrDefault(obj => obj.Id == id) ??
                                    this.PhysicalConnectionTypes.FirstOrDefault(obj => obj.Id == id) ??
                                    this.PhysicalResourceComponentTypes.FirstOrDefault(obj => obj.Id == id) ??
                                    this.LogicalResources.FirstOrDefault(obj => obj.Id == id) ??
                                    this.PhysicalResources.FirstOrDefault(obj => obj.Id == id) ??
                                    this.PhysicalConnections.FirstOrDefault(obj => obj.Id == id) ??
                                    this.PhysicalServers.FirstOrDefault(obj => obj.Id == id) ??
                                    this.LogicalResourceFolderMappings.FirstOrDefault(obj => obj.Id == id) ??
                                    this.LogicalResourceMembers.FirstOrDefault(obj => obj.Id == id) ??
                                    this.PhysicalResourceComponents.FirstOrDefault(obj => obj.Id == id) ??
                                    this.LogicalResourceEntityTypeMappings.FirstOrDefault(obj => obj.Id == id) as IClusterObject;

            return result;
        }

        /// <summary>
        /// Remove a cluster object from the configuration
        /// </summary>
        public void RemoveClusterObject(IClusterObject clusterObject)
        {
            if (clusterObject == null)
            {
                return;
            }

            if (clusterObject.Configuration != this)
            {
                throw new ArgumentException("Cluster object is not owned by this configuration", "clusterObject");
            }

            // ReSharper disable CanBeReplacedWithTryCastAndCheckForNull
            if (clusterObject is ILogicalResource)
            {
                ILogicalResource lr = (ILogicalResource)clusterObject;
                this.LogicalResources.Remove(lr);
            }
            else if (clusterObject is IPhysicalResource)
            {
                IPhysicalResource pr = (IPhysicalResource)clusterObject;
                pr.LogicalResource.PhysicalResources.Remove(pr);
            }
            else if (clusterObject is IPhysicalConnection)
            {
                IPhysicalConnection pc = (IPhysicalConnection)clusterObject;
                pc.SourceComponent.OutboundConnections.Remove(pc);
            }
            else if (clusterObject is IPhysicalServer)
            {
                IPhysicalServer ps = (IPhysicalServer)clusterObject;
                this.PhysicalServers.Remove(ps);
            }
            else if (clusterObject is ILogicalResourceTypeGroup)
            {
                ILogicalResourceTypeGroup lrtg = (ILogicalResourceTypeGroup)clusterObject;
                this.LogicalResourceTypeGroups.Remove(lrtg);
            }
            else if (clusterObject is ILogicalResourceType)
            {
                ILogicalResourceType lrt = (ILogicalResourceType)clusterObject;
                this.LogicalResourceTypes.Remove(lrt);
            }
            else if (clusterObject is IPhysicalConnectionType)
            {
                IPhysicalConnectionType pct = (IPhysicalConnectionType)clusterObject;
                this.PhysicalConnectionTypes.Remove(pct);
            }
            else if (clusterObject is IPhysicalResourceComponentType)
            {
                IPhysicalResourceComponentType prct = (IPhysicalResourceComponentType)clusterObject;
                prct.ResourceType.ComponentTypes.Remove(prct);
            }
            else if (clusterObject is ILogicalResourceFolderMapping)
            {
                ILogicalResourceFolderMapping lrfm = (ILogicalResourceFolderMapping)clusterObject;
                lrfm.LogicalResource.FolderMappings.Remove(lrfm);
            }
            else if (clusterObject is ILogicalResourceFolderItemMapping)
            {
                ILogicalResourceFolderItemMapping lrfim = (ILogicalResourceFolderItemMapping)clusterObject;
                lrfim.LogicalResourceFolderMapping.ResourceFolderItemMappings.Remove(lrfim);
            }
            else if (clusterObject is ILogicalResourceMember)
            {
                ILogicalResourceMember lrm = (ILogicalResourceMember)clusterObject;
                lrm.ChildResource.ParentResourceMembers.Remove(lrm);
            }
            else if (clusterObject is IPhysicalResourceComponent)
            {
                IPhysicalResourceComponent prc = (IPhysicalResourceComponent)clusterObject;
                prc.PhysicalResource.Components.Remove(prc);
            }

            // ReSharper restore CanBeReplacedWithTryCastAndCheckForNull
        }

        /// <summary>
        /// Add/Update a cluster object from another configuration
        /// </summary>
        public IClusterObject ImportClusterObject(IClusterObject clusterObject, bool transientFieldsOnly = false)
        {
            if (clusterObject == null)
            {
                return null;
            }

            IClusterObject result = null;

            // ReSharper disable CanBeReplacedWithTryCastAndCheckForNull
            if (clusterObject is ILogicalResource)
            {
                ILogicalResource lr = (ILogicalResource)clusterObject;
                result = ImportLogicalResource(lr, transientFieldsOnly);
            }
            else if (clusterObject is IPhysicalResource)
            {
                IPhysicalResource pr = (IPhysicalResource)clusterObject;
                result = ImportPhysicalResource(pr, transientFieldsOnly);
            }
            else if (clusterObject is IPhysicalConnection)
            {
                IPhysicalConnection pc = (IPhysicalConnection)clusterObject;
                result = ImportPhysicalConnection(pc, transientFieldsOnly);
            }
            else if (clusterObject is IPhysicalServer)
            {
                IPhysicalServer ps = (IPhysicalServer)clusterObject;
                result = ImportPhysicalServer(ps, transientFieldsOnly);
            }
            else if (clusterObject is ILogicalResourceTypeGroup)
            {
                ILogicalResourceTypeGroup lrtg = (ILogicalResourceTypeGroup)clusterObject;
                result = ImportLogicalResourceTypeGroup(lrtg, transientFieldsOnly);
            }
            else if (clusterObject is ILogicalResourceType)
            {
                ILogicalResourceType lrt = (ILogicalResourceType)clusterObject;
                result = ImportLogicalResourceType(lrt, transientFieldsOnly);
            }
            else if (clusterObject is IPhysicalConnectionType)
            {
                IPhysicalConnectionType pct = (IPhysicalConnectionType)clusterObject;
                result = ImportPhysicalConnectionType(pct, transientFieldsOnly);
            }
            else if (clusterObject is IPhysicalResourceComponentType)
            {
                IPhysicalResourceComponentType prct = (IPhysicalResourceComponentType)clusterObject;
                result = ImportPhysicalResourceComponentType(prct, transientFieldsOnly);
            }
            else if (clusterObject is ILogicalResourceFolderMapping)
            {
                ILogicalResourceFolderMapping lrfm = (ILogicalResourceFolderMapping)clusterObject;
                result = ImportLogicalResourceFolderMapping(lrfm, transientFieldsOnly);
            }
            else if (clusterObject is ILogicalResourceFolderItemMapping)
            {
                ILogicalResourceFolderItemMapping lrfim = (ILogicalResourceFolderItemMapping)clusterObject;
                result = ImportLogicalResourceFolderItemMapping(lrfim, transientFieldsOnly);
            }
            else if (clusterObject is ILogicalResourceMember)
            {
                ILogicalResourceMember lrm = (ILogicalResourceMember)clusterObject;
                result = ImportLogicalResourceMember(lrm, transientFieldsOnly);
            }
            else if (clusterObject is IPhysicalResourceComponent)
            {
                IPhysicalResourceComponent prc = (IPhysicalResourceComponent)clusterObject;
                result = ImportPhysicalResourceComponent(prc, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a physical connection type from another configuration
        /// </summary>
        private IPhysicalConnectionType ImportPhysicalConnectionType(IPhysicalConnectionType pct, bool transientFieldsOnly)
        {
            IPhysicalConnectionType result = GetClusterObjectById(pct.Id) as IPhysicalConnectionType;

            if (result == null && !transientFieldsOnly)
            {
                result = new PhysicalConnectionType(this, pct.Id);
                this.PhysicalConnectionTypes.Add(result);
            }

            if (result != null)
            {
                CopyFields(pct, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a physical resource component type from another configuration
        /// </summary>
        private IPhysicalResourceComponentType ImportPhysicalResourceComponentType(IPhysicalResourceComponentType prct, bool transientFieldsOnly)
        {
            // Import related items
            ILogicalResourceType lrt = ImportLogicalResourceType(prct.ResourceType, transientFieldsOnly);

            IPhysicalResourceComponentType result = GetClusterObjectById(prct.Id) as IPhysicalResourceComponentType;

            if (result == null && !transientFieldsOnly)
            {
                result = new PhysicalResourceComponentType(lrt, prct.Id);
                lrt.ComponentTypes.Add(result);
            }

            if (result != null)
            {
                CopyFields(prct, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a logical resource folder mapping from another configuration
        /// </summary>
        private ILogicalResourceFolderMapping ImportLogicalResourceFolderMapping(ILogicalResourceFolderMapping lrfm, bool transientFieldsOnly)
        {
            // Import related items
            ILogicalResource lr = ImportLogicalResource(lrfm.LogicalResource, transientFieldsOnly);

            ILogicalResourceFolderMapping result = GetClusterObjectById(lrfm.Id) as ILogicalResourceFolderMapping;

            if (result == null && !transientFieldsOnly)
            {
                result = LogicalResourceFolderMappingFactory.CreateLogicalResourceFolderMapping((LogicalResourceFolderMappingType)lrfm.Type, lr, lrfm.Folder);
                lr.FolderMappings.Add(result);
            }

            if (result != null)
            {
                CopyFields(lrfm, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a logical resource folder item mapping from another configuration
        /// </summary>
        private ILogicalResourceFolderItemMapping ImportLogicalResourceFolderItemMapping(ILogicalResourceFolderItemMapping lrfim, bool transientFieldsOnly)
        {
            // Import related items
            ILogicalResourceFolderMapping parent = this.ImportLogicalResourceFolderMapping(lrfim.LogicalResourceFolderMapping, transientFieldsOnly);

            ILogicalResourceFolderItemMapping result = GetClusterObjectById(lrfim.Id) as ILogicalResourceFolderItemMapping;

            if (result == null && !transientFieldsOnly)
            {
                result = new LogicalResourceFolderItemMapping(parent, lrfim.Item, lrfim.Id);
                parent.ResourceFolderItemMappings.Add(result);
            }

            if (result != null)
            {
                CopyFields(lrfim, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a logical resource member from another configuration
        /// </summary>
        private ILogicalResourceMember ImportLogicalResourceMember(ILogicalResourceMember lrm, bool transientFieldsOnly)
        {
            // Import related items
            ILogicalResource parent = ImportLogicalResource(lrm.ParentResource, transientFieldsOnly);
            ILogicalResource child = ImportLogicalResource(lrm.ChildResource, transientFieldsOnly);

            ILogicalResourceMember result = GetClusterObjectById(lrm.Id) as ILogicalResourceMember;

            if (result == null && !transientFieldsOnly)
            {
                result = new LogicalResourceMember(parent, child, lrm.Id);
                parent.ChildResourceMembers.Add(result);
            }

            if (result != null)
            {
                CopyFields(lrm, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a physical server from another configuration
        /// </summary>
        private IPhysicalServer ImportPhysicalServer(IPhysicalServer ps, bool transientFieldsOnly)
        {
            IPhysicalServer result = GetClusterObjectById(ps.Id) as IPhysicalServer;

            if (result == null && !transientFieldsOnly)
            {
                result = new PhysicalServer(this, ps.Id);
                this.PhysicalServers.Add(result);
            }

            if (result != null)
            {
                CopyFields(ps, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a logical resource from another configuration
        /// </summary>
        private ILogicalResource ImportLogicalResource(ILogicalResource lr, bool transientFieldsOnly)
        {
            // Import related items
            ILogicalResourceType lrt = ImportLogicalResourceType(lr.ResourceType, transientFieldsOnly);

            ILogicalResource result = GetClusterObjectById(lr.Id) as ILogicalResource;

            if (result == null && !transientFieldsOnly)
            {
                result = LogicalResourceFactory.CreateLogicalResource(lrt.InternalName, this, lr.Id);
                this.LogicalResources.Add(result);
            }

            if (result != null)
            {
                CopyFields(lr, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a logical resource type group from another configuration
        /// </summary>
        private ILogicalResourceTypeGroup ImportLogicalResourceTypeGroup(ILogicalResourceTypeGroup lrtg, bool transientFieldsOnly)
        {
            ILogicalResourceTypeGroup result = GetClusterObjectById(lrtg.Id) as ILogicalResourceTypeGroup;

            if (result == null && !transientFieldsOnly)
            {
                result = new LogicalResourceTypeGroup(this, lrtg.Id);
                this.LogicalResourceTypeGroups.Add(result);
            }

            if (result != null)
            {
                CopyFields(lrtg, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a logical resource type from another configuration
        /// </summary>
        private ILogicalResourceType ImportLogicalResourceType(ILogicalResourceType lrt, bool transientFieldsOnly)
        {
            // Import related items
            if (lrt.ResourceTypeGroup != null)
            {
                ImportLogicalResourceTypeGroup(lrt.ResourceTypeGroup, transientFieldsOnly);
            }

            ILogicalResourceType result = GetClusterObjectById(lrt.Id) as ILogicalResourceType;

            if (result == null && !transientFieldsOnly)
            {
                result = new LogicalResourceType(this, lrt.Id);
                this.LogicalResourceTypes.Add(result);
            }

            if (result != null)
            {
                CopyFields(lrt, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a physical resource from another configuration
        /// </summary>
        private IPhysicalResource ImportPhysicalResource(IPhysicalResource pr, bool transientFieldsOnly)
        {
            // Import related items
            ILogicalResource lr = ImportLogicalResource(pr.LogicalResource, transientFieldsOnly);

            IPhysicalResource result = GetClusterObjectById(pr.Id) as IPhysicalResource;

            if (result == null && !transientFieldsOnly)
            {
                result = PhysicalResourceFactory.CreatePhysicalResource(lr, pr.Id);
                lr.PhysicalResources.Add(result);
            }

            if (result != null)
            {
                CopyFields(pr, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a physical connection from another configuration
        /// </summary>
        private IPhysicalConnection ImportPhysicalConnection(IPhysicalConnection pc, bool transientFieldsOnly)
        {
            // Import related items
            IPhysicalResourceComponent sink = ImportPhysicalResourceComponent(pc.SinkComponent, transientFieldsOnly);
            IPhysicalResourceComponent source = ImportPhysicalResourceComponent(pc.SourceComponent, transientFieldsOnly);

            IPhysicalConnection result = GetClusterObjectById(pc.Id) as IPhysicalConnection;

            if (result == null && !transientFieldsOnly)
            {
                result = PhysicalConnectionFactory.CreatePhysicalConnection(pc.ConnectionType.InternalName, source, sink, pc.Id);
                source.OutboundConnections.Add(result);
            }

            if (result != null)
            {
                CopyFields(pc, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Import a physical resource component from another configuration
        /// </summary>
        private IPhysicalResourceComponent ImportPhysicalResourceComponent(IPhysicalResourceComponent prc, bool transientFieldsOnly)
        {
            // Import related items
            IPhysicalResource pr = ImportPhysicalResource(prc.PhysicalResource, transientFieldsOnly);
            ImportPhysicalResourceComponentType(prc.ComponentType, transientFieldsOnly);

            IPhysicalResourceComponent result = GetClusterObjectById(prc.Id) as IPhysicalResourceComponent;

            if (result == null && !transientFieldsOnly)
            {
                result = PhysicalResourceComponentFactory.CreatePhysicalResourceComponent(pr, prc.ComponentType.InternalName, prc.Id);
                pr.Components.Add(result);
            }

            if (result != null)
            {
                CopyFields(prc, result, transientFieldsOnly);
            }

            return result;
        }

        /// <summary>
        /// Copy cluster fields from the one object to the other
        /// </summary>
        private static void CopyFields(IClusterObject fromObject, IClusterObject toObject, bool transientFieldsOnly)
        {
            // Retrieve attribute data from cluster object
            IDictionary<PropertyInfo, ClusterFieldAttribute> clusterFieldProperties = AttributeHelper.GetPropertyLevelAttributes<ClusterFieldAttribute>(toObject);

            foreach (KeyValuePair<PropertyInfo, ClusterFieldAttribute> clusterFieldPair in clusterFieldProperties)
            {
                ClusterFieldAttribute attribute = clusterFieldPair.Value;

                // If the field doesn't exist or we only want transient fields and it isn't transient then skip
                if (transientFieldsOnly && !attribute.Transient)
                {
                    continue;
                }

                object fieldValue = fromObject.GetClusterField(attribute.FieldName);
                toObject.SetClusterField(attribute.FieldName, fieldValue, false);
            }
        }

        /// <summary>
        /// Validate the current cluster model
        /// </summary>
        public IEnumerable<IClusterValidationResult> Validate()
        {
            List<IClusterValidationResult> result = new List<IClusterValidationResult>();

            // Most things are tied to logical resources - don't bother validating anything except servers on an empty model
            if (this.LogicalResources.Any())
            {
                foreach (ILogicalResourceTypeGroup obj in this.LogicalResourceTypeGroups)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (ILogicalResourceType obj in this.LogicalResourceTypes)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (IPhysicalResourceComponentType obj in this.PhysicalResourceComponentTypes)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (IPhysicalConnectionType obj in this.PhysicalConnectionTypes)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (ILogicalResource obj in this.LogicalResources)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (IPhysicalResource obj in this.PhysicalResources)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (IPhysicalConnection obj in this.PhysicalConnections)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (IPhysicalResourceComponent obj in this.PhysicalResourceComponents)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (ILogicalResourceFolderMapping obj in this.LogicalResourceFolderMappings)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (ILogicalResourceFolderItemMapping obj in this.LogicalResourceFolderItemMappings)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (ILogicalResourceEntityTypeMapping obj in this.LogicalResourceEntityTypeMappings)
                {
                    result.AddRange(obj.Validate());
                }

                foreach (ILogicalResourceMember obj in this.LogicalResourceMembers)
                {
                    result.AddRange(obj.Validate());
                }
            }

            foreach (IPhysicalServer obj in this.PhysicalServers)
            {
                result.AddRange(obj.Validate());
            }

            return result;
        }

        #endregion

        #region Event Propogation
        // ReSharper disable InconsistentNaming

        /// <summary>
        /// Invoked when an item is removed from the physical connection types collection
        /// </summary>
        private void PhysicalConnectionTypes_ItemRemoved(object sender, IPhysicalConnectionType item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the physical connection types collection
        /// </summary>
        private void PhysicalConnectionTypes_ItemAdded(object sender, IPhysicalConnectionType item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the logical resource types collection
        /// </summary>
        private void LogicalResourceTypes_ItemRemoved(object sender, ILogicalResourceType item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;
            item.ComponentTypes.ItemAdded -= ComponentTypes_ItemAdded;
            item.ComponentTypes.ItemRemoved -= ComponentTypes_ItemRemoved;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the logical resource types collection
        /// </summary>
        private void LogicalResourceTypes_ItemAdded(object sender, ILogicalResourceType item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;
            item.ComponentTypes.ItemAdded += ComponentTypes_ItemAdded;
            item.ComponentTypes.ItemRemoved += ComponentTypes_ItemRemoved;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }

            // Fire add events for objects that already exist
            foreach (IPhysicalResourceComponentType r in item.ComponentTypes)
            {
                this.ComponentTypes_ItemAdded(this, r);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the component types collection on a logical resource type
        /// </summary>
        private void ComponentTypes_ItemRemoved(object sender, IPhysicalResourceComponentType item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the component types collection on a logical resource type
        /// </summary>
        private void ComponentTypes_ItemAdded(object sender, IPhysicalResourceComponentType item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the logical resource type groups collection
        /// </summary>
        private void LogicalResourceTypeGroups_ItemRemoved(object sender, ILogicalResourceTypeGroup item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the logical resource type groups collection
        /// </summary>
        private void LogicalResourceTypeGroups_ItemAdded(object sender, ILogicalResourceTypeGroup item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the physical connections collection
        /// </summary>
        private void PhysicalConnections_ItemRemoved(object sender, IPhysicalConnection item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;
            item.ConnectionStatus.PropertyChanged -= this.ItemPropertyChanged;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the physical connections collection
        /// </summary>
        private void PhysicalConnections_ItemAdded(object sender, IPhysicalConnection item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;
            item.ConnectionStatus.PropertyChanged += this.ItemPropertyChanged;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the physical servers collection
        /// </summary>
        private void PhysicalServers_ItemRemoved(object sender, IPhysicalServer item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the physical servers collection
        /// </summary>
        private void PhysicalServers_ItemAdded(object sender, IPhysicalServer item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the physical resources collection
        /// </summary>
        private void PhysicalResources_ItemRemoved(object sender, IPhysicalResource item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;
            item.Components.ItemAdded -= Components_ItemAdded;
            item.Components.ItemRemoved -= Components_ItemRemoved;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the physical resources collection
        /// </summary>
        private void PhysicalResources_ItemAdded(object sender, IPhysicalResource item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;
            item.Components.ItemAdded += Components_ItemAdded;
            item.Components.ItemRemoved += Components_ItemRemoved;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }

            // Fire add events for objects that already exist
            foreach (IPhysicalResourceComponent r in item.Components)
            {
                this.Components_ItemAdded(this, r);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the logical resources collection
        /// </summary>
        private void LogicalResources_ItemRemoved(object sender, ILogicalResource item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;
            item.PhysicalResources.ItemAdded -= PhysicalResources_ItemAdded;
            item.PhysicalResources.ItemRemoved -= PhysicalResources_ItemRemoved;
            item.FolderMappings.ItemAdded -= FolderMappings_ItemAdded;
            item.FolderMappings.ItemRemoved -= FolderMappings_ItemRemoved;
            item.EntityTypeMappings.ItemAdded -= EntityTypeMappings_ItemAdded;
            item.EntityTypeMappings.ItemRemoved -= EntityTypeMappings_ItemRemoved;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the logical resources collection
        /// </summary>
        private void LogicalResources_ItemAdded(object sender, ILogicalResource item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;
            item.PhysicalResources.ItemAdded += PhysicalResources_ItemAdded;
            item.PhysicalResources.ItemRemoved += PhysicalResources_ItemRemoved;
            item.FolderMappings.ItemAdded += FolderMappings_ItemAdded;
            item.FolderMappings.ItemRemoved += FolderMappings_ItemRemoved;
            item.ChildResourceMembers.ItemAdded += ChildResourceMembers_ItemAdded;
            item.ChildResourceMembers.ItemRemoved += ChildResourceMembers_ItemRemoved;
            item.EntityTypeMappings.ItemAdded += EntityTypeMappings_ItemAdded;
            item.EntityTypeMappings.ItemRemoved += EntityTypeMappings_ItemRemoved;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }

            // Fire add events for objects that already exist
            foreach (ILogicalResourceEntityTypeMapping r in item.EntityTypeMappings)
            {
                this.EntityTypeMappings_ItemAdded(this, r);
            }

            foreach (ILogicalResourceMember r in item.ChildResourceMembers)
            {
                this.ChildResourceMembers_ItemAdded(this, r);
            }

            foreach (ILogicalResourceFolderMapping r in item.FolderMappings)
            {
                this.FolderMappings_ItemAdded(this, r);
            }

            foreach (IPhysicalResource r in item.PhysicalResources)
            {
                this.PhysicalResources_ItemAdded(this, r);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from a logical resource's parent resource member collection
        /// </summary>
        private void ChildResourceMembers_ItemRemoved(object sender, ILogicalResourceMember item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to a logical resource's parent resource member collection
        /// </summary>
        private void ChildResourceMembers_ItemAdded(object sender, ILogicalResourceMember item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Invoked when a property is changed on a contained cluster object
        /// </summary>
        private void ItemPropertyChanged(object sender, string propertyName, object oldValue, object newValue)
        {
            if (this.ItemPropertyChangedEvent != null)
            {
                this.ItemPropertyChangedEvent(this, (IClusterObject)sender, propertyName, oldValue, newValue);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the physical resource components collection
        /// </summary>
        private void Components_ItemAdded(object sender, IPhysicalResourceComponent item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;
            item.OutboundConnections.ItemAdded += PhysicalConnections_ItemAdded;
            item.OutboundConnections.ItemRemoved += PhysicalConnections_ItemRemoved;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }

            // Fire add events for objects that already exist
            foreach (IPhysicalConnection r in item.OutboundConnections)
            {
                this.PhysicalConnections_ItemAdded(this, r);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the physical resource components collection
        /// </summary>
        private void Components_ItemRemoved(object sender, IPhysicalResourceComponent item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;
            item.OutboundConnections.ItemAdded -= PhysicalConnections_ItemAdded;
            item.OutboundConnections.ItemRemoved -= PhysicalConnections_ItemRemoved;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the folder mappings collection on a logical resource
        /// </summary>
        private void FolderMappings_ItemRemoved(object sender, ILogicalResourceFolderMapping item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;
            item.ResourceFolderItemMappings.ItemAdded -= this.FolderItemMappings_ItemAdded;
            item.ResourceFolderItemMappings.ItemRemoved -= this.FolderItemMappings_ItemRemoved;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the folder mappings collection on a logical resource
        /// </summary>
        private void FolderMappings_ItemAdded(object sender, ILogicalResourceFolderMapping item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;
            item.ResourceFolderItemMappings.ItemAdded += this.FolderItemMappings_ItemAdded;
            item.ResourceFolderItemMappings.ItemRemoved += this.FolderItemMappings_ItemRemoved;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the folder resource mappings collection on a logical resource
        /// </summary>
        private void FolderItemMappings_ItemRemoved(object sender, ILogicalResourceFolderItemMapping item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the folder resource mappings collection on a logical resource
        /// </summary>
        private void FolderItemMappings_ItemAdded(object sender, ILogicalResourceFolderItemMapping item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is removed from the folder mappings collection on a logical resource
        /// </summary>
        private void EntityTypeMappings_ItemRemoved(object sender, ILogicalResourceEntityTypeMapping item)
        {
            item.PropertyChanged -= this.ItemPropertyChanged;

            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Invoked when an item is added to the folder mappings collection on a logical resource
        /// </summary>
        private void EntityTypeMappings_ItemAdded(object sender, ILogicalResourceEntityTypeMapping item)
        {
            item.PropertyChanged += this.ItemPropertyChanged;

            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        // ReSharper restore InconsistentNaming
        #endregion

        #region Standard Logical Resource Accessors

        /// <summary>
        /// Access the Exony relational database logical resource
        /// </summary>
        public ExonyDatabaseLogicalResource ExonyRelationalDatabaseLogicalResource
        {
            get
            {
                ILogicalResource result = this.LogicalResources.FirstOrDefault(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyRelationalDatabase));

                return result == null ? null : (ExonyDatabaseLogicalResource)result;
            }
        }

        /// <summary>
        /// Access the Exony data pipeline service logical resources
        /// </summary>
        public IEnumerable<ExonyDataPipelineLogicalResource> ExonyDataPipelineServiceLogicalResource
        {
            get
            {
                return this.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyDataPipelineService)).Cast<ExonyDataPipelineLogicalResource>();
            }
        }

        /// <summary>
        /// Access the Exony data pipeline service logical resource
        /// </summary>
        public ExonyProvisioningServerLogicalResource ExonyProvisioningServiceLogicalResource
        {
            get
            {
                ILogicalResource result = this.LogicalResources.FirstOrDefault(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyProvisioningService));

                return result == null ? null : (ExonyProvisioningServerLogicalResource)result;
            }
        }

        /// <summary>
        /// Access the Exony olap processor service logical resources
        /// </summary>
        public IEnumerable<ExonyOlapProcessorLogicalResource> ExonyOlapProcessorServiceLogicalResources
        {
            get
            {
                return this.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyOlapProcessorService)).Cast<ExonyOlapProcessorLogicalResource>();
            }
        }

        /// <summary>
        /// Access the Exony olap database logical resources
        /// </summary>
        public IEnumerable<ExonyOlapDatabaseLogicalResource> ExonyOlapDatabaseLogicalResourceLogicalResources
        {
            get
            {
                return this.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyOlapDatabase)).Cast<ExonyOlapDatabaseLogicalResource>();
            }
        }

        /// <summary>
        /// Access the Exony Redshift database logical resources
        /// </summary>
        public IEnumerable<RedshiftDatabaseLogicalResource> ExonyRedshiftDatabaseLogicalResourceLogicalResources
        {
            get
            {
                return this.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.RedshiftDatabase)).Cast<RedshiftDatabaseLogicalResource>();
            }
        }

        /// <summary>
        /// Access the Exony mediator service logical resources
        /// </summary>
        public IEnumerable<ExonyMediatorLogicalResource> ExonyMediatorServiceLogicalResources
        {
            get
            {
                return this.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyMediatorService)).Cast<ExonyMediatorLogicalResource>();
            }
        }

        /// <summary>
        /// Access the Exony application service logical resource
        /// </summary>
        public ExonyAppServerLogicalResource ExonyApplicationServiceLogicalResource
        {
            get
            {
                ILogicalResource result = this.LogicalResources.FirstOrDefault(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.ExonyApplicationServer));

                return result == null ? null : (ExonyAppServerLogicalResource)result;
            }
        }

        /// <summary>
        /// Access the Microsoft RS Web Service logical resource
        /// </summary>
        public MicrosoftReportingServicesLogicalResource MicrosoftReportingServicesLogicalResource
        {
            get
            {
                ILogicalResource result = this.LogicalResources.FirstOrDefault(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.MicrosoftReportingServicesWebService));

                return result == null ? null : (MicrosoftReportingServicesLogicalResource)result;
            }
        }

        /// <summary>
        /// Access the Microsoft RS database logical resource
        /// </summary>
        public MicrosoftReportingServicesDatabaseLogicalResource MicrosoftReportingServicesDatabaseLogicalResource
        {
            get
            {
                ILogicalResource result = this.LogicalResources.FirstOrDefault(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.MicrosoftReportingServicesDatabase));

                return result == null ? null : (MicrosoftReportingServicesDatabaseLogicalResource)result;
            }
        }

        #endregion

        #region Implementation of IXmlSerializable

        /// <summary>
        /// This method is reserved and should not be used. When implementing the IXmlSerializable interface, you should return null (Nothing in Visual Basic) from this method, and instead, if specifying a custom schema is required, apply the <see cref="T:System.Xml.Serialization.XmlSchemaProviderAttribute"/> to the class.
        /// </summary>
        /// <returns>
        /// An <see cref="T:System.Xml.Schema.XmlSchema"/> that describes the XML representation of the object that is produced by the <see cref="M:System.Xml.Serialization.IXmlSerializable.WriteXml(System.Xml.XmlWriter)"/> method and consumed by the <see cref="M:System.Xml.Serialization.IXmlSerializable.ReadXml(System.Xml.XmlReader)"/> method.
        /// </returns>
        public XmlSchema GetSchema()
        {
            return null;
        }

        /// <summary>
        /// Generates an object from its XML representation.
        /// </summary>
        /// <param name="reader">The <see cref="T:System.Xml.XmlReader"/> stream from which the object is deserialized.</param>
        public void ReadXml(XmlReader reader)
        {
            string vesrionString = reader.GetAttribute("Version");
            int version = string.IsNullOrEmpty(vesrionString) ? 1 : Int32.Parse(vesrionString);

            XmlReader docReader;

            // Perform upgrade);
            if (version != XmlSchemaVersion)
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(reader);
                doc = UpgradeXml(doc, version);
                docReader = new XmlNodeReader(doc);
                docReader.ReadToDescendant("ClusterConfiguration");
            }
            else
            {
                docReader = reader;
            }

            this.UserMode = false;

            // Clear all existing configuration
            this.LogicalResourceTypeGroups.Clear();
            this.LogicalResourceTypes.Clear();
            this.PhysicalConnectionTypes.Clear();
            this.PhysicalServers.Clear();
            this.LogicalResources.Clear();

            // Load data from xml
            docReader.ReadToDescendant("LogicalResourceTypeGroups");
            ReadLogicalResourceTypeGroups(docReader);

            docReader.ReadToNextSibling("LogicalResourceTypes");
            ReadLogicalResourceTypes(docReader);

            docReader.ReadToNextSibling("PhysicalConnectionTypes");
            ReadPhysicalConnectionTypes(docReader);

            docReader.ReadToNextSibling("PhysicalResourceComponentTypes");
            ReadPhysicalResourceComponentTypes(docReader);

            docReader.ReadToNextSibling("PhysicalServers");
            ReadPhysicalServers(docReader);

            docReader.ReadToNextSibling("LogicalResources");
            ReadLogicalResources(docReader);

            docReader.ReadToNextSibling("PhysicalResources");
            ReadPhysicalResources(docReader);

            docReader.ReadToNextSibling("PhysicalResourceComponents");
            ReadPhysicalResourceComponents(docReader);

            docReader.ReadToNextSibling("PhysicalConnections");
            ReadPhysicalConnections(docReader);

            reader.ReadToNextSibling("LogicalResourceMembers");
            ReadLogicalResourceMembers(docReader);

            docReader.ReadToNextSibling("LogicalResourceEntityTypeMappings");
            ReadLogicalResourceEntityTypeMappings(docReader);

            this.UserMode = true;
        }

        /// <summary>
        /// Reads the list of logical resource type groups from the reader
        /// </summary>
        private void ReadLogicalResourceTypeGroups(XmlReader reader)
        {
            if (reader.ReadToDescendant("LogicalResourceTypeGroup"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    LogicalResourceTypeGroup obj = new LogicalResourceTypeGroup(this, id);

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);
                    SetClusterFieldProperties(obj, properties);

                    this.LogicalResourceTypeGroups.Add(obj);
                }
                while (reader.ReadToNextSibling("LogicalResourceTypeGroup"));
            }
        }

        /// <summary>
        /// Reads the list of logical resource types from the XmlReader
        /// </summary>
        private void ReadLogicalResourceTypes(XmlReader reader)
        {
            if (reader.ReadToDescendant("LogicalResourceType"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    LogicalResourceType obj = new LogicalResourceType(this, id);

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);
                    SetClusterFieldProperties(obj, properties);

                    this.LogicalResourceTypes.Add(obj);
                }
                while (reader.ReadToNextSibling("LogicalResourceType"));
            }
        }

        /// <summary>
        /// Reads the list of physical resource component types from the reader
        /// </summary>
        private void ReadPhysicalResourceComponentTypes(XmlReader reader)
        {
            if (reader.ReadToDescendant("PhysicalResourceComponentType"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);

                    ILogicalResourceType lrt = this.LogicalResourceTypes.First(l => Equals(l.Id, new Guid(properties["RESOURCE_TYPE_ID"])));

                    PhysicalResourceComponentType obj = new PhysicalResourceComponentType(lrt, id);
                    SetClusterFieldProperties(obj, properties);

                    lrt.ComponentTypes.Add(obj);
                }
                while (reader.ReadToNextSibling("PhysicalResourceComponentType"));
            }
        }

        /// <summary>
        /// Reads the list of physical connection types from the reader
        /// </summary>
        private void ReadPhysicalConnectionTypes(XmlReader reader)
        {
            if (reader.ReadToDescendant("PhysicalConnectionType"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    PhysicalConnectionType obj = new PhysicalConnectionType(this, id);

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);
                    SetClusterFieldProperties(obj, properties);

                    this.PhysicalConnectionTypes.Add(obj);
                }
                while (reader.ReadToNextSibling("PhysicalConnectionType"));
            }
        }

        /// <summary>
        /// Reads the list of physical servers from the reader
        /// </summary>
        private void ReadPhysicalServers(XmlReader reader)
        {
            if (reader.ReadToDescendant("PhysicalServer"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    PhysicalServer obj = new PhysicalServer(this, id);

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);
                    SetClusterFieldProperties(obj, properties);

                    this.PhysicalServers.Add(obj);
                }
                while (reader.ReadToNextSibling("PhysicalServer"));
            }
        }

        /// <summary>
        /// Reads the list of logical resources from the reader
        /// </summary>
        private void ReadLogicalResources(XmlReader reader)
        {
            if (reader.ReadToDescendant("LogicalResource"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    if (!reader.ReadToDescendant("ResourceTypeInternalName"))
                    {
                        throw new ApplicationException("No ResourceTypeInternalName specified for Logical Resource");
                    }

                    string resourceTypeInternalName = reader.ReadElementContentAsString();

                    ILogicalResource obj = LogicalResourceFactory.CreateLogicalResource(resourceTypeInternalName, this, id);

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);
                    SetClusterFieldProperties(obj, properties);

                    this.LogicalResources.Add(obj);
                }
                while (reader.ReadToNextSibling("LogicalResource"));
            }
        }

        /// <summary>
        /// Reads the list of physical resources from the reader
        /// </summary>
        private void ReadPhysicalResources(XmlReader reader)
        {
            if (reader.ReadToDescendant("PhysicalResource"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);

                    ILogicalResource lr = this.LogicalResources.First(l => Equals(l.Id, new Guid(properties["RESOURCE_ID"])));

                    IPhysicalResource obj = PhysicalResourceFactory.CreatePhysicalResource(lr, id);
                    SetClusterFieldProperties(obj, properties);

                    lr.PhysicalResources.Add(obj);
                }
                while (reader.ReadToNextSibling("PhysicalResource"));
            }
        }

        /// <summary>
        /// Reads the list of physical resource components from the reader
        /// </summary>
        private void ReadPhysicalResourceComponents(XmlReader reader)
        {
            if (reader.ReadToDescendant("PhysicalResourceComponent"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    if (!reader.ReadToDescendant("ComponentTypeInternalName"))
                    {
                        throw new ApplicationException("No ComponentTypeInternalName specified for Physical Resource Component");
                    }

                    string componentTypeInternalName = reader.ReadElementContentAsString();

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);

                    IPhysicalResource pr = this.PhysicalResources.First(l => Equals(l.Id, new Guid(properties["RESOURCE_INSTANCE_ID"])));

                    IPhysicalResourceComponent obj = PhysicalResourceComponentFactory.CreatePhysicalResourceComponent(pr, componentTypeInternalName, id);

                    SetClusterFieldProperties(obj, properties);

                    pr.Components.Add(obj);
                }
                while (reader.ReadToNextSibling("PhysicalResourceComponent"));
            }
        }

        /// <summary>
        /// Reads the list of physical connections from the reader
        /// </summary>
        private void ReadPhysicalConnections(XmlReader reader)
        {
            if (reader.ReadToDescendant("PhysicalConnection"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    if (!reader.ReadToDescendant("ConnectionTypeInternalName"))
                    {
                        throw new ApplicationException("No ConnectionTypeInternalName specified for Physical Connection");
                    }

                    string connectionTypeInternalName = reader.ReadElementContentAsString();

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);

                    IPhysicalResourceComponent sourceComponent = this.PhysicalResourceComponents.First(l => Equals(l.Id, new Guid(properties["SOURCE_COMPONENT_ID"])));

                    IPhysicalResourceComponent sinkComponent = this.PhysicalResourceComponents.First(l => Equals(l.Id, new Guid(properties["SINK_COMPONENT_ID"])));

                    IPhysicalConnection obj = PhysicalConnectionFactory.CreatePhysicalConnection(connectionTypeInternalName, sourceComponent, sinkComponent, id);

                    SetClusterFieldProperties(obj, properties);

                    obj.SourceComponent.OutboundConnections.Add(obj);
                }
                while (reader.ReadToNextSibling("PhysicalConnection"));
            }
        }

        /// <summary>
        /// Reads the list of logical resource members from the reader
        /// </summary>
        private void ReadLogicalResourceMembers(XmlReader reader)
        {
            if (reader.ReadToDescendant("LogicalResourceMember"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);

                    ILogicalResource parentResource = this.LogicalResources.First(l => Equals(l.Id, new Guid(properties["PARENT_RESOURCE_ID"])));

                    ILogicalResource childResource = this.LogicalResources.First(l => Equals(l.Id, new Guid(properties["CHILD_RESOURCE_ID"])));

                    ILogicalResourceMember obj = new LogicalResourceMember(parentResource, childResource, id);

                    SetClusterFieldProperties(obj, properties);

                    obj.ParentResource.ChildResourceMembers.Add(obj);
                }
                while (reader.ReadToNextSibling("LogicalResourceMember"));
            }
        }

        /// <summary>
        /// Reads the list of logical resource entity mappings from the reader
        /// </summary>
        private void ReadLogicalResourceEntityTypeMappings(XmlReader reader)
        {
            if (reader.ReadToDescendant("LogicalResourceEntityTypeMapping"))
            {
                do
                {
                    string guid = reader.GetAttribute("Id");
                    if (string.IsNullOrEmpty(guid))
                    {
                        throw new ApplicationException("Id missing!");
                    }

                    Guid id = new Guid(guid);

                    if (!reader.ReadToDescendant("EntityTypeInternalName"))
                    {
                        throw new ApplicationException("No EntityTypeInternalName specified for Logical Resource Entity Type Mapping");
                    }

                    string entityTypeInternalName = reader.ReadElementContentAsString();

                    IDictionary<string, string> properties = ReadClusterFieldProperties(reader);

                    string sourceClusterResourceIdString = properties.ContainsKey("SOURCE_CLUSTER_RESOURCE_ID") ? properties["SOURCE_CLUSTER_RESOURCE_ID"] : null;
                    Guid? sourceClusterResourceId = sourceClusterResourceIdString != null && sourceClusterResourceIdString.IsGuid() ? new Guid(sourceClusterResourceIdString) : default(Guid?);

                    ILogicalResource parentResource = this.LogicalResources.First(l => Equals(l.Id, new Guid(properties["CLUSTER_RESOURCE_ID"])));
                    ILogicalResource sourceResource = sourceClusterResourceId != null ? this.LogicalResources.First(l => Equals(l.Id, sourceClusterResourceId)) : null;

                    ILogicalResourceEntityTypeMapping obj = new LogicalResourceEntityTypeMapping(parentResource, id, entityTypeInternalName, sourceResource);

                    SetClusterFieldProperties(obj, properties);

                    obj.LogicalResource.EntityTypeMappings.Add(obj);
                }
                while (reader.ReadToNextSibling("LogicalResourceEntityTypeMapping"));
            }
        }

        /// <summary>
        /// Set the cluster fields on the object
        /// </summary>
        private static void SetClusterFieldProperties(IClusterObject clusterObject, IDictionary<string, string> clusterFieldProperties)
        {
            Dictionary<string, object> amalgamatedDictionary = clusterFieldProperties.ToDictionary(key => key.Key, val => val.Value as object);

            // Check against our current properties whether we need to default a value or not.
            IDictionary<PropertyInfo, Attribute[]> internalProperties = AttributeHelper.GetPropertyLevelAttributes(clusterObject);
            foreach (KeyValuePair<PropertyInfo, Attribute[]> missingProperties in internalProperties.Where(val => !clusterFieldProperties.ContainsKey(val.Key.Name)
                && val.Value.OfType<ClusterFieldAttribute>().Any(attri => !string.IsNullOrEmpty(attri.FieldName))))
            {
                DefaultValueAttribute defaultValue = missingProperties.Value.OfType<DefaultValueAttribute>().FirstOrDefault();
                if (defaultValue == null)
                {
                    continue;
                }

                amalgamatedDictionary.Add(missingProperties.Key.Name, defaultValue.Value);
            }

            foreach (KeyValuePair<string, object> fieldProperties in amalgamatedDictionary)
            {
                clusterObject.SetClusterField(fieldProperties.Key, fieldProperties.Value, true);
            }
        }

        /// <summary>
        /// Read the properties for the current cluster object from the reader
        /// </summary>
        private static IDictionary<string, string> ReadClusterFieldProperties(XmlReader reader)
        {
            Dictionary<string, string> results = new Dictionary<string, string>();

            if (Equals(reader.Name, "Properties") || reader.ReadToDescendant("Properties"))
            {
                if (reader.ReadToDescendant("Property"))
                {
                    do
                    {
                        string propertyName = reader.GetAttribute("Name");
                        if (string.IsNullOrEmpty(propertyName))
                        {
                            throw new ApplicationException("Name is missing!");
                        }

                        string propertyValue = null;

                        string nilAttributeValue = reader.GetAttribute("nil", @"http://www.w3.org/2001/XMLSchema-instance");

                        if (string.IsNullOrEmpty(nilAttributeValue) || !Boolean.Parse(nilAttributeValue))
                        {
                            propertyValue = reader.ReadElementContentAsString();
                        }
                        else
                        {
                            // Skip
                            reader.ReadElementContentAsString();
                        }

                        results.Add(propertyName, propertyValue);
                    }
                    while (reader.Name == "Property" || reader.ReadToNextSibling("Property"));
                }
            }

            return results;
        }

        /// <summary>
        /// Converts an object into its XML representation.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Xml.XmlWriter"/> stream to which the object is serialized.</param>
        public void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");

            writer.WriteAttributeString("Version", XmlSchemaVersion.ToString(CultureInfo.InvariantCulture));

            WriteLogicalResourceTypeGroups(writer);
            WriteLogicalResourceTypes(writer);
            WritePhysicalConnectionTypes(writer);
            WritePhysicalResourceComponentTypes(writer);

            WritePhysicalServers(writer);
            WriteLogicalResources(writer);
            WritePhysicalResources(writer);
            WritePhysicalResourceComponents(writer);
            WritePhysicalConnections(writer);
            WriteLogicalResourceMembers(writer);
            WriteLogicalResourceEntityTypeMappings(writer);
        }

        /// <summary>
        /// Appends the list of logical resource type groups to the writer
        /// </summary>
        private void WriteLogicalResourceTypeGroups(XmlWriter writer)
        {
            writer.WriteStartElement("LogicalResourceTypeGroups");
            foreach (ILogicalResourceTypeGroup currentObject in this.LogicalResourceTypeGroups)
            {
                writer.WriteStartElement("LogicalResourceTypeGroup");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the list of logical resource types to the writer
        /// </summary>
        private void WriteLogicalResourceTypes(XmlWriter writer)
        {
            writer.WriteStartElement("LogicalResourceTypes");
            foreach (ILogicalResourceType currentObject in this.LogicalResourceTypes)
            {
                writer.WriteStartElement("LogicalResourceType");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the list of physical resource component types to the writer
        /// </summary>
        private void WritePhysicalResourceComponentTypes(XmlWriter writer)
        {
            writer.WriteStartElement("PhysicalResourceComponentTypes");
            foreach (IPhysicalResourceComponentType currentObject in this.PhysicalResourceComponentTypes)
            {
                writer.WriteStartElement("PhysicalResourceComponentType");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the list of physical connection types to the writer
        /// </summary>
        private void WritePhysicalConnectionTypes(XmlWriter writer)
        {
            writer.WriteStartElement("PhysicalConnectionTypes");
            foreach (IPhysicalConnectionType currentObject in this.PhysicalConnectionTypes)
            {
                writer.WriteStartElement("PhysicalConnectionType");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the configured physical servers to the writer
        /// </summary>
        private void WritePhysicalServers(XmlWriter writer)
        {
            writer.WriteStartElement("PhysicalServers");
            foreach (IPhysicalServer currentObject in this.PhysicalServers)
            {
                writer.WriteStartElement("PhysicalServer");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));

                WriteClusterFieldProperties(writer, currentObject);
                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the configured logical resources to the writer
        /// </summary>
        private void WriteLogicalResources(XmlWriter writer)
        {
            writer.WriteStartElement("LogicalResources");
            foreach (ILogicalResource currentObject in this.LogicalResources)
            {
                writer.WriteStartElement("LogicalResource");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));
                writer.WriteElementString("ResourceTypeInternalName", currentObject.ResourceType.InternalName);

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the configured physical resources to the writer
        /// </summary>
        private void WritePhysicalResources(XmlWriter writer)
        {
            writer.WriteStartElement("PhysicalResources");
            foreach (IPhysicalResource currentObject in this.PhysicalResources)
            {
                writer.WriteStartElement("PhysicalResource");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the configured physical resource components to the writer
        /// </summary>
        private void WritePhysicalResourceComponents(XmlWriter writer)
        {
            writer.WriteStartElement("PhysicalResourceComponents");
            foreach (IPhysicalResourceComponent currentObject in this.PhysicalResourceComponents)
            {
                writer.WriteStartElement("PhysicalResourceComponent");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));
                writer.WriteElementString("ComponentTypeInternalName", currentObject.ComponentType.InternalName);

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the configured physical connections to the writer
        /// </summary>
        private void WritePhysicalConnections(XmlWriter writer)
        {
            writer.WriteStartElement("PhysicalConnections");
            foreach (IPhysicalConnection currentObject in this.PhysicalConnections)
            {
                writer.WriteStartElement("PhysicalConnection");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));
                writer.WriteElementString("ConnectionTypeInternalName", currentObject.ConnectionType.InternalName);

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the configured physical connections to the writer
        /// </summary>
        private void WriteLogicalResourceMembers(XmlWriter writer)
        {
            writer.WriteStartElement("LogicalResourceMembers");
            foreach (ILogicalResourceMember currentObject in this.LogicalResourceMembers)
            {
                writer.WriteStartElement("LogicalResourceMember");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));

                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the configured physical connections to the writer
        /// </summary>
        private void WriteLogicalResourceEntityTypeMappings(XmlWriter writer)
        {
            writer.WriteStartElement("LogicalResourceEntityTypeMappings");
            foreach (ILogicalResourceEntityTypeMapping currentObject in this.LogicalResourceEntityTypeMappings)
            {
                writer.WriteStartElement("LogicalResourceEntityTypeMapping");
                writer.WriteAttributeString("Id", (string)TypeConversion.ConvertType(currentObject.Id, typeof(string)));
                writer.WriteElementString("EntityTypeInternalName", currentObject.EntityTypeInternalName);
                WriteClusterFieldProperties(writer, currentObject);

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Appends the fields with values associated with the input cluster object to the writer
        /// </summary>
        private static void WriteClusterFieldProperties(XmlWriter writer, IClusterObject clusterObject)
        {
            IDictionary<string, string> clusterFieldProperties = GetClusterFieldProperties(clusterObject);
            writer.WriteStartElement("Properties");
            foreach (string propertyName in clusterFieldProperties.Keys)
            {
                string propertyValue = clusterFieldProperties[propertyName];

                writer.WriteStartElement("Property");
                writer.WriteAttributeString("Name", propertyName);
                if (propertyValue == null)
                {
                    writer.WriteAttributeString("xsi", "nil", "http://www.w3.org/2001/XMLSchema-instance", "true");
                }
                else
                {
                    writer.WriteValue(propertyValue);
                }

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Gets the fields with the configured values associated with the input cluster object
        /// </summary>
        private static IDictionary<string, string> GetClusterFieldProperties(IClusterObject currentObject)
        {
            IDictionary<string, string> result = new Dictionary<string, string>();

            foreach (PropertyInfo propInfo in currentObject.GetType().GetProperties())
            {
                ClusterFieldAttribute clusterFieldAttribute =
                    AttributeHelper.GetPropertyLevelAttribute<ClusterFieldAttribute>(currentObject, propInfo.Name);

                if (clusterFieldAttribute != null && !string.IsNullOrEmpty(clusterFieldAttribute.FieldName))
                {
                    string fieldName = clusterFieldAttribute.FieldName;

                    object fieldValue = TypeConversion.ConvertType(propInfo.GetValue(currentObject, null), typeof(string));
                    if (clusterFieldAttribute.Encrypted && fieldValue != null)
                    {
                        string encryptedValue = ExonySymmetricCryptographer.EncryptUsingRotatingKey((string)fieldValue);
                        fieldValue = encryptedValue;
                    }

                    result[fieldName] = fieldValue == null ? null : fieldValue.ToString();
                }
            }

            return result;
        }

        /// <summary>
        /// Upgrade the xml data and return the upgraded data
        /// </summary>
        private static XmlDocument UpgradeXml(XmlDocument doc, int currentVersion)
        {
            if (currentVersion > XmlSchemaVersion)
            {
                throw new ArgumentException("Xml schema version is greater than the current version!");
            }

            if (currentVersion < 1)
            {
                throw new ArgumentException("Xml schema version is lower than the minimum supported version!");
            }

            #region Version 1 -> 2

            if (currentVersion == 1)
            {
                // Upgrade type internal names
                XmlNodeList nodes =
                    doc.SelectNodes(
                        "//LogicalResourceTypes/LogicalResourceType/Properties/Property[@Name='INTERNAL_NAME']|//LogicalResources/LogicalResource/ResourceTypeInternalName");

                if (nodes != null)
                {
                    foreach (XmlNode node in nodes)
                    {
                        if (string.Equals(node.InnerText, "CRT_CICM", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_CISCO_CICM";
                        }
                        else if (string.Equals(node.InnerText, "CRT_CCM", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_CISCO_CALL_MANAGER";
                        }
                        else if (string.Equals(node.InnerText, "CRT_NAM", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_CISCO_NAM";
                        }
                        else if (string.Equals(node.InnerText, "CRT_CCVP_RSDB", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_CISCO_CVP_REPORTING_SERVER";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EXDBMS", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_EXONY_RELATIONAL_DB";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EXOLAP", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_EXONY_OLAP_DB";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EXAPP", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_EXONY_APPLICATION_SERVER";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EX_MEDIATOR", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_EXONY_MEDIATOR";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EX_PROVISIONING", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_EXONY_PROVISIONING_SERVER";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EX_OLAP_PROCESSOR", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_EXONY_OLAP_PROCESSOR";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EX_DATA_PIPELINE", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_EXONY_DATA_IMPORT_SERVER";
                        }
                        else if (string.Equals(node.Value, "CRT_EXRPT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_MICROSOFT_REPORTING_WEB_SERVER";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EXRPTDB", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_MICROSOFT_REPORTING_DB_SERVER";
                        }
                        else if (string.Equals(node.InnerText, "CRT_EX_PARTITIONING", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CRT_EXONY_PARTITIONING_SERVER";
                        }
                    }
                }

                // Upgrade name and description for report server type
                XmlNode cvpLogicalResourceTypeNode =
                    doc.SelectSingleNode("//LogicalResourceTypes/LogicalResourceType[@Id='{00000046-0000-0000-0000-000000000020}']/Properties/Property[@Name ='DESCRIPTION']");

                if (cvpLogicalResourceTypeNode != null)
                {
                    cvpLogicalResourceTypeNode.InnerText = "Cisco CVP Reporting Server Resource Type";
                }

                cvpLogicalResourceTypeNode =
                    doc.SelectSingleNode("//LogicalResourceTypes/LogicalResourceType[@Id='{00000046-0000-0000-0000-000000000020}']/Properties/Property[@Name ='NAME']");

                if (cvpLogicalResourceTypeNode != null)
                {
                    cvpLogicalResourceTypeNode.InnerText = "Cisco CVP Reporting Server";
                }

                nodes =
                    doc.SelectNodes(
                        "//PhysicalResourceComponentTypes/PhysicalResourceComponentType/Properties/Property[@Name='INTERNAL_NAME']|//PhysicalResourceComponents/PhysicalResourceComponent/ComponentTypeInternalName");

                if (nodes != null)
                {
                    foreach (XmlNode node in nodes)
                    {
                        if (string.Equals(node.InnerText, "CT_CICM_AWS", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_CICM_AWS";
                        }
                        else if (string.Equals(node.InnerText, "CT_CICM_HDS", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_CICM_HDS";
                        }
                        else if (string.Equals(node.InnerText, "CT_CICM_CONAPI", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_CICM_CONAPI";
                        }
                        else if (string.Equals(node.InnerText, "CT_CCM_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_CALL_MANAGER_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_NAM_AWS", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_NAM_AWS";
                        }
                        else if (string.Equals(node.InnerText, "CT_NAM_HDS", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_NAM_HDS";
                        }
                        else if (string.Equals(node.InnerText, "CT_NAM_HDS", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_NAM_HDS";
                        }
                        else if (string.Equals(node.InnerText, "CT_NAM_HDS", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_NAM_HDS";
                        }
                        else if (string.Equals(node.InnerText, "CT_NAM_CONAPI", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_NAM_CONAPI";
                        }
                        else if (string.Equals(node.InnerText, "CT_CCVP_RSDB_CORE", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_CVP_REPORTING_SERVER_CORE_DB";
                        }
                        else if (string.Equals(node.InnerText, "CT_CCVP_RSDB_CALLBACK", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_CISCO_CVP_REPORTING_SERVER_CALLBACK_DB";
                        }
                        else if (string.Equals(node.InnerText, "CT_EXDBMS_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_RELATIONAL_DB_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_EX_OLAP_CORE_DATABASE", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_OLAP_DB_CORE";
                        }
                        else if (string.Equals(node.InnerText, "CT_EX_OLAP_QUERY_DATABASE_1", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_OLAP_DB_QUERY1";
                        }
                        else if (string.Equals(node.InnerText, "CT_EX_OLAP_QUERY_DATABASE_2", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_OLAP_DB_QUERY2";
                        }
                        else if (string.Equals(node.InnerText, "CT_EXAPP_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_APPLICATION_SERVER_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_EX_MEDIATOR_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_MEDIATOR_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_EX_PROVISIONING_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_PROVISIONING_SERVER_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_OLAP_PROCESSOR_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_EX_DATA_PIPELINE_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_DATA_IMPORT_SERVER_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_EXRPT_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_MICROSOFT_REPORTING_WEB_SERVER_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_EXRPTDB_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_MICROSOFT_REPORTING_DB_SERVER_DEFAULT";
                        }
                        else if (string.Equals(node.InnerText, "CT_EX_PARTITIONING_DEFAULT", StringComparison.InvariantCultureIgnoreCase))
                        {
                            node.InnerText = "CT_EXONY_PARTITIONING_SERVER_DEFAULT";
                        }
                    }
                }

                // Upgrade name and description for report server component types
                XmlNode cvpCoreDbComponentTypeNode =
                    doc.SelectSingleNode("//PhysicalResourceComponentTypes/PhysicalResourceComponentType[@Id='{634e50a7-8c2c-4103-acd7-9f85dd74566f}']/Properties/Property[@Name ='DESCRIPTION']");

                if (cvpCoreDbComponentTypeNode != null)
                {
                    cvpCoreDbComponentTypeNode.InnerText = "Core Database Component";
                }

                cvpCoreDbComponentTypeNode =
                    doc.SelectSingleNode("//PhysicalResourceComponentTypes/PhysicalResourceComponentType[@Id='{634e50a7-8c2c-4103-acd7-9f85dd74566f}']/Properties/Property[@Name ='NAME']");

                if (cvpCoreDbComponentTypeNode != null)
                {
                    cvpCoreDbComponentTypeNode.InnerText = "Core Database";
                }

                XmlNode cvpCallbackDbComponentTypeNode =
                    doc.SelectSingleNode("//PhysicalResourceComponentTypes/PhysicalResourceComponentType[@Id='{d022cdf5-e791-4f87-b421-2f50f76efa91}']/Properties/Property[@Name ='DESCRIPTION']");

                if (cvpCallbackDbComponentTypeNode != null)
                {
                    cvpCallbackDbComponentTypeNode.InnerText = "Callback Database Component";
                }

                cvpCallbackDbComponentTypeNode =
                    doc.SelectSingleNode("//PhysicalResourceComponentTypes/PhysicalResourceComponentType[@Id='{d022cdf5-e791-4f87-b421-2f50f76efa91}']/Properties/Property[@Name ='NAME']");

                if (cvpCallbackDbComponentTypeNode != null)
                {
                    cvpCallbackDbComponentTypeNode.InnerText = "Callback Database";
                }

                // Add new CVP Call Server resource type
                if (doc.SelectSingleNode("//LogicalResourceTypes/LogicalResourceType[@Id = '{a695af50-297f-419d-a709-96d550777f87}']") == null)
                {
                    XmlNode resourceTypesNode = doc.SelectSingleNode("//LogicalResourceTypes");
                    const string Xml = @"<LogicalResourceType Id=""{a695af50-297f-419d-a709-96d550777f87}"">
      <Properties xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">
        <Property Name=""RESOURCE_TYPE_GROUP_ID"">{9a622d92-deb4-4570-8cbf-3afec8ef6b36}</Property>
        <Property Name=""MIN_RESOURCES"">0</Property>
        <Property Name=""MAX_RESOURCES"" xsi:nil=""true"" />
        <Property Name=""MIN_RESOURCE_INSTANCES"">1</Property>
        <Property Name=""MAX_RESOURCE_INSTANCES"">2</Property>
        <Property Name=""IMPORT_SUPPORTED"">True</Property>
        <Property Name=""NAME"">Cisco CVP Call Server</Property>
        <Property Name=""DESCRIPTION"">Cisco CVP Call Server Resource Type</Property>
        <Property Name=""INTERNAL_NAME"">CRT_CISCO_CVP_CALL_SERVER</Property>
        <Property Name=""SYSTEM"">True</Property>
      </Properties>
    </LogicalResourceType>";
                    XmlTools.ImportChildNodeFromXmlString(
                        resourceTypesNode,
Xml);
                }

                // Add new CVP Call Server component type
                if (doc.SelectSingleNode("//PhysicalResourceComponentTypes/PhysicalResourceComponentType[@Id = '{aee18d47-53bd-4019-8f49-af5f41d8d838}']") == null)
                {
                    XmlNode componentTypesNode = doc.SelectSingleNode("//PhysicalResourceComponentTypes");
                    const string Xml = @"<PhysicalResourceComponentType Id=""{aee18d47-53bd-4019-8f49-af5f41d8d838}"">
      <Properties xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">
        <Property Name=""RESOURCE_TYPE_ID"">{a695af50-297f-419d-a709-96d550777f87}</Property>
        <Property Name=""CONNECTION_TYPE_ID"" xsi:nil=""true"" />
        <Property Name=""REQUIRED"">True</Property>
        <Property Name=""MAX_INSTANCES_PER_SERVER"">1</Property>
        <Property Name=""NAME"">Default</Property>
        <Property Name=""DESCRIPTION"">Default Component</Property>
        <Property Name=""INTERNAL_NAME"">CT_CISCO_CVP_CALL_SERVER_DEFAULT</Property>
        <Property Name=""SYSTEM"">True</Property>
      </Properties>
    </PhysicalResourceComponentType>";
                    XmlTools.ImportChildNodeFromXmlString(
                        componentTypesNode,
Xml);
                }

                // Add new Avaya CMS resource Type
                if (doc.SelectSingleNode("//LogicalResourceTypes/LogicalResourceType[@Id = '{4465b290-ba56-4ab7-9c38-c25158d60286}']") == null)
                {
                    XmlNode resourceTypesNode = doc.SelectSingleNode("//LogicalResourceTypes");
                    const string Xml = @"<LogicalResourceType Id=""{4465b290-ba56-4ab7-9c38-c25158d60286}"">
      <Properties xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">
        <Property Name=""RESOURCE_TYPE_GROUP_ID"" xsi:nil=""true"" />
        <Property Name=""MIN_RESOURCES"">0</Property>
        <Property Name=""MAX_RESOURCES"" xsi:nil=""true"" />
        <Property Name=""MIN_RESOURCE_INSTANCES"">1</Property>
        <Property Name=""MAX_RESOURCE_INSTANCES"">1</Property>
        <Property Name=""IMPORT_SUPPORTED"">True</Property>
        <Property Name=""NAME"">Avaya CMS</Property>
        <Property Name=""DESCRIPTION"">Avaya CMS Resource Type</Property>
        <Property Name=""INTERNAL_NAME"">CRT_AVAYA_CMS</Property>
        <Property Name=""SYSTEM"">True</Property>
      </Properties>
    </LogicalResourceType>";
                    XmlTools.ImportChildNodeFromXmlString(resourceTypesNode, Xml);
                }

                // Add New Avaya CMS default Component type
                if (doc.SelectSingleNode("//PhysicalResourceComponentTypes/PhysicalResourceComponentType[@Id = '{1b5ae143-632c-465e-b15f-a7bdc3c4e89c}']") == null)
                {
                    XmlNode componentTypesNode = doc.SelectSingleNode("//PhysicalResourceComponentTypes");
                    const string Xml = @"<PhysicalResourceComponentType Id=""{1b5ae143-632c-465e-b15f-a7bdc3c4e89c}"">
      <Properties xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">
        <Property Name=""RESOURCE_TYPE_ID"">{4465b290-ba56-4ab7-9c38-c25158d60286}</Property>
        <Property Name=""CONNECTION_TYPE_ID"">{2d370fd6-3326-42d9-8eed-8ff78d3cc269}</Property>
        <Property Name=""REQUIRED"">True</Property>
        <Property Name=""MAX_INSTANCES_PER_SERVER"">1</Property>
        <Property Name=""NAME"">Default</Property>
        <Property Name=""DESCRIPTION"">Default Component</Property>
        <Property Name=""INTERNAL_NAME"">CT_AVAYA_CMS_DEFAULT</Property>
        <Property Name=""SYSTEM"">True</Property>
      </Properties>
    </PhysicalResourceComponentType>";
                    XmlTools.ImportChildNodeFromXmlString(
                        componentTypesNode,
Xml);
                }
            }
            #endregion

            return doc;
        }

        #endregion

        #region Implementation of ICloneable

        /// <summary>
        /// Creates a new object that is a copy of the current instance.
        /// </summary>
        /// <returns>
        /// A new object that is a copy of this instance.
        /// </returns>
        /// <filterpriority>2</filterpriority>
        public object Clone()
        {
            return XmlTools.Clone(this);
        }

        #endregion
    }
}
