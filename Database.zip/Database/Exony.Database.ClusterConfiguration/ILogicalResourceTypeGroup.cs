#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using Exony.Database.ClusterConfiguration.Collections;

    public interface ILogicalResourceTypeGroup : IClusterObject
    {
        /// <summary>
        /// Name for this cluster object
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Internal name for this cluster object
        /// </summary>
        string InternalName { get; set; }

        /// <summary>
        /// Description for this cluster object
        /// </summary>
        string Description { get; set; }

        /// <summary>
        /// The resource types associated with this group
        /// </summary>
        LogicalResourceTypeCollection LogicalResourceTypes { get; }
    }
}
