#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System.Linq;

    public class PhysicalResourceComponentTypeCollection : ClusterObjectCollection<IPhysicalResourceComponentType>
    {
        #region Fields

        /// <summary>
        /// The resource type (if specified)
        /// </summary>
        private readonly ILogicalResourceType resourceType;

        #endregion

        #region Construction

        /// <summary>
        /// Create a PhysicalResourceComponentTypeCollection for the specified type
        /// </summary>
        public PhysicalResourceComponentTypeCollection(ILogicalResourceType resourceType)
            : base(resourceType.Configuration)
        {
            this.resourceType = resourceType;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public IPhysicalResourceComponentType CreateNew()
        {
            IPhysicalResourceComponentType result = new PhysicalResourceComponentType(this.resourceType);
            this.Add(result);
            return result;
        }

        /// <summary>
        /// Called prior to removing an item from this collection
        /// </summary>
        protected override void OnPreRemove(IPhysicalResourceComponentType item)
        {
            base.OnPreRemove(item);

            // Remove all components of this type
            foreach (IPhysicalResourceComponent comp in this.configuration.PhysicalResourceComponents.Where(prc => prc.ComponentType.Equals(item)))
            {
                comp.PhysicalResource.Components.Remove(comp);
            }
        }

        #endregion
    }
}