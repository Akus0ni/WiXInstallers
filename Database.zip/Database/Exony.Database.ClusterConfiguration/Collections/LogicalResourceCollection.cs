#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;
    using System.Linq;

    using Exony.Database.ClusterConfiguration.LogicalResources;

    /// <summary>
    /// Collection of cluster objects owned by a particular parent
    /// </summary>
    public class LogicalResourceCollection : ClusterObjectCollection<ILogicalResource>
    {
        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public LogicalResourceCollection(ClusterConfiguration configuration)
            : base(configuration)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public ILogicalResource CreateNew(string resourceTypeInternalName)
        {
            ILogicalResource result = LogicalResourceFactory.CreateLogicalResource(resourceTypeInternalName, this.configuration);
            this.Add(result);
            return result;
        }

        /// <summary>
        /// Called prior to adding an item
        /// </summary>
        protected override void OnPreAdd(ILogicalResource item)
        {
            base.OnPreAdd(item);

            if (this.configuration.UserMode)
            {
                ILogicalResourceType resourceType = item.ResourceType;

                if (this.configuration.LogicalResources.Count(lr => Equals(lr, resourceType)) >= resourceType.MaxResources)
                {
                    throw new InvalidOperationException(string.Format("You have reached the maximum resource count for resources of type [{0}]", resourceType.Name));
                }
            }
        }

        /// <summary>
        /// Called prior to removing an item
        /// </summary>
        protected override void OnPreRemove(ILogicalResource item)
        {
            base.OnPreRemove(item);

            // Remove related items first
            item.ChildResourceMembers.Clear(); // Other end cleared automatically
            item.ParentResourceMembers.Clear();
            item.PhysicalResources.Clear();
            item.FolderMappings.Clear();
            item.EntityTypeMappings.Clear();
        }

        #endregion
    }
}
