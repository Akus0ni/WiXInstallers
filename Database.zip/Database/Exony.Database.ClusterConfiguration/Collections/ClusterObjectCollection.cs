#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Collection of cluster objects owned by a particular parent
    /// </summary>
    public class ClusterObjectCollection<T> : ICollection<T>
        where T : IClusterObject
    {
        #region Delegates

        /// <summary>
        /// Event delegate for items
        /// </summary>
        public delegate void ItemEventDelegate(object sender, T item);

        #endregion

        #region Events

        /// <summary>
        /// Fired when an item is added to this collection
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ItemEventDelegate ItemAdded;

        /// <summary>
        /// Fired when an item is removed from this collection
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ItemEventDelegate ItemRemoved;

        /// <summary>
        /// Fired before an item is added to the collection
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ItemEventDelegate ItemPreAdd;

        /// <summary>
        /// Fired before an item is removed from the collection
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
        public event ItemEventDelegate ItemPreRemove;

        #endregion

        #region Fields

        /// <summary>
        /// The configuration that the items in this collection belong to
        /// </summary>
        protected readonly ClusterConfiguration configuration;

        /// <summary>
        /// Underlying item collection
        /// </summary>
        protected List<T> items = new List<T>();

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public ClusterObjectCollection(ClusterConfiguration configuration)
        {
            ArgumentValidation.CheckForNullReference(configuration, "configuration");

            this.configuration = configuration;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Add the specified items to this collection
        /// </summary>
        public virtual void AddRange(IEnumerable<T> items)
        {
            foreach (T current in items)
            {
                this.Add(current);
            }
        }

        /// <summary>
        /// Called when an item is added to this collection
        /// </summary>
        protected virtual void FireItemAdded(T item)
        {
            if (this.ItemAdded != null)
            {
                this.ItemAdded(this, item);
            }
        }

        /// <summary>
        /// Called before an item is removed from this collection
        /// </summary>
        protected virtual void FireItemPreRemove(T item)
        {
            if (this.ItemPreRemove != null)
            {
                this.ItemPreRemove(this, item);
            }
        }

        /// <summary>
        /// Called before an item is added to this collection
        /// </summary>
        protected virtual void FireItemPreAdd(T item)
        {
            if (this.ItemPreAdd != null)
            {
                this.ItemPreAdd(this, item);
            }
        }

        /// <summary>
        /// Called when an item is removed from this collection
        /// </summary>
        protected virtual void FireItemRemoved(T item)
        {
            if (this.ItemRemoved != null)
            {
                this.ItemRemoved(this, item);
            }
        }

        /// <summary>
        /// Gets the LogicalResource with the specified id
        /// </summary>
        public T GetById(Guid id)
        {
            return this.FirstOrDefault(resource => resource.Id == id);
        }

        /// <summary>
        /// Called prior to adding an item
        /// </summary>
        protected virtual void OnPreAdd(T item)
        {
            // Don't allow null values to be added to collection
            ArgumentValidation.CheckForNullReference(item, "item");

            // Ensure that items added are from the same model
            if (item.Configuration != this.configuration)
            {
                throw new ArgumentException("Item being added does not belong to this cluster model");
            }
        }

        /// <summary>
        /// Called prior to removing an item
        /// </summary>
        protected virtual void OnPreRemove(T item)
        {
        }

        /// <summary>
        /// Called after removing an item
        /// </summary>
        protected virtual void OnPostRemove(T item)
        {
        }

        /// <summary>
        /// Called after adding an item
        /// </summary>
        protected virtual void OnPostAdd(T item)
        {
        }

        #endregion

        #region Implementation of IEnumerable

        /// <summary>
        /// Returns an enumerator that iterates through the collection.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.Collections.Generic.IEnumerator`1" /> that can be used to iterate through the collection.
        /// </returns>
        /// <filterpriority>1</filterpriority>
        public virtual IEnumerator<T> GetEnumerator()
        {
            return this.items.GetEnumerator();
        }

        /// <summary>
        /// Returns an enumerator that iterates through a collection.
        /// </summary>
        /// <returns>
        /// An <see cref="T:System.Collections.IEnumerator" /> object that can be used to iterate through the collection.
        /// </returns>
        /// <filterpriority>2</filterpriority>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion

        #region Implementation of ICollection<T>

        /// <summary>
        /// Adds an item to the <see cref="T:System.Collections.Generic.ICollection`1" />.
        /// </summary>
        /// <param name="item">The object to add to the <see cref="T:System.Collections.Generic.ICollection`1" />.</param>
        /// <exception cref="T:System.NotSupportedException">The <see cref="T:System.Collections.Generic.ICollection`1" /> is read-only.</exception>
        public virtual void Add(T item)
        {
            if (this.items.Contains(item))
            {
                // Already exists so just return
                return;
            }

            this.FireItemPreAdd(item);

            this.OnPreAdd(item);

            this.items.Add(item);

            this.OnPostAdd(item);

            this.FireItemAdded(item);
        }

        /// <summary>
        /// Removes all items from the <see cref="T:System.Collections.Generic.ICollection`1" />.
        /// </summary>
        /// <exception cref="T:System.NotSupportedException">The <see cref="T:System.Collections.Generic.ICollection`1" /> is read-only. </exception>
        public virtual void Clear()
        {
            // Copy collection to prevent modification whilst itterating
            List<T> itemsToRemove = new List<T>();
            itemsToRemove.AddRange(this);

            foreach (T item in itemsToRemove)
            {
                this.Remove(item);
            }
        }

        /// <summary>
        /// Determines whether the <see cref="T:System.Collections.Generic.ICollection`1" /> contains a specific value.
        /// </summary>
        /// <returns>
        /// true if <paramref name="item" /> is found in the <see cref="T:System.Collections.Generic.ICollection`1" />; otherwise, false.
        /// </returns>
        /// <param name="item">The object to locate in the <see cref="T:System.Collections.Generic.ICollection`1" />.</param>
        public virtual bool Contains(T item)
        {
            return this.items.Contains(item);
        }

        /// <summary>
        /// Copies the elements of the <see cref="T:System.Collections.Generic.ICollection`1" /> to an <see cref="T:System.Array" />, starting at a particular <see cref="T:System.Array" /> index.
        /// </summary>
        /// <param name="array">The one-dimensional <see cref="T:System.Array" /> that is the destination of the elements copied from <see cref="T:System.Collections.Generic.ICollection`1" />. The <see cref="T:System.Array" /> must have zero-based indexing.</param>
        /// <param name="arrayIndex">The zero-based index in <paramref name="array" /> at which copying begins.</param>
        /// <exception cref="T:System.ArgumentNullException"><paramref name="array" /> is null.</exception>
        /// <exception cref="T:System.ArgumentOutOfRangeException"><paramref name="arrayIndex" /> is less than 0.</exception>
        public virtual void CopyTo(T[] array, int arrayIndex)
        {
            this.items.CopyTo(array, arrayIndex);
        }

        /// <summary>
        /// Removes the first occurrence of a specific object from the <see cref="T:System.Collections.Generic.ICollection`1" />.
        /// </summary>
        /// <returns>
        /// true if <paramref name="item" /> was successfully removed from the <see cref="T:System.Collections.Generic.ICollection`1" />; otherwise, false. This method also returns false if <paramref name="item" /> is not found in the original <see cref="T:System.Collections.Generic.ICollection`1" />.
        /// </returns>
        /// <param name="item">The object to remove from the <see cref="T:System.Collections.Generic.ICollection`1" />.</param>
        /// <exception cref="T:System.NotSupportedException">The <see cref="T:System.Collections.Generic.ICollection`1" /> is read-only.</exception>
        public virtual bool Remove(T item)
        {
            if (this.Contains(item))
            {
                this.FireItemPreRemove(item);

                this.OnPreRemove(item);

                bool result = this.items.Remove(item);

                this.OnPostRemove(item);

                if (result)
                {
                    this.FireItemRemoved(item);
                }

                return result;
            }

            return false;
        }

        /// <summary>
        /// Gets the number of elements contained in the <see cref="T:System.Collections.Generic.ICollection`1" />.
        /// </summary>
        /// <returns>
        /// The number of elements contained in the <see cref="T:System.Collections.Generic.ICollection`1" />.
        /// </returns>
        public virtual int Count
        {
            get { return this.items.Count; }
        }

        /// <summary>
        /// Gets a value indicating whether the <see cref="T:System.Collections.Generic.ICollection`1" /> is read-only.
        /// </summary>
        /// <returns>
        /// true if the <see cref="T:System.Collections.Generic.ICollection`1" /> is read-only; otherwise, false.
        /// </returns>
        public virtual bool IsReadOnly
        {
            get { return false; }
        }

        #endregion
    }
}
