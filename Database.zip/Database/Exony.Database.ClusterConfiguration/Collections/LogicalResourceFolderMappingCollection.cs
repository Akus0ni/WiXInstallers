#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;

    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.Common.Folders;

    /// <summary>
    /// Collection of cluster objects owned by a particular parent
    /// </summary>
    public class LogicalResourceFolderMappingCollection : ClusterObjectCollection<ILogicalResourceFolderMapping>
    {
        #region Fields

        /// <summary>
        /// The parent of the mapping
        /// </summary>
        private readonly ILogicalResource parent;

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public LogicalResourceFolderMappingCollection(ILogicalResource parent)
            : base(parent.Configuration)
        {
            this.parent = parent;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public ILogicalResourceFolderMapping CreateNew(LogicalResourceFolderMappingType mappingType, Folder folder)
        {
            ILogicalResourceFolderMapping result = LogicalResourceFolderMappingFactory.CreateLogicalResourceFolderMapping(mappingType, this.parent, folder);
            this.Add(result);

            return result;
        }

        /// <summary>
        /// Called prior to removing an item
        /// </summary>
        protected override void OnPreRemove(ILogicalResourceFolderMapping item)
        {
            base.OnPreRemove(item);

            item.ResourceFolderItemMappings.Clear();
        }

        /// <summary>
        /// Called prior to adding an item to this collection
        /// </summary>
        protected override void OnPreAdd(ILogicalResourceFolderMapping item)
        {
            base.OnPreAdd(item);

            // Check that the item belongs to this logical resource
            if (item.LogicalResource != this.parent)
            {
                throw new ArgumentException("Folder mapping does not belong to this logical resource!");
            }
        }

        #endregion
    }
}
