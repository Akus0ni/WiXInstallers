#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;

    using Exony.Database.ClusterConfiguration.PhysicalConnections;

    /// <summary>
    /// Collection of cluster objects owned by a particular parent
    /// </summary>
    public class PhysicalConnectionCollection : ClusterObjectCollection<IPhysicalConnection>
    {
        #region Fields

        /// <summary>
        /// The component that this collection belongs to
        /// </summary>
        private readonly IPhysicalResourceComponent parent;

        /// <summary>
        // Is the parent the sink for connections or the source
        /// </summary>
        private readonly bool containsInboundConnections;

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public PhysicalConnectionCollection(IPhysicalResourceComponent parent, bool containsInboundConnections)
            : base(parent.Configuration)
        {
            this.parent = parent;
            this.containsInboundConnections = containsInboundConnections;
        }

        #endregion

        #region Properties

        /// <summary>
        // Does this collection contain inbound or outbound connections
        /// </summary>
        public bool ContainsInboundConnections
        {
            get { return this.containsInboundConnections; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public IPhysicalConnection CreateNew(string connectionTypeInternalName, IPhysicalResourceComponent otherEnd)
        {
            IPhysicalResourceComponent sinkComponent = this.containsInboundConnections ? this.parent : otherEnd;
            IPhysicalResourceComponent sourceComponent = this.containsInboundConnections ? otherEnd : this.parent;

            IPhysicalConnection result = PhysicalConnectionFactory.CreatePhysicalConnection(connectionTypeInternalName, sourceComponent, sinkComponent);

            this.Add(result);

            return result;
        }

        /// <summary>
        /// Called prior to adding a connection to this collection
        /// </summary>
        protected override void OnPreAdd(IPhysicalConnection item)
        {
            base.OnPreAdd(item);

            // Standard validation
            if (this.containsInboundConnections && item.SinkComponent != this.parent)
            {
                throw new ArgumentException("The sink of the specified connection is not this component");
            }

            if (!this.containsInboundConnections && item.SourceComponent != this.parent)
            {
                throw new ArgumentException("The source of the specified connection is not this component");
            }
        }

        /// <summary>
        /// Called after adding a connection to this collection
        /// </summary>
        protected override void OnPostAdd(IPhysicalConnection item)
        {
            base.OnPostAdd(item);

            // Propogate add to other side
            if (this.containsInboundConnections)
            {
                if (!item.SourceComponent.OutboundConnections.Contains(item))
                {
                    item.SourceComponent.OutboundConnections.Add(item);
                }
            }
            else
            {
                if (!item.SinkComponent.InboundConnections.Contains(item))
                {
                    item.SinkComponent.InboundConnections.Add(item);
                }
            }
        }

        /// <summary>
        /// Called after removing a connection from this collection
        /// </summary>
        protected override void OnPostRemove(IPhysicalConnection item)
        {
            base.OnPostRemove(item);

            // Propogate add to other side
            if (this.containsInboundConnections)
            {
                if (item.SourceComponent.OutboundConnections.Contains(item))
                {
                    item.SourceComponent.OutboundConnections.Remove(item);
                }
            }
            else
            {
                if (item.SinkComponent.InboundConnections.Contains(item))
                {
                    item.SinkComponent.InboundConnections.Remove(item);
                }
            }
        }

        #endregion
    }
}
