#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;
    using System.Linq;

    using Exony.Database.ClusterConfiguration.PhysicalResourceComponents;

    /// <summary>
    /// Collection of cluster objects owned by a particular parent
    /// </summary>
    public class PhysicalResourceComponentCollection : ClusterObjectCollection<IPhysicalResourceComponent>
    {
        #region Fields

        /// <summary>
        /// The parent of the endpoint
        /// </summary>
        private readonly IClusterObject parent;

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public PhysicalResourceComponentCollection(IPhysicalResource parent)
            : base(parent.Configuration)
        {
            this.parent = parent;
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public PhysicalResourceComponentCollection(IPhysicalServer parent)
            : base(parent.Configuration)
        {
            this.parent = parent;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public IPhysicalResourceComponent CreateNew(string componentTypeInternalName)
        {
            IPhysicalResource resource = this.parent as IPhysicalResource;

            if (resource == null)
            {
                throw new NotImplementedException("Cannot call CreateNew via the server object - must use the physical resource");
            }

            ArgumentValidation.CheckForEmptyString(componentTypeInternalName, "componentTypeInternalName");

            // XX: TODO - check the component type is valid for this resource

            // Check there is not already a component added with the specified type
            if (resource.Components.Any(comp => comp.ComponentType.InternalName.Equals(componentTypeInternalName, StringComparison.InvariantCultureIgnoreCase)))
            {
                throw new ArgumentException("Instance of specified component type already exists in this collection!", "componentType");
            }

            IPhysicalResourceComponent result = PhysicalResourceComponentFactory.CreatePhysicalResourceComponent(resource, componentTypeInternalName);
            this.Add(result);

            return result;
        }

        /// <summary>
        /// Indicates if the specified component type exists on this resource instance
        /// </summary>
        public IPhysicalResourceComponent GetByComponentTypeInternalName(string componentTypeInternalName)
        {
            return this.FirstOrDefault(comp => comp.ComponentType.InternalName.Equals(componentTypeInternalName, StringComparison.InvariantCultureIgnoreCase));
        }

        /// <summary>
        /// Called prior to removing an item
        /// </summary>
        protected override void OnPreRemove(IPhysicalResourceComponent item)
        {
            base.OnPreRemove(item);

            // Are we removing from the model
            if (this.parent is IPhysicalResource)
            {
                item.InboundConnections.Clear();
                item.OutboundConnections.Clear();
            }
        }

        /// <summary>
        /// Called after adding an item to this collection
        /// </summary>
        protected override void OnPostAdd(IPhysicalResourceComponent item)
        {
            base.OnPostAdd(item);

            // Add membership into other end
            if (this.parent is IPhysicalResource)
            {
                item.Server.Components.Add(item);
            }
            else
            {
                item.PhysicalResource.Components.Add(item);
            }
        }

        /// <summary>
        /// Called after removing an item from this collection
        /// </summary>
        protected override void OnPostRemove(IPhysicalResourceComponent item)
        {
            base.OnPostRemove(item);

            // If we are removing from the model then ensure it's removed from the server
            if (this.parent is IPhysicalResource)
            {
                item.Server.Components.Remove(item);
            }
        }

        #endregion
    }
}
