#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;
    using System.Linq;

    /// <summary>
    /// Collection of cluster objects owned by a particular parent
    /// </summary>
    public class LogicalResourceMemberCollection : ClusterObjectCollection<ILogicalResourceMember>
    {
        #region Fields

        /// <summary>
        /// The parent or child resource
        /// </summary>
        private readonly ILogicalResource resource;

        /// <summary>
        /// Is the resource the parent or child
        /// </summary>
        private readonly bool isParent;

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public LogicalResourceMemberCollection(ILogicalResource resource, bool isParent)
            : base(resource.Configuration)
        {
            this.resource = resource;
            this.isParent = isParent;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new member
        /// </summary>
        public ILogicalResourceMember CreateNew(ILogicalResource other)
        {
            ILogicalResourceMember result = this.isParent ? new LogicalResourceMember(this.resource, other) : new LogicalResourceMember(other, this.resource);
            this.Add(result);

            return result;
        }

        /// <summary>
        /// Called prior to adding an item to this collection
        /// </summary>
        protected override void OnPreAdd(ILogicalResourceMember item)
        {
            base.OnPreAdd(item);

            // Check if this a member to itself
            if ((this.isParent && Equals(item.ChildResource, this.resource)) ||
                (!this.isParent && Equals(item.ParentResource, this.resource)))
            {
                throw new ArgumentException("Cannot create a membership to self");
            }

            // Check if this is a duplicate member
            if (this.Any(m => Equals(m.ChildResource, item.ChildResource) && Equals(m.ParentResource, item.ParentResource)))
            {
                throw new ArgumentException("Membership between the two resources already exists");
            }

            // Check if member exists in reverse (item cannot be parent and child of the same resource)
            bool inverseExists;

            if (this.isParent)
            {
                inverseExists = this.resource.ParentResourceMembers.Any(m => Equals(m.ChildResource, this.resource) &&
                    Equals(m.ParentResource, item.ChildResource));
            }
            else
            {
                inverseExists = this.resource.ChildResourceMembers.Any(m => Equals(m.ParentResource, this.resource) &&
                    Equals(m.ChildResource, item.ParentResource));
            }

            if (inverseExists)
            {
                throw new ArgumentException("A resource cannot be both a parent and child of the same resource");
            }
        }

        /// <summary>
        /// Called after adding an item to this collection
        /// </summary>
        protected override void OnPostAdd(ILogicalResourceMember item)
        {
            base.OnPostAdd(item);

            // Add membership into other end
            if (this.isParent)
            {
                item.ChildResource.ParentResourceMembers.Add(item);
            }
            else
            {
                item.ParentResource.ChildResourceMembers.Add(item);
            }
        }

        /// <summary>
        /// Called after removing an item from this collection
        /// </summary>
        protected override void OnPostRemove(ILogicalResourceMember item)
        {
            base.OnPostRemove(item);

            // Remnove membership from other end
            if (this.isParent)
            {
                item.ChildResource.ParentResourceMembers.Remove(item);
            }
            else
            {
                item.ParentResource.ChildResourceMembers.Remove(item);
            }
        }

        #endregion
    }
}
