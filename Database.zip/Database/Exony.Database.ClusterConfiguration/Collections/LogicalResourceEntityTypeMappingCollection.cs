#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;
    using System.Linq;

    /// <summary>
    /// Collection of entity types mapped to a parent logical resource
    /// </summary>
    public class LogicalResourceEntityTypeMappingCollection : ClusterObjectCollection<ILogicalResourceEntityTypeMapping>
    {
        #region Fields

        /// <summary>
        /// The parent of the mapping
        /// </summary>
        private readonly ILogicalResource parent;

        #endregion

        #region Constructors and Destructors

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public LogicalResourceEntityTypeMappingCollection(ILogicalResource parent)
            : base(parent.Configuration)
        {
            this.parent = parent;
        }

        #endregion

        #endregion

        #region Public Methods and Operators

        /// <summary>
        /// Create a new item
        /// </summary>
        /// <param name="entityTypeInternalName">Name of the entity type internal.</param>
        /// <param name="sourceLogicalResource">The source logical resource.</param>
        /// <exception cref="NotSupportedException">The <see cref="T:System.Collections.Generic.ICollection`1" /> is read-only.</exception>
        public ILogicalResourceEntityTypeMapping CreateNew(string entityTypeInternalName, ILogicalResource sourceLogicalResource)
        {
            ILogicalResourceEntityTypeMapping result = new LogicalResourceEntityTypeMapping(this.parent, entityTypeInternalName, sourceLogicalResource);
            this.Add(result);

            return result;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Called prior to adding an item to this collection
        /// </summary>
        /// <param name="item">Logical resource entity type map</param>
        /// <exception cref="ArgumentException">Entity Type mapping does not belong to this logical resource!</exception>
        /// <exception cref="ArgumentException">Entity Type mapping is duplicate</exception>
        /// <exception cref="ArgumentNullException">item is null.</exception>
        protected override void OnPreAdd(ILogicalResourceEntityTypeMapping item)
        {
            base.OnPreAdd(item);

            // Check that the item belongs to this logical resource
            if (item.LogicalResource != this.parent)
            {
                throw new ArgumentException("Entity Type mapping does not belong to this logical resource!");
            }

            if (this.parent.Configuration.UserMode)
            {
                if (
                    this.items.Any(
                        m => m.EntityTypeInternalName.Equals(item.EntityTypeInternalName, StringComparison.InvariantCultureIgnoreCase) && m.SourceLogicalResource == item.SourceLogicalResource))
                {
                    throw new ArgumentException("Entity Type mapping is duplicate");
                }
            }
        }

        #endregion
    }
}