#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System.Collections.Generic;
    using System.Linq;

    public class LogicalResourceTypeCollection : ClusterObjectCollection<ILogicalResourceType>
    {
        #region Fields

        /// <summary>
        /// The group for the resource types (if specified)
        /// </summary>
        private readonly ILogicalResourceTypeGroup resourceTypeGroup;

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public LogicalResourceTypeCollection(ClusterConfiguration configuration)
            : base(configuration)
        {
        }

        /// <summary>
        /// Create a LogicalResourceTypeCollection for the specified group
        /// </summary>
        public LogicalResourceTypeCollection(ILogicalResourceTypeGroup resourceTypeGroup)
            : base(resourceTypeGroup.Configuration)
        {
            this.resourceTypeGroup = resourceTypeGroup;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public ILogicalResourceType CreateNew()
        {
            ILogicalResourceType result = new LogicalResourceType(this.configuration);

            // Set the resource type group if set
            result.ResourceTypeGroup = this.resourceTypeGroup;

            this.Add(result);
            return result;
        }

        /// <summary>
        /// Called after adding this item to the collection
        /// </summary>
        protected override void OnPostAdd(ILogicalResourceType item)
        {
            base.OnPostAdd(item);

            // Set the resource type group
            // This is only set if the collection is owned by a logical resource group
            // If this is the global collection then it will contain logical resources with different groups
            if (this.resourceTypeGroup != null)
            {
                item.ResourceTypeGroup = this.resourceTypeGroup;
            }

            // Make sure that this new item is in the global types collection
            if (!this.configuration.LogicalResourceTypes.Contains(item))
            {
                this.configuration.LogicalResourceTypes.Add(item);
            }
        }

        /// <summary>
        /// Called prior to removing an item
        /// </summary>
        protected override void OnPreRemove(ILogicalResourceType item)
        {
            base.OnPreRemove(item);

            // Clear the resource type group
            item.ResourceTypeGroup = null;

            if (this.resourceTypeGroup == null)
            {
                // Remove all resources of this type
                List<ILogicalResource> typesToRemove = new List<ILogicalResource>(this.configuration.LogicalResources.Where(lr => lr.ResourceType.Equals(item)));
                foreach (ILogicalResource logicalResource in typesToRemove)
                {
                    this.configuration.LogicalResources.Remove(logicalResource);
                }
            }
        }

        #endregion
    }
}
