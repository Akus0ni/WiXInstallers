#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System.Collections.Generic;

    public class LogicalResourceTypeGroupCollection : ClusterObjectCollection<ILogicalResourceTypeGroup>
    {
        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public LogicalResourceTypeGroupCollection(ClusterConfiguration configuration)
            : base(configuration)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public ILogicalResourceTypeGroup CreateNew()
        {
            ILogicalResourceTypeGroup result = new LogicalResourceTypeGroup(this.configuration);
            this.Add(result);
            return result;
        }

        /// <summary>
        /// Called prior to removing a group from the collection
        /// </summary>
        protected override void OnPreRemove(ILogicalResourceTypeGroup item)
        {
            base.OnPreRemove(item);

            List<ILogicalResourceType> allTypes = new List<ILogicalResourceType>(item.LogicalResourceTypes);

            foreach (ILogicalResourceType type in allTypes)
            {
                type.ResourceTypeGroup = null;
            }
        }

        #endregion
    }
}
