#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;
    using System.Linq;

    using Exony.Database.ClusterConfiguration.PhysicalResources;
    using Exony.Database.Common.Enumerations;

    /// <summary>
    /// Collection of cluster objects owned by a particular parent
    /// </summary>
    public class PhysicalResourceCollection : ClusterObjectCollection<IPhysicalResource>
    {
        #region Fields

        /// <summary>
        /// The parent of the physical resources
        /// </summary>
        private readonly ILogicalResource parent;

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public PhysicalResourceCollection(ILogicalResource parent)
            : base(parent.Configuration)
        {
            this.parent = parent;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public IPhysicalResource CreateNew()
        {
            IPhysicalResource result = PhysicalResourceFactory.CreatePhysicalResource(this.parent);
            this.Add(result);

            // Automatically add all required components to a new resource
            foreach (PhysicalResourceComponentType compType in
                this.configuration.PhysicalResourceComponentTypes.Where(prct =>
                    prct.ResourceType.InternalName.Equals(result.LogicalResource.ResourceType.InternalName)).Cast<PhysicalResourceComponentType>().Where(
                    compType => compType.Required && WellKnownPhysicalResourceComponentTypes.IsSupported(compType.InternalName)))
            {
                result.Components.CreateNew(compType.InternalName);
            }

            return result;
        }

        /// <summary>
        /// Called prior to adding an item to this collection
        /// </summary>
        protected override void OnPreAdd(IPhysicalResource item)
        {
            base.OnPreAdd(item);

            if (this.configuration.UserMode)
            {
                // Check that the item belongs to this logical resource
                if (item.LogicalResource != this.parent)
                {
                    throw new ArgumentException("Physical resource does not belong to this logical resource!");
                }

                if (this.parent.PhysicalResources.Count() >= this.parent.ResourceType.MaxResourceInstances)
                {
                    throw new InvalidOperationException("You have reached the maximum resource instance count for this resource");
                }
            }
        }

        /// <summary>
        /// Called prior to removing an item
        /// </summary>
        protected override void OnPreRemove(IPhysicalResource item)
        {
            base.OnPreRemove(item);
            item.Components.Clear();
        }

        #endregion
    }
}
