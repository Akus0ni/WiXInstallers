#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Collections
{
    using System;
    using System.Linq;

    /// <summary>
    /// Collection of cluster objects owned by a particular parent
    /// </summary>
    public class PhysicalServerCollection : ClusterObjectCollection<IPhysicalServer>
    {
        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        public PhysicalServerCollection(ClusterConfiguration configuration)
            : base(configuration)
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Create a new item
        /// </summary>
        public IPhysicalServer CreateNew()
        {
            IPhysicalServer result = new PhysicalServer(this.configuration);
            this.Add(result);

            return result;
        }

        /// <summary>
        /// Gets the LogicalResource with the specified internalname
        /// </summary>
        public IPhysicalServer GetByServerName(string serverName)
        {
            return this.FirstOrDefault(server => server.ServerName.Equals(serverName, StringComparison.InvariantCultureIgnoreCase));
        }

        /// <summary>
        /// Indicates if a LogicalResource with the specified unique key exists
        /// </summary>
        public bool ExistsByServerName(string serverName)
        {
            return this.Any(server => server.ServerName.Equals(serverName, StringComparison.InvariantCultureIgnoreCase));
        }

        /// <summary>
        /// Called prior to removing an item
        /// </summary>
        protected override void OnPreRemove(IPhysicalServer item)
        {
            base.OnPreRemove(item);

            foreach (IPhysicalResourceComponent comp in item.Configuration.PhysicalResourceComponents.Where(prc => prc.Server.Id == item.Id))
            {
                comp.PhysicalResource.Components.Remove(comp);
            }
        }
        #endregion
    }
}
