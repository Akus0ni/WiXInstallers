#region Copyright © Exony Limited. All rights reserved.

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

#endregion

namespace Exony.Database.ClusterConfiguration
{
    /// <summary>
    /// Interface for all logical resource entity type mapping implementations
    /// </summary>
    public interface ILogicalResourceEntityTypeMapping : IClusterObject
    {
        /// <summary>
        /// The logical resource for this mapping
        /// </summary>
        ILogicalResource LogicalResource { get; }

        /// <summary>
        /// The source logical resource for this mapping
        /// </summary>
        ILogicalResource SourceLogicalResource { get; }

        /// <summary>
        /// The entity type for this mapping
        /// </summary>
        string EntityTypeInternalName { get; }

        /// <summary>
        /// Indicates whether import of items of specific entity type from the logical resource is enabled or not
        /// </summary>
        bool ImportEnabled { get; set; }

        /// <summary>
        /// Indicates whether provisioning of items of specific entity type to the logical resource is enabled or not
        /// </summary>
        bool ProvisioningEnabled { get; set; }

        /// <summary>
        /// Should this item type be loaded into the cache on this cluster resource?
        /// </summary>
        bool CacheEnabled { get; set; }
    }
}
