#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using Exony.Database.Common.DataObjects.Resources;

    public interface ILogicalResourceFolderItemMapping : IClusterObject
    {
        /// <summary>
        /// The id of the logical resource folder mapping for this folder item mapping resource
        /// </summary>
        Guid ResourceFolderMappingId { get; }

        /// <summary>
        /// Indicates identity of mapped item
        /// </summary>
        int ItemBizUrn { get; }

        /// <summary>
        /// Indicates type of mapped item
        /// </summary>
        int ItemTypeUrn { get; }

        /// <summary>
        /// Indicates priority of this mapping
        /// </summary>
        int Priority { get; set; }

        ResourceKey Item { get; }

        ILogicalResourceFolderMapping LogicalResourceFolderMapping { get; }
    }
}
