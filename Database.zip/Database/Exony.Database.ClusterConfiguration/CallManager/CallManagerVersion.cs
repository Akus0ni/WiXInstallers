#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.CallManager
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Supported CallManager versions
    /// </summary>
    public class CallManagerVersion
    {
        #region Fields

        /// <summary>
        /// Display name for the callmanager version
        /// </summary>
        private readonly string displayName;

        /// <summary>
        /// Folder name for the callmanager version
        /// </summary>
        private readonly string folderName;

        /// <summary>
        /// Version number
        /// </summary>
        private readonly double version;

        /// <summary>
        /// The axl version to use in the header
        /// </summary>
        private readonly double axlVersion;

        /// <summary>
        /// All configured versions
        /// </summary>
        private static readonly IDictionary<string, CallManagerVersion> allVersionsByDisplayName = new Dictionary<string, CallManagerVersion>();

        #endregion

        #region Static Instances

        public static CallManagerVersion VERSION_5X = new CallManagerVersion("5.x", "Version5", 5.0, 5.0);
        public static CallManagerVersion VERSION_6X = new CallManagerVersion("6.0.x", "Version6", 6.0, 1.0);
        public static CallManagerVersion VERSION_61X = new CallManagerVersion("6.1.x", "Version61", 6.1, 6.1);
        public static CallManagerVersion VERSION_7X = new CallManagerVersion("7.x", "Version7", 7.0, 7.0);
        public static CallManagerVersion VERSION_8X = new CallManagerVersion("8.0.x", "Version8", 8.0, 8.0);
        public static CallManagerVersion VERSION_85X = new CallManagerVersion("8.5.x", "Version85", 8.5, 8.0);
        public static CallManagerVersion VERSION_9X = new CallManagerVersion("9.0.x", "Version9", 9.0, 9.0);
        public static CallManagerVersion VERSION_10X = new CallManagerVersion("10.0.x", "Version10", 10.0, 10.0);
        public static CallManagerVersion VERSION_105X = new CallManagerVersion("10.5.x", "Version105", 10.5, 10.5);
        public static CallManagerVersion VERSION_11X = new CallManagerVersion("11.0.x", "Version11", 11.0, 11.0);
        public static CallManagerVersion VERSION_115X = new CallManagerVersion("11.5.x", "Version115", 11.5, 11.5);
        public static CallManagerVersion VERSION_12X = new CallManagerVersion("12.0.x", "Version12", 12.0, 12.0);
        public static CallManagerVersion VERSION_125X = new CallManagerVersion("12.5.x", "Version125", 12.5, 12.5);
        public static CallManagerVersion VERSION_14X = new CallManagerVersion("14.0.x", "Version14", 14.0, 14.0);
        public static CallManagerVersion VERSION_15X = new CallManagerVersion("15.0.x", "Version15", 15.0, 15.0);

        #endregion

        #region Construction

        /// <summary>
        /// Default constructor
        /// </summary>
        private CallManagerVersion(string displayName, string folderName, double version, double axlVersion)
        {
            this.displayName = displayName;
            this.folderName = folderName;
            this.version = version;
            this.axlVersion = axlVersion;

            allVersionsByDisplayName.Add(displayName, this);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Display name for the callmanager version
        /// </summary>
        public string DisplayName
        {
            get
            {
                return this.displayName;
            }
        }

        /// <summary>
        /// Folder name for the callmanager version
        /// </summary>
        public string FolderName
        {
            get
            {
                return this.folderName;
            }
        }

        /// <summary>
        /// Version number
        /// </summary>
        public double Version
        {
            get
            {
                return this.version;
            }
        }

        /// <summary>
        /// AXL version number
        /// </summary>
        public double AxlVersion
        {
            get
            {
                return this.axlVersion;
            }
        }

        /// <summary>
        /// All configured versions
        /// </summary>
        public static IList<CallManagerVersion> AllVersions
        {
            get { return new List<CallManagerVersion>(allVersionsByDisplayName.Values); }
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Gets a CallManagerVersion based on the displayName
        /// </summary>
        public static CallManagerVersion Parse(string version)
        {
            if (allVersionsByDisplayName.ContainsKey(version))
            {
                return allVersionsByDisplayName[version];
            }

            throw new ArgumentException("Specified callmanager version is invalid");
        }

        #endregion

        #region Operators

        public static bool operator >(CallManagerVersion x, CallManagerVersion y)
        {
            return x.Version > y.Version;
        }

        public static bool operator <(CallManagerVersion x, CallManagerVersion y)
        {
            return x.Version < y.Version;
        }

        public static bool operator <=(CallManagerVersion x, CallManagerVersion y)
        {
            return x.Version <= y.Version;
        }

        public static bool operator >=(CallManagerVersion x, CallManagerVersion y)
        {
            return x.Version >= y.Version;
        }

        #endregion
    }
}
