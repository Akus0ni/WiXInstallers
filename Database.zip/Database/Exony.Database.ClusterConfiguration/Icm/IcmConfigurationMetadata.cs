#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Icm
{
    using System;
    using System.Xml;

    public class IcmConfigurationMetadata
    {
        /// <summary>
        /// Private constructor
        /// </summary>
        private IcmConfigurationMetadata()
        {
            this.Name = string.Empty;
            this.ChecksumSupported = true;
            this.Imported = true;
        }

        /// <summary>
        /// The import version for this dimension
        /// </summary>
        public string ImportVersion { get; private set; }

        /// <summary>
        /// Is the item name
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Is the item imported
        /// </summary>
        public bool Imported { get; private set; }

        /// <summary>
        /// Is the import custom
        /// </summary>
        public bool CustomImport { get; private set; }

        /// <summary>
        /// Is checksum calculation supported for this import
        /// </summary>
        public bool ChecksumSupported { get; private set; }

        /// <summary>
        /// Load an instance from Xml
        /// </summary>
        public static IcmConfigurationMetadata LoadFromXml(XmlElement element, string defaultImportVersion)
        {
            IcmConfigurationMetadata meta = new IcmConfigurationMetadata();

            meta.Name = element.GetAttribute("Name");

            if (element.HasAttribute("Imported"))
            {
                meta.Imported = Boolean.Parse(element.GetAttribute("Imported"));
            }

            if (element.HasAttribute("CustomImport"))
            {
                meta.CustomImport = Boolean.Parse(element.GetAttribute("CustomImport"));
            }

            if (element.HasAttribute("ChecksumSupported"))
            {
                meta.ChecksumSupported = Boolean.Parse(element.GetAttribute("ChecksumSupported"));
            }

            meta.ImportVersion = element.HasAttribute("ImportVersion") ?
                element.GetAttribute("ImportVersion") : defaultImportVersion;

            return meta;
        }
    }
}
