#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Icm
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Represents a particular version of ICM
    /// </summary>
    [Serializable]
    public class IcmVersion : IComparable<IcmVersion>
    {
        #region Fields

        /// <summary>
        /// The major version component
        /// </summary>
        private readonly int majorVersion;

        /// <summary>
        /// The minor version component
        /// </summary>
        private readonly int minorVersion;

        /// <summary>
        /// The build number component
        /// </summary>
        private readonly int buildNumber;

        /// <summary>
        /// The human-readable name of the version.
        /// </summary>
        private readonly string versionName;

        /// <summary>
        /// Private list of the versions available.
        /// </summary>
        private static readonly List<IcmVersion> versionList = new List<IcmVersion>();

        #endregion

        #region Construction/Disposal

        /// <summary>
        /// Initialise a <code>IcmVersion</code> with the specified major/minor version and build number
        /// </summary>
        public IcmVersion(int majorVersion, int minorVersion, int buildNumber, string versionName)
        {
            this.majorVersion = majorVersion;
            this.minorVersion = minorVersion;
            this.buildNumber = buildNumber;
            this.versionName = versionName;
            versionList.Add(this);
        }

        /// <summary>
        /// Initialise a <code>IcmVersion</code> with the specified major/minor version
        /// </summary>
        public IcmVersion(int majorVersion, int minorVersion, string versionName)
            : this(majorVersion, minorVersion, 0, versionName)
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// The human-readable name of the version.
        /// </summary>
        public string VersionName
        {
            get
            {
                return this.versionName;
            }
        }

        /// <summary>
        /// The major version component
        /// </summary>
        public int MajorVersion
        {
            get
            {
                return majorVersion;
            }
        }

        /// <summary>
        /// The minor version component
        /// </summary>
        public int MinorVersion
        {
            get
            {
                return minorVersion;
            }
        }

        /// <summary>
        /// The build number component
        /// </summary>
        public int BuildNumber
        {
            get
            {
                return buildNumber;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Compare this version with the specified one
        /// </summary>
        public virtual int CompareTo(IcmVersion other)
        {
            // Use base class to check for nullptr
            if ((object)other != null)
            {
                if (other.majorVersion > this.majorVersion)
                {
                    return -1;
                }

                if (other.majorVersion < this.majorVersion)
                {
                    return 1;
                }

                // Same major version
                if (other.minorVersion > this.minorVersion)
                {
                    return -1;
                }

                if (other.minorVersion < this.minorVersion)
                {
                    return 1;
                }

                // Same minor version
                if (other.buildNumber > this.buildNumber)
                {
                    return -1;
                }

                if (other.buildNumber < this.buildNumber)
                {
                    return 1;
                }

                // Same build number
                return 0;
            }

            return -1;
        }

        /// <summary>
        /// Converts this to a system version object
        /// </summary>
        public Version ToVersion()
        {
            return new Version(this.MajorVersion, this.MinorVersion);
        }

        /// <summary>
        /// Display this version as a string
        /// </summary>
        public override string ToString()
        {
            return this.buildNumber > 0
                       ? string.Format("{0}.{1}.{2}", this.majorVersion, this.minorVersion, this.buildNumber)
                       : string.Format("{0}.{1}", this.majorVersion, this.minorVersion);
        }

        /// <summary>
        /// Determine if this object is equal to the specified object
        /// </summary>
        public override bool Equals(object other)
        {
            IcmVersion otherVersion = other as IcmVersion;
            return otherVersion != null && this.CompareTo(otherVersion) == 0;
        }

        /// <summary>
        /// Generate a unique hashcode for this object
        /// </summary>
        public override int GetHashCode()
        {
            return this.majorVersion ^ this.minorVersion ^ this.buildNumber;
        }

        /// <summary>
        /// Parse the specified string into a IcmVersion
        /// </summary>
        public static IcmVersion Parse(string version, bool tryParse = false)
        {
            if (version == null)
            {
                if (!tryParse)
                {
                    throw new ArgumentNullException("version");
                }

                return UNKNOWN;
            }

            string[] parts = version.Split('.');

            // Must be at least major/minor
            if (parts.Length < 2)
            {
                if (!tryParse)
                {
                    throw new ArgumentException(string.Format(@"Invalid version string: ""{0}""", version), "version");
                }

                return UNKNOWN;
            }

            int major;
            int minor;
            int build = 0;

            try
            {
                major = Int32.Parse(parts[0]);
            }
            catch (Exception)
            {
                if (!tryParse)
                {
                    throw new ArgumentException(string.Format(@"Invalid version string: ""{0}""", version), "version");
                }

                return UNKNOWN;
            }

            try
            {
                minor = Int32.Parse(parts[1]);
            }
            catch (Exception)
            {
                if (!tryParse)
                {
                    throw new ArgumentException(string.Format(@"Invalid version string: ""{0}""", version), "version");
                }

                return UNKNOWN;
            }

            if (parts.Length > 2)
            {
                try
                {
                    build = Int32.Parse(parts[2]);
                }
                catch (Exception)
                {
                    if (!tryParse)
                    {
                        throw new ArgumentException(string.Format(@"Invalid version string: ""{0}""", version), "version");
                    }

                    return UNKNOWN;
                }
            }

            IcmVersion foundVersion = versionList.ToList().FirstOrDefault(val => val.MajorVersion == major && val.MinorVersion == minor && val.BuildNumber == build);

            return foundVersion ?? new IcmVersion(major, minor, build, version);
        }

        #endregion

        #region Operators

        public static bool operator >(IcmVersion x, IcmVersion y)
        {
            if ((object)x == null)
            {
                return (object)y != null;
            }

            return x.CompareTo(y) > 0;
        }

        public static bool operator <(IcmVersion x, IcmVersion y)
        {
            if ((object)x == null)
            {
                return false;
            }

            return x.CompareTo(y) < 0;
        }

        public static bool operator <=(IcmVersion x, IcmVersion y)
        {
            if ((object)x == null)
            {
                return false;
            }

            return x.CompareTo(y) <= 0;
        }

        public static bool operator >=(IcmVersion x, IcmVersion y)
        {
            if ((object)x == null)
            {
                return true;
            }

            return x.CompareTo(y) >= 0;
        }

        public static bool operator ==(IcmVersion x, IcmVersion y)
        {
            if ((object)x != null)
            {
                return x.CompareTo(y) == 0;
            }

            return (object)y == null;
        }

        public static bool operator !=(IcmVersion x, IcmVersion y)
        {
            return !(x == y);
        }

        #endregion

        #region Static Instances

        public static IcmVersion UNKNOWN = new IcmVersion(0, 0, "Unknown");

        public static IcmVersion VERSION_5_0 = new IcmVersion(75, 1, 0, "5.0");

        public static IcmVersion VERSION_6_0 = new IcmVersion(84, 0, 0, "6.0");

        public static IcmVersion VERSION_6_0_2 = new IcmVersion(84, 3, 0, "6.0.2");

        public static IcmVersion VERSION_7_0 = new IcmVersion(93, 0, 0, "7.0");

        public static IcmVersion VERSION_7_1 = new IcmVersion(96, 0, 0, "7.1");

        public static IcmVersion VERSION_7_2 = new IcmVersion(97, 0, 0, "7.2");

        public static IcmVersion VERSION_7_5_BETA = new IcmVersion(111, 0, 0, "7.5 Beta");

        public static IcmVersion VERSION_7_5 = new IcmVersion(111, 4, 0, "7.5");

        public static IcmVersion VERSION_8_0_0 = new IcmVersion(122, 0, 0, "8.0");

        public static IcmVersion VERSION_8_0_1d5 = new IcmVersion(124, 0, 0, "8.0.1d5");

        public static IcmVersion VERSION_8_0_1d6 = new IcmVersion(124, 2, 0, "8.0.1d6");

        public static IcmVersion VERSION_8_0_1rc3 = new IcmVersion(127, 0, 0, "8.0.1rc3");

        public static IcmVersion VERSION_9_0 = new IcmVersion(162, 2, 0, "9.0");

        public static IcmVersion VERSION_10_0bld1157 = new IcmVersion(175, 0, 0, "10.0 (Build 1157)");

        public static IcmVersion VERSION_10_0bld1535 = new IcmVersion(175, 2, 0, "10.0 (Build 1535)");

        public static IcmVersion VERSION_10_5 = new IcmVersion(175, 3, 0, "10.5");

        public static IcmVersion VERSION_11_0bld03041 = new IcmVersion(181, 3, 0, "11.0 (Build 3041)");

        public static IcmVersion VERSION_11_5bld06538 = new IcmVersion(187, 0, 0, "11.5 (Build 6538)");

        public static IcmVersion VERSION_11_5bld03297 = new IcmVersion(188, 0, 0, "11.5 (Build 3297)");

        public static IcmVersion VERSION_12_0bld00274 = new IcmVersion(202, 0, 0, "12.0 (Build 296)");

        public static IcmVersion VERSION_12_6 = new IcmVersion(231, 0, 0, "12.6");

        //Upgraded version of 12.6 from 231 to 232
        public static IcmVersion VERSION_12_6bld881 = new IcmVersion(232, 0, 0, "12.6 (Build 881)");

        #endregion
    }
}
