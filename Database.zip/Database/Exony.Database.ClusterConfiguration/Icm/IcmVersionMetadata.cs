#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Icm
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;
    using System.Xml;
    using System.Xml.XPath;

    public class IcmVersionMetadata
    {
        #region Fields

        /// <summary>
        /// Name of the configuration file
        /// </summary>
        private const string CONFIGURATION_FILE_NAME = "IcmConfiguration.xml";

        /// <summary>
        /// The display name for the current version
        /// </summary>
        private string displayName = string.Empty;

        /// <summary>
        /// The database version
        /// </summary>
        private IcmVersion dbVersion;

        /// <summary>
        /// The import version
        /// </summary>
        private string importVersion = string.Empty;

        /// <summary>
        /// Is provisioning enabled on this version
        /// </summary>
        private bool provisionable = true;

        /// <summary>
        /// Is script support enabled on this version
        /// </summary>
        private bool scriptSupport;

        /// <summary>
        /// Is this version enabled
        /// </summary>
        private bool enabled = true;

        /// <summary>
        /// Is checksum calculation supported
        /// </summary>
        private bool calculateChecksum = true;

        /// <summary>
        /// Is tidemarking supported by this version?
        /// </summary>
        private bool tidemarkSupport;

        /// <summary>
        /// Supported configuration imports
        /// </summary>
        private IDictionary<string, IcmConfigurationMetadata> configurations = new Dictionary<string, IcmConfigurationMetadata>();

        /// <summary>
        /// Supported dimensions
        /// </summary>
        private IDictionary<string, IcmDimensionMetadata> dimensions = new Dictionary<string, IcmDimensionMetadata>();

        /// <summary>
        /// Supported members
        /// </summary>
        private IDictionary<string, IcmMemberMetadata> members = new Dictionary<string, IcmMemberMetadata>();

        /// <summary>
        /// Meta data stored by version
        /// </summary>
        private static readonly IDictionary<IcmVersion, IcmVersionMetadata> MetaByVersion;

        #endregion

        #region Construction

        /// <summary>
        /// Static constructor
        /// </summary>
        static IcmVersionMetadata()
        {
            // Load default config
            MetaByVersion = LoadMetaDataFromFile();
        }

        /// <summary>
        /// Private constructor
        /// </summary>
        private IcmVersionMetadata()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// The display name for the current version
        /// </summary>
        public string DisplayName
        {
            get { return this.displayName; }
        }

        /// <summary>
        /// The database version
        /// </summary>
        public IcmVersion DbVersion
        {
            get { return this.dbVersion; }
        }

        /// <summary>
        /// The import version
        /// </summary>
        public string ImportVersion
        {
            get { return this.importVersion; }
        }

        /// <summary>
        /// Is provisioning enabled on this version
        /// </summary>
        public bool Provisionable
        {
            get { return this.provisionable; }
        }

        /// <summary>
        /// Is script support enabled on this version
        /// </summary>
        public bool ScriptSupport
        {
            get { return this.scriptSupport; }
        }

        /// <summary>
        /// Is this version enabled
        /// </summary>
        public bool Enabled
        {
            get { return this.enabled; }
        }

        /// <summary>
        /// Is checksum calculation supported
        /// </summary>
        public bool CalculateChecksum
        {
            get { return this.calculateChecksum; }
        }

        /// <summary>
        /// Is tidemarking supported on this version
        /// </summary>
        public bool TidemarkSupport
        {
            get { return this.tidemarkSupport; }
        }

        /// <summary>
        /// Supported configuration imports
        /// </summary>
        public IDictionary<string, IcmConfigurationMetadata> Configurations
        {
            get
            {
                return new Dictionary<string, IcmConfigurationMetadata>(this.configurations);
            }
        }

        /// <summary>
        /// Supported dimensions
        /// </summary>
        public IDictionary<string, IcmDimensionMetadata> Dimensions
        {
            get
            {
                return new Dictionary<string, IcmDimensionMetadata>(this.dimensions);
            }
        }

        /// <summary>
        /// Supported members
        /// </summary>
        public IDictionary<string, IcmMemberMetadata> Members
        {
            get
            {
                return new Dictionary<string, IcmMemberMetadata>(this.members);
            }
        }

        #endregion

        #region Static Methods

        /// <summary>
        /// Load supported version metadata from disk
        /// </summary>
        private static IDictionary<IcmVersion, IcmVersionMetadata> LoadMetaDataFromFile()
        {
            // Build up the results
            IDictionary<IcmVersion, IcmVersionMetadata> results = new Dictionary<IcmVersion, IcmVersionMetadata>();

            string executingDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (executingDirectory == null)
            {
                throw new Exception("Could not find the executing directory.");
            }

            string configFolder = Path.Combine(executingDirectory, "Icm");

            // Get the config file path
            string fullPath = Path.Combine(configFolder, CONFIGURATION_FILE_NAME);

            // Load config data

            XmlDocument configDoc = new XmlDocument() { XmlResolver = null };
            XmlReaderSettings settings = new XmlReaderSettings() { DtdProcessing = DtdProcessing.Prohibit};
            configDoc.Load(XmlReader.Create(fullPath, settings));

            XmlElement rootElement = configDoc.DocumentElement;
            if (rootElement == null)
            {
                throw new Exception("Invalid xml data supplied");
            }

            // Load the versions
            XPathNavigator navigator = rootElement.CreateNavigator();

            // Sort them by DbVersion ascending so that previous version includes are loaded correctly
            XPathExpression selectExpression = navigator.Compile("Version");
            selectExpression.AddSort("@DbVersion", XmlSortOrder.Ascending, XmlCaseOrder.None, string.Empty, XmlDataType.Number);

            XPathNodeIterator nodeIterator = navigator.Select(selectExpression);

            while (nodeIterator.MoveNext())
            {
                XmlElement versionElement = ((IHasXmlNode)nodeIterator.Current).GetNode() as XmlElement;

                if(versionElement != null)
                { 
                    string dbVersion = versionElement.GetAttribute("DbVersion");
                    string displayName = versionElement.GetAttribute("DisplayName");
                    string importVersion = versionElement.GetAttribute("ImportVersion");

                    IcmVersion baseDbVersion = null;
                    if (versionElement.HasAttribute("BaseDbVersion"))
                    {
                        baseDbVersion = IcmVersion.Parse(versionElement.GetAttribute("BaseDbVersion"));
                    }

                    bool provisionable = true;
                    if (versionElement.HasAttribute("Provisionable"))
                    {
                        provisionable = Boolean.Parse(versionElement.GetAttribute("Provisionable"));
                    }

                    bool scriptSupport = true;
                    if (versionElement.HasAttribute("ScriptSupport"))
                    {
                        scriptSupport = Boolean.Parse(versionElement.GetAttribute("ScriptSupport"));
                    }

                    bool enabled = true;
                    if (versionElement.HasAttribute("Enabled"))
                    {
                        enabled = Boolean.Parse(versionElement.GetAttribute("Enabled"));
                    }

                    bool calculateChecksum = true;
                    if (versionElement.HasAttribute("CalculateChecksum"))
                    {
                        calculateChecksum = Boolean.Parse(versionElement.GetAttribute("CalculateChecksum"));
                    }

                    bool tidemarkSupport = false;
                    if (versionElement.HasAttribute("TidemarkSupport"))
                    {
                        tidemarkSupport = Boolean.Parse(versionElement.GetAttribute("TidemarkSupport"));
                    }

                    // Load configuration imports
                    Dictionary<string, IcmConfigurationMetadata> configurations;

                    // Are we based off a previous version of ICM
                    if (baseDbVersion != null)
                    {
                        if (results.ContainsKey(baseDbVersion))
                        {
                            // Clone the base settings
                            configurations = new Dictionary<string, IcmConfigurationMetadata>(results[baseDbVersion].Configurations);
                        }
                        else
                        {
                            throw new Exception("Specified base DB version is unknown!");
                        }
                    }
                    else
                    {
                        configurations = new Dictionary<string, IcmConfigurationMetadata>();
                    }

                    XmlNodeList configNodes = versionElement.SelectNodes("Configurations/Configuration");
                    if (configNodes == null)
                    {
                        throw new Exception("Invalid xml data supplied");
                    }

                    foreach (XmlElement currentConfigElement in configNodes)
                    {
                        IcmConfigurationMetadata meta = IcmConfigurationMetadata.LoadFromXml(currentConfigElement, importVersion);

                        // Overwrite base
                        configurations[meta.Name] = meta;
                    }

                    // Load dimensions
                    Dictionary<string, IcmDimensionMetadata> dimensions;

                    // Are we based off a previous version of ICM
                    if (baseDbVersion != null)
                    {
                        if (results.ContainsKey(baseDbVersion))
                        {
                            // Clone the base settings
                            dimensions = new Dictionary<string, IcmDimensionMetadata>(results[baseDbVersion].Dimensions);
                        }
                        else
                        {
                            throw new Exception("Specified base DB version is unknown!");
                        }
                    }
                    else
                    {
                        dimensions = new Dictionary<string, IcmDimensionMetadata>();
                    }

                    XmlNodeList dimensionNodes = versionElement.SelectNodes("Dimensions/Dimension");
                    if (dimensionNodes == null)
                    {
                        throw new Exception("Invalid xml data supplied");
                    }

                    foreach (XmlElement currentDimensionElement in dimensionNodes)
                    {
                        IcmDimensionMetadata meta = IcmDimensionMetadata.LoadFromXml(currentDimensionElement, importVersion);

                        // Overwrite base
                        dimensions[meta.Name] = meta;
                    }

                    // Load members
                    Dictionary<string, IcmMemberMetadata> members;

                    // Are we based off a previous version of ICM
                    if (baseDbVersion != null)
                    {
                        if (results.ContainsKey(baseDbVersion))
                        {
                            // Clone the base settings
                            members = new Dictionary<string, IcmMemberMetadata>(results[baseDbVersion].Members);
                        }
                        else
                        {
                            throw new Exception("Specified base DB version is unknown!");
                        }
                    }
                    else
                    {
                        members = new Dictionary<string, IcmMemberMetadata>();
                    }

                    XmlNodeList memberNodes = versionElement.SelectNodes("Members/Member");
                    if (memberNodes == null)
                    {
                        throw new Exception("Invalid xml data supplied");
                    }

                    foreach (XmlElement currentMemberElement in memberNodes)
                    {
                        IcmMemberMetadata meta = IcmMemberMetadata.LoadFromXml(currentMemberElement, importVersion);

                        // Overwrite includes
                        members[meta.Name] = meta;
                    }

                    IcmVersionMetadata versionMeta = new IcmVersionMetadata();
                    versionMeta.dbVersion = IcmVersion.Parse(dbVersion);
                    versionMeta.displayName = displayName;
                    versionMeta.importVersion = importVersion;
                    versionMeta.configurations = configurations;
                    versionMeta.dimensions = dimensions;
                    versionMeta.members = members;
                    versionMeta.enabled = enabled;
                    versionMeta.provisionable = provisionable;
                    versionMeta.calculateChecksum = calculateChecksum;
                    versionMeta.scriptSupport = scriptSupport;
                    versionMeta.tidemarkSupport = tidemarkSupport;

                    results.Add(versionMeta.dbVersion, versionMeta);
                }
            }

            return results;
        }

        /// <summary>
        /// Indicates if an entry for the specified version exists
        /// </summary>
        public static bool IsVersionSupported(IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Indicates if the specified version is enabled
        /// </summary>
        public static bool IsVersionEnabled(IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];
                return meta.enabled;
            }

            return false;
        }

        /// <summary>
        /// Indicates if the specified version is provisionable
        /// </summary>
        public static bool IsVersionProvisionable(IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];
                return meta.provisionable;
            }

            return false;
        }

        /// <summary>
        /// Get the import version number based on the icm db version - used for fact imports only
        /// </summary>
        public static string GetImportVersion(IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];
                return meta.importVersion;
            }

            throw new ArgumentException("Specified version is not supported");
        }

        /// <summary>
        /// Get the import version number for a configuration import based on the icm db version
        /// </summary>
        public static string GetConfigurationImportVersion(IcmVersion version, string configName)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.configurations.ContainsKey(configName))
                {
                    IcmConfigurationMetadata configMeta = meta.configurations[configName];
                    return configMeta.ImportVersion;
                }

                throw new ArgumentException("Specified dimension is not supported");
            }

            throw new ArgumentException("Specified version is not supported");
        }

        /// <summary>
        /// Get the import version number for a dimension based on the icm db version
        /// </summary>
        public static string GetDimensionImportVersion(IcmVersion version, string dimensionName)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.dimensions.ContainsKey(dimensionName))
                {
                    IcmDimensionMetadata dimMeta = meta.dimensions[dimensionName];
                    return dimMeta.ImportVersion;
                }

                throw new ArgumentException("Specified dimension is not supported");
            }

            throw new ArgumentException("Specified version is not supported");
        }

        /// <summary>
        /// Get the import version number for a member based on the icm db version
        /// </summary>
        public static string GetMemberImportVersion(IcmVersion version, string memberName)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.members.ContainsKey(memberName))
                {
                    IcmMemberMetadata memberMeta = meta.members[memberName];
                    return memberMeta.ImportVersion;
                }

                throw new ArgumentException("Specified member is not supported");
            }

            throw new ArgumentException("Specified version is not supported");
        }

        /// <summary>
        /// Is the specified configuration imported for the specified ICM version
        /// </summary>
        public static bool IsConfigurationImportSupported(string configName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.configurations.ContainsKey(configName))
                {
                    IcmConfigurationMetadata dimMeta = meta.configurations[configName];
                    return dimMeta.Imported;
                }
            }

            return false;
        }

        /// <summary>
        /// Is the specified dimension imported for the specified ICM version
        /// </summary>
        public static bool IsDimensionImportSupported(string dimensionName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.dimensions.ContainsKey(dimensionName))
                {
                    IcmDimensionMetadata dimMeta = meta.dimensions[dimensionName];
                    return dimMeta.Imported;
                }
            }

            return false;
        }

        /// <summary>
        /// Is the specified member imported for the specified ICM version
        /// </summary>
        public static bool IsMemberImportSupported(string memberName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.members.ContainsKey(memberName))
                {
                    IcmMemberMetadata memberMeta = meta.members[memberName];
                    return memberMeta.Imported;
                }
            }

            return false;
        }

        /// <summary>
        /// Is the specified dimension import a custom microflow
        /// </summary>
        public static bool IsDimensionImportCustom(string dimensionName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.dimensions.ContainsKey(dimensionName))
                {
                    IcmDimensionMetadata dimMeta = meta.dimensions[dimensionName];
                    return dimMeta.CustomImport;
                }
            }

            return false;
        }

        /// <summary>
        /// Is the specified configuration import custom?
        /// </summary>
        public static bool IsConfigurationImportCustom(string configName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.configurations.ContainsKey(configName))
                {
                    IcmConfigurationMetadata memberMeta = meta.configurations[configName];
                    return memberMeta.CustomImport;
                }
            }

            return false;
        }

        /// <summary>
        /// Is tidemarking supported on the specified ICM version
        /// </summary>
        public static bool IsTidemarkingSupported(IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];
                return meta.TidemarkSupport;
            }

            return false;
        }

        /// <summary>
        /// Is tidemarking supported for the specified dimension on the specified ICM version
        /// </summary>
        public static bool IsDimensionTidemarkingSupported(string dimensionName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.dimensions.ContainsKey(dimensionName))
                {
                    IcmDimensionMetadata dimMeta = meta.dimensions[dimensionName];
                    return dimMeta.TidemarkSupport && meta.TidemarkSupport;
                }
            }

            return false;
        }

        /// <summary>
        /// Is tidemarking supported for the specified member on the specified ICM version
        /// </summary>
        public static bool IsMemberTidemarkingSupported(string memberName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.members.ContainsKey(memberName))
                {
                    IcmMemberMetadata memMeta = meta.members[memberName];
                    return memMeta.TidemarkSupport && meta.TidemarkSupport;
                }
            }

            return false;
        }

        /// <summary>
        /// Is checksum calculation supported for the specified dimension on the specified ICM version
        /// </summary>
        public static bool IsDimensionChecksumSupported(string dimensionName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.dimensions.ContainsKey(dimensionName))
                {
                    IcmDimensionMetadata dimMeta = meta.dimensions[dimensionName];
                    return dimMeta.ChecksumSupported;
                }
            }

            return false;
        }

        /// <summary>
        /// Is the specified member provisioning for the specified ICM version
        /// </summary>
        public static bool IsMemberImportCustom(string memberName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.members.ContainsKey(memberName))
                {
                    IcmMemberMetadata memberMeta = meta.members[memberName];
                    return memberMeta.CustomImport;
                }
            }

            return false;
        }

        /// <summary>
        /// Is checksum calculation supported for the specified member on the specified ICM version
        /// </summary>
        public static bool IsMemberChecksumSupported(string memberName, IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                if (meta.members.ContainsKey(memberName))
                {
                    IcmMemberMetadata memberMeta = meta.members[memberName];
                    return memberMeta.ChecksumSupported;
                }
            }

            return false;
        }

        /// <summary>
        /// Indicates if the specified version of ICM supports checksum calculation
        /// </summary>
        public static bool IsChecksumCalculationSupported(IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                return meta.calculateChecksum;
            }

            return false;
        }

        /// <summary>
        /// Get the version meta data for the specified version
        /// </summary>
        public static IcmVersionMetadata GetVersionMetadata(IcmVersion version)
        {
            if (MetaByVersion.ContainsKey(version))
            {
                IcmVersionMetadata meta = MetaByVersion[version];

                return meta;
            }

            throw new ArgumentException("Unsupported version");
        }

        #endregion
    }
}
