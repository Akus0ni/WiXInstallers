#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;

    using Exony.Database.Common.Folders;

    public enum LogicalResourceFolderMappingType
    {
        ImportRule = 'I'
    }

    /// <summary>
    /// Interface for all logical resource folder mapping implementations
    /// </summary>
    public interface ILogicalResourceFolderMapping : IClusterObject
    {
        /// <summary>
        /// The id of the logical resource for this physical resource
        /// </summary>
        Guid ResourceId { get; }

        /// <summary>
        /// The type of logical resource folder mapping
        /// </summary>
        char Type { get; }

        /// <summary>
        /// Inicates the tenant or folder this mapping relates to
        /// </summary>
        Guid FolderId { get; }

        /// <summary>
        /// The logical resource for this mapping
        /// </summary>
        ILogicalResource LogicalResource { get; }

        /// <summary>
        /// The folder item mappings
        /// </summary>
        LogicalResourceFolderItemMappingCollection ResourceFolderItemMappings { get; }

        [ClusterConfigVisibility(ClusterConfigVisibility.Hidden)]
        [ClusterField(Transient = true)]
        Folder Folder { get; }
    }
}
