﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Xml;
    using System.Xml.XPath;

    public class EgainVersionMapping
    {
        #region Static Fields

        /// <summary>
        /// The version map list
        /// </summary>
        private static readonly List<VersionMap> VersionMapList;

        #endregion

        #region Constructors and Destructors

        /// <summary>
        /// Static constructor
        /// </summary>
        static EgainVersionMapping()
        {
            // Load default config
            VersionMapList = LoadMetaDataFromFile();
        }

        /// <summary>
        /// Private constructor
        /// </summary>
        private EgainVersionMapping()
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets the Base version based on the Enterprise Chat & Email version.
        /// </summary>
        /// <param name="eceVersion">The Enterprise Chat & Email version.</param>
        public static string GetBaseVersion(string eceVersion)
        {
            Version baseVersion = Version.Parse("0.0.0");
            Version parsedEceVersion = Version.Parse(eceVersion);

            foreach (VersionMap versionMap in VersionMapList)
            {
                Version currentEceVersion = versionMap.Ece;
                int eceVersionCompareResult = parsedEceVersion.Build > 0
                    ? parsedEceVersion.CompareTo(currentEceVersion)
                    : (currentEceVersion.Build > 0
                        ? Version.Parse($"{parsedEceVersion.Major}.{parsedEceVersion.Minor}.0").CompareTo(currentEceVersion)
                        : Version.Parse($"{parsedEceVersion.Major}.{parsedEceVersion.Minor}").CompareTo(currentEceVersion));

                if (eceVersionCompareResult == 0)
                {
                    // Found exact ECE version map, exit early from loop
                    baseVersion = versionMap.Base;
                    break;
                }

                // Passed in ECE version is lower than current found ECE version if eceVersionCompareResult < 0
                // which we'll ignore
                if (eceVersionCompareResult > 0)
                {
                    // Passed in ECE version is higher than current found ECE version
                    Version currentBaseVersion = versionMap.Base;
                    int baseVersionCompareResult = currentBaseVersion.CompareTo(baseVersion);

                    if (baseVersionCompareResult < 0)
                    {
                        baseVersion = currentBaseVersion;
                    }
                }
            }

            // The ECE version may be higher than any that we currently have mappings for, so we need to pick the very highest
            // eGain version
            if (baseVersion == Version.Parse("0.0.0"))
            {
                // Get the ECE Version parts
                List<int> eceVersionArray = eceVersion.Split('.').Select(versionPart => Convert.ToInt32(versionPart)).ToList();
                int eceVersionArraySize = eceVersionArray.Count;

                foreach (VersionMap versionMap in VersionMapList)
                {
                    string metaEceVersion =
                        $"{(versionMap.Ece.Major < 0 ? 0 : versionMap.Ece.Major)}.{(versionMap.Ece.Minor < 0 ? 0 : versionMap.Ece.Minor)}.{(versionMap.Ece.Build < 0 ? 0 : versionMap.Ece.Build)}";
                    List<int> metaEceVersionArray = metaEceVersion.Split('.').Select(versionPart => Convert.ToInt32(versionPart)).ToList();
                    int metaEceVersionArraySize = metaEceVersionArray.Count;
                    int biggestCount = metaEceVersionArraySize >= eceVersionArraySize ? metaEceVersionArraySize : eceVersionArraySize;

                    for (int pos = 0; pos < biggestCount; pos++)
                    {
                        int currentPassedInChar = eceVersionArraySize >= pos ? eceVersionArray[pos] : 0;
                        int currentMapChar = metaEceVersionArraySize >= pos ? metaEceVersionArray[pos] : 0;
                        if (currentPassedInChar > currentMapChar)
                        {
                            baseVersion = versionMap.Base;
                            break;
                        }

                        if (currentPassedInChar < currentMapChar)
                        {
                            break;
                        }
                    }
                }
            }

            // The ECE version is lower than any that we have mappings for, so is unsupported
            if (baseVersion == Version.Parse("0.0.0"))
            {
                throw new ArgumentException($"Enterprise Chat & Email version {eceVersion} is not supported");
            }

            return $"{baseVersion.Major}.{baseVersion.Minor}.{baseVersion.Build}";
        }

        /// <summary>
        /// Determines whether [version map is correct].
        /// </summary>
        /// <param name="baseVersion">The Base version.</param>
        /// <param name="eceVersion">The Enterprise Chat & Email version.</param>
        public static bool IsVersionMapCorrect(string baseVersion, string eceVersion)
        {
            if (Version.Parse(baseVersion).CompareTo(Version.Parse(GetBaseVersion(eceVersion))) == 0)
            {
                // Versions passed in are exactly the same as expected (e.g. 11.6 rather than 11.6.0)
                return true;
            }

            List<int> baseVersionArray = baseVersion.Split('.').Select(versionPart => Convert.ToInt32(versionPart)).ToList();
            List<int> expectedBaseVersionArray = GetBaseVersion(eceVersion).Split('.').Select(versionPart => Convert.ToInt32(versionPart)).ToList();
            int baseVersionArrayParts = baseVersionArray.Count;
            int expectedBaseVersionParts = expectedBaseVersionArray.Count;
            int biggestCount = baseVersionArrayParts >= expectedBaseVersionParts ? baseVersionArrayParts : expectedBaseVersionParts;

            for (int pos = 0; pos < biggestCount; pos++)
            {
                int currentPassedInChar = baseVersionArrayParts >= pos ? baseVersionArray[pos] : 0;
                int currentExpectedChar = expectedBaseVersionParts >= pos ? expectedBaseVersionArray[pos] : 0;
                if (currentPassedInChar != currentExpectedChar)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Loads the meta data from file.
        /// </summary>
        private static List<VersionMap> LoadMetaDataFromFile()
        {
            List<VersionMap> versionMapList = new List<VersionMap>();
            string location = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (string.IsNullOrWhiteSpace(location))
            {
                throw new Exception("Unable to find configuration file");
            }

            string filePath = Path.Combine(location, "eGainConfiguration.xml");
            XmlDocument configDoc = new XmlDocument();
            configDoc.Load(filePath);
            XmlElement rootElement = configDoc.DocumentElement;
            if (rootElement == null)
            {
                throw new Exception("Unable to parse configuration file");
            }

            XPathNavigator navigator = rootElement.CreateNavigator();
            XPathExpression selectExpression = navigator.Compile("Version");
            selectExpression.AddSort("@Ece", XmlSortOrder.Ascending, XmlCaseOrder.None, string.Empty, XmlDataType.Number);
            XPathNodeIterator nodeIterator = navigator.Select(selectExpression);

            while (nodeIterator.MoveNext())
            {
                XmlElement versionElement = ((IHasXmlNode)nodeIterator.Current).GetNode() as XmlElement;

                if (versionElement != null)
                {
                    string eceVersion = versionElement.GetAttribute("Ece");
                    string baseVersion = versionElement.GetAttribute("Base");

                    VersionMap currentNodeVersionMap = new VersionMap { Ece = Version.Parse(eceVersion), Base = Version.Parse(baseVersion) };
                    versionMapList.Add(currentNodeVersionMap);
                }
            }

            return versionMapList;
        }

        #endregion

        /// <summary>
        /// A structure representing the version mapping of "Enterprise Chat & Email" and "Base eGain" products.
        /// </summary>
        private struct VersionMap
        {
            #region Public Properties

            /// <summary>
            /// Gets or sets the base version.
            /// </summary>
            /// <value>
            /// The base version.
            /// </value>
            public Version Base { get; set; }

            /// <summary>
            /// Gets or sets the Enterprise Chat & Email version.
            /// </summary>
            /// <value>
            /// The Enterprise Chat & Email version.
            /// </value>
            public Version Ece { get; set; }

            #endregion
        }
    }
}