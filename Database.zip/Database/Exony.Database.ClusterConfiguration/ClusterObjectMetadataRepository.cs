﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Concurrent;
    using System.ComponentModel;
    using System.Linq;
    using System.Reflection;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Class for maintaining static metadata about cluster objects.
    /// </summary>
    internal static class ClusterObjectMetadataRepository
    {
        /// <summary>
        /// Mapping of metadata by type.
        /// </summary>
        private static IDictionary<Type, IClusterObjectMetadata> metadataByType 
            = new ConcurrentDictionary<Type, IClusterObjectMetadata>();

        /// <summary>
        /// Get the metadata for the specified type.
        /// </summary>
        public static IClusterObjectMetadata GetMetadata(Type dataType)
        {
            if (!metadataByType.ContainsKey(dataType))
            {
                InitialiseMetadata(dataType);
            }

            return metadataByType[dataType];
        }

        /// <summary>
        /// Initialise metadata for the specified type.
        /// </summary>
        private static void InitialiseMetadata(Type dataType)
        {
            List<IClusterFieldMetadata> allFieldMetadata = new List<IClusterFieldMetadata>();

            // Get all properties on type 
            IDictionary<PropertyInfo, Attribute[]> typeProperties = AttributeHelper.GetPropertyLevelAttributes(dataType);

            // First process non-secret properties
            foreach (KeyValuePair<PropertyInfo, Attribute[]> pair in typeProperties)
            {
                // Look for a Cluster Field Attribute
                ClusterFieldAttribute attribute = pair.Value.OfType<ClusterFieldAttribute>().FirstOrDefault();

                if (attribute == null || string.IsNullOrEmpty(attribute.FieldName))
                {
                    continue;
                }

                ClusterFieldMetadata fieldMetadata = new ClusterFieldMetadata();
                fieldMetadata.Encrypted = attribute.Encrypted;
                fieldMetadata.FieldName = attribute.FieldName;
                fieldMetadata.IgnoreOnCreate = attribute.IgnoreOnCreate;
                fieldMetadata.Secret = attribute.Secret;
                fieldMetadata.StorageType = attribute.StorageType;
                fieldMetadata.Transient = attribute.Transient;
                fieldMetadata.PropertyName = pair.Key.Name;
                fieldMetadata.DataType = pair.Key.PropertyType;
                fieldMetadata.SecretRegex = string.IsNullOrWhiteSpace(attribute.SecretRegex) 
                    ? null : new Regex(attribute.SecretRegex, RegexOptions.IgnoreCase);

                DefaultValueAttribute defaultValueAttribute = pair.Value.OfType<DefaultValueAttribute>().FirstOrDefault();
                if (defaultValueAttribute != null)
                {
                    fieldMetadata.HasDefaultValue = true;
                    fieldMetadata.DefaultValue = defaultValueAttribute.Value;
                }

                allFieldMetadata.Add(fieldMetadata);
            }

            ClusterObjectMetadata clusterObjectMetadata = new ClusterObjectMetadata(allFieldMetadata);

            metadataByType[dataType] = clusterObjectMetadata;
        }
    }
}
