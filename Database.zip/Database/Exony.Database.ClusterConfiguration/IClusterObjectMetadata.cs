﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

using System.Collections.Generic;

namespace Exony.Database.ClusterConfiguration
{
    /// <summary>
    /// Interface for all Cluster Object Metadata implementations.
    /// </summary>
    internal interface IClusterObjectMetadata
    {
        /// <summary>
        /// Retrieve the metadata for cluster fields on this object.
        /// </summary>
        IEnumerable<IClusterFieldMetadata> Fields { get; }

        /// <summary>
        /// Get field metadata by field name.
        /// </summary>
        IClusterFieldMetadata GetField(string fieldName);

        /// <summary>
        /// Flag indicating if this type has any data stored in secrets manager.
        /// </summary>
        bool HasSecrets { get; }
    }
}
