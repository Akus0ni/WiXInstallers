#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    public enum ClusterValidationSeverity
    {
        Warning,
        Error
    }

    public interface IClusterValidationResult
    {
        /// <summary>
        /// The severity associated with this result
        /// </summary>
        ClusterValidationSeverity Severity { get; }

        /// <summary>
        /// The object that reported the validation failure
        /// </summary>
        IClusterObject AffectedObject { get; }

        /// <summary>
        /// Details about the validation failure
        /// </summary>
        string Message { get; }
    }
}
