﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Text.RegularExpressions;

    internal class ClusterFieldMetadata : IClusterFieldMetadata
    {
        /// <summary>
        /// Name of the field.
        /// </summary>
        public string FieldName { get; set; }

        /// <summary>
        /// Name of the property.
        /// </summary>
        public string PropertyName { get; set; }

        /// <summary>
        /// Is the field encrypted?
        /// </summary>
        public bool Encrypted { get; set; }

        /// <summary>
        /// Ignores database operation for the attribute.
        /// </summary>
        public bool IgnoreOnCreate { get; set; }

        /// <summary>
        /// Indicates if this is a transient field - i.e. a field that is used to store transient state for a service
        /// Transient fields are handled differently when loading/saving the model dependentent on the model load type
        /// </summary>
        public bool Transient { get; set; }

        /// <summary>
        /// Where is the data stored?
        /// </summary>
        public ClusterFieldStorageType StorageType { get; set; }

        /// <summary>
        /// Is this field stored in secrets manager.
        /// </summary>
        public bool Secret { get; set; }

        /// <summary>
        /// Indicates if this type has a default value specified.
        /// </summary>
        public bool HasDefaultValue { get; set; }

        /// <summary>
        /// The deafult value (if specified).
        /// </summary>
        public object DefaultValue { get; set; }

        /// <summary>
        /// Data type of the field.
        /// </summary>
        public Type DataType { get; set; }

        /// <summary>
        /// Regular expression for determining if value should be 
        /// stored in remote secrets manager. Only used if Secret = true.
        /// </summary>
        public Regex SecretRegex { get; set; }

        /// <summary>
        /// Check if the specified field value should be treated as a secret.
        /// </summary>
        public bool TreatValueAsSecret(object value)
        {
            // Don't store null values in secrets manager
            if (value == null)
            {
                return false;
            }

            if (this.Secret)
            {
                string valueString = TypeConversion.ConvertType<string>(value);

                if (string.IsNullOrWhiteSpace(valueString))
                {
                    return false;
                }

                if (this.SecretRegex != null)
                {
                    return this.SecretRegex.IsMatch(valueString);
                }
 
                // Field marked as secret and needs to be stored externally
                return true;
            }

            return false;
        }
    }
}
