#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Reflection;
    using System.Threading;

    using Exony.ComponentModel;
    using Exony.Security.Encryption;

    /// <summary>
    /// Base class for all cluster objects
    /// </summary>
    public abstract class ClusterObject : IClusterObject, ICustomTypeDescriptor
    {
        #region Constants

        /// <summary>
        /// Macro representing the short product name
        /// </summary>
        public static readonly string SHORT_PRODUCT_NAME_MACRO = "%SHORT_PRODUCT_NAME%";

        #endregion

        #region Events

        /// <summary>
        /// Fired when a property is changed
        /// </summary>
        public event ClusterObjectPropertyChangedEventDelegate PropertyChanged;

        #endregion

        #region Fields

        /// <summary>
        /// Master configuration for this cluster object
        /// </summary>
        protected ClusterConfiguration configuration;

        /// <summary>
        /// Primary key id for this cluster object
        /// </summary>
        private readonly Guid id;

        /// <summary>
        /// Indicates if this cluster object is enabled
        /// </summary>
        protected bool enabled;

        /// <summary>
        /// Indicates if this cluster object is a system object
        /// </summary>
        private bool system;

        /// <summary>
        /// Field access lock for thread safe access to fields in this class
        /// </summary>
        protected ReaderWriterLock fieldAccessLock = new ReaderWriterLock();

        #endregion

        #region Construction

        /// <summary>
        /// Constructs a ClusterType with the specified master configuration
        /// </summary>
        protected ClusterObject(ClusterConfiguration configuration)
            : this(configuration, Guid.NewGuid())
        {
        }

        /// <summary>
        /// Constructs a ClusterType with the specified master configuration
        /// </summary>
        protected ClusterObject(ClusterConfiguration configuration, Guid id)
        {
            this.configuration = configuration;

            // Set default values
            this.id = id;
            this.enabled = true;
            this.system = false;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Primary key id for this cluster object
        /// </summary>
        [GlobalisedCategory("Exony.Database.ClusterConfiguration", "String_Category_General", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDisplayName("Exony.Database.ClusterConfiguration", "String_ClusterObject_Id_DisplayName", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDescription("Exony.Database.ClusterConfiguration", "String_ClusterObject_Id_Description", "Exony.Database.ClusterConfiguration.Resources")]
        [ClusterConfigVisibility(ClusterConfigVisibility.Advanced)]
        public virtual Guid Id
        {
            get
            {
                this.fieldAccessLock.AcquireReaderLock(Timeout.Infinite);

                try
                {
                    return this.id;
                }
                finally
                {
                    this.fieldAccessLock.ReleaseReaderLock();
                }
            }
        }

        /// <summary>
        /// Indicates if this cluster object is enabled
        /// </summary>
        [GlobalisedCategory("Exony.Database.ClusterConfiguration", "String_Category_General", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDisplayName("Exony.Database.ClusterConfiguration", "String_ClusterObject_Enabled_DisplayName", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDescription("Exony.Database.ClusterConfiguration", "String_ClusterObject_Enabled_Description", "Exony.Database.ClusterConfiguration.Resources")]
        [ClusterField(FieldName = "ENABLED")]
        [ClusterConfigVisibility(ClusterConfigVisibility.Basic | ClusterConfigVisibility.Advanced)]
        public virtual bool Enabled
        {
            get
            {
                this.fieldAccessLock.AcquireReaderLock(Timeout.Infinite);

                try
                {
                    return this.enabled;
                }
                finally
                {
                    this.fieldAccessLock.ReleaseReaderLock();
                }
            }

            set
            {
                object oldValue;

                this.fieldAccessLock.AcquireWriterLock(Timeout.Infinite);

                try
                {
                    oldValue = this.enabled;
                    this.enabled = value;
                }
                finally
                {
                    this.fieldAccessLock.ReleaseWriterLock();
                }

                FirePropertyChanged(MethodBase.GetCurrentMethod().PropertyName(), oldValue, value);
            }
        }

        /// <summary>
        /// Indicates if this cluster object is a system object
        /// </summary>
        [GlobalisedCategory("Exony.Database.ClusterConfiguration", "String_Category_General", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDisplayName("Exony.Database.ClusterConfiguration", "String_ClusterObject_System_DisplayName", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDescription("Exony.Database.ClusterConfiguration", "String_ClusterObject_System_Description", "Exony.Database.ClusterConfiguration.Resources")]
        [ClusterField(FieldName = "SYSTEM")]
        public virtual bool System
        {
            [ClusterConfigVisibility(ClusterConfigVisibility.Advanced)]
            get
            {
                this.fieldAccessLock.AcquireReaderLock(Timeout.Infinite);

                try
                {
                    return this.system;
                }
                finally
                {
                    this.fieldAccessLock.ReleaseReaderLock();
                }
            }

            [ClusterConfigVisibility(ClusterConfigVisibility.Hidden)]
            set
            {
                object oldValue;

                this.fieldAccessLock.AcquireWriterLock(Timeout.Infinite);

                try
                {
                    oldValue = this.system;
                    this.system = value;
                }
                finally
                {
                    this.fieldAccessLock.ReleaseWriterLock();
                }

                FirePropertyChanged(MethodBase.GetCurrentMethod().PropertyName(), oldValue, value);
            }
        }

        /// <summary>
        /// The master configuration for this cluster object
        /// </summary>
        [ClusterConfigVisibility(ClusterConfigVisibility.Hidden)]
        public ClusterConfiguration Configuration
        {
            get { return this.configuration; }
        }

        /// <summary>
        /// Get a display name for this object
        /// </summary>
        [ClusterConfigVisibility(ClusterConfigVisibility.Advanced)]
        [GlobalisedDisplayName("Exony.Database.ClusterConfiguration", "String_ClusterObject_DisplayName_DisplayName", "Exony.Database.ClusterConfiguration.Resources")]
        [GlobalisedDescription("Exony.Database.ClusterConfiguration", "String_ClusterObject_DisplayName_Description", "Exony.Database.ClusterConfiguration.Resources")]
        public virtual string DisplayName
        {
            get { return string.Empty; }
        }

        #endregion

        #region State

        /// <summary>
        /// Save this object's state
        /// </summary>
        public virtual IDictionary<string, object> SaveState()
        {
            Dictionary<string, object> result = new Dictionary<string, object>();

            // Load cluster fields
            IDictionary<PropertyInfo, ClusterFieldAttribute> clusterFieldInfo = AttributeHelper.GetPropertyLevelAttributes<ClusterFieldAttribute>(this);

            foreach (KeyValuePair<PropertyInfo, ClusterFieldAttribute> pair in clusterFieldInfo)
            {
                if (string.IsNullOrEmpty(pair.Value.FieldName))
                {
                    continue;
                }

                object value = pair.Key.GetValue(this, null);

                if (value != null && pair.Value.Encrypted)
                {
                    string stringVal = TypeConversion.ConvertType(value, typeof(string)) as string;
                    string encryptedString = ExonySymmetricCryptographer.EncryptUsingRotatingKey(stringVal);
                    value = encryptedString;
                }

                result.Add(pair.Value.FieldName, value);
            }

            return result;
        }

        /// <summary>
        /// Load this object's state
        /// </summary>
        public virtual void LoadState(IDictionary<string, object> state)
        {
            // Load cluster fields
            IDictionary<PropertyInfo, ClusterFieldAttribute> clusterFieldInfo = AttributeHelper.GetPropertyLevelAttributes<ClusterFieldAttribute>(this);

            foreach (KeyValuePair<PropertyInfo, ClusterFieldAttribute> pair in clusterFieldInfo)
            {
                if (string.IsNullOrEmpty(pair.Value.FieldName))
                {
                    continue;
                }

                object value = state[pair.Value.FieldName];

                if (value != null && pair.Value.Encrypted)
                {
                    string stringVal = TypeConversion.ConvertType(value, typeof(string)) as string;
                    string decryptedString = ExonySymmetricCryptographer.Decrypt(stringVal);
                    value = decryptedString;
                }

                value = TypeConversion.ConvertType(value, pair.Key.PropertyType);

                if (pair.Key.CanWrite)
                {
                    pair.Key.SetValue(this, value, null);
                }
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Set a field based on it's cluster field name (i.e. the FieldName defined on a ClusterFieldAttribute). Encrypted flag indicates if an encrypted value is being passed through.
        /// </summary>
        public void SetClusterField(string name, object value, bool encrypted)
        {
            IDictionary<PropertyInfo, ClusterFieldAttribute> clusterFieldInfo = AttributeHelper.GetPropertyLevelAttributes<ClusterFieldAttribute>(this);

            foreach (KeyValuePair<PropertyInfo, ClusterFieldAttribute> pair in
                clusterFieldInfo.Where(pair => !string.IsNullOrEmpty(pair.Value.FieldName) && pair.Value.FieldName.Equals(name, StringComparison.InvariantCulture)))
            {
                bool valueEncrypted = pair.Value.Encrypted && encrypted;
                if (value != null && valueEncrypted)
                {
                    string stringVal = TypeConversion.ConvertType(value, typeof(string)) as string;
                    string decryptedString = ExonySymmetricCryptographer.Decrypt(stringVal);
                    value = decryptedString;
                }

                value = TypeConversion.ConvertType(value, pair.Key.PropertyType);

                if (pair.Key.CanWrite)
                {
                    try
                    {
                        pair.Key.SetValue(this, value, null);
                    }
                    catch (Exception e)
                    {
                        throw new ArgumentException(string.Format("Error setting property named {0} with value {1} in cluster resource of id {2}.", name, valueEncrypted ? "****" : value, this.Id), e);
                    }
                }

                break;
            }
        }

        /// <summary>
        /// Get a field based on it's cluster field name (i.e. the FieldName defined on a ClusterFieldAttribute).
        /// </summary>
        public object GetClusterField(string name)
        {
            object result = null;

            IDictionary<PropertyInfo, ClusterFieldAttribute> clusterFieldInfo = AttributeHelper.GetPropertyLevelAttributes<ClusterFieldAttribute>(this);

            foreach (KeyValuePair<PropertyInfo, ClusterFieldAttribute> pair in
                clusterFieldInfo.Where(pair => !string.IsNullOrEmpty(pair.Value.FieldName) && pair.Value.FieldName.Equals(name, StringComparison.InvariantCulture)))
            {
                result = pair.Key.GetValue(this, null);
            }

            return result;
        }

        /// <summary>
        /// Retrieve info for a cluster fields
        /// </summary>
        public ClusterObjectFieldInfo GetClusterFieldInfo(string name)
        {
            IDictionary<PropertyInfo, ClusterFieldAttribute> clusterFieldInfo = AttributeHelper.GetPropertyLevelAttributes<ClusterFieldAttribute>(this);

            return clusterFieldInfo.Where(pair => !string.IsNullOrEmpty(pair.Value.FieldName)
                && pair.Value.FieldName.Equals(name, StringComparison.InvariantCulture)).Select(pair =>
                    new ClusterObjectFieldInfo(pair.Value.Transient)).FirstOrDefault();
        }

        /// <summary>
        /// Fire a property changed event
        /// </summary>
        protected void FirePropertyChanged(string propertyName, object oldValue, object newValue)
        {
            // Don't fire event if nothing has changed
            if (Equals(oldValue, newValue))
            {
                return;
            }

            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, propertyName, oldValue, newValue);
            }
        }

        /// <summary>
        /// Validate this cluster object
        /// </summary>
        public virtual IEnumerable<IClusterValidationResult> Validate()
        {
            List<IClusterValidationResult> result = new List<IClusterValidationResult>();

            return result;
        }

        /// <summary>
        /// Get the value of a property by name
        /// </summary>
        public object GetPropertyValue(string propertyName)
        {
            PropertyInfo property = this.GetType().GetProperty(propertyName);
            return property.GetValue(this, null);
        }

        /// <summary>
        /// Set the value of a property by name
        /// </summary>
        public void SetPropertyValue(string propertyName, object value)
        {
            PropertyInfo property = this.GetType().GetProperty(propertyName);
            value = TypeConversion.ConvertType(value, property.PropertyType);
            property.SetValue(this, value, null);
        }

        #endregion

        #region Object Overrides

        /// <summary>
        /// Display this object as a string
        /// </summary>
        public override string ToString()
        {
            return this.DisplayName;
        }

        /// <summary>
        /// Compare this item for equality with the specified item
        /// </summary>
        public override bool Equals(object obj)
        {
            IClusterObject other = obj as IClusterObject;

            if (other == null)
            {
                return false;
            }

            return other.Id.Equals(this.Id) && other.GetType() == this.GetType();
        }

        /// <summary>
        /// Get a hashcode for this object
        /// </summary>
        public override int GetHashCode()
        {
            return this.Id.GetHashCode();
        }

        #endregion

        #region Implementation of ICustomTypeDescriptor

        public AttributeCollection GetAttributes()
        {
            return GlobalisedTypeDescriptor.GetAttributes(this);
        }

        public string GetClassName()
        {
            return GlobalisedTypeDescriptor.GetClassName(this);
        }

        public string GetComponentName()
        {
            return GlobalisedTypeDescriptor.GetComponentName(this);
        }

        public TypeConverter GetConverter()
        {
            return GlobalisedTypeDescriptor.GetConverter(this);
        }

        public EventDescriptor GetDefaultEvent()
        {
            return GlobalisedTypeDescriptor.GetDefaultEvent(this);
        }

        public PropertyDescriptor GetDefaultProperty()
        {
            return GlobalisedTypeDescriptor.GetDefaultProperty(this);
        }

        public object GetEditor(Type editorBaseType)
        {
            return GlobalisedTypeDescriptor.GetEditor(this, editorBaseType);
        }

        public EventDescriptorCollection GetEvents()
        {
            return GlobalisedTypeDescriptor.GetEvents(this);
        }

        public EventDescriptorCollection GetEvents(Attribute[] attributes)
        {
            return GlobalisedTypeDescriptor.GetEvents(this, attributes);
        }

        public PropertyDescriptorCollection GetProperties()
        {
            return GlobalisedTypeDescriptor.GetProperties(this);
        }

        public PropertyDescriptorCollection GetProperties(Attribute[] attributes)
        {
            return GlobalisedTypeDescriptor.GetProperties(this, attributes);
        }

        public object GetPropertyOwner(PropertyDescriptor pd)
        {
            return this;
        }

        #endregion
    }
}
