#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ClusterValidation
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Exony.Database.Common.Enumerations;

    internal static class LogicalResources
    {
        /// <summary>
        /// Validate the total number of connections from the specified component to any components of the specified type
        /// </summary>
        internal static IEnumerable<IClusterValidationResult> ValidateSinglePublisher(ILogicalResource logicalResource)
        {
            List<IClusterValidationResult> results = new List<IClusterValidationResult>();

            int publisherCount = logicalResource.PhysicalResources.Count(pr => pr.IsPublisher);

            if (publisherCount != 1)
            {
                results.Add(new ClusterValidationResult(ClusterValidationSeverity.Error, logicalResource, "Incorrect number of publisher physical resources specified. Expected: 1, Found: {0}", publisherCount));
            }

            return results;
        }

        /// <summary>
        /// Validate that the total number of parent resources of the specified types is in the supplied range
        /// </summary>
        internal static IEnumerable<IClusterValidationResult> ValidateParentResourceCount(ILogicalResource logicalResource, int minCount, int maxCount, params string[] typeInternalNames)
        {
            List<IClusterValidationResult> results = new List<IClusterValidationResult>();

            int resourceCount =
                logicalResource.ParentResourceMembers.Count(
                    prm => typeInternalNames.Contains(prm.ParentResource.ResourceType.InternalName, StringComparer.InvariantCultureIgnoreCase));

            StringBuilder nameBuilder = new StringBuilder();
            foreach (string typeName in typeInternalNames)
            {
                nameBuilder.Append(typeName);
                nameBuilder.Append(",");
            }

            nameBuilder.Remove(nameBuilder.Length - 1, 1);

            if (resourceCount < minCount)
            {
                results.Add(new ClusterValidationResult(ClusterValidationSeverity.Error, logicalResource, "Insufficent parent resources of type [{0}]. Expected: {1}, Found: {2}", nameBuilder, minCount, resourceCount));
            }

            if (resourceCount > maxCount)
            {
                results.Add(new ClusterValidationResult(ClusterValidationSeverity.Error, logicalResource, "To many parent resources of type [{0}]. Expected: {1}, Found: {2}", nameBuilder, maxCount, resourceCount));
            }

            return results;
        }

        /// <summary>
        /// Validate that the total number of child resources of the specified types is in the supplied range
        /// </summary>
        internal static IEnumerable<IClusterValidationResult> ValidateChildResourceCount(ILogicalResource logicalResource, int minCount, int maxCount, params string[] typeInternalNames)
        {
            List<IClusterValidationResult> results = new List<IClusterValidationResult>();

            int resourceCount =
                logicalResource.ChildResourceMembers.Count(
                    prm => typeInternalNames.Contains(prm.ChildResource.ResourceType.InternalName, StringComparer.InvariantCultureIgnoreCase));

            StringBuilder nameBuilder = new StringBuilder();
            foreach (string typeName in typeInternalNames)
            {
                nameBuilder.Append(typeName);
                nameBuilder.Append(",");
            }

            nameBuilder.Remove(nameBuilder.Length - 1, 1);

            if (resourceCount < minCount)
            {
                results.Add(new ClusterValidationResult(ClusterValidationSeverity.Error, logicalResource, "Insufficent child resources of type [{0}]. Expected: {1}, Found: {2}", nameBuilder, minCount, resourceCount));
            }

            if (resourceCount > maxCount)
            {
                results.Add(new ClusterValidationResult(ClusterValidationSeverity.Error, logicalResource, "To many child resources of type [{0}]. Expected: {1}, Found: {2}", nameBuilder, maxCount, resourceCount));
            }

            return results;
        }

        internal static IEnumerable<IClusterValidationResult> ValidateAllDatabaseTypeMappingsExist(ILogicalResource logicalResource)
        {
            List<IClusterValidationResult> results = new List<IClusterValidationResult>();

            IEnumerable<ResourceType> dbCacheTypes = ResourceType.GetDatabaseCacheTypes();
            IEnumerable<ResourceType> typesWithMapping = logicalResource.EntityTypeMappings.Select(map => ResourceTypeFactory.Parse(map.EntityTypeInternalName));
            IEnumerable<ResourceType> dbCacheTypesWithoutMapping = dbCacheTypes.Except(typesWithMapping).ToArray();

            if (dbCacheTypesWithoutMapping.Any())
            {
                string types = string.Join(", ", dbCacheTypesWithoutMapping.Select(t => t.Name).Take(10).ToArray());
                results.Add(new ClusterValidationResult(ClusterValidationSeverity.Error, logicalResource, "Type mappings missing [{0}]", types));
            }

            return results;
        }

        internal static IEnumerable<IClusterValidationResult> ValidateEntityTypeMappings(ILogicalResource logicalResource, bool sourceClusterNull)
        {
            return (from mapping in logicalResource.EntityTypeMappings let isSourceClusterNull = mapping.SourceLogicalResource == null where isSourceClusterNull != sourceClusterNull select new ClusterValidationResult(ClusterValidationSeverity.Error, logicalResource, "Type mapping with invalid source logical resource: [{0}]", mapping.SourceLogicalResource != null ? mapping.SourceLogicalResource.DisplayName : "<null>")).Cast<IClusterValidationResult>().ToList();
        }
    }
}