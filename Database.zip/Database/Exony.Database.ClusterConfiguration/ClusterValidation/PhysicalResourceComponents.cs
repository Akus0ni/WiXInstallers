#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.ClusterValidation
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    #region Physical Resource Components

    internal static class PhysicalResourceComponents
    {
        /// <summary>
        /// Validate the total number of outbound connections from the specified component to any components of the specified type
        /// </summary>
        internal static IEnumerable<IClusterValidationResult> ValidateOutboundConnectionCountToComponentType(
            IPhysicalResourceComponent sourceComponent,
            string sinkTypeInternalName,
            int maxConnections)
        {
            IPhysicalResourceComponentType sinkType =
                sourceComponent.Configuration.PhysicalResourceComponentTypes.First(prct => string.Equals(prct.InternalName, sinkTypeInternalName, StringComparison.InvariantCultureIgnoreCase));

            List<IClusterValidationResult> results = new List<IClusterValidationResult>();

            int count = sourceComponent.OutboundConnections.Count(oc => Equals(oc.SinkComponent.ComponentType, sinkType));

            if (count > maxConnections)
            {
                // Invalid number of outbound connections to component type [{0}]. Maximum connections [{1}], actual connections [{2}]
                results.Add(
                    new ClusterValidationResult(
                        ClusterValidationSeverity.Error,
                        sourceComponent,
                        Resources.String_Validation_Invalid_Outbound_Connection_Count_To_Component_Type,
                        sinkType.DisplayName,
                        maxConnections,
                        count));
            }

            return results;
        }

        /// <summary>
        /// Validate the total number of inbound connections to the specified component from any components of the specified type
        /// </summary>
        internal static IEnumerable<IClusterValidationResult> ValidateInboundConnectionCountFromComponentType(
            IPhysicalResourceComponent sinkComponent,
            string sourceTypeInternalName,
            int maxConnections)
        {
            IPhysicalResourceComponentType sourceType =
                sinkComponent.Configuration.PhysicalResourceComponentTypes.First(prct => string.Equals(prct.InternalName, sourceTypeInternalName, StringComparison.InvariantCultureIgnoreCase));

            List<IClusterValidationResult> results = new List<IClusterValidationResult>();

            int count = sinkComponent.InboundConnections.Count(oc => Equals(oc.SourceComponent.ComponentType, sourceType));

            if (count > maxConnections)
            {
                // Invalid number of inbound connections from component type [{0}]. Maximum connections [{1}], actual connections [{2}]
                results.Add(
                    new ClusterValidationResult(
                        ClusterValidationSeverity.Error,
                        sinkComponent,
                        Resources.String_Validation_Invalid_Inbound_Connection_Count_From_Component_Type,
                        sourceType.DisplayName,
                        maxConnections,
                        count));
            }

            return results;
        }

        /// <summary>
        /// Validate the total number of connections to the specified component from any components of the specified type on the same logical resource
        /// </summary>
        internal static IEnumerable<IClusterValidationResult> ValidateInboundConnectionCountFromComponentTypeAndLogicalResource(
            IPhysicalResourceComponent sinkComponent,
            string sourceTypeInternalName,
            int maxConnections)
        {
            IPhysicalResourceComponentType sourceType =
                sinkComponent.Configuration.PhysicalResourceComponentTypes.First(prct => string.Equals(prct.InternalName, sourceTypeInternalName, StringComparison.InvariantCultureIgnoreCase));

            var a = sinkComponent.InboundConnections.GroupBy(c => new { c.SourceComponent.PhysicalResource.LogicalResource, c.SourceComponent.ComponentType });

            var b = a.ToDictionary(g => g.Key, g => g.Count()).Where(g => g.Key.ComponentType == sourceType && g.Value > maxConnections);

            // Invalid number of inbound connections from component type [{0}] on logical resource [{1}]. Maximum connections [{2}], actual connections [{3}]
            var d =
                b.Select(
                    r =>
                    new ClusterValidationResult(
                        ClusterValidationSeverity.Error,
                        sinkComponent,
                        Resources.String_Validation_Invalid_Inbound_Connection_Count_From_Component_Type_On_Logical_Resource,
                        sourceType.DisplayName,
                        r.Key.LogicalResource.Name,
                        maxConnections,
                        r.Value)).Cast<IClusterValidationResult>();

            return d;
        }
    }

    #endregion
}
