#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    public interface IOleDbConnectionSinkComponent
    {
        /// <summary>
        /// The catalog of the ole db sink component
        /// </summary>
        string Catalog { get; }

        /// <summary>
        /// The port number of the ole db sink component. If null, then no port is required
        /// </summary>
        int? Port { get; }

        /// <summary>
        /// The instance name.
        /// </summary>
        string InstanceName { get; }
    }
}
