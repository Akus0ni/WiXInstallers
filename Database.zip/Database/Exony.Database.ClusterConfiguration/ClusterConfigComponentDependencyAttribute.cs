#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
    public sealed class ClusterConfigComponentDependencyAttribute : Attribute
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public ClusterConfigComponentDependencyAttribute(string componentTypeName)
        {
            ArgumentValidation.CheckForEmptyString(componentTypeName, "componentTypeName");
            this.ComponentTypeName = componentTypeName;
        }

        /// <summary>
        /// Component Type Name
        /// </summary>
        public string ComponentTypeName { get; set; }
    }
}
