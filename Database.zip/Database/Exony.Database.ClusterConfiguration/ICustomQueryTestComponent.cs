#region Copyright © Exony Limited. All rights reserved.

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

#endregion

namespace Exony.Database.ClusterConfiguration
{
    /// <summary>
    /// Defines a custom test query for a component. When implemented on a component, where implemented monitoring will
    /// perform an additional test using the custom test query.
    /// </summary>
    public interface ICustomQueryTestComponent
    {
        /// <summary>
        /// The custom test query to run
        /// </summary>
        string CustomTestQuery { get; set; }
    }
}
