#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using Exony.Identity;

    /// <summary>
    /// Implementation of IImpersonate which does nothing - ie. used when impersonation is not required.
    /// </summary>
    internal class Impersonation : IImpersonate
    {
        #region IImpersonate Members

        public void Revert()
        {
            // do nothing
        }

        void IImpersonate.Impersonate()
        {
            // do nothing
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            // do nothing
        }

        #endregion
    }
}
