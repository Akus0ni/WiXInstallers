#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System.Collections.Generic;

    public interface IMonitoringAdmin
    {
        /// <summary>
        /// Flag indicating if we should automatically restart the host if monitoring detects a critical change
        /// </summary>
        bool AutoRestartOnCriticalChange { get; }

        /// <summary>
        /// The user name for stopping/starting services
        /// </summary>
        string ServiceControlUser { get; }

        /// <summary>
        /// The password for stopping/starting services
        /// </summary>
        string ServiceControlPassword { get; }

        /// <summary>
        /// Check if the specified property change on the supplied object would cause a service restart
        /// </summary>
        bool CheckForServiceRestart(IClusterObject clusterObject, string propertyName, object oldValue,
                                    object newValue, out IEnumerable<string> servicesToRestart);

        /// <summary>
        /// Check if a service restart is required.
        /// </summary>
        bool CheckForServiceRestart(IPhysicalResourceComponent oldState, out IEnumerable<string> servicesToRestart);
    }
}
