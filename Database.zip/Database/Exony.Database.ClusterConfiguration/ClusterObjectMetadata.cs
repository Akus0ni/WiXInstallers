﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    internal class ClusterObjectMetadata : IClusterObjectMetadata 
    {
        /// <summary>
        /// Field metadata keyed by field name
        /// </summary>
        private IDictionary<string, IClusterFieldMetadata> fieldsByFieldName = 
            new Dictionary<string, IClusterFieldMetadata>(StringComparer.InvariantCultureIgnoreCase);

        /// <summary>
        /// Field metadata keyed by property name
        /// </summary>
        private IDictionary<string, IClusterFieldMetadata> fieldsByPropertyName =
            new Dictionary<string, IClusterFieldMetadata>(StringComparer.InvariantCultureIgnoreCase);

        /// <summary>
        /// Default constructor.
        /// </summary>
        public ClusterObjectMetadata(IList<IClusterFieldMetadata> fields)
        {
            foreach (IClusterFieldMetadata currentField in fields)
            {
                fieldsByFieldName.Add(currentField.FieldName, currentField);
                fieldsByPropertyName.Add(currentField.PropertyName, currentField);
            }

            this.HasSecrets = fieldsByFieldName.Values.Any(f => f.Secret);
        }
        /// <summary>
        /// Retrieve the metadata for cluster fields on this object.
        /// </summary>
        public IEnumerable<IClusterFieldMetadata> Fields
        {
            get
            {
                return this.fieldsByFieldName.Values;
            }
        }

        /// <summary>
        /// Get field metadata by field name.
        /// </summary>
        public IClusterFieldMetadata GetField(string fieldName)
        {
            IClusterFieldMetadata result;

            // Check by field name and then by property name
            if (!this.fieldsByFieldName.TryGetValue(fieldName, out result))
            {
                this.fieldsByPropertyName.TryGetValue(fieldName, out result);
            }

            return result;
        }

        /// <summary>
        /// Flag indicating if this type has any data stored in secrets manager.
        /// </summary>
        public bool HasSecrets { get; }
    }
}
