#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion
namespace Exony.Database.ClusterConfiguration.UnitTests.Persistance
{
    using Exony.Database.ClusterConfiguration.Persistance;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class SqlPersistanceManagerFactoryUnitTests
    {
        [TestMethod]
        [TestCategory("Database")]
        public void TestFactory()
        {
            var manager = SqlPersistanceManagerFactory.Create("connection");
            Assert.AreEqual("connection", manager.DbConnectionString);
            Assert.AreEqual(PersistanceManager.ModelAccessMode.Configuration, manager.AccessMode);
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestFactoryWithServiceAccessMode()
        {
            var manager = SqlPersistanceManagerFactory.Create("connection", PersistanceManager.ModelAccessMode.Service);
            Assert.AreEqual("connection", manager.DbConnectionString);
            Assert.AreEqual(PersistanceManager.ModelAccessMode.Service, manager.AccessMode);
        }
    }
}