namespace Exony.Database.ClusterConfiguration.UnitTests
{
    using System;
    using System.Linq;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.Common.Folders;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ClusterConfigurationUnitTests
    {
        [TestMethod]
        [TestCategory("Database")]
        public void TestConstructor()
        {
            var clusterConfig = new ClusterConfiguration();
            Assert.IsNotNull(clusterConfig);
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestProcessFolders()
        {
            var clusterConfiguration = new ClusterConfiguration();
            clusterConfiguration.LogicalResourceTypes.Add(new LogicalResourceType(clusterConfiguration) { InternalName = "CRT_EXONY_APPLICATION_SERVER" });
            var resource = new ExonyAppServerLogicalResource(clusterConfiguration);
            var folder = new Folder(null, Guid.NewGuid(), "name", true, null);

            resource.FolderMappings.Add(new ImportRuleFolderMapping(resource, folder));
            var resources = new[] { resource };
            clusterConfiguration.LogicalResources.AddRange(resources);

            var folders = ClusterConfiguration.ProcessFolders(resources);

            Assert.AreEqual(folder, folders.Single());
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestProcessFoldersWithParentFolder()
        {
            var clusterConfiguration = new ClusterConfiguration();
            clusterConfiguration.LogicalResourceTypes.Add(new LogicalResourceType(clusterConfiguration) { InternalName = "CRT_EXONY_APPLICATION_SERVER" });
            var resource = new ExonyAppServerLogicalResource(clusterConfiguration);
            var root = new Folder(null, Guid.Empty, string.Empty, true, string.Empty);
            var folder = new Folder(root, Guid.NewGuid(), "name", false, null);

            resource.FolderMappings.Add(new ImportRuleFolderMapping(resource, folder));
            var resources = new[] { resource };
            clusterConfiguration.LogicalResources.AddRange(resources);

            var folders = ClusterConfiguration.ProcessFolders(resources).ToList();

            Assert.AreEqual(folder, folders.First());
            Assert.AreEqual(root, folders.Last());
        }
    }
}
