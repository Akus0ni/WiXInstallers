﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Database.ClusterConfiguration;
    using NUnit.Framework;

    [TestFixture]
    [Category("Database")]
    public class EgainVersionMappingUnitTests
    {
        /// <summary>
        /// Tests the get the base version method.
        /// </summary>
        [Test]
        public void GetBaseVersionTest()
        {
            Dictionary<string, string> mappedVersionDictionary = new Dictionary<string, string> { { "11.5", "15.0.3" }, { "11.5.0", "15.0.3" }, { "11.5.3", "15.0.3" }, { "11.6", "15.5.2" }, { "11.6.1", "15.5.2" } };

            // These should all pass
            foreach (KeyValuePair<string, string> versionKeyPair in mappedVersionDictionary)
            {
                string eceVersion = versionKeyPair.Key;
                string baseVersion = EgainVersionMapping.GetBaseVersion(eceVersion);
                Assert.IsTrue(string.Equals(baseVersion, versionKeyPair.Value, StringComparison.InvariantCulture));
            }

            // These should all throw an exception
            List<string> unsupportedVersionList = new List<string> { "10.5", "1.1.8", "11.4.9" };
            foreach (string unsupportedEceVersion in unsupportedVersionList)
            {
                ArgumentException caughtException = Assert.Throws<ArgumentException>(() => EgainVersionMapping.GetBaseVersion(unsupportedEceVersion));
                Assert.AreEqual($"Enterprise Chat & Email version {unsupportedEceVersion} is not supported", caughtException.Message);
            }
        }

        /// <summary>
        /// Tests the is version map correct method.
        /// </summary>
        [Test]
        public void IsVersionMapCorrectTest()
        {
            Dictionary<string, KeyValuePair<string, bool>> mappedVersionDictionary = new Dictionary<string, KeyValuePair<string, bool>>
                                                                                     {
                                                                                         { "11.5", new KeyValuePair<string, bool>("15.0.3", true) },
                                                                                         { "11.5.3", new KeyValuePair<string, bool>("15.0.3", true) },
                                                                                         { "11.5.9", new KeyValuePair<string, bool>("15.0.3", true) },
                                                                                         { "11.5.0", new KeyValuePair<string, bool>("15.0.3", true) },
                                                                                         { "11.6", new KeyValuePair<string, bool>("15.0.3", false) },
                                                                                         { "11.6.0", new KeyValuePair<string, bool>("15.5.2", true) }
                                                                                     };

            string unsuccessfulMaps = (from versionKeyValuePair in mappedVersionDictionary
                let isCorrect = versionKeyValuePair.Value.Value
                let specifiedBaseVersion = versionKeyValuePair.Value.Key
                let specifiedEceVersion = versionKeyValuePair.Key
                let result = EgainVersionMapping.IsVersionMapCorrect(specifiedBaseVersion, specifiedEceVersion)
                where result != isCorrect
                select
                    $"Specified version {specifiedEceVersion} was expected to {(isCorrect ? "successfully" : "unsuccessfully")} map to version {specifiedBaseVersion}, instead it was {(result ? "successful" : "unsuccessful")}")
                .ToList().Aggregate(string.Empty, (current, badMap) => current + (string.IsNullOrWhiteSpace(current) ? badMap : Environment.NewLine + badMap));

            if (!string.IsNullOrWhiteSpace(unsuccessfulMaps))
            {
                throw new Exception(unsuccessfulMaps);
            }
        }
    }
}
