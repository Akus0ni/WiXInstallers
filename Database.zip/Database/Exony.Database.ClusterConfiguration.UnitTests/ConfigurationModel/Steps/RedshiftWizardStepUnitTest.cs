﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.IO;
    using System.Linq;
    using System.Reflection;

    [TestClass]
    public class RedshiftWizardStepUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Steps\\Config\\RedshiftWizardStepJson");

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string clusterConfigurationXmlPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Steps\\Config\\ClusterConfigurationXmlFile");

        #endregion

        [TestMethod]
        [TestCategory("RedshiftWizardChangeStep")]
        public void ParseFile_AddRedshiftServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("AddRedshiftServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.RedshiftDatabase) && lr.Name.Equals("awsServer")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(((Exony.Database.ClusterConfiguration.PhysicalResourceComponent)manager.Configuration.ClusterObjects.Last()).Server.DefaultAddress, "eg5012qa29-emc2-new2-instance.cbxic4o4fvd9.us-west-2.rds.amazonaws.com");
            Assert.AreEqual(((Exony.Database.ClusterConfiguration.PhysicalResourceComponent)manager.Configuration.ClusterObjects.Last()).Server.DisplayName, "aws");
            Assert.AreEqual(logicalResource.Name, "awsServer");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardChangeStep")]
        public void ParseFile_RemovRedshiftServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("RemoveRedshiftServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.RedshiftDatabase) && lr.Name.Equals("Redshift")).FirstOrDefault();
            Assert.IsNull(logicalResource);
        }

        [TestMethod]
        [TestCategory("RedshiftWizardChangeStep")]
        public void ParseFile_UpdateRedshiftServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateRedshiftServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.RedshiftDatabase) && lr.Name.Equals("RedshiftServer")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "RedshiftServer");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardChangeStep")]
        public void ParseFile_UpdateServerNameRedshiftServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateServerNameRedshiftServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.RedshiftDatabase) && lr.Name.Equals("Redshift")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.PhysicalResources.Last().ServerDisplayName, "awsBoohoo");
        }

        #region Test

        #endregion

        /// <summary>
        /// Load Peristance manager.
        /// </summary>
        private static IPersistanceManager LoadPersistanceManager(string fileName)
        {
            string xmlPath = Path.Combine(clusterConfigurationXmlPath, "ClusterConfigurationModelBase1.xml");

            IPersistanceManager manager = new CustomFilePersistanceManager(xmlPath, CustomPersistanceManagerForUnitTests.ModelAccessMode.Configuration);
            manager.Load();

            ClusterConfigurationUtility.Configure(manager, Path.Combine(jsonPath, fileName), null);

            return manager;
        }

    }
}
