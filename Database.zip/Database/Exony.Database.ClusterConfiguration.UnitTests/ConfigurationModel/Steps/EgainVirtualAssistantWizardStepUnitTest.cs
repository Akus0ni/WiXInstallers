﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.IO;
    using System.Linq;
    using System.Reflection;

    [TestClass]
    public class EgainVirtualAssistantWizardStepUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Steps\\Config\\EgainVirtualAssistantWizardStepJson");

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string clusterConfigurationXmlPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Steps\\Config\\ClusterConfigurationXmlFile");

        #endregion

        [TestMethod]
        [TestCategory("EgainVirtualAssistantWizardChangeStep")]
        public void ParseFile_AddEgainVirtualAssistantServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("AddEgainVAServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainVirtualAssistantServer) && lr.Name.Equals("egainva1.0")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(((Exony.Database.ClusterConfiguration.PhysicalResourceComponent)manager.Configuration.ClusterObjects.Last()).Server.DefaultAddress, "172.21.8.155");
            Assert.AreEqual(((Exony.Database.ClusterConfiguration.PhysicalResourceComponent)manager.Configuration.ClusterObjects.Last()).Server.DisplayName, "va");
            Assert.AreEqual(logicalResource.Name, "egainva1.0");
        }

        [TestMethod]
        [TestCategory("EgainVirtualAssistantWizardChangeStep")]
        public void ParseFile_RemoveEgainVirtualAssistantServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("RemoveEgainVAServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainVirtualAssistantServer) && lr.Name.Equals("eGainVA")).FirstOrDefault();
            Assert.IsNull(logicalResource);
        }

        [TestMethod]
        [TestCategory("EgainVirtualAssistantWizardChangeStep")]
        public void ParseFile_UpdateEgainVirtualAssistantServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateEgainVAServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainVirtualAssistantServer) && lr.Name.Equals("eGainVA1.0")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "eGainVA1.0");
        }

        [TestMethod]
        [TestCategory("EgainVirtualAssistantWizardChangeStep")]
        public void ParseFile_UpdateServerNameEgainVirtualAssistantServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateServerNameEgainVAServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainVirtualAssistantServer) && lr.Name.Equals("eGainVA")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.PhysicalResources.Last().ServerDisplayName, "vaBoohoo");
        }

        #region Test

        #endregion

        /// <summary>
        /// Load Peristance manager.
        /// </summary>
        private static IPersistanceManager LoadPersistanceManager(string fileName)
        {
            string xmlPath = Path.Combine(clusterConfigurationXmlPath, "ClusterConfigurationModelBase1.xml");

            IPersistanceManager manager = new CustomFilePersistanceManager(xmlPath, CustomPersistanceManagerForUnitTests.ModelAccessMode.Configuration);
            manager.Load();

            ClusterConfigurationUtility.Configure(manager, Path.Combine(jsonPath, fileName), null);

            return manager;
        }
    }
}
