﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Linq;
    using System.Reflection;

    [TestClass]
    public class CiscoUcceWizardStepUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Steps\\Config\\CiscoUcceWizardStepJson");

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string clusterConfigurationXmlPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Steps\\Config\\ClusterConfigurationXmlFile");

        #endregion

        #region Test

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_AddCiscoUcceStepMinimumSetting_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("ValidMinimal.json");
            
            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Server");
            Assert.AreEqual(logicalResource.Enabled, true);
            Assert.AreEqual(logicalResource.Provisionable, false);
            Assert.AreEqual(logicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "ussuhvin0061");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.GetByServerName("ussuhvin0061").DefaultAddress, "ussuhvin0061.egeng.info");

            string[] wizardData = logicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');
            Assert.AreEqual(wizardData[0].Split('=')[1], "ussuhvin0061.egeng.info");
            Assert.AreEqual(wizardData[1].Split('=')[1], "us61_awdb");
            Assert.AreEqual(wizardData[2].Split('=')[1], "False");
            Assert.AreEqual(wizardData[4].Split('=')[1], "sa");
            Assert.AreEqual(wizardData[5].Split('=')[1], "Pa55word");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_AddCiscoUcceStepProvisionableAllFalse_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("Provisionable.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Server");
            Assert.AreEqual(logicalResource.Enabled, true);
            Assert.AreEqual(logicalResource.Provisionable, true);
            Assert.AreEqual(logicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "ussuhvin0061");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.GetByServerName("ussuhvin0061").DefaultAddress, "ussuhvin0061.egeng.info");

            string[] wizardData = logicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');
            Assert.AreEqual(wizardData[0].Split('=')[1], "ussuhvin0061.egeng.info");
            Assert.AreEqual(wizardData[1].Split('=')[1], "us61_awdb");
            Assert.AreEqual(wizardData[2].Split('=')[1], "False");
            Assert.AreEqual(wizardData[4].Split('=')[1], "sa");
            Assert.AreEqual(wizardData[5].Split('=')[1], "Pa55word");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_AddCiscoUcceStepProvisionableAllTrue_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("ProvisionableAllTrue.json");
            
            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Server");
            Assert.AreEqual(logicalResource.Enabled, true);
            Assert.AreEqual(logicalResource.Provisionable, true);
            Assert.AreEqual(logicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "ussuhvin0061");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.GetByServerName("ussuhvin0061").DefaultAddress, "ussuhvin0061.egeng.info");

            string[] wizardData = logicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');
            Assert.AreEqual(wizardData[0].Split('=')[1], "ussuhvin0061.egeng.info");
            Assert.AreEqual(wizardData[1].Split('=')[1], "us61_awdb");
            Assert.AreEqual(wizardData[2].Split('=')[1], "False");
            Assert.AreEqual(wizardData[4].Split('=')[1], "sa");
            Assert.AreEqual(wizardData[5].Split('=')[1], "Pa55word");

            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("AwsComponent"));
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("HdsComponent"));
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("DdsComponent"));
            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("ConapiComponent"));

            Assert.AreEqual(logicalResource.PhysicalResources.Last().Components.ToArray()[0].Configuration.PhysicalResources.Last().Components.First().Server.ServerName, "ussuhvin0061");
            Assert.AreEqual(logicalResource.PhysicalResources.Last().Components.ToArray()[0].Configuration.PhysicalResources.Last().Components.First().Server.DefaultAddress, "ussuhvin0061.egeng.info");

            Assert.AreEqual(logicalResource.GetPropertyValue("DomainPassPhrase"), "QaEngg@123");
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainUserName"), "qeuser@egeng.info");

            Assert.AreEqual(logicalResource.GetPropertyValue("MultiMediaSupport"), true);
            Assert.AreEqual(logicalResource.GetPropertyValue("PurgeItemsOnDelete"), true);
            Assert.AreEqual(logicalResource.GetPropertyValue("ScriptProvisioningEnabled"), true);
            Assert.AreEqual(logicalResource.GetPropertyValue("ScriptLockUserName"), "eGain User");
            Assert.AreEqual(logicalResource.GetPropertyValue("SupervisorDomainAccountRequired"), true);

            Assert.AreEqual(logicalResource.GetPropertyValue("DomainServer1"), "egeng.info");
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainAnonymous"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainDelegation"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainEncryption"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainServerBind"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainFastBind"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainReadOnlyServer"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainSsl"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("SecureAuthentication"), true);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainSealing"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainSigning"), false);
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainUserName"), "qeuser@egeng.info");
            Assert.AreEqual(logicalResource.GetPropertyValue("DomainPassPhrase"), "QaEngg@123");

        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_AddCiscoUcceStepHdsTrue_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("HdsTrue.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Server");
            Assert.AreEqual(logicalResource.Enabled, true);
            Assert.AreEqual(logicalResource.Provisionable, false);
            Assert.AreEqual(logicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "ussuhvin0061");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.GetByServerName("ussuhvin0061").DefaultAddress, "ussuhvin0061.egeng.info");

            string[] wizardData = logicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');
            Assert.AreEqual(wizardData[0].Split('=')[1], "ussuhvin0061.egeng.info");
            Assert.AreEqual(wizardData[1].Split('=')[1], "us61_awdb");
            Assert.AreEqual(wizardData[2].Split('=')[1], "False");
            Assert.AreEqual(wizardData[4].Split('=')[1], "sa");
            Assert.AreEqual(wizardData[5].Split('=')[1], "Pa55word");

            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("AwsComponent"));
            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("HdsComponent"));
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("DdsComponent"));
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("ConapiComponent"));

            Assert.AreEqual(logicalResource.PhysicalResources.Last().Components.ToArray()[1].Server.ServerName, "abc");
            Assert.AreEqual(logicalResource.PhysicalResources.Last().Components.ToArray()[1].Server.DefaultAddress, "abc.egeng.info");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_AddCiscoUcceStepDdsTrue_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("DdsTrue.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Server");
            Assert.AreEqual(logicalResource.Enabled, true);
            Assert.AreEqual(logicalResource.Provisionable, false);
            Assert.AreEqual(logicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "ussuhvin0061");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.GetByServerName("ussuhvin0061").DefaultAddress, "ussuhvin0061.egeng.info");

            string[] wizardData = logicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');
            Assert.AreEqual(wizardData[0].Split('=')[1], "ussuhvin0061.egeng.info");
            Assert.AreEqual(wizardData[1].Split('=')[1], "us61_awdb");
            Assert.AreEqual(wizardData[2].Split('=')[1], "False");
            Assert.AreEqual(wizardData[4].Split('=')[1], "sa");
            Assert.AreEqual(wizardData[5].Split('=')[1], "Pa55word");

            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("AwsComponent"));
            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("HdsComponent"));
            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("DdsComponent"));
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("ConapiComponent"));

            Assert.AreEqual(logicalResource.PhysicalResources.Last().Components.ToArray()[1].Server.ServerName, "abc");
            Assert.AreEqual(logicalResource.PhysicalResources.Last().Components.ToArray()[1].Server.DefaultAddress, "abc.egeng.info");

            Assert.AreEqual(logicalResource.PhysicalResources.Last().Components.ToArray()[2].Server.ServerName, "xyz");
            Assert.AreEqual(logicalResource.PhysicalResources.Last().Components.ToArray()[2].Server.DefaultAddress, "xyz.egeng.info");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_DualSided_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("DualSided.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Server");
            Assert.AreEqual(logicalResource.Enabled, true);
            Assert.AreEqual(logicalResource.Provisionable, false);
            Assert.AreEqual(logicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "ussuhvin0061");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.GetByServerName("ussuhvin0061").DefaultAddress, "ussuhvin0061.egeng.info");

            string[] wizardData = logicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');
            Assert.AreEqual(wizardData[0].Split('=')[1], "ussuhvin0061.egeng.info");
            Assert.AreEqual(wizardData[1].Split('=')[1], "us61_awdb");
            Assert.AreEqual(wizardData[2].Split('=')[1], "False");
            Assert.AreEqual(wizardData[4].Split('=')[1], "sa");
            Assert.AreEqual(wizardData[5].Split('=')[1], "Pa55word");

            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("AwsComponent"));
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("HdsComponent"));
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("DdsComponent"));
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("ConapiComponent"));
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_UpdateResourceName_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("NewResourceName.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco United")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco United");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_UpdateProvisioningFlag_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateProvisioningFlag.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Demo")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Demo");
            Assert.AreEqual(logicalResource.Provisionable, false);
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("ConapiComponent"));
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_UpdateAwServerName_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateAwServerName.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Demo")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Demo");
            Assert.AreEqual(logicalResource.Provisionable, false);
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("ConapiComponent"));
            Assert.AreEqual(logicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "holdup");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_UpdateAwServerAddress_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateAwServerAddress.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Demo")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Demo");
            Assert.AreEqual(logicalResource.Provisionable, false);
            Assert.IsNull(logicalResource.PhysicalResources.Last().GetPropertyValue("ConapiComponent"));
            Assert.AreEqual(logicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "holdup");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.GetByServerName("holdup").DefaultAddress, "usqaicm1251.egeng.info");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_UpdateHdsFlag_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateHdsFlag.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Demo")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Demo");
            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("HdsComponent"));
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardChangeStep")]
        public void ParseFile_UpdateDdsFlag_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateDdsFlag.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && lr.Name.Equals("Cisco UCCE Demo")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "Cisco UCCE Demo");
            Assert.IsNotNull(logicalResource.PhysicalResources.Last().GetPropertyValue("DdsComponent"));
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NegativeTimeout_Exception()
        {
            LoadModelFromFile("NegativeTimeout.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        public void ParseFile_NoUnifiedConfigUrlUseDefault_Exception()
        {
            LoadModelFromFile("NoUnifiedConfigUrlUseDefault.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        public void ParseFile_InvalidUrlFormatButParsable_Success()
        {
            LoadModelFromFile("InvalidUrlFormat.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        public void ParseFile_ValidUrlFormat_Exception()
        {
            LoadModelFromFile("ValidUrlFormat.json");
        }

        #endregion

        /// <summary>
        /// Load Peristance manager.
        /// </summary>
        private static IPersistanceManager LoadPersistanceManager(string fileName)
        {
            string xmlPath = Path.Combine(clusterConfigurationXmlPath, "ClusterConfigurationModelBase.xml");

            IPersistanceManager manager = new CustomFilePersistanceManager(xmlPath, CustomPersistanceManagerForUnitTests.ModelAccessMode.Configuration);
            manager.Load();

            ClusterConfigurationUtility.Configure(manager, Path.Combine(jsonPath, fileName), null);

            return manager;
        }

        /// <summary>
        /// Load cluster model from file path.
        /// </summary>
        private static ClusterConfigurationChangeModel LoadModelFromFile(string fileName)
        {
            string fullPath = Path.Combine(jsonPath, fileName);
            return ConfigurationModelLoader.LoadModelFromFile(fullPath);
        }
    }
}
