﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using System;
    using System.Text.Json;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.Common.Folders;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Data.SqlClient;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System.Runtime.Serialization;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Moq;
    using System.Reflection;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Database.ClusterConfiguration.Collections;

    [TestClass]
    public class CallManagerWizardStepUnitTests
    {
        #region ConfigPaths

        /// <summary>
        /// File path to the callManagerwizardstep json files.
        /// </summary>
        private static string JsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Steps\\Config\\CallManagerWizardStepJson");

        /// <summary>
        /// File path to the cluster configuration model xml file.
        /// </summary>
        private static string ClusterConfigurationModelFilePath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Steps\\Config\\ClusterConfigurationXmlFile\\ClusterConfigurationModel.xml");

        #endregion

        #region TestMethods

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_AddCallManagerStepWithoutLinkedIcm_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("NullLinkedIcm.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager) && lr.Name.Equals("Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "VSH62QE0245");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.10.43.245");
            Assert.AreEqual(icmLogicalResource.Version, "12.5.x");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');

            Assert.AreEqual(wizardData[0].Split('=')[1], "https://10.10.43.245:8443/axl/");
            Assert.AreEqual(wizardData[1].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[2].Split('=')[1], "Administrator");
            Assert.AreEqual(wizardData[4].Split('=')[1], "120");

            ILogicalResource icmLogicalResource1 = manager.Configuration.LogicalResources.
                Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) &&
                lr.Name.Equals("Icmserver1")).FirstOrDefault();

            bool checkLinkedIcmExist = icmLogicalResource.ParentResourceMembers.
                FirstOrDefault(crm => Equals(crm.ParentResource, icmLogicalResource1)) is null ? true : false;

            Assert.IsTrue(checkLinkedIcmExist);
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_AddCallManagerStepWithLinkedIcm_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("NotNullLinkedIcm.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager) && lr.Name.Equals("Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "VSH62QE0245");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.10.43.245");
            Assert.AreEqual(icmLogicalResource.Version, "12.5.x");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');

            Assert.AreEqual(wizardData[0].Split('=')[1], "https://10.10.43.245:8443/axl/");
            Assert.AreEqual(wizardData[1].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[2].Split('=')[1], "Administrator");
            Assert.AreEqual(wizardData[4].Split('=')[1], "120");

            ILogicalResource icmLogicalResource1 = manager.Configuration.LogicalResources.
                Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) && 
                lr.Name.Equals("Icmserver1")).FirstOrDefault();

            bool checkLinkedIcmExist = icmLogicalResource.ParentResourceMembers.
                FirstOrDefault(crm => Equals(crm.ParentResource, icmLogicalResource1)) is null ? false : true;

            Assert.IsTrue(checkLinkedIcmExist);
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_InValidVersion_Exception()
        {
            IPersistanceManager manager = LoadPersistanceManager("InvalidVersion.json");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_NegTimeout_Exception()
        {
            IPersistanceManager manager = LoadPersistanceManager("NegTimeout.json");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_InValidUrl_Exception()
        {
            IPersistanceManager manager = LoadPersistanceManager("InvalidUrl.json"); 
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_RemoveCallManagerServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("RemoveCMServer.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager) && lr.Name.Equals("Call manager 1")).FirstOrDefault();

            Assert.IsNull(icmLogicalResource);
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_RemovCMIncorrectName_Exception()
        {
            IPersistanceManager manager = LoadPersistanceManager("RemoveCMInValidName.json");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMChangeServerName_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateServerName.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager) && lr.Name.Equals("Cisco Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);

            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "VSH62QE0248");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMResourceName_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateServerResourceName.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager) &&
                lr.Name.Equals("Call Manager 2")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_UpdateCMResrcNmeWithoutPrev_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdServerResNmeWithoutPrevNme.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager) &&
                lr.Name.Equals("Call Manager 2")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_UpdateCMResrcNmeIncorrRescName_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdServerResNmeIncorrPrevNme.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager) &&
                lr.Name.Equals("Call Manager 2")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMChangeServerAddress_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateServerAddress.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager)
                && lr.Name.Equals("Cisco Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);

            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().
                Server.DefaultAddress, "10.10.43.240");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMChangeVersion_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateVersion.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager)
                && lr.Name.Equals("Cisco Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);

            Assert.AreEqual(icmLogicalResource.Version, "5.x");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMChangeUrl_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateUrl.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager)
                && lr.Name.Equals("Cisco Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');

            Assert.AreEqual(wizardData[0].Split('=')[1], "https://10.10.43.240:8443/axl/");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMChangeUserName_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateUserName.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager)
                && lr.Name.Equals("Cisco Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');

            Assert.AreEqual(wizardData[2].Split('=')[1], "Admin");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMChangePassword_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdatePassword.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager)
                && lr.Name.Equals("Cisco Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');

            Assert.AreEqual(wizardData[1].Split('=')[1], "yoyo@123");
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMRemoveLinkedIcm_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateRemoveLinkedIcm.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager)
                && lr.Name.Equals("Cisco Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);

            ILogicalResource icmLogicalResource1 = manager.Configuration.LogicalResources.
                Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) &&
                lr.Name.Equals("Icmserver1")).FirstOrDefault();

            bool checkLinkedIcmExistNull = icmLogicalResource.ParentResourceMembers.
                FirstOrDefault(crm => Equals(crm.ParentResource, icmLogicalResource1)) is null ? true : false;

            Assert.IsTrue(checkLinkedIcmExistNull);
        }

        [TestMethod]
        [TestCategory("CallManagerWizardChangeStep")]
        public void parseFile_UpdateCMAddLinkedIcm_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateAddLinkedIcm.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCallManager)
                && lr.Name.Equals("Cisco Call Manager 1")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);

            ILogicalResource icmLogicalResource1 = manager.Configuration.LogicalResources.
                Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) &&
                lr.Name.Equals("Icmserver1")).FirstOrDefault();

            bool checkLinkedIcmExist = icmLogicalResource.ParentResourceMembers.
                FirstOrDefault(crm => Equals(crm.ParentResource, icmLogicalResource1)) is null ? false : true;

            Assert.IsTrue(checkLinkedIcmExist);
        }

        #endregion

        /// <summary>
        /// Load Peristance manager.
        /// </summary>
        private static IPersistanceManager LoadPersistanceManager(string fileName)
        {
            string xmlPath = ClusterConfigurationModelFilePath;

            IPersistanceManager manager = new CustomFilePersistanceManager(xmlPath, CustomPersistanceManagerForUnitTests.ModelAccessMode.Configuration);

            manager.Load();

            ClusterConfigurationUtility.Configure(manager, Path.Combine(JsonPath, fileName), null);

            return manager;
        }
    }

}