﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Linq;
    using System.Reflection;

    [TestClass]
    public class EgainWizardStepUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Steps\\Config\\EgainWizardStepJson");

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string clusterConfigurationXmlPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Steps\\Config\\ClusterConfigurationXmlFile");

        #endregion

        #region Test

        [TestMethod]
        [TestCategory("EgainWizardChangeStep")]
        public void ParseFile_AddEgainServer_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("ValidEgainServer.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainServer) && lr.Name.Equals("eGain 123")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "eGain 123");
            Assert.AreEqual(logicalResource.GetPropertyValue("DeploymentTypeString"), "NonIntegrated");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.Last().ServerName, "USQAVIM005A");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.Last().DefaultAddress, "USQAVIM005A.egeng.info");

            string[] wizardData = logicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');
            Assert.AreEqual(wizardData[0].Split('=')[1], "USQAVIM005A.egeng.info");
            Assert.AreEqual(wizardData[1].Split('=')[1], "eGActiveDB");
            Assert.AreEqual(wizardData[2].Split('=')[1], "False");
            Assert.AreEqual(wizardData[4].Split('=')[1], "sa");
            Assert.AreEqual(wizardData[5].Split('=')[1], "Pa55word");
        }

        [TestMethod]
        [TestCategory("EgainWizardChangeStep")]
        public void ParseFile_UpdateResourceName_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateResourceName.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainServer) && lr.Name.Equals("New eGain Test Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "New eGain Test Server");
        }

        [TestMethod]
        [TestCategory("EgainWizardChangeStep")]
        public void ParseFile_UpdateServerName_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateServerName.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainServer) && lr.Name.Equals("eGain Test Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "eGain Test Server");
            Assert.AreEqual(logicalResource.GetPropertyValue("DeploymentTypeString"), "NonIntegrated");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.Last().ServerName, "AnalyticsStark");
        }

        [TestMethod]
        [TestCategory("EgainWizardChangeStep")]
        public void ParseFile_UpdateServerAddress_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateServerAddress.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainServer) && lr.Name.Equals("eGain Test Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "eGain Test Server");
            Assert.AreEqual(logicalResource.GetPropertyValue("DeploymentTypeString"), "NonIntegrated");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.Last().DefaultAddress, "USQAVIM005A.egeng.info");
        }

        [TestMethod]
        [TestCategory("EgainWizardChangeStep")]
        public void ParseFile_UpdateDbDetails_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdateDbDetails.json");

            ILogicalResource logicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.EgainServer) && lr.Name.Equals("eGain Test Server")).FirstOrDefault();
            Assert.IsNotNull(logicalResource);
            Assert.AreEqual(logicalResource.Name, "eGain Test Server");
            Assert.AreEqual(logicalResource.GetPropertyValue("DeploymentTypeString"), "NonIntegrated");
            Assert.AreEqual(logicalResource.Configuration.PhysicalServers.Last().DefaultAddress, "USQAVIM005A.egeng.info");

            string[] wizardData = logicalResource.Configuration.PhysicalConnections.ElementAt(12).ConnectionString.Split(';');
            Assert.AreEqual(wizardData[0].Split('=')[1], "USQAVIM005A.egeng.info");
            Assert.AreEqual(wizardData[1].Split('=')[1], "eGActiveDB");
            Assert.AreEqual(wizardData[2].Split('=')[1], "False");
            Assert.AreEqual(wizardData[4].Split('=')[1], "sa");
            Assert.AreEqual(wizardData[5].Split('=')[1], "Pa55word");
        }

        #endregion

        /// <summary>
        /// Load Peristance manager.
        /// </summary>
        private static IPersistanceManager LoadPersistanceManager(string fileName)
        {
            string xmlPath = Path.Combine(clusterConfigurationXmlPath, "ClusterConfigurationModelBase.xml");

            IPersistanceManager manager = new CustomFilePersistanceManager(xmlPath, CustomPersistanceManagerForUnitTests.ModelAccessMode.Configuration);
            manager.Load();

            ClusterConfigurationUtility.Configure(manager, Path.Combine(jsonPath, fileName), null);

            return manager;
        }
    }
}
