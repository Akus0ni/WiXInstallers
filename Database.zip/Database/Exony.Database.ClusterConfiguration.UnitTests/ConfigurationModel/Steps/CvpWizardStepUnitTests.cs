﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using System;
    using System.Text.Json;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.Common.Folders;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Data.SqlClient;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System.Runtime.Serialization;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Moq;
    using System.Reflection;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Database.ClusterConfiguration.Collections;

    [TestClass]
    public class CvpWizardStepUnitTests
    {
        #region ConfigPaths

        /// <summary>
        /// File path to the CvpWizardstep json files.
        /// </summary>
        private static string JsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Steps\\Config\\CvpWizardStepJson");

        /// <summary>
        /// File path to the cluster configuration model xml file.
        /// </summary>
        private static string ClusterConfigurationModelFilePath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Steps\\Config\\ClusterConfigurationXmlFile\\ClusterConfigurationCvp.xml");

        #endregion

        #region TestMethods

        [TestMethod]
        [TestCategory("CvpWizardChangeStep")]
        public void parseFile_AddCvpStepWithoutLinkedIcm_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("NullLinkedIcm.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCvpOpsConsoleServer) && lr.Name.Equals("cvpOperations")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "USQACVP120OPS");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.32.90.254");
            Assert.AreEqual(icmLogicalResource.Version, "12");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.Last().ConnectionString.Split(';');

            ILogicalResource icmLogicalResource1 = manager.Configuration.LogicalResources.
                Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.CiscoCicm) &&
                lr.Name.Equals("IcmServer1")).FirstOrDefault();

            bool checkLinkedIcmExist = icmLogicalResource.ParentResourceMembers.
                FirstOrDefault(crm => Equals(crm.ParentResource, icmLogicalResource1)) is null ? true : false;

            Assert.IsTrue(checkLinkedIcmExist);
        }

        #endregion

        /// <summary>
        /// Load Peristance manager.
        /// </summary>
        private static IPersistanceManager LoadPersistanceManager(string fileName)
        {
            string xmlPath = ClusterConfigurationModelFilePath;

            IPersistanceManager manager = new CustomFilePersistanceManager(xmlPath, CustomPersistanceManagerForUnitTests.ModelAccessMode.Configuration);

            manager.Load();

            ClusterConfigurationUtility.Configure(manager, Path.Combine(JsonPath, fileName), null);

            return manager;
        } 
    }
}