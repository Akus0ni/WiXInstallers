﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using System;
    using System.Text.Json;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.Common.Folders;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Data.SqlClient;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System.Runtime.Serialization;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Moq;
    using System.Reflection;
    using Exony.Database.ClusterConfiguration.Setup;
    using Exony.Database.ClusterConfiguration.Collections;

    [TestClass]
    public class AvayaWizardStepUnitTests
    {
        #region ConfigPaths

        /// <summary>
        /// File path to the AvayaWizardstep json files.
        /// </summary>
        private static string JsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Steps\\Config\\AvayaWizardStepJson");

        /// <summary>
        /// File path to the cluster configuration model xml file.
        /// </summary>
        private static string ClusterConfigurationModelFilePath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Steps\\Config\\ClusterConfigurationXmlFile\\ClusterConfigurationAvaya.xml");

        #endregion

        #region TestMethods

        [TestMethod]
        [TestCategory("AvayaWizardChangeStep")]
        public void parseFile_AddAvayaStep_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("ValidConfig.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.AvayaCms) && lr.Name.Equals("Avaya2")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "avaya1");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.32.90.201");
            Assert.AreEqual(icmLogicalResource.Version, "17");
            
            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.ElementAt(9).ConnectionString.Split(';');

            Assert.AreEqual(wizardData[8].Split('=')[1], "admin");
            Assert.AreEqual(wizardData[9].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[3].Split('=')[1], "10.32.90.201");
            Assert.AreEqual(wizardData[5].Split('=')[1], "1500");
            Assert.AreEqual(wizardData[6].Split('=')[1], "onsoctcp");
        }

        [TestMethod]
        [TestCategory("AvayaWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_AddAvayaIllegalVersion_InValid()
        {
            IPersistanceManager manager = LoadPersistanceManager("InValidConfig.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.AvayaCms) && lr.Name.Equals("Avaya2")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "avaya1");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.32.90.201");
            Assert.AreEqual(icmLogicalResource.Version, "21");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.ElementAt(9).ConnectionString.Split(';');

            Assert.AreEqual(wizardData[8].Split('=')[1], "admin");
            Assert.AreEqual(wizardData[9].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[3].Split('=')[1], "10.32.90.201");
            Assert.AreEqual(wizardData[5].Split('=')[1], "1500");
            Assert.AreEqual(wizardData[6].Split('=')[1], "onsoctcp");
        }

        [TestMethod]
        [TestCategory("AvayaWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_AddAvayaIllegalProtocol_InValid()
        {
            IPersistanceManager manager = LoadPersistanceManager("InvalidProtocol.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.AvayaCms) && lr.Name.Equals("Avaya2")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "avaya1");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.32.90.201");
            Assert.AreEqual(icmLogicalResource.Version, "21");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.ElementAt(9).ConnectionString.Split(';');

            Assert.AreEqual(wizardData[8].Split('=')[1], "admin");
            Assert.AreEqual(wizardData[9].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[3].Split('=')[1], "10.32.90.201");
            Assert.AreEqual(wizardData[5].Split('=')[1], "1500");
            Assert.AreEqual(wizardData[6].Split('=')[1], "onsoctcp");
        }

        [TestMethod]
        [TestCategory("AvayaWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_AddAvayaIllegalTimeZoneId_InValid()
        {
            IPersistanceManager manager = LoadPersistanceManager("InvalidTimeZoneId.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.AvayaCms) && lr.Name.Equals("Avaya2")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "avaya1");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.32.90.201");
            Assert.AreEqual(icmLogicalResource.Version, "21");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.ElementAt(9).ConnectionString.Split(';');

            Assert.AreEqual(wizardData[8].Split('=')[1], "admin");
            Assert.AreEqual(wizardData[9].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[3].Split('=')[1], "10.32.90.201");
            Assert.AreEqual(wizardData[5].Split('=')[1], "1500");
            Assert.AreEqual(wizardData[6].Split('=')[1], "onsoctcp");
        }

        [TestMethod]
        [TestCategory("AvayaWizardChangeStep")]
        public void parseFile_RemoveAvayaResource_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("RemoveValidConfig.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.AvayaCms) && lr.Name.Equals("Avaya")).FirstOrDefault();

            Assert.IsNull(icmLogicalResource);
        }

        [TestMethod]
        [TestCategory("AvayaWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_UpdateResNameAvayaStep_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdatedResNameConfig.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.AvayaCms) && lr.Name.Equals("Avaya2")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.DisplayName, "Avaya3");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "avaya1");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.32.90.201");
            Assert.AreEqual(icmLogicalResource.Version, "17");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.ElementAt(9).ConnectionString.Split(';');

            Assert.AreEqual(wizardData[8].Split('=')[1], "admin");
            Assert.AreEqual(wizardData[9].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[3].Split('=')[1], "10.32.90.201");
            Assert.AreEqual(wizardData[5].Split('=')[1], "1500");
            Assert.AreEqual(wizardData[6].Split('=')[1], "onsoctcp");
        }

        [TestMethod]
        [TestCategory("AvayaWizardChangeStep")]
        [ExpectedException(typeof(StepExecutionException))]
        public void parseFile_UpdateInValidTimeZoneAvayaStep_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdatedInValidTimeZoneIdConfig.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.AvayaCms) && lr.Name.Equals("Avaya")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(icmLogicalResource.DisplayName, "Avaya");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "avaya1");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.32.90.201");
            Assert.AreEqual(icmLogicalResource.Version, "17");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.ElementAt(9).ConnectionString.Split(';');

            Assert.AreEqual(wizardData[8].Split('=')[1], "admin");
            Assert.AreEqual(wizardData[9].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[3].Split('=')[1], "10.32.90.201");
            Assert.AreEqual(wizardData[5].Split('=')[1], "1500");
            Assert.AreEqual(wizardData[6].Split('=')[1], "onsoctcp");
        }

        [TestMethod]
        [TestCategory("AvayaWizardChangeStep")]
        public void parseFile_UpdateValidTimeZoneAvayaStep_Valid()
        {
            IPersistanceManager manager = LoadPersistanceManager("UpdatedValidTimeZoneIdConfig.json");

            ILogicalResource icmLogicalResource = manager.Configuration.LogicalResources.Where(lr => lr.ResourceType.InternalName.Equals(WellKnownClusterResourceTypes.AvayaCms) && lr.Name.Equals("Avaya")).FirstOrDefault();

            Assert.IsNotNull(icmLogicalResource);
            Assert.AreEqual(((AvayaCmsLogicalResource)icmLogicalResource).TimezoneId, "Alaskan Standard Time");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.ServerName, "avaya1");
            Assert.AreEqual(icmLogicalResource.PhysicalResources.FirstOrDefault().Components.FirstOrDefault().Server.DefaultAddress, "10.32.90.201");
            Assert.AreEqual(icmLogicalResource.Version, "17");

            string[] wizardData = icmLogicalResource.Configuration.PhysicalConnections.ElementAt(8).ConnectionString.Split(';');

            Assert.AreEqual(wizardData[8].Split('=')[1], "admin");
            Assert.AreEqual(wizardData[9].Split('=')[1], "egain@123");
            Assert.AreEqual(wizardData[3].Split('=')[1], "10.32.90.201");
            Assert.AreEqual(wizardData[5].Split('=')[1], "1500");
            Assert.AreEqual(wizardData[6].Split('=')[1], "onsoctcp");
        }

        #endregion

        /// <summary>
        /// Load Peristance manager.
        /// </summary>
        private static IPersistanceManager LoadPersistanceManager(string fileName)
        {
            string xmlPath = ClusterConfigurationModelFilePath;

            IPersistanceManager manager = new CustomFilePersistanceManager(xmlPath, CustomPersistanceManagerForUnitTests.ModelAccessMode.Configuration);

            manager.Load();

            ClusterConfigurationUtility.Configure(manager, Path.Combine(JsonPath, fileName), null);

            return manager;
        }
    }
}