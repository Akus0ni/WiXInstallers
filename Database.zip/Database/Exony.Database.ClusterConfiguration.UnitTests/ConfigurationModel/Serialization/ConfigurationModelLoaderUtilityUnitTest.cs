﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Serialization
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Reflection;

    [TestClass]
    public class ConfigurationModelLoaderUtilityUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Serialization\\Config\\ConfigurationModelLoaderUtilityJson");

        #endregion

        #region Test

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyStringValue_Exception()
        {
            LoadModelFromFile("EmptyStringValue.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        public void ParseFile_ValidStringValue_Success()
        {
            LoadModelFromFile("ValidStringValue.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidBooleanValue_Exception()
        {
            LoadModelFromFile("InvalidBooleanValue.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        public void ParseFile_ValidBooleanValue_Success()
        {
            LoadModelFromFile("ValidBooleanValue.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidIntegerValue_Exception()
        {
            LoadModelFromFile("InvalidIntegerValue.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        public void ParseFile_ValidIntegerValue_Success()
        {
            LoadModelFromFile("ValidIntegerValue.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullStringValueForRequiredField_Exception()
        {
            LoadModelFromFile("NullStringValueForRequiredField.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        public void ParseFile_NullStringValueForNullableField_Success()
        {
            LoadModelFromFile("NullStringValueForNullableField.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyStringValueForRequiredField_Exception()
        {
            LoadModelFromFile("EmptyStringValueForRequiredField.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        public void ParseFile_EmptyStringValueForCanBeEmptyField_Success()
        {
            LoadModelFromFile("EmptyStringValueForCanBeEmptyField.json");
        }

        [TestMethod]
        [TestCategory("ConfigurationModelLoaderUtility")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_BooleanValueInString_Exception()
        {
            LoadModelFromFile("BooleanValueInString.json");
        }

        #endregion

        /// <summary>
        /// Load cluster model from file path.
        /// </summary>
        private static ClusterConfigurationChangeModel LoadModelFromFile(string fileName)
        {
            string fullPath = Path.Combine(jsonPath, fileName);
            return ConfigurationModelLoader.LoadModelFromFile(fullPath);
        }
    }
}