﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using System;
    using System.Text.Json;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.Common.Folders;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Data.SqlClient;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System.Runtime.Serialization;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Moq;
    using System.Reflection;

    [TestClass]
    public class AvayaSerializationUnitTests
    {
        #region Config Json Path

        /// <summary>
        /// File path to the callmanagerwizardserialization json files.
        /// </summary>
        static string WizardSerializerJsonFolderPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Serialization\\Config\\AvayaWizardSerializerJson");

        #endregion

        private void LoadModelFromFile(string filePath)
        {
            filePath = Path.Combine(WizardSerializerJsonFolderPath, filePath);

            ConfigurationModelLoader.LoadModelFromFile(filePath);
        } 

        #region TestMethods

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_EmptyMode_Exception()
        {
            LoadModelFromFile("EmptyMode.json");
        }
       

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_ValidMode_Success() { 

            LoadModelFromFile("ValidMode.json");
        }
       
       [TestMethod]
       [TestCategory("RunWizardStepSerializer")]
       [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
       public void parseFile_InValidMode_Exception()
       {
           LoadModelFromFile("InValidMode.json");  
       }

       [TestMethod]
       [TestCategory("RunWizardStepSerializer")]
       [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
       public void parseFile_ResourceNameEmpty_Exception()
       {
           LoadModelFromFile("ResourceNameEmpty.json");
       }

       [TestMethod]
       [TestCategory("RunWizardStepSerializer")]
       [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
       public void parseFile_IncorrectResourceNameKey_Exception()
       {
           LoadModelFromFile("IncorrectResourceNameKey.json");
       }
    
       [TestMethod]
       [TestCategory("RunWizardStepSerializer")]
       [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
       public void parseFile_ServerNameEmpty_Exception()
       {
           LoadModelFromFile("ServerNameEmpty.json");
       }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerAddressEmpty_Exception()
        {
            LoadModelFromFile("ServerAddressEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_VersionEmpty_Exception()
        {
            LoadModelFromFile("VersionEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_TimeZoneDisplayEmpty_Exception()
        {
            LoadModelFromFile("TimeZoneDisplayEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_TimeZoneDisplayInValid_Exception()
        {
            LoadModelFromFile("TimeZoneDisplayInValid.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ProtocolInValid_Exception()
        {
            LoadModelFromFile("ProtocolInValid.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_UserNameEmpty_Exception()
        {
            LoadModelFromFile("UserNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_PasswordEmpty_Exception()
        {
            LoadModelFromFile("PasswordEmpty.json");
        }
        #endregion
    }
}