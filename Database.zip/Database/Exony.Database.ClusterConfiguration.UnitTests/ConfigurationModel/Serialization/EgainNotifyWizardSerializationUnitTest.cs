﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Serialization
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Reflection;

    [TestClass]
    public class EgainNotifyWizardSerializationUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Serialization\\Config\\EgainNotifyWizardSerializationJson");

        #endregion

        #region Test

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidWizardType_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidWizardType_Exception()
        {
            LoadModelFromFile("InvalidWizardType.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidMode_Exception()
        {
            LoadModelFromFile("InvalidMode.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidMode_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyResourceName_Exception()
        {
            LoadModelFromFile("EmptyResourceName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullResourceName_Exception()
        {
            LoadModelFromFile("NullResourceName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidResourceName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyServerName_Exception()
        {
            LoadModelFromFile("EmptyServerName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullServerName_Exception()
        {
            LoadModelFromFile("NullServerName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidServerName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyServerAddress_Exception()
        {
            LoadModelFromFile("EmptyServerAddress.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullServerAddress_Exception()
        {
            LoadModelFromFile("NullServerAddress.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidServerAddress_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDbCatalog_Exception()
        {
            LoadModelFromFile("EmptyDbCatalog.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDbCatalog_Exception()
        {
            LoadModelFromFile("NullDbCatalog.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidDbCatalogs_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDriver_Exception()
        {
            LoadModelFromFile("EmptyDriver.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDriver_Exception()
        {
            LoadModelFromFile("NullDriver.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidDriver_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyPort_Exception()
        {
            LoadModelFromFile("EmptyPort.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_NullPort_Sucess()
        {
            LoadModelFromFile("NullPort.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidPort_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDbUserName_Exception()
        {
            LoadModelFromFile("EmptyDbUserName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDbUserName_Exception()
        {
            LoadModelFromFile("NullDbUserName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidDbUserName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDbPassword_Exception()
        {
            LoadModelFromFile("EmptyDbPassword.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDbPassword_Exception()
        {
            LoadModelFromFile("NullDbPassword.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidDPassword_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidSslMode_Exception()
        {
            LoadModelFromFile("InvalidSslMode.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidSslMode_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidUpdateResourceName_Success()
        {
            LoadModelFromFile("ValidUpdateResourceName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidUpdateServerName_Success()
        {
            LoadModelFromFile("ValidUpdateServerName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidUpdateServerAddress_Success()
        {
            LoadModelFromFile("ValidUpdateServerAddress.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidUpdateCatalogueName_Success()
        {
            LoadModelFromFile("ValidUpdateCatalogueName.json");
        }

        [TestMethod]
        [TestCategory("EgainNotifyWizardStepSerializer")]
        public void ParseFile_ValidUpdateSslEnabled_Success()
        {
            LoadModelFromFile("ValidUpdateSslEnabled.json");
        }

        #endregion

        /// <summary>
        /// Load cluster model from file path.
        /// </summary>
        private static ClusterConfigurationChangeModel LoadModelFromFile(string fileName)
        {
            string fullPath = Path.Combine(jsonPath, fileName);
            return ConfigurationModelLoader.LoadModelFromFile(fullPath);
        }
    }
}
