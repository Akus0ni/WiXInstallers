﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using System;
    using System.Text.Json;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.Common.Folders;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Data.SqlClient;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System.Runtime.Serialization;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Moq;
    using System.Reflection;

    [TestClass]
    public class CvpSerializationUnitTests
    {
        #region Config Json Path

        /// <summary>
        /// File path to the callmanagerwizardserialization json files.
        /// </summary>
        static string WizardSerializerJsonFolderPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Serialization\\Config\\CvpWizardSerializerJson");

        #endregion

        private void LoadModelFromFile(string filePath)
        {
            filePath = Path.Combine(WizardSerializerJsonFolderPath, filePath);

            ConfigurationModelLoader.LoadModelFromFile(filePath);
        } 

        #region TestMethods

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_EmptyMode_Exception()
        {
            LoadModelFromFile("EmptyMode.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_ValidMode_Success() { 

            LoadModelFromFile("ValidMode.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_InValidMode_Exception()
        {
            LoadModelFromFile("InValidMode.json");  
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ResourceNameEmpty_Exception()
        {
            LoadModelFromFile("ResourceNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectResourceNameKey_Exception()
        {
            LoadModelFromFile("IncorrectResourceNameKey.json");
        }
       
        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerNameEmpty_Exception()
        {
            LoadModelFromFile("ServerNameEmpty.json");
        }


        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerAddressEmpty_Exception()
        {
            LoadModelFromFile("ServerAddressEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NegTimeOut_Exception()
        {
            LoadModelFromFile("NegTimeOut.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_CallSvrRes_Exception()
        {
            LoadModelFromFile("CallSvrResNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_CallSvrSvrName_Exception()
        {
            LoadModelFromFile("CallSvrSvrNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_CallSvrSvrAddress_Exception()
        {
            LoadModelFromFile("CallSvrSvrAddressEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_CallSvrLinkedIcm_Exception()
        {
            LoadModelFromFile("CallSvrLinkedIcmEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ReportResNameEmpty_Exception()
        {
            LoadModelFromFile("RepSvrResNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ReportSvrNameEmpty_Exception()
        {
            LoadModelFromFile("RepSvrNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ReportSvrAddrEmpty_Exception()
        {
            LoadModelFromFile("RepSvrAddrEmpty.json");
        }
        
        #endregion
    }
}