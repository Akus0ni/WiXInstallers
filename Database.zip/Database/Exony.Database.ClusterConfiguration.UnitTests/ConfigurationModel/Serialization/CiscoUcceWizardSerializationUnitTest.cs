﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Serialization.RunWizardStepSerializer
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Reflection;

    [TestClass]
    public class CiscoUcceWizardStepSerializerUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Serialization\\Config\\CiscoUcceWizardSerializerJson");

        #endregion

        #region Test

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidWizardType_Exception()
        {
            LoadModelFromFile("InvalidWizardType.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_ValidWizardType_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidMode_Exception()
        {
            LoadModelFromFile("InvalidMode.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_ValidMode_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyResourceName_Exception()
        {
            LoadModelFromFile("EmptyResourceName.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullResourceName_Exception()
        {
            LoadModelFromFile("NullResourceName.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_ValidResourceName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_DbIntegratedSecurityFalseNoDbCredential_Exception()
        {
            LoadModelFromFile("DbIntegratedSecurityFalseNoDbCredential.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_ProvisionableFlagTrueNoCommonDataSetFalse_Exception()
        {
            LoadModelFromFile("ProvisionableFlagTrueNoCommonDataSetFalse.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_DbIntegratedSecurityTrueNoCommonDataDefined_Success()
        {
            LoadModelFromFile("DbIntegratedSecurityTrueNoCommonDataDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_HdsFlagTrueNoPrimaryHdsDefined_Exception()
        {
            LoadModelFromFile("HdsFlagTrueNoPrimaryHdsDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_HdsFlagTruePrimaryHdsDefined_Success()
        {
            LoadModelFromFile("HdsFlagTruePrimaryHdsDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_DdsFlagTrueNoPrimaryHdsDefined_Exception()
        {
            LoadModelFromFile("DdsFlagTrueNoPrimaryHdsDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_DdsFlagTrueNoPrimaryDdsDefined_Exception()
        {
            LoadModelFromFile("DdsFlagTrueNoPrimaryDdsDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_CorrectDdsSetup_Success()
        {
            LoadModelFromFile("CorrectDdsSetup.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyNewResourceName_Exception()
        {
            LoadModelFromFile("EmptyNewResourceName.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullNewResourceName_Exception()
        {
            LoadModelFromFile("NullNewResourceName.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_ValidNewResourceName_Success()
        {
            LoadModelFromFile("ValidNewResourceName.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_ProvisionableFlagTrueNoPrimaryProvisioningDefined_Exception()
        {
            LoadModelFromFile("ProvisionableFlagTrueNoPrimaryProvisioningDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_ProvisionableFlagTruePrimaryProvisioningDefined_Success()
        {
            LoadModelFromFile("ProvisionableFlagTruePrimaryProvisioningDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        public void ParseFile_ProvisionableFlagTrueSecondaryProvisioningDefined_Success()
        {
            LoadModelFromFile("ProvisionableFlagTrueSecondaryProvisioningDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_SecondaryAwDataNotDefined_Exception()
        {
            LoadModelFromFile("SecondaryAwDataNotDefined.json");
        }

        [TestMethod]
        [TestCategory("CiscoUcceWizardSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_SecondaryProvisioningDataNotDefined_Exception()
        {
            LoadModelFromFile("SecondaryProvisioningDataNotDefined.json");
        }

        #endregion

        /// <summary>
        /// Load cluster model from file path.
        /// </summary>
        private static ClusterConfigurationChangeModel LoadModelFromFile(string fileName)
        {
            string fullPath = Path.Combine(jsonPath, fileName);
            return ConfigurationModelLoader.LoadModelFromFile(fullPath);
        }
    }
}
