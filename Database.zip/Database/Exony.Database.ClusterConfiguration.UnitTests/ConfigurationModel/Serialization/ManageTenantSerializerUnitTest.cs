﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Serialization
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Reflection;

    [TestClass]
    public class ManageTenantSerializerUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Serialization\\Config\\ManageTenantSerializationJson");

        #endregion

        #region Tests

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidWizardType_Exception()
        {
            LoadModelFromFile("InvalidWizardType.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        public void ParseFile_ValidWizardType_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidMode_Exception()
        {
            LoadModelFromFile("InvalidMode.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        public void ParseFile_ValidMode_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyTenantName_Exception()
        {
            LoadModelFromFile("EmptyTenantName.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullTenantName_Exception()
        {
            LoadModelFromFile("NullTenantName.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        public void ParseFile_ValidTenantName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        public void ParseFile_EmptyTenantDescription_Success()
        {
            LoadModelFromFile("EmptyTenantDescription.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        public void ParseFile_NullTenantDescription_Success()
        {
            LoadModelFromFile("NullTenantDescription.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        public void ParseFile_ValidTenantDescription_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("ManageTenantSerialization")]
        public void ParseFile_PropertiesNotDefined_Success()
        {
            LoadModelFromFile("PropertiesNotDefined.json");
        }

        #endregion

        /// <summary>
        /// Load cluster model from file path.
        /// </summary>
        private static ClusterConfigurationChangeModel LoadModelFromFile(string fileName)
        {
            string fullPath = Path.Combine(jsonPath, fileName);
            return ConfigurationModelLoader.LoadModelFromFile(fullPath);
        }
    }
}
