﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Serialization
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Reflection;

    [TestClass]
    public class RedshiftWizardSerializationUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Serialization\\Config\\RedshiftWizardSerializationJson");

        #endregion

        #region Test

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidWizardType_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidWizardType_Exception()
        {
            LoadModelFromFile("InvalidWizardType.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidMode_Exception()
        {
            LoadModelFromFile("InvalidMode.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidMode_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyResourceName_Exception()
        {
            LoadModelFromFile("EmptyResourceName.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullResourceName_Exception()
        {
            LoadModelFromFile("NullResourceName.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidResourceName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyServerName_Exception()
        {
            LoadModelFromFile("EmptyServerName.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullServerName_Exception()
        {
            LoadModelFromFile("NullServerName.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidServerName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyServerAddress_Exception()
        {
            LoadModelFromFile("EmptyServerAddress.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullServerAddress_Exception()
        {
            LoadModelFromFile("NullServerAddress.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidServerAddress_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_EmptyDbCatalog_Success()
        {
            LoadModelFromFile("EmptyDbCatalog.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_NullDbCatalog_Success()
        {
            LoadModelFromFile("NullDbCatalog.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidDbCatalogs_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDriver_Exception()
        {
            LoadModelFromFile("EmptyDriver.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDriver_Exception()
        {
            LoadModelFromFile("NullDriver.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidDriver_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyPort_Exception()
        {
            LoadModelFromFile("EmptyPort.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_NullPort_Sucess()
        {
            LoadModelFromFile("NullPort.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidPort_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDbUserName_NotIAMBased_Exception()
        {
            LoadModelFromFile("EmptyDbUserNameNotIAMBased.json");
        }
        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_EmptyDbUserName_IAMBased_Success()
        {
            LoadModelFromFile("EmptyDbUserNameIAMBased.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDbUserName_NotIAMBased_Exception()
        {
            LoadModelFromFile("NullDbUserNameNotIAMBased.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_NullDbUserName_IAMBased_Success()
        {
            LoadModelFromFile("NullDbUserNameIAMBased.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidDbUserName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDbPassword_NotIAMBased_Exception()
        {
            LoadModelFromFile("EmptyDbPasswordNotIAMBased.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_EmptyDbPassword_IAMBased_Success()
        {
            LoadModelFromFile("EmptyDbPasswordIAMBased.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDbPassword_NotIAMBased_Exception()
        {
            LoadModelFromFile("NullDbPasswordNotIAMBased.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_NullDbPassword_IAMBased_Success()
        {
            LoadModelFromFile("NullDbPasswordIAMBased.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidDPassword_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidIsIAmBasedAuthentication_Exception()
        {
            LoadModelFromFile("InvalidIsIAmBasedAuthentication.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidIsIAmBasedAuthentication_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidUpdateResourceName_Success()
        {
            LoadModelFromFile("ValidUpdateResourceName.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidUpdateServerName_Success()
        {
            LoadModelFromFile("ValidUpdateServerName.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidUpdateServerAddress_Success()
        {
            LoadModelFromFile("ValidUpdateServerAddress.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidUpdateCatalogueName_Success()
        {
            LoadModelFromFile("ValidUpdateCatalogueName.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidUpdateIsIAMBasedAuthentication_Success()
        {
            LoadModelFromFile("ValidUpdateIsIAMBasedAuthentication.json");
        }

        [TestMethod]
        [TestCategory("RedshiftWizardStepSerializer")]
        public void ParseFile_ValidUpdateTenantName_Success()
        {
            LoadModelFromFile("ValidUpdateTenantName.json");
        }

        #endregion

        /// <summary>
        /// Load cluster model from file path.
        /// </summary>
        private static ClusterConfigurationChangeModel LoadModelFromFile(string fileName)
        {
            string fullPath = Path.Combine(jsonPath, fileName);
            return ConfigurationModelLoader.LoadModelFromFile(fullPath);
        }
    }
}
