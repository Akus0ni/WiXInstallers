﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Steps
{
    using System;
    using System.Text.Json;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.LogicalResourceFolderMappings;
    using Exony.Database.ClusterConfiguration.LogicalResources;
    using Exony.Database.Common.Folders;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Data.SqlClient;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.Common.Enumerations;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Steps;
    using System.Runtime.Serialization;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Moq;
    using System.Reflection;

    [TestClass]
    public class CallManagerSerializationUnitTests
    {
        #region Config Json Path

        /// <summary>
        /// File path to the callmanagerwizardserialization json files.
        /// </summary>
        static string WizardSerializerJsonFolderPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            , "ConfigurationModel\\Serialization\\Config\\CallManagerWizardSerializerJson");

        #endregion

        private void LoadModelFromFile(string filePath)
        {
            filePath = Path.Combine(WizardSerializerJsonFolderPath, filePath);

            ConfigurationModelLoader.LoadModelFromFile(filePath);
        } 

        #region TestMethods

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_AllValidParameters_Valid()
        {
            LoadModelFromFile("AllValidParameters.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectStepType_Exception()
        {
            LoadModelFromFile("IncorrectStepType.json");
        }
        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_EmptyStepType_Exception()
        {
            LoadModelFromFile("EmptyStepType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullValueStepType_Exception()
        {
            LoadModelFromFile("NullValueStepType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullKeyValueStepType_Exception()
        {
            LoadModelFromFile("NullKeyValueStepType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_ValidWizardType_Success()
        {
            LoadModelFromFile("ValidWizardType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_InValidWizardType_Exception()
        {
            LoadModelFromFile("InValidWizardType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_EmptyWizardType_Exception()
        {
            LoadModelFromFile("EmptyWizardType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullValueWizardType_Exception()
        {
            LoadModelFromFile("NullValueWizardType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectKeyNameWizardType_Exception()
        {
            LoadModelFromFile("IncorrectKeyNameWizardType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullKeyNameWizardType_Exception()
        {
            LoadModelFromFile("NullKeyNameWizardType.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_ValidMode_Success() { 

            LoadModelFromFile("ValidMode.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_InValidMode_Exception()
        {
            LoadModelFromFile("InValidMode.json");  
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullValueMode_Exception()
        {
            LoadModelFromFile("NullValueMode.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullKeyValueMode_Exception()
        {
            LoadModelFromFile("NullKeyValueMode.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ResourceNameEmpty_Exception()
        {
            LoadModelFromFile("ResourceNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ResourceNameNullValue_Exception()
        {
            LoadModelFromFile("ResourceNameNullValue.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ResourceNameKeyNull_Exception()
        {
            LoadModelFromFile("ResourceNameKeyNull.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectResourceNameKey_Exception()
        {
            LoadModelFromFile("IncorrectResourceNameKey.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerNameEmpty_Exception()
        {
            LoadModelFromFile("ServerNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerNameNullValue_Exception()
        {
            LoadModelFromFile("ServerNameNullValue.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerNameKeyNull_Exception()
        {
            LoadModelFromFile("ServerNameKeyNull.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectServerNameKey_Exception()
        {
            LoadModelFromFile("IncorrectServerNameKey.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerAddressEmpty_Exception()
        {
            LoadModelFromFile("ServerAddressEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerAddressNullValue_Exception()
        {
            LoadModelFromFile("ServerAddressNullValue.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_ServerAddressKeyNull_Exception()
        {
            LoadModelFromFile("ServerAddressKeyNull.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectServerAddressKey_Exception()
        {
            LoadModelFromFile("IncorrectServerAddressKey.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_VersionEmpty_Exception()
        {
            LoadModelFromFile("VersionEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_VersionNullValue_Exception()
        {
            LoadModelFromFile("VersionNullValue.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_VersionKeyNull_Exception()
        {
            LoadModelFromFile("VersionKeyNull.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectVersionKey_Exception()
        {
            LoadModelFromFile("IncorrectVersionKey.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_UrlEmpty_Success()
        {
            LoadModelFromFile("UrlEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_UrlNullValue_Exception()
        {
            LoadModelFromFile("UrlNullValue.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_UrlNullKeyValue_Exception()
        {
            LoadModelFromFile("UrlNullKeyValue.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_UrlIncorrectKeyName_Exception()
        {
            LoadModelFromFile("UrlIncorrectKeyName.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_UserNameEmpty_Exception()
        {
            LoadModelFromFile("UserNameEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_UserNameNullValue_Exception()
        {
            LoadModelFromFile("UserNameNullValue.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_UserNameKeyNull_Exception()
        {
            LoadModelFromFile("UserNameKeyNull.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectUserNameKey_Exception()
        {
            LoadModelFromFile("IncorrectUserNameKey.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_PasswordEmpty_Exception()
        {
            LoadModelFromFile("PasswordEmpty.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_PasswordNullValue_Exception()
        {
            LoadModelFromFile("PasswordNullValue.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_PasswordKeyNull_Exception()
        {
            LoadModelFromFile("PasswordKeyNull.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_IncorrectPasswordKey_Exception()
        {
            LoadModelFromFile("IncorrectPasswordKey.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_EmptyTimeOut_Exception()
        {
            LoadModelFromFile("EmptyTimeOut.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_NullKeyValueTimeout_Valid()
        {
            LoadModelFromFile("NullKeyValueTimeout.json");   
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_LinkedIcmResourceNamesEmpty_Exception()
        {
            LoadModelFromFile("LinkedIcmResourceNamesEmpty.json");   
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_LinkedIcmResourceNamesNullValue_Valid()
        {
            LoadModelFromFile("LinkedIcmResourceNamesNullValue.json"); 
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_LinkedIcmResourceNamesKeyNullValue_Valid()
        {
            LoadModelFromFile("LinkedIcmResourceNamesKeyNullValue.json");  
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullValueKindServerName_Exception()
        {
            LoadModelFromFile("NullValueKindServerName.json");  
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullValueKindServerAddress_Exception()
        {
            LoadModelFromFile("NullValueKindServerAddress.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullValueKindVersion_Exception()
        {
            LoadModelFromFile("NullValueKindVersion.json");  
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_NullValueKindUrl_Exception()
        {
            LoadModelFromFile("NullValueKindUrl.json"); 
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullValueKindUserName_Exception()
        {
            LoadModelFromFile("NullValueKindUserName.json");
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void parseFile_NullValueKindPassword_Exception()
        {
            LoadModelFromFile("NullValueKindPassword.json");   
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_NullValueKindTimeout_Success()
        {
            LoadModelFromFile("NullValueKindTimeout.json"); 
        }

        [TestMethod]
        [TestCategory("RunWizardStepSerializer")]
        public void parseFile_NullValueKindLinkedIcmValues_Success()
        {
            LoadModelFromFile("NullValueKindLinkedIcmValues.json");
        }

        #endregion
    }
}