﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Serialization.RunWizardStepSerializer
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Reflection;

    [TestClass]
    public class EgainWizardStepSerializerUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Serialization\\Config\\EgainWizardSerializerJson");

        #endregion

        #region Test

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidWizardType_Exception()
        {
            LoadModelFromFile("InvalidWizardType.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidWizardType_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidMode_Exception()
        {
           LoadModelFromFile("InvalidMode.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidMode_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyResourceName_Exception()
        {
            LoadModelFromFile("EmptyResourceName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullResourceName_Exception()
        {
            LoadModelFromFile("NullResourceName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidResourceName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyServerName_Exception()
        {
            LoadModelFromFile("EmptyServerName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullServerName_Exception()
        {
            LoadModelFromFile("NullServerName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidServerName_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyServerAddress_Exception()
        {
            LoadModelFromFile("EmptyServerAddress.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullServerAddress_Exception()
        {
            LoadModelFromFile("NullServerAddress.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidServerAddress_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDbCatalog_Exception()
        {
            LoadModelFromFile("EmptyDbCatalog.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDbCatalog_Exception()
        {
            LoadModelFromFile("NullDbCatalog.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidDbCatalogs_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidIntegratedSecurity_Exception()
        {
            LoadModelFromFile("InvalidIntegratedSecurity.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidIntegratedSecurityFalse_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IntegratedSecurityFlagFalseNoDbLoginDefined_Exception()
        {
            LoadModelFromFile("IntegratedSecurityFlagFalseNoDbLoginDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidIntegratedSecurityTrue_Success()
        {
            LoadModelFromFile("ValidIntegratedSecurityTrue.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDbUserId_Exception()
        {
            LoadModelFromFile("EmptyDbUserId.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDbUserId_Exception()
        {
            LoadModelFromFile("NullDbUserId.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidDbUserId_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyDbPassword_Exception()
        {
            LoadModelFromFile("EmptyDbPassword.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullDbPassword_Exception()
        {
            LoadModelFromFile("NullDbPassword.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidDbPassworde_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyNewResourceName_Exception()
        {
            LoadModelFromFile("EmptyNewResourceName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullNewResourceName_Exception()
        {
            LoadModelFromFile("NullNewResourceName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidNewResourceName_Success()
        {
            LoadModelFromFile("ValidNewResourceName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateServerName_Success()
        {
            LoadModelFromFile("UpdateServerName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateServerAddress_Success()
        {
            LoadModelFromFile("UpdateServerAddress.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateCatalogName_Success()
        {
            LoadModelFromFile("UpdateCatalogName.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateIntegratedSecurityTrue_Success()
        {
            LoadModelFromFile("UpdateIntegratedSecurity.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateIntegratedSecurityFalse_Success()
        {
            LoadModelFromFile("UpdateIntegratedSecurityFalse.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateIntegratedSecurityFalseNoDbDetailsChange_Success()
        {
            LoadModelFromFile("UpdateIntegratedSecurityFalseNoDbChange.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidIsAiComponentConfiguredFlag_Exception()
        {
            LoadModelFromFile("InvalidIsAiComponentConfiguredFlag.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidIsAiComponentConfiguredTrue_Success()
        {
            LoadModelFromFile("Valid.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IsAiComponentConfiguredFlagTrueNoServerNameDefined_Exception()
        {
            LoadModelFromFile("IsAiComponentConfiguredFlagTrueNoServerNameDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IsAiComponentConfiguredFlagTrueNoServerAddressDefined_Exception()
        {
            LoadModelFromFile("IsAiComponentConfiguredFlagTrueNoServerAddressDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IsAiComponentConfiguredFlagTrueNoCatalogueNameDefined_Exception()
        {
            LoadModelFromFile("IsAiComponentConfiguredFlagTrueNoCatalogueNameDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IsAiComponentConfiguredFlagTrueNoDriverDefined_Exception()
        {
            LoadModelFromFile("IsAiComponentConfiguredFlagTrueNoDriverDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IsAiComponentConfiguredFlagTrueNoUserNameDefined_Exception()
        {
            LoadModelFromFile("IsAiComponentConfiguredFlagTrueNoUserNameDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IsAiComponentConfiguredFlagTrueNoPasswordDefined_Exception()
        {
            LoadModelFromFile("IsAiComponentConfiguredFlagTrueNoPasswordDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        // This won't throw exception as it is not mandatory to have connection port defined for AI component because it will by default take 5432 as port.
        public void ParseFile_IsAiComponentConfiguredFlagTrueNoConnectionPortDefined_Success()
        {
            LoadModelFromFile("IsAiComponentConfiguredFlagTrueNoConnectionPortDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        // This won't throw exception as it is not mandatory to have SslEnabled defined for AI component because it will by default take true for SslEnabled.
        public void ParseFile_IsAiComponentConfiguredFlagTrueNoSslEnabledDefined_Success()
        {
            LoadModelFromFile("IsAiComponentConfiguredFlagTrueNoSslEnabledDefined.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_ValidIsAiComponentConfiguredFalse_Success()
        {
            LoadModelFromFile("ValidIsAiComponentConfiguredFalse.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateIsAiComponentConfiguredFalse_Success()
        {
            LoadModelFromFile("UpdateIsAiComponentConfigured.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateIsAiComponentConfiguredTrue_Success()
        {
            LoadModelFromFile("UpdateIsAiComponentConfiguredTrue.json");
        }

        [TestMethod]
        [TestCategory("EgainWizardStepSerializer")]
        public void ParseFile_UpdateIsAiComponentConfiguredTrueNoDbDetailsChange_Success()
        {
            LoadModelFromFile("UpdateIsAiComponentConfiguredTrueNoDbChange.json");
        }

        #endregion

        /// <summary>
        /// Load cluster model from file path.
        /// </summary>
        private static ClusterConfigurationChangeModel LoadModelFromFile(string fileName)
        {
            string fullPath = Path.Combine(jsonPath, fileName);
            return ConfigurationModelLoader.LoadModelFromFile(fullPath);
        }
    }
}