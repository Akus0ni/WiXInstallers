﻿#region Copyright © eGain Communications Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.ConfigurationModel.Serialization
{
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Database.ClusterConfiguration.ConfigurationModel.Serialization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.IO;
    using System.Reflection;

    [TestClass]
    public class ManageEquipmentMappingSerializerUnitTest
    {
        #region Fields

        /// <summary>
        /// Json test file path.
        /// </summary>
        /// 
        static string jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ConfigurationModel\\Serialization\\Config\\ManageEquipmentMappingSerializationJson");

        #endregion

        #region Json Value Validation

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IncorrectMode_Exception()
        {
            LoadModelFromFile("IncorrectMode.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        public void ParseFile_CorrectMode_Success()
        {
            LoadModelFromFile("CorrectMode.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyResourceNameValue_Exception()
        {
            LoadModelFromFile("EmptyResourceNameValue.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullResourceNameValue_Exception()
        {
            LoadModelFromFile("NullResourceNameValue.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_EmptyTenantNameValue_Exception()
        {
            LoadModelFromFile("EmptyTenantNameValue.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_NullTenantNameValue_Exception()
        {
            LoadModelFromFile("NullTenantNameValue.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidDefaultImportLocation_Exception()
        {
            LoadModelFromFile("InvalidDefaultImportLocation.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        public void ParseFile_ValidDefaultImportLocation_Success()
        {
            LoadModelFromFile("ValidDefaultImportLocation.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        public void ParseFile_DefaultImportLocationDefaultValue_Success()
        {
            LoadModelFromFile("DefaultImportLocationDefaultValue.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidRemoteTMTenantId_Exception()
        {
            LoadModelFromFile("InvalidRemoteTMTenantId.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        public void ParseFile_ValidRemoteTMTenantId_Success()
        {
            LoadModelFromFile("ValidRemoteTMTenantId.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        public void ParseFile_RemoteTMTenantIdDefaultValue_Success()
        {
            LoadModelFromFile("RemoteTMTenantIdDefaultValue.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_InvalidStepType_Exception()
        {
            LoadModelFromFile("InvalidStepType.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        public void ParseFile_ValidStepType_Success()
        {
            LoadModelFromFile("ValidStepType.json");
        }

        #endregion

        #region Json Key Validation

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IncorrectModeKey_Exception()
        {
            LoadModelFromFile("IncorrectModeKey.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IncorrectStepTypeKey_Exception()
        {
            LoadModelFromFile("IncorrectStepTypeKey.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IncorrectStepDataKey_Exception()
        {
            LoadModelFromFile("IncorrectStepDataKey.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IncorrectResourceNameKey_Exception()
        {
            LoadModelFromFile("IncorrectResourceNameKey.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        [ExpectedException(typeof(System.Runtime.Serialization.SerializationException))]
        public void ParseFile_IncorrectTenantNameKey_Exception()
        {
            LoadModelFromFile("IncorrectTenantNameKey.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        public void ParseFile_IncorrectDefaultImportLocationKey_Exception()
        {
            LoadModelFromFile("IncorrectDefaultImportLocationKey.json");
        }

        [TestMethod]
        [TestCategory("ManageEquipmentMappingSerialization")]
        public void ParseFile_IncorrectRemoteTMTenantIdKey_Exception()
        {
            LoadModelFromFile("IncorrectRemoteTMTenantIdKey.json");
        }

        #endregion

        /// <summary>
        /// Load cluster model from file path.
        /// </summary>
        private static ClusterConfigurationChangeModel LoadModelFromFile(string fileName)
        {
            string fullPath = Path.Combine(jsonPath, fileName);
            return ConfigurationModelLoader.LoadModelFromFile(fullPath);
        }
    }
}
