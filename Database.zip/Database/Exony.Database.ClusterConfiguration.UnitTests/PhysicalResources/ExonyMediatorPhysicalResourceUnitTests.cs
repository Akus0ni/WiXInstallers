#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion
namespace Exony.Database.ClusterConfiguration.UnitTests.PhysicalResources
{
    using System;

    using Exony.Database.ClusterConfiguration.Collections;
    using Exony.Database.ClusterConfiguration.PhysicalResources;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;

    [TestClass]
    public class ExonyMediatorPhysicalResourceUnitTests
    {
        [TestMethod]
        [TestCategory("Database")]
        public void TestLocalRelativePath()
        {
            var mockParent = new Mock<ILogicalResource>(MockBehavior.Strict);
            mockParent.Setup(x => x.Configuration).Returns(new ClusterConfiguration());
            mockParent.Setup(x => x.PhysicalResources).Returns(new PhysicalResourceCollection(mockParent.Object));
            var mediatorResource = new ExonyMediatorPhysicalResource(mockParent.Object);

            mediatorResource.StateFolderPath = ".\\Folder";

            Assert.AreEqual(".\\Folder", mediatorResource.StateFolderPath);
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestLocalAbsolutePath()
        {
            var mockParent = new Mock<ILogicalResource>(MockBehavior.Strict);
            mockParent.Setup(x => x.Configuration).Returns(new ClusterConfiguration());
            mockParent.Setup(x => x.PhysicalResources).Returns(new PhysicalResourceCollection(mockParent.Object));
            var mediatorResource = new ExonyMediatorPhysicalResource(mockParent.Object);

            mediatorResource.StateFolderPath = "C:\\Folder";

            Assert.AreEqual("C:\\Folder", mediatorResource.StateFolderPath);
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestRemoteAbsolutePath()
        {
            var mockParent = new Mock<ILogicalResource>(MockBehavior.Strict);
            mockParent.Setup(x => x.Configuration).Returns(new ClusterConfiguration());
            mockParent.Setup(x => x.PhysicalResources).Returns(new PhysicalResourceCollection(mockParent.Object));
            var mediatorResource = new ExonyMediatorPhysicalResource(mockParent.Object);

            try
            {
                mediatorResource.StateFolderPath = "\\\\machine\\Folder";
                Assert.Fail();
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual(Resources.String_Validation_Value_Not_Valid_Directory_Path, e.Message);
            }
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestInvalidPath()
        {
            var mockParent = new Mock<ILogicalResource>(MockBehavior.Strict);
            mockParent.Setup(x => x.Configuration).Returns(new ClusterConfiguration());
            mockParent.Setup(x => x.PhysicalResources).Returns(new PhysicalResourceCollection(mockParent.Object));
            var mediatorResource = new ExonyMediatorPhysicalResource(mockParent.Object);

            try
            {
                mediatorResource.StateFolderPath = "https://www.google.com";
                Assert.Fail();
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual(Resources.String_Validation_Value_Not_Valid_Directory_Path, e.Message);
            }
        }
    }
}