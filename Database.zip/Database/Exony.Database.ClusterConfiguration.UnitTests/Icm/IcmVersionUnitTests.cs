#region Copyright © Exony Limited. All rights reserved.

// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

#endregion

namespace Exony.Database.ClusterConfiguration.UnitTests.Icm
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    using Exony.Database.ClusterConfiguration.Icm;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class IcmVersionUnitTests
    {
        #region Public Methods and Operators

        /// <summary>
        /// Tests the icm version.
        /// </summary>
        [TestMethod]
        [TestCategory("Database")]
        public void TestIcmVersion()
        {
            FieldInfo[] fields = typeof(IcmVersion).GetFields(BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Public);

            int versionCount = fields.Count(val => val.FieldType == typeof(IcmVersion));
            FieldInfo listInfo = fields.FirstOrDefault(val => val.FieldType == typeof(List<IcmVersion>));

            Assert.IsNotNull(listInfo, "IcmVersion internal semi-cache of versions is not an enumerable or cannot be found.");
            IEnumerable<IcmVersion> staticList = (IEnumerable<IcmVersion>)listInfo.GetValue(IcmVersion.UNKNOWN);
            IList<IcmVersion> icmVersions = staticList.ToList();
            foreach (IcmVersion version in icmVersions)
            {
                IcmVersion parsedVersion = IcmVersion.Parse(string.Format("{0}.{1}.{2}", version.MajorVersion, version.MinorVersion, version.BuildNumber));
                Assert.AreSame(version, parsedVersion, "IcmVersion returned by IcmVersion.Parse is not the same reference as otherwise returned by the static field.");
            }

            Assert.AreEqual(icmVersions.Count(), versionCount, "IcmVersion internal list dosen't match up to the amount of static implementations in the class itself.");
        }

        /// <summary>
        /// Tests the non integer part one fails.
        /// </summary>
        [TestMethod]
        [TestCategory("Database")]
        public void TestNonIntegerFails()
        {
            // Test first part fails non-numeric
            this.TestParseFail("BAZ.45", true);
            // Test second part fails non-numeric
            this.TestParseFail("143.BAR", true);
            // Test third part fails non-numeric
            this.TestParseFail("143.23.FOO", true);
            // Test single part version fails
            this.TestParseFail("143", true);
            // Test null version fails
            this.TestParseFail(string.Empty, false);
        }

        /// <summary>
        /// Tests the non integer is invalid when we arent throwing exceptions.
        /// </summary>
        [TestMethod]
        [TestCategory("Database")]
        public void TestNonIntegerIsInvalidWhenWeArentThrowingExceptions()
        {
            Assert.AreEqual(IcmVersion.UNKNOWN, IcmVersion.Parse(null, true));
            Assert.AreEqual(IcmVersion.UNKNOWN, IcmVersion.Parse("123", true));
            Assert.AreEqual(IcmVersion.UNKNOWN, IcmVersion.Parse("123.BAR", true));
            Assert.AreEqual(IcmVersion.UNKNOWN, IcmVersion.Parse("FOO.123", true));
            Assert.AreEqual(IcmVersion.UNKNOWN, IcmVersion.Parse("123.456.BAZ", true));
            Assert.AreEqual(IcmVersion.VERSION_5_0, IcmVersion.Parse("75.1.0", true));
        }

        /// <summary>
        /// Tests the parse works.
        /// </summary>
        [TestMethod]
        [TestCategory("Database")]
        public void TestParseWorks()
        {
            const string VersionString = "123.456.789";
            var version = IcmVersion.Parse(VersionString);
            Assert.AreEqual(123, version.MajorVersion);
            Assert.AreEqual(456, version.MinorVersion);
            Assert.AreEqual(789, version.BuildNumber);
            Assert.AreEqual(VersionString, version.VersionName);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Tests the parser fails.
        /// </summary>
        /// <param name="parseString">The parse string.</param>
        /// <param name="compareResult">if set to <c>true</c> [compare result].</param>
        private void TestParseFail(string parseString, bool compareResult)
        {
            try
            {
                IcmVersion.Parse(compareResult ? parseString : null);
                Assert.Fail();
            }
            catch (ArgumentException e)
            {
                Assert.AreEqual("version", e.ParamName);
                if (compareResult)
                {
                    Assert.AreEqual(string.Format(@"Invalid version string: ""{1}""{0}Parameter name: version", Environment.NewLine, parseString), e.Message);
                }
            }
        }

        #endregion
    }
}