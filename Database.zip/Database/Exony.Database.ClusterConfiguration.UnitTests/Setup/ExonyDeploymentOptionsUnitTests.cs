#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion
namespace Exony.Database.ClusterConfiguration.UnitTests.Setup
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Xml;

    using Exony.Database.ClusterConfiguration.Setup;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Resources = Exony.Database.ClusterConfiguration.UnitTests.Properties.Resources;

    [TestClass]
    public class ExonyDeploymentOptionsUnitTests
    {
        [TestMethod]
        [TestCategory("Database")]
        public void TestValidateSimple()
        {
            var clusterConfig = new ClusterConfiguration();

            using (var reader = new XmlTextReader(new MemoryStream(Resources.AllInOneBasicConfig)))
            {
                clusterConfig.ReadXml(reader);

                var exonyDeploymentOptions = new ExonyDeploymentOptions(clusterConfig);

                var validationResults = exonyDeploymentOptions.Validate();

                Assert.AreEqual(validationResults.Count(), 0);
            }
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestValidateFourTeirWithBadSecondary()
        {
            var clusterConfig = new ClusterConfiguration();

            using (var reader = new XmlTextReader(new MemoryStream(Resources.FourTierWithBadSecondary)))
            {
                clusterConfig.ReadXml(reader);

                var exonyDeploymentOptions = new ExonyDeploymentOptions(clusterConfig);

                var validationResults = exonyDeploymentOptions.Validate();

                Assert.AreEqual(validationResults.Count(), 0);
            }
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestWithUNCMediatorPath()
        {
            var clusterConfig = new ClusterConfiguration();

            using (var reader = new XmlTextReader(new MemoryStream(Resources.WithUNC)))
            {
                try
                {
                    clusterConfig.ReadXml(reader);
                    Assert.Fail("should fail.");
                }
                catch (ArgumentException e)
                {
                    Assert.IsInstanceOfType(e.InnerException, typeof(TargetInvocationException));
                    Assert.IsInstanceOfType(e.InnerException.InnerException, typeof(ArgumentException));
                    Assert.IsNull(e.InnerException.InnerException.InnerException);

                    Assert.AreEqual(@"Error setting property named STATE_FOLDER_PATH with value \\SKYNET\Backups in cluster resource of id cbff5295-1c0b-4012-bd52-9843b80c7df3.", e.Message);
                    Assert.AreEqual("The value must be a valid directory path", e.InnerException.InnerException.Message);
                }
            }
        }
    }
}