namespace Exony.Database.ClusterConfiguration.UnitTests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ClusterEnumToolsUnitTests
    {
        [TestMethod]
        [TestCategory("Database")]
        public void TestGetDeploymentTypes()
        {
            Assert.AreEqual(IcmDeploymentType.NAM, ClusterEnumTools.GetDeploymentType(1, 10, 5));
            Assert.AreEqual(IcmDeploymentType.IVRICM, ClusterEnumTools.GetDeploymentType(2, 10, 5));
            Assert.AreEqual(IcmDeploymentType.NAMRogger, ClusterEnumTools.GetDeploymentType(3, 10, 5));
            Assert.AreEqual(IcmDeploymentType.ICMRouterLogger, ClusterEnumTools.GetDeploymentType(4, 10, 5));
            Assert.AreEqual(IcmDeploymentType.UCCE8000, ClusterEnumTools.GetDeploymentType(5, 10, 5));
            Assert.AreEqual(IcmDeploymentType.UCCE12000, ClusterEnumTools.GetDeploymentType(6, 10, 5));
            Assert.AreEqual(IcmDeploymentType.CCE, ClusterEnumTools.GetDeploymentType(7, 10, 5));
            Assert.AreEqual(IcmDeploymentType.ICMRogger, ClusterEnumTools.GetDeploymentType(8, 10, 5));
            Assert.AreEqual(IcmDeploymentType.UCCE4000, ClusterEnumTools.GetDeploymentType(9, 10, 5));
            Assert.AreEqual(IcmDeploymentType.PackagedCCELab, ClusterEnumTools.GetDeploymentType(10, 10, 5));
            Assert.AreEqual(IcmDeploymentType.HCS1000, ClusterEnumTools.GetDeploymentType(11, 10, 5));
            Assert.AreEqual(IcmDeploymentType.HCS500, ClusterEnumTools.GetDeploymentType(12, 10, 5));
            Assert.AreEqual(IcmDeploymentType.UCCE450, ClusterEnumTools.GetDeploymentType(13, 10, 5));
            Assert.AreEqual(IcmDeploymentType.HCS4000, ClusterEnumTools.GetDeploymentType(14, 10, 5));
            Assert.AreEqual(IcmDeploymentType.HCS12000, ClusterEnumTools.GetDeploymentType(15, 10, 5));
            Assert.AreEqual(IcmDeploymentType.Standard, ClusterEnumTools.GetDeploymentType(999, 10, 5));
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestGetDeploymentTypeString()
        {
            Assert.AreEqual("CCE", ClusterEnumTools.GetDeploymentTypeString(IcmDeploymentType.CCE));
        }

        [TestMethod]
        [TestCategory("Database")]
        public void TestGetDeploymentType()
        {
            Assert.AreEqual(IcmDeploymentType.None, ClusterEnumTools.GetDeploymentType(null));
            Assert.AreEqual(IcmDeploymentType.None, ClusterEnumTools.GetDeploymentType(string.Empty));
            Assert.AreEqual(IcmDeploymentType.CCE, ClusterEnumTools.GetDeploymentType("CCE"));
        }
    }
}
