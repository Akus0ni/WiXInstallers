﻿#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Exony.Database.ClusterConfiguration.Utility
{
    using CommandLine;
    using Exony.Database.ClusterConfiguration.Persistance;
    using Exony.Database.ClusterConfiguration.ConfigurationModel;
    using Exony.Diagnostics;
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Diagnostics;
    using System.Text;

    public class Program
    {
        #region Error Codes

        /// <summary>
        /// Generic execution error code.
        /// </summary>
        private const int ERROR_EXECUTION_FAILURE = 1;

        /// <summary>
        /// Invalid arguments supplied.
        /// </summary>
        private const int ERROR_INVALID_PARAMETERS = 2;

        #endregion

        #region Actions

        /// <summary>
        /// Action to upgrade the model.
        /// </summary>
        private const string ACTION_UPGRADE = "upgrade";

        /// <summary>
        /// Action to configure the model.
        /// </summary>
        private const string ACTION_CONFIGURE = "configure";

        #endregion

        #region Fields

        /// <summary>
        /// Logger for this class.
        /// </summary>
        private static ISystemLogger log = new SystemLogger();

        #endregion

        #region Command Line Options

        /// <summary>
        /// Command line options.
        /// </summary>
        public class Options
        {
            [Option('a', "actions", Required = true, HelpText = "The actions to perform.")]
            public string Actions { get; set; }

            [Option('s', "dbServer", Required = false, HelpText = "The database server for connections.", Default = "localhost")]
            public string DbServer { get; set; }

            [Option('c', "dbCatalog", Required = false, HelpText = "The database catalog for connections.", Default ="Portal")]
            public string DbCatalog { get; set; }

            [Option('u', "dbUser", Required = false, HelpText = "The database user for connections.", Default = null)]
            public string DbUser { get; set; }

            [Option('p', "dbPassword", Required = false, HelpText = "The database password for connections.", Default = null)]
            public string DbPassword { get; set; }

            [Option('d', "debug", Required = false, HelpText = "Allow remote debugger to attach.", Default = false)]
            public bool Debug { get; set; }

            [Option('j', "configPath", Required = false, HelpText = "Path to configuration json.", Default = false)]
            public string configPath { get; set; }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Main entry point for this application.
        /// </summary>
        public static void Main(string[] args)
        {
            Parser.Default.ParseArguments<Options>(args)
                .WithParsed(RunOptions)
                .WithNotParsed(HandleParseError);
        }

        /// <summary>
        /// Run this command line application with the specified options.
        /// </summary>
        private static void RunOptions(Options options)
        {
            if (options.Debug)
            {
                Debugger.Launch();
                Debugger.Break();
            }

            IPersistanceManager manager;

            string dbConnectionString;

            try
            {
                dbConnectionString = GetDbConnectionString(options);

                manager = SqlPersistanceManagerFactory.Create(dbConnectionString);

                log.Debug("Loading model...");
                manager.Load();
                log.Debug("Model loaded successfully");
            }
            catch (Exception ex)
            {
                log.Error("Failed to load cluster model from database", ex);
				Environment.ExitCode = ERROR_EXECUTION_FAILURE;
                return;
            }

            string[] actionParts = options.Actions.Split(',');

            foreach (string currentAction in actionParts)
            {
                if (string.Equals(currentAction, ACTION_UPGRADE, StringComparison.InvariantCultureIgnoreCase))
                {
                    try
                    {
                        if (manager.UpgradeRequired)
                        {
                            log.Debug("Upgrading model...");
                            manager.Upgrade();
                            log.Debug("Model upgraded successfully");
                        }
                        else
                        {
                            log.Debug("Model is already up to date!");
                        }
                    }
                    catch (Exception ex)
                    {
                        log.Error("Failed to upgrade cluster model", ex);
                        Environment.ExitCode = ERROR_EXECUTION_FAILURE;
                        return;
                    }
                }
                else if (string.Equals(currentAction, ACTION_CONFIGURE, StringComparison.InvariantCultureIgnoreCase))
                {
                    try
                    {
                        IDataAdapter dataAdapter = new DbDataAdapter(dbConnectionString);
                        ClusterConfigurationUtility.Configure(manager, options.configPath, dataAdapter);
                        log.Info("Cluster model configured successfully.");
                    }
                    catch (Exception ex)
                    {
                        log.Error("Failed to configure cluster model", ex);
                        Environment.ExitCode = ERROR_EXECUTION_FAILURE;
                        return;
                    }
                }
                else
                {
                    log.Warning($"Unsupported action [{currentAction}]");
                    continue;
                }
                
            }
        }

        /// <summary>
        /// Invoked when the supplied arguments are not valid.
        /// </summary>
        private static void HandleParseError(IEnumerable<Error> errors)
        {
            StringBuilder errorBuilder = new StringBuilder();
            errorBuilder.AppendLine($"Invalid parameters supplied to command line tool.");

            foreach (Error currentError in errors)
            {
                errorBuilder.AppendLine("\t" + currentError.ToString());
            }

            log.Error(errorBuilder.ToString());

            Environment.ExitCode = ERROR_INVALID_PARAMETERS;
        }

        /// <summary>
        /// Get the DB connection string from the specified options.
        /// </summary>
        private static string GetDbConnectionString(Options options)
        {
            SqlConnectionStringBuilder builder =
                new SqlConnectionStringBuilder();

            builder.InitialCatalog = options.DbCatalog ?? "Portal";

            if (options.DbUser != null)
            {
                builder.UserID = options.DbUser;
                builder.Password = options.DbPassword;
            }
            else
            {
                builder.IntegratedSecurity = true;
            }

            builder.DataSource = options.DbServer ?? "localhost";

            return builder.ToString();
        }

        #endregion
    }
}
