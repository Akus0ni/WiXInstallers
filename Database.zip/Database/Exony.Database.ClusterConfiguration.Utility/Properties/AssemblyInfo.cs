﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Exony.Database.ClusterConfiguration.Utility")]
[assembly: AssemblyDescription("Command line utility for cluster configuration")]
[assembly: AssemblyConfiguration(Exony.Configuration.Product.Configuration)]
[assembly: AssemblyCompany(Exony.Configuration.Product.Company)]
[assembly: AssemblyProduct(Exony.Configuration.Product.ProductName)]
[assembly: AssemblyCopyright(Exony.Configuration.Product.Copyright)]
[assembly: AssemblyTrademark(Exony.Configuration.Product.Trademark)]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d8f7363f-d1e8-4545-8275-e1ec05058100")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion(Exony.Configuration.Product.Version)]
[assembly: AssemblyFileVersion(Exony.Configuration.Product.Version)]
[assembly: AssemblyInformationalVersion(Exony.Configuration.Product.BuildVersion)]
