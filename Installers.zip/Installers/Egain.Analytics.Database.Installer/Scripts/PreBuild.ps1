﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\Database\Exony.Database.Installer\bin\$BuildConfiguration" -Destination "$PSScriptRoot\~installerTemp\Database" -Recurse

Copy-Item "$PSScriptRoot\..\..\..\Database\Exony.Database.Installer.Batch\bin\$BuildConfiguration\*" -Destination "$PSScriptRoot\~installerTemp\Database" -Recurse -Force

Copy-Item "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.DbCheck\Exony.Portal.Tools.DbCheck.Console\bin\$BuildConfiguration" -Destination "$PSScriptRoot\~installerTemp\DBCheck" -Recurse -Force

Copy-Item "$PSScriptRoot\..\..\..\Database\Exony.Database.Runtime\bin\$BuildConfiguration\Exony.Reporting.Application.Logging.dll",
    "$PSScriptRoot\..\..\..\Database\Exony.Database.Runtime\bin\$BuildConfiguration\Exony.Reporting.Application.Logging.pdb" -Destination "$PSScriptRoot\~installerTemp\Database" -Recurse -Force
