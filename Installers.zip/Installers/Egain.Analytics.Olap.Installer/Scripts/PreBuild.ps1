﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\Olap\OlapProcessor\Service\bin\$BuildConfiguration" -Destination "$PSScriptRoot\~installerTemp\OLAP" -Recurse

#This must be Debug. DO NOT CHANGE
Copy-Item "$PSScriptRoot\..\..\..\Olap\Database\Portal\bin\Debug" -Destination "$PSScriptRoot\~installerTemp\Database" -Recurse

Copy-Item "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe", 
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe.config",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.pdb",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe.config",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.pdb",
    "$PSScriptRoot\..\..\..\ThirdParty\MSOLAP\Interop.VBA.dll" -Destination "$PSScriptRoot\~installerTemp\OLAP" -Recurse -Force
