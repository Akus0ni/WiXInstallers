﻿#$signToolPath = "C:\Program Files (x86)\Microsoft SDKs\ClickOnce\SignTool\signtool.exe"
#$certPath = "$PSScriptRoot\..\..\..\exony.pfx"
#$certPassphrase = "ohlund3"

#$files = Get-ChildItem -Path "$PSScriptRoot\..\..\..\Egain.Identity\Identity.Server.Compiled\bin" -Recurse -Include Exony*.dll,Egain*.dll 
#for ($i=0; $i -lt $files.Count; $i++) {
#    &$signToolPath sign /q /f $certPath /p $certPassphrase /fd SHA256 /t "http://timestamp.sectigo.com" $files[$i].FullName
#}

#$files = Get-ChildItem -Path "$PSScriptRoot\..\..\..\Egain.Identity\Identity.Server.WindowsAuthentication.Compiled\bin" -Recurse -Include Exony*.dll,Egain*.dll 
#for ($i=0; $i -lt $files.Count; $i++) {
#    &$signToolPath sign /q /f $certPath /p $certPassphrase /fd SHA256 /t "http://timestamp.sectigo.com" $files[$i].FullName
#}

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot\~installerTemp" -recurse
}

New-Item "$PSScriptRoot\~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\Egain.Identity\Identity.Server.Compiled" -Destination "$PSScriptRoot\~installerTemp\IdentityServer\Identity.Server" -Recurse
Copy-Item "$PSScriptRoot\..\..\..\Egain.Identity\Identity.Server.WindowsAuthentication.Compiled" -Destination "$PSScriptRoot\~installerTemp\IdentityServer\Identity.Server.WindowsAuthentication" -Recurse
