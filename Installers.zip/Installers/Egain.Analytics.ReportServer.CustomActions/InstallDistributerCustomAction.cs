﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

using Distributor;
using Egain.Analytics.Installer.CustomActions;
using System;
using WixToolset.Dtf.WindowsInstaller;

namespace Egain.Analytics.ReportServer.CustomActions
{
    public class InstallDistributerCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "InstallDistributerCustomAction.";

        private static class Keys
        {
            public const string UserName = "UserName";
            public const string Password = "Password";
            public const string FolderPath = "FolderPath";
        }

        #endregion

        public static Session sessionValue;

        [CustomAction]
        public static ActionResult InstallDistributer(Session session)
        {
            //System.Diagnostics.Debugger.Launch();
            session.Log("BEGIN InstallDistributer custom action");
            sessionValue = session;
            try
            {
                //split the progress bar in 100 small chunks
                ActionTextandProgressUpdates.ResetProgressBar(session, 100);
                ActionTextandProgressUpdates.IncrementProgressBar(session, 1);

                string userName = CustomActionUtils.GetVariableValue(
                       session, Keys.UserName, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Username [{userName}]"));

                string password = CustomActionUtils.GetVariableValue(
                           session, Keys.Password, ImmediateActionVariablePrefix);

                string folderPath = CustomActionUtils.GetVariableValue(
                           session, Keys.FolderPath, ImmediateActionVariablePrefix); 
                session.Log(CustomActionUtils.EscapeString($"Folder [{folderPath}]"));
            
                Distribute distributor = new Distribute();
                distributor.ProgressChanged += new EventHandler<string>(DistributorLogs);
                bool debug = false;
                bool showProgress = false;
                bool skipVisualStudio = true; // skip visual studio by default from version 17 onwards
                string executionAccountUser = userName;
                string executionAccountPassword = password;
                string sourceDir = folderPath;

                distributor.Install(debug, sourceDir, showProgress, skipVisualStudio, executionAccountUser, executionAccountPassword);
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action InstallDistributer {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        [CustomAction]
        public static ActionResult UnInstallDistributer(Session session)
        {
            //System.Diagnostics.Debugger.Launch();
            session.Log("BEGIN UnInstallDistributer custom action");
            sessionValue = session;
            try 
            {
                ActionTextandProgressUpdates.ResetProgressBar(session, 100);
                ActionTextandProgressUpdates.IncrementProgressBar(session, 1);

                string folderPath = CustomActionUtils.GetVariableValue(
                           session, Keys.FolderPath, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Folder [{folderPath}]"));

                Distribute distributor = new Distribute();
                distributor.ProgressChanged += new EventHandler<string>(DistributorLogs);
                bool debug = false;
                bool showProgress = false;
                bool skipVisualStudio = true; // skip visual studio by default from version 17 onwards
                string sourceDir = folderPath;

                distributor.UnInstall(debug, sourceDir, showProgress, skipVisualStudio);
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action UnInstallDistributer {0}", ex);
                return ActionResult.Failure;
            }
            return ActionResult.Success;
        }

        public static void DistributorLogs(object sender, string e)
        {
            ActionTextandProgressUpdates.StatusMessage(sessionValue, e);
            ActionTextandProgressUpdates.IncrementProgressBar(sessionValue, 1);
        }
        
    }

}
