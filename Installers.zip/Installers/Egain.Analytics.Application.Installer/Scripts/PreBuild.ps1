﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\Exony.Reporting.Application.Server\bin\$BuildConfiguration" -Destination "$PSScriptRoot\~installerTemp\Application" -Recurse
Copy-Item "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe", 
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe.config",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.pdb",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe.config",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.pdb" -Destination "$PSScriptRoot\~installerTemp\Application" -Recurse -Force


Add-Type -AssemblyName System.IO.Compression.FileSystem

if (-Not (Test-Path "$HOME/.s3cache")) 
{
  New-Item -Path "$HOME/.s3cache" -ItemType Directory
}

if (-Not (Test-Path "$HOME/.s3cache/msmdpump/Msmdpump_Sql_2019.zip")) 
{
  Write-Output "Cache miss for MSMDPUMP zip file - downloading from AWS S3"
  aws s3 cp s3://egain-analytics/build-assets/msmdpump/Msmdpump_Sql_2019.zip "$HOME/.s3cache/msmdpump/Msmdpump_Sql_2019.zip"
}

[System.IO.Compression.ZipFile]::ExtractToDirectory("$HOME/.s3cache/msmdpump/Msmdpump_Sql_2019.zip", "$PSScriptRoot/~installerTemp/OlapAnalyzer")
