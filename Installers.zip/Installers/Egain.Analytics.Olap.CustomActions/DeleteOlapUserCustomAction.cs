﻿// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Olap.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Custom action class to delete user from list
    /// </summary>
    public class DeleteOlapUserCustomAction
    {
        /// <summary>
        /// custom action method to delete user from a list
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        [CustomAction]
        public static ActionResult DeleteOlapUser(Session session)
        {
            try
            {
                session.Log("Begin DeleteOlapUserCustomAction");

                session.Database.ExecutePropertyQuery("LOGINLIST");

                //delete selected user
                string deleteUser = session["LOGINLIST"];
                string command = String.Format("DELETE FROM ListBox WHERE ListBox.Value = '{0}'", deleteUser);
                using (View view = session.Database.OpenView(command))
                {
                    view.Execute();
                    view.Close();
                }
                return ActionResult.Success;
            }
            catch(Exception ex)
            {
                session.Log(ex.Message);
                return ActionResult.Failure;
            }
            
        }
    }
}
