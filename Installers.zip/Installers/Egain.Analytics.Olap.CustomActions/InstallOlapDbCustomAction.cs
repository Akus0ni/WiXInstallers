// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Olap.CustomActions
{
    using Egain.Analytics.Installer.CustomActions;

    using System;
    using Exony.Olap.Database.DatabaseDeployer;

    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// custom action class to install olap database
    /// </summary>
    public class InstallOlapDbCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "InstallOlapDbCustomAction.";
        private static Session sessionData = null;

        private static class Keys
        {
            public const string OlapCatalogKey = "OlapDbCatalog";
            public const string AsUsersKey = "AsUsers";

            //repeated need to discuss with scott
            public const string SqlInstanceKey = "DbServer";
            public const string SqlCatalogKey = "DbCatalog";
            public const string SqlLoginNameKey = "DbUser";
            public const string SqlPasswordKey = "DbPassword";
            public const string OlapDbPathKey = "OlapDbPath";

        }

        /// <summary>
        /// custom action method to install olap database
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        #endregion
        [CustomAction]
        public static ActionResult InstallOlapDatabase(Session session)
        {
            try
            {
                session.Log("BEGIN InstallOlapDatabase custom action");
                sessionData = session;

                string olapCatalog = CustomActionUtils.GetVariableValue(
                        session, Keys.OlapCatalogKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"OlapCatalog [{olapCatalog}]"));
                string sqlInstance = CustomActionUtils.GetVariableValue(
                        session, Keys.SqlInstanceKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"SqlInstance [{sqlInstance}]"));
                string sqlCatalog = CustomActionUtils.GetVariableValue(
                        session, Keys.SqlCatalogKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"SqlCatalog [{sqlCatalog}]"));
                string sqlLoginName = CustomActionUtils.GetVariableValue(
                        session, Keys.SqlLoginNameKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"SqlLoginName [{sqlLoginName}]"));
                string sqlPassword = CustomActionUtils.GetVariableValue(
                        session, Keys.SqlPasswordKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"sqlPassword [{sqlPassword}]"));
                string olapDbPath = CustomActionUtils.GetVariableValue(
                        session, Keys.OlapDbPathKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"olapDbPath [{olapDbPath}]"));
                string asUsers = CustomActionUtils.GetVariableValue(
                        session, Keys.AsUsersKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"asUsers [{asUsers}]"));
                string olapInstance = Environment.MachineName;
                session.Log($"olapInstance {olapInstance}");

                string sqlIntegratedSecurity = "True";
                if (!String.IsNullOrEmpty(sqlLoginName))
                {
                    sqlIntegratedSecurity = "False";
                }
                session.Log(CustomActionUtils.EscapeString($"SqlIntegratedSecurity [{sqlIntegratedSecurity}]"));

                //getting args for olap database installation
                string[] args = new string[] { "/OLAPINSTANCE:" + olapInstance ,"/OLAPCATALOG:"+ olapCatalog,
                                               "/SQLINSTANCE:"+ sqlInstance,"/SQLCATALOG:"+ sqlCatalog,
                                               "/SQLLOGINNAME:"+ sqlLoginName,"/SQLPASSWORD:"+ sqlPassword,"/SQLINTEGRATEDSECURITY:"+sqlIntegratedSecurity,
                                               "/ASUSERS:"+ asUsers,"/SNAPSHOTISOLATION:True"};

                //Calling Olap database installation method
                Program installDb = new Program(olapDbPath);

                installDb.ProgressChanged += new EventHandler<string>(installDbProgressChanged);
                int result = installDb.Execute(args);

                session.Log(CustomActionUtils.EscapeString($"Olap Installation Result [{result}]"));

                if(result == -1)
                {
                    session.Log("Error installing Olap database");
                    return ActionResult.Failure;
                }
            }
            catch (Exception ex)
            {
                session.Log("Error installing Olap database {0}", ex);
                return ActionResult.Failure;
            }
            return ActionResult.Success;
        }

        /// <summary>
        /// method to update progressbar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="status"></param>
        private static void installDbProgressChanged(object sender, string status)
        {
            ActionTextandProgressUpdates.StatusMessage(sessionData, status);
            ActionTextandProgressUpdates.IncrementProgressBar(sessionData, 5);
        }
    }
}
