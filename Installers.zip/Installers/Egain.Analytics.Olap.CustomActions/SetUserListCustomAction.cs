﻿// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Olap.CustomActions
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// custom action class which collects the AS user from UI for olap db installation
    /// </summary>
    public class SetUserListCustomAction
    {
        /// <summary>
        /// custom action method which collects the AS user from UI for olap db installation
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        [CustomAction]
        public static ActionResult SetUserList(Session session)
        {
            try
            {
                session.Log("BEGIN SetUserListCustomAction");

                // get users from a list
                IList userlist = session.Database.ExecuteQuery("SELECT Value FROM ListBox WHERE ListBox.Property = 'LOGINLIST'");

                if(userlist.Count > 0)
                {
                    string[] existingUsers = new string[userlist.Count];
                    int index = 0;
                    foreach (string user in userlist)
                    {
                        existingUsers[index] = user;
                        index++;
                    }

                    string users = string.Join(",", existingUsers);
                    session["AS_USER_LIST"] = users;
                    session.Log("AS_USER_LIST {0}", session["AS_USER_LIST"]);
                }

                session["AS_USER_LIST"] = "";
                return ActionResult.Success;
            }
            catch(Exception ex)
            {
                session.Log(ex.Message);
                session.Log(ex.StackTrace);
                return ActionResult.Failure;
            }           
        }
    }
}
