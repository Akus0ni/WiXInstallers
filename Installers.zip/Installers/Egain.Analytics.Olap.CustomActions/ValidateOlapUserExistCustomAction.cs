﻿// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Olap.CustomActions
{
    using Egain.Analytics.Installer.CustomActions;

    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// custom action class to install validate AS user and it into listbox
    /// </summary>
    public class ValidateOlapUserExistCustomAction
    {
        /// <summary>
        /// custom action method to install validate AS user and it into listbox
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        [CustomAction]
        public static ActionResult ValidateUserOrServerOlap(Session session)
        {
            try
            {
                session.Log("BEGIN ValidateOlapUserCustomAction custom action");

                string username = session["AnalysisLoginsDlg.LoginText"].ToUpper();

                session.Log(username);

                //return if no user has been added
                if (string.IsNullOrEmpty(username))
                {
                    return ActionResult.Success;
                }

                //Validate user
                bool userExists = UserValidation.UserOrServerExist(username);

                if (userExists)
                {
                    //fetch existing record
                    IList existingUsers = session.Database.ExecuteQuery("SELECT Value FROM ListBox WHERE ListBox.Property = 'LOGINLIST'");

                    int index = session.Database.CountRows("ListBox", "Property = 'LOGINLIST'");

                    foreach(string user in existingUsers)
                    {
                        if(user == username)
                        {
                            session["USER_OR_SERVER_EXIST"] = "2";
                            session["AnalysisLoginsDlg.LoginText"] = "";
                            return ActionResult.Success;
                        }
                    }


                    View view = session.Database.OpenView("SELECT * FROM ListBox");
                    view.Execute();

                    Record record = session.Database.CreateRecord(4);

                    record.SetString(1, "LOGINLIST");
                    record.SetInteger(2, ++index);
                    record.SetString(3, username);
                    record.SetString(4, username);

                    //insert new user
                    view.InsertTemporary(record);
                    view.Close();

                    session["USER_OR_SERVER_EXIST"] = "1";
                    session["AnalysisLoginsDlg.LoginText"] = "";

                }
                else
                {
                    session["USER_OR_SERVER_EXIST"] = "0";
                }

            }
            catch (Exception ex)
            {
                session.Log("Error validation user {0}", ex.Message);
                session.Log("Error validation user {0}", ex.StackTrace);
                session["USER_OR_SERVER_EXIST"] = "0";
                return ActionResult.Success;               
            }
            return ActionResult.Success;
        }
    }
}
