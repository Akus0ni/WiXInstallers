﻿// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Olap.CustomActions
{
    using Egain.Analytics.Installer.CustomActions;
    using Microsoft.AnalysisServices;
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using System.Xml;

    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// custom action class to delete olap database
    /// </summary>
    public class DropOlapDbCustomAction
    {
        /// <summary>
        /// custom action to delete olap database
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        [CustomAction]
        public static ActionResult DropOlapDb(Session session)
        {
            try
            {
                session.Log("Begin DropOlapDbCustomAction");

                ActionTextandProgressUpdates.StatusMessage(session, "Delete Olap Database started");
                ActionTextandProgressUpdates.IncrementProgressBar(session, 5);

                string server = Environment.MachineName;
                session.Log("Olap Server {0}", server);

                //Return if drop olap database option not selected
                if (session["DROP_OLAP_DB"] == "0")
                {
                    return ActionResult.Success;
                }

                //Show MessageBox if uninstalling component in silent mode
                if (string.IsNullOrEmpty(session["DROP_OLAP_DB"]))
                {
                    DialogResult result = MessageBox.Show("Do you want to delete OLAP database?", "Delete OLAP Database", MessageBoxButtons.YesNo);
                    if (result == DialogResult.No) 
                    { 
                        return ActionResult.Success;
                    }
                } 

                string catalog = string.Empty;

                //Get OLAP catalog name
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Exony\\Components\\OLAP"))
                {
                    if (key != null)
                    {
                        catalog = key.GetValue("OlapCatalog") as string;
                    }
                }
                session.Log("OlapCatalog {0}", catalog);

                DeleteOlapDatabase(server, catalog, session);

                ActionTextandProgressUpdates.StatusMessage(session, "Delete Olap Database completed");
                ActionTextandProgressUpdates.IncrementProgressBar(session, 5);

            }
            catch (Exception ex)
            {
                session.Log(ex.Message);
                return ActionResult.Failure;
            }
            
            return ActionResult.Success;
        }

        /// <summary>
        /// Method connects with analysis server and delete a olap database
        /// </summary>
        /// <param name="serverName"></param>
        /// <param name="databaseName"></param>
        /// <param name="session"></param>
        private static void DeleteOlapDatabase(string serverName,string databaseName,Session session)
        {
            try
            {
                //Connect to the Analysis Services server
                Server server = new Server();
                server.Connect($"Data Source={serverName}");

                try
                {
                    //Check if the database exists
                    Microsoft.AnalysisServices.Database database = server.Databases.FindByName(databaseName);
                    if (database == null)
                    {
                        session.Log("Olap Database '{0}' does not exist.", databaseName);

                    }
                    else
                    {
                        //Delete the database
                        server.Databases[databaseName].Drop();
                        session.Log("Olap Database '{0}' deleted successfully.", databaseName);

                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    //Disconnect from the Analysis Services server
                    server.Disconnect();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
