# eGain Analytics: Partitioning Installer


## Overview

This project builds an msi that can be used to install the eGain Analytics Partitioning product.

<br/>

## MSBuild Properties

|Name|Description|Default|
|---|---|---|
|BuildVersion|The full build version number.|0.0.0.0|
|ReleaseName|Display name for the release.|Development Build|
|ProductSuiteShortName|Short name for the product suite.|EA|
|ProductSuiteFullName|Full name for the product suite.|eGain Analytics|
|CompanyName|Company name.|eGain Corporation|
|Skin|Installer UI skin.|eGain|

<br/>

## MSI Public Properties

|Name|Description|Default|
|---|---|---|
|INSTALLFOLDER|The full root folder path for file installation.||
|DB_USER|The SQL user name for accessing the Analytics database.|&lt;empty&gt; = use windows authentication|
|DB_PASSWORD|The SQL password for accessing the Analytics database.|&lt;empty&gt;|
|DB_SERVER|The database server on which the Analytics database is installed.|localhost|
|DB_CATALOG|The SQL catalog name for the Analytics database.|Portal|

<br/>

## MSI Features

No individual features currently supported.

<br/>

## Command Line Installation Examples

This installer can be run in UI mode with prefilled properties and logging enabled using the following command:

```console
msiexec /i Egain.Analytics.Partitioning.Installer.msi [Properties] /L*v [Log File Location]
```

e.g.

```console
msiexec /i Egain.Analytics.Partitioning.Installer.msi INSTALLFOLDER="" /L*v log.txt
```


This installer can be run in silent mode with prefilled properties and logging enabled using the following command:

```console
msiexec /i Egain.Analytics.Partitioning.Installer.msi [Properties] /QN /L*v [Log File Location]
```

e.g.

```console
msiexec /i Egain.Analytics.Partitioning.Installer.msi INSTALLFOLDER="" /QN /L*v log.txt
```

Features are added using ADDLOCAL="FeatureName,FeatureName,..." as follows: (Not currently supported)

```console
msiexec /i Egain.Analytics.Partitioning.Installer.msi [Properties] ADDLOCAL="[Features]" /L*v [Log File Location]
```

e.g:

```console
msiexec /i Egain.Analytics.Partitioning.Installer.msi INSTALLFOLDER="" ADDLOCAL="Feature1,Feature2" /L*v log.txt
```