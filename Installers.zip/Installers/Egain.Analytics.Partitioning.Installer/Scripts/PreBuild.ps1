﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\Exony.Database.Partitioning.Service\bin\$BuildConfiguration", 
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe", 
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe.config",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.pdb",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe.config",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.pdb" -Destination "$PSScriptRoot\~installerTemp\Partitioning" -Recurse -Force
