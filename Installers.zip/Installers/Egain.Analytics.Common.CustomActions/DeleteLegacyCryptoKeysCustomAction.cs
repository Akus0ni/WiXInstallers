#region Copyright � eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Security.AccessControl;
    using System.Security.Principal;
    using Exony.Win32;
    using WixToolset.Dtf.WindowsInstaller;
    using Microsoft.Win32;

    public static class DeleteLegacyCryptoKeysCustomAction
    {
        /// <summary>
        /// Custom action to delete the Exony\ConfigurationManagement key from the registry. This key wasn't removed on unistall prior to 17.0.7
        /// and it was installed in a way that only Network Service had full control. As such it needs to be forcfully removed prior to install of the
        /// common components by taking ownership of the key. If we do not do this then the installer will not be able to update the key on install.
        /// </summary>
        /// 
        [CustomAction]
        public static ActionResult DeleteLegacyCryptoKeys(Session session)
        {
            if (session == null)
            {
                throw new ArgumentNullException(nameof(session));
            }

            try
            {
                session.Log("Begin DeleteLegacyCryptoKeys custom action");

                //System.Diagnostics.Debugger.Launch();
                //System.Diagnostics.Debugger.Break();

                DeleteKeyInternal();

                session.Log("End DeleteLegacyCryptoKeys custom action");
            }
#pragma warning disable CA1031
            catch (Exception ex)
#pragma warning restore CA1031
            {
                session.Log("ERROR in custom action DeleteLegacyCryptoKeys {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Delete the legacy ConfigurationManagement encryption key by forcing ownership change.
        /// </summary>
        private static void DeleteKeyInternal()
        {
            try
            {
                TokenManipulator.AddPrivilege(PrivilegeNames.SeTakeOwnershipPrivilege);

                using (RegistryKey softwareKey = Registry.LocalMachine.OpenSubKey(@"Software", RegistryKeyPermissionCheck.ReadWriteSubTree))
                {
                    using (RegistryKey exonyKey = softwareKey.OpenSubKey(@"Exony", RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.TakeOwnership))
                    {
                        if (exonyKey == null)
                        {
                            return;
                        }

                        using (RegistryKey configManagementKey = exonyKey.OpenSubKey(@"ConfigurationManagement", RegistryKeyPermissionCheck.ReadWriteSubTree, RegistryRights.TakeOwnership))
                        {
                            if (configManagementKey == null)
                            {
                                return;
                            }

                            // Take ownership of the keys as they may have been previously installed 
                            // in a manner which prevents us deleting them.
                            TakeRegistryKeyOwnership(configManagementKey);
                            TakeRegistryKeyOwnership(exonyKey);
                        } 
                    }

                    // Re-open keys to delete
                    using (RegistryKey exonyKey = softwareKey.OpenSubKey(@"Exony", true))
                    {
                        exonyKey.DeleteSubKey("ConfigurationManagement");

                        if (exonyKey.GetSubKeyNames().Length < 1)
                        {
                            softwareKey.DeleteSubKey("Exony");
                        }
                    }
                }
            }
            finally
            {
                TokenManipulator.RemovePrivilege(PrivilegeNames.SeTakeOwnershipPrivilege);
            }
        }

        /// <summary>
        /// Take ownership of the specified registry key.
        /// </summary>
        private static void TakeRegistryKeyOwnership(RegistryKey key)
        {
            // Make the local administrators group the key owner.
            NTAccount admins = new NTAccount("Administrators");
            RegistrySecurity regSecurity = key.GetAccessControl();
            regSecurity.SetOwner(admins);
            regSecurity.AddAccessRule(new RegistryAccessRule(admins, RegistryRights.FullControl, AccessControlType.Allow));
            key.SetAccessControl(regSecurity);
        }
    }
}
