#region Copyright � eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Linq;
    using WixToolset.Dtf.WindowsInstaller;
    using Microsoft.Win32;

    public static class ConfigureCryptoCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "ConfigureCryptoCA.";

        private const string DefaultProviderKey = "DefaultProvider";

        #endregion

        #region Constants

        private static string[] AllowedProviders = { "Local", "AzureVault", "AwsKms" };

        #endregion

        [CustomAction]
        public static ActionResult ConfigureCrypto(Session session)
        {
            if (session == null)
            {
                throw new ArgumentNullException(nameof(session));
            }

            try
            {
                session.Log("Begin ConfigureCrypto custom action");

                string defaultProvider = CustomActionUtils.GetVariableValue(
                    session, DefaultProviderKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Default Provider [{defaultProvider}]"));

                if (!AllowedProviders.Contains(defaultProvider))
                {
                    throw new ArgumentException("Invalid default provider specified");
                }

                // Local is represented in registry as empty string
                if (defaultProvider.Equals("Local"))
                {
                    defaultProvider = string.Empty;
                }

                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"Software\Egain\Common\Crypto", true))
                {
                    key.SetValue("DefaultProvider", defaultProvider);
                }

                session.Log("End ConfigureCrypto custom action");
            }
#pragma warning disable CA1031
            catch (Exception ex)
#pragma warning restore CA1031
            {
                session.Log("ERROR in custom action ConfigureCrypto {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
