﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using WixToolset.Dtf.WindowsInstaller;

    public static class ConfigureCloudCustomAction
    {
        [CustomAction]
        public static ActionResult ConfigureCloud(Session session)
        {
            if (session == null)
            {
                throw new ArgumentNullException(nameof(session));
            }

            try
            {
                session.Log("Begin ConfigureCloud custom action");

                //System.Diagnostics.Debugger.Launch();
                //System.Diagnostics.Debugger.Break();

                bool cloudEnabled = false;
                bool awsKmsEnabled = false;
                bool awsSecretsEnabled = false;

                FeatureInfo feature = session.Features["Cloud"];
                if (feature.RequestState == InstallState.Local ||
                    ((feature.RequestState != InstallState.Absent) && (feature.CurrentState == InstallState.Local)))
                {
                    cloudEnabled = true;
                }

                feature = session.Features["AwsKms"];
                if (feature.RequestState == InstallState.Local ||
                    ((feature.RequestState != InstallState.Absent) && (feature.CurrentState == InstallState.Local)))
                {
                    awsKmsEnabled = true;
                }

                feature = session.Features["AwsSecrets"];
                if (feature.RequestState == InstallState.Local ||
                    ((feature.RequestState != InstallState.Absent) && (feature.CurrentState == InstallState.Local)))
                {
                    awsSecretsEnabled = true;
                }

                // If we have AWS KMS installed then ensure the local component is only added if not in cloud mode
                if (awsKmsEnabled)
                {
                    session.Features["AwsKmsLocal"].RequestState = cloudEnabled ? InstallState.Absent : InstallState.Local;
                }

                // If we have AWS Secrets installed then ensure the local component is only added if not in cloud mode
                if (awsSecretsEnabled)
                {
                    session.Features["AwsSecretsLocal"].RequestState = cloudEnabled ? InstallState.Absent : InstallState.Local;
                }

                session.Log("End ConfigureCloud custom action");
            }
#pragma warning disable CA1031
            catch (Exception ex)
#pragma warning restore CA1031
            {
                session.Log("ERROR in custom action ConfigureCloud {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
