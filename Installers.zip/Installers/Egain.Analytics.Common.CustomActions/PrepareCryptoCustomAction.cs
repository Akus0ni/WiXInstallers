#region Copyright � eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Collections.Generic;
    using WixToolset.Dtf.WindowsInstaller;

    public static class PrepareCryptoCustomAction
    {
        #region Constants

        private const string AwsProviderName = "AwsKms";
        private const string AzureProviderName = "AzureVault";
        private const string LocalProviderName = "Local";

        #endregion

        [CustomAction]
        public static ActionResult PrepareCrypto(Session session)
        {
            if (session == null)
            {
                throw new ArgumentNullException(nameof(session));
            }

            try
            {
                session.Log("Begin PrepareCrypto custom action");

                //System.Diagnostics.Debugger.Launch();
                //System.Diagnostics.Debugger.Break();

                bool azureEnabled = false;
                bool awsEnabled = false;
                bool localEnabled = false;

                List<string> allowedProviderNames = new List<string>();

                FeatureInfo feature = session.Features["AzureKeyVault"];
                if (feature.RequestState == InstallState.Local ||
                    ((feature.RequestState != InstallState.Absent) && (feature.CurrentState == InstallState.Local)))
                {
                    azureEnabled = true;
                    allowedProviderNames.Add(AzureProviderName);
                }

                feature = session.Features["AwsKms"];
                if (feature.RequestState == InstallState.Local ||
                    ((feature.RequestState != InstallState.Absent) && (feature.CurrentState == InstallState.Local)))
                {
                    awsEnabled = true;
                    allowedProviderNames.Add(AwsProviderName);
                }

                feature = session.Features["Cryptography"];
                if (feature.RequestState == InstallState.Local ||
                    ((feature.RequestState != InstallState.Absent) && (feature.CurrentState == InstallState.Local)))
                {
                    localEnabled = true;
                    allowedProviderNames.Add(LocalProviderName);
                }

                // Delete existing rows
                using (View view = session.Database.OpenView("DELETE FROM ComboBox WHERE Property = 'DEFAULT_CRYPTO_PROVIDER'"))
                {
                    view.Execute();
                }
                
                // Add rows
                using (View view = session.Database.OpenView("SELECT * FROM ComboBox"))
                {
                    view.Execute();

                    int index = 0;

                    if (localEnabled)
                    {
                        Record record = session.Database.CreateRecord(4);
                        record.SetString(1, "DEFAULT_CRYPTO_PROVIDER"); // Property
                        record.SetInteger(2, ++index); // Order
                        record.SetString(3, LocalProviderName); // Value
                        record.SetString(4, "Local"); // Text

                        view.InsertTemporary(record);
                    }

                    if (azureEnabled)
                    {
                        Record record = session.Database.CreateRecord(4);
                        record = session.Database.CreateRecord(4);
                        record.SetString(1, "DEFAULT_CRYPTO_PROVIDER"); // Property
                        record.SetInteger(2, ++index); // Order
                        record.SetString(3, AzureProviderName); // Value
                        record.SetString(4, "Azure Key Vault"); // Text

                        view.InsertTemporary(record);
                    }

                    if (awsEnabled)
                    {
                        Record record = session.Database.CreateRecord(4);
                        record = session.Database.CreateRecord(4);
                        record.SetString(1, "DEFAULT_CRYPTO_PROVIDER"); // Property
                        record.SetInteger(2, ++index); // Order
                        record.SetString(3, AwsProviderName); // Value
                        record.SetString(4, "AWS KMS"); // Text

                        view.InsertTemporary(record);
                    }
                }

                // Ensure that default is valid
                string currentDefaultCryptoProvider = session["DEFAULT_CRYPTO_PROVIDER"];
                string newDefaultCryptoProvider = currentDefaultCryptoProvider;

                // Ensure default is valid
                if (!allowedProviderNames.Contains(currentDefaultCryptoProvider))
                {
                    if (azureEnabled)
                    {
                        newDefaultCryptoProvider = AzureProviderName;
                    }
                    else if (awsEnabled)
                    {
                        newDefaultCryptoProvider = AwsProviderName;
                    }
                    else
                    {
                        newDefaultCryptoProvider = LocalProviderName;
                    }
                    
                }

                session["DEFAULT_CRYPTO_PROVIDER"] = newDefaultCryptoProvider;
                session["MultipleCryptoOptions"] = allowedProviderNames.Count > 1 ? "1" : "0";

                session.Log("End PrepareCrypto custom action");
            }
#pragma warning disable CA1031
            catch (Exception ex)
#pragma warning restore CA1031
            {
                session.Log("ERROR in custom action  PrepareCrypto {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
