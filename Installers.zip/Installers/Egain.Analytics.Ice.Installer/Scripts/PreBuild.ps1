﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.Ice\bin\$BuildConfiguration" -Destination "$PSScriptRoot\~installerTemp\Ice" -Recurse
Copy-Item "$PSScriptRoot\..\..\..\Database\Exony.Database.ClusterConfiguration.Utility\bin\$BuildConfiguration\Exony.Database.ClusterConfiguration.Utility.exe", 
    "$PSScriptRoot\..\..\..\Database\Exony.Database.ClusterConfiguration.Utility\bin\$BuildConfiguration\Exony.Database.ClusterConfiguration.Utility.exe.config",
    "$PSScriptRoot\..\..\..\Database\Exony.Database.ClusterConfiguration.Utility\bin\$BuildConfiguration\Exony.Database.ClusterConfiguration.Utility.pdb",
    "$PSScriptRoot\..\..\..\Database\Exony.Database.ClusterConfiguration.Utility\bin\$BuildConfiguration\System.Management.Automation.dll",
    "$PSScriptRoot\..\..\..\Database\Exony.Database.ClusterConfiguration.Utility\bin\$BuildConfiguration\CommandLine.dll" -Destination "$PSScriptRoot\~installerTemp\Ice" -Recurse -Force
