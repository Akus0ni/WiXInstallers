# eGain Analytics: Report Server Installer


## Overview

This project builds an msi that can be used to install the eGain Analytics Report Server product.

<br/>

## MSBuild Properties

|Name|Description|Default|
|---|---|---|
|BuildVersion|The full build version number.|0.0.0.0|
|ReleaseName|Display name for the release.|Development Build|
|ProductSuiteShortName|Short name for the product suite.|EA|
|ProductSuiteFullName|Full name for the product suite.|eGain Analytics|
|CompanyName|Company name.|eGain Corporation|
|Skin|Installer UI skin.|eGain|

<br/>

## MSI Public Properties

|Name|Description|Default|
|---|---|---|
|INSTALLFOLDER|The full root folder path for file installation.||
|RSE_USER|The user name for accessing the Reporting Services Execution account.|&lt;empty&gt; = use windows authentication|
|RSE_PASSWORD|The password for accessing the Reporting Services Execution account.|&lt;empty&gt;|

<br/>

## MSI Features

No individual features currently supported.

<br/>

## Command Line Installation Examples

This installer can be run in UI mode with prefilled properties and logging enabled using the following command:

```console
msiexec /i Egain.Analytics.ReportServer.Installer.msi [Properties] /L*v [Log File Location]
```

e.g.

```console
msiexec /i Egain.Analytics.ReportServer.Installer.msi INSTALLFOLDER="" /L*v log.txt
```


This installer can be run in silent mode with prefilled properties and logging enabled using the following command:

```console
msiexec /i Egain.Analytics.ReportServer.Installer.msi [Properties] /QN /L*v [Log File Location]
```

e.g.

```console
msiexec /i Egain.Analytics.ReportServer.Installer.msi INSTALLFOLDER="" /QN /L*v log.txt
```

Features are added using ADDLOCAL="FeatureName,FeatureName,..." as follows: (Not currently supported)

```console
msiexec /i Egain.Analytics.ReportServer.Installer.msi [Properties] ADDLOCAL="[Features]" /L*v [Log File Location]
```

e.g:

```console
msiexec /i Egain.Analytics.ReportServer.Installer.msi INSTALLFOLDER="" ADDLOCAL="Feature1,Feature2" /L*v log.txt
```