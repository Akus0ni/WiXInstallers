﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\Extensions\Egain.Analytics.ReportingServices.Distribute\bin\$BuildConfiguration" -Destination "$PSScriptRoot\~installerTemp\ReportServer" -Recurse
Copy-Item "$PSScriptRoot\..\..\..\Extensions\RSInit\bin\$BuildConfiguration\*" -Destination "$PSScriptRoot\~installerTemp\ReportServer" -Recurse -Force