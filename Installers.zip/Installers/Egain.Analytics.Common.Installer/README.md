# eGain Analytics: Common Installer


## Overview

This project builds an msi that can be used to install the eGain Analytics Common Components.

<br/>

## MSBuild Properties

|Name|Description|Default|
|---|---|---|
|BuildVersion|The full build version number.|0.0.0.0|
|ReleaseName|Display name for the release.|Development Build|
|ProductSuiteShortName|Short name for the product suite.|EA|
|ProductSuiteFullName|Full name for the product suite.|eGain Analytics|
|CompanyName|Company name.|eGain Corporation|
|Skin|Installer UI skin.|eGain|

<br/>

## MSI Public Properties

|Name|Description|Default|
|---|---|---|
|AZURE_CLIENT_ID|The client id for use with the [AzureVault] feature.||
|AZURE_MASTER_KEY_ID|The master key id for use with the [AzureVault] feature.||
|AZURE_CERTIFICATE_PATH|Path to the certificate file for use with the [AzureVault] feature.||
|AZURE_CERTIFICATE_PASSWORD|Certificate password for use with the [AzureVault] feature. Blank value is allowed if the certificate is not password protected.||
|AWS_CLIENT_ID|The client id for use with the [AwsKms] feature.||
|AWS_MASTER_KEY_ID|The master key id for use with the [AwsKms] feature.||
|AWS_CLIENT_SECRET|The client secret for use with the [AwsKms] feature.||
|CRYPTOGRAPHY_PASSPHRASE|The passphrase used to generate the cryptography machine key for use with the [Cryptography] feature.||
|SHOW_FEATURE_SELECTION|Indicates if the Customize (Feature Selection) dialog should be shown during the UI sequence (0 = No, 1 = Yes).|1|
|DEFAULT_CRYPTO_PROVIDER|Indicates the default crypto provider to use. This must be one of [AwsKms\|AzureVault\|Local]. It can only be set to AwsKms if the AwsKms feature is installed. It can only be set to AzureVault if the AzureVault feature is installed.||
|DEPLOYMENT_ID|Deployment ID for the install for use with the [Cloud] feature.||
|TENANT_MANAGER_URL|URL for accessing Tenant Manager for use with the [Cloud] feature.||
|TENANT_MANAGER_CERT_THUMBPRINT|Thumbprint for locating the tenant manager certificate in the windows certificate store.||
|IS_GOV_CLOUD|1 = Government Cloud, 0 = Standard Cloud||
|AWS_SECRETS_CLIENT_ID|The client id for use with the [AwsSecrets] feature.||
|AWS_SECRETS_CLIENT_SECRET|The client secret for use with the [AwsSecrets] feature.||
|AWS_SECRETS_SERVICE_URL|The service URL for use with the [AwsSecrets] feature.||
|AWS_SECRETS_REGION|The region for use with the [AwsSecrets] feature.||

<br/>

## MSI Features

|Name|Description|
|---|---|
|Jdk|Installs Open JDK and required registry keys.|
|Cryptography|Installs the legacy encryption machine key in the registry.|
|AzureKeyVault|Installs the required registry keys and certificate for Azure KeyVault support.|
|AwsKms|Installs the required registry keys for AWS KMS support.|
|Cloud|Installs the required registry keys for Cloud support.|
|AwsSecrets|Installs the required registry keys for AWS Secrets Manager support.|
|EnhancedSecurity|Installs the required registry keys to enable enhanced security for FedRAMP (e.g. log file, message queue, and state file encryption at rest).|

<br/>

## Command Line Installation Examples

This installer can be run in UI mode with prefilled properties and logging enabled using the following command:

```console
msiexec /i Egain.Analytics.Common.Installer.msi [Properties] /L*v [Log File Location]
```

e.g.

```console
msiexec /i Egain.Analytics.Common.Installer.msi INSTALLFOLDER="" /L*v log.txt
```


This installer can be run in silent mode with prefilled properties and logging enabled using the following command:

```console
msiexec /i Egain.Analytics.Common.Installer.msi [Properties] /QN /L*v [Log File Location]
```

e.g.

```console
msiexec /i Egain.Analytics.Common.Installer.msi INSTALLFOLDER="" /QN /L*v log.txt
```

Features are added using ADDLOCAL="FeatureName,FeatureName,..." as follows:

```console
msiexec /i Egain.Analytics.Common.Installer.msi [Properties] ADDLOCAL="[Features]" /L*v [Log File Location]
```

e.g:

```console
msiexec /i Egain.Analytics.Common.Installer.msi INSTALLFOLDER="" ADDLOCAL="Jdk,Cryptography" /L*v log.txt
```