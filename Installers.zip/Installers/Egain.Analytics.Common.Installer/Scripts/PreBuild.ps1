﻿Add-Type -AssemblyName System.IO.Compression.FileSystem

if (-Not (Test-Path "$HOME/.s3cache")) 
{
  New-Item -Path "$HOME/.s3cache" -ItemType Directory
}

if (-Not (Test-Path "$HOME/.s3cache/jdk/OpenJDK11U-jdk_x64_windows_hotspot_11.0.21_9.zip")) 
{
  Write-Output "Cache miss for JDK zip file - downloading from AWS S3"
  aws s3 cp s3://egain-analytics/build-assets/jdk/OpenJDK11U-jdk_x64_windows_hotspot_11.0.21_9.zip "$HOME/.s3cache/jdk/OpenJDK11U-jdk_x64_windows_hotspot_11.0.21_9.zip"
}

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

New-Item "$PSScriptRoot/~installerTemp" -type directory

[System.IO.Compression.ZipFile]::ExtractToDirectory("$HOME/.s3cache/jdk/OpenJDK11U-jdk_x64_windows_hotspot_11.0.21_9.zip", "$PSScriptRoot/~installerTemp/JDK")
