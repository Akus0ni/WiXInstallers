#region Copyright © Exony Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.IdentityServer.CustomActions
{
    using System;
    using System.Security.AccessControl;
    using System.Security.Cryptography;
    using System.Security.Cryptography.X509Certificates;
    using System.Security.Principal;
    using Exony.WebServices.Certificates;
    using WixToolset.Dtf.WindowsInstaller;

    public class IdentityServerCertificateCustomAction
    {
        [CustomAction]
        public static ActionResult CreateCertificate(Session session)
        {
            try
            {
                session.Log("Begin CreateCertificate custom action");

                session.Log("Installing Identity Server Certificate");
                AddCertificate();

                session.Log("End CreateCertificate custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action CreateCertificate {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        private static void AddCertificate()
        {
            // Self Signed Ssl Certificate for signing
            var certificateName = "CN=idsrv3";

            var containerName = "idserver3container";
            var friendlyName = "Identity Server Signing";
            var location = StoreLocation.LocalMachine;
            var storeName = StoreName.My;

            X509Store store = new X509Store(storeName, location);
            store.Open(OpenFlags.ReadWrite);
            X509Certificate2Collection cers = store.Certificates.Find(X509FindType.FindBySubjectDistinguishedName, certificateName, false);
            store.Close();

            if (cers.Count == 0)
            {
                // create a new self-signed certificate and store
                string hash = CertificateApi.CreateSelfSignedCertificate(containerName, certificateName, friendlyName, storeName, location);

                // find our new certificate by its hash
                X509Certificate2 newCert = CertificateApi.GetSelfSignedCertificate(hash, storeName, location);

                // give permissions to Network Service, in case this was run by a different user
                var rsa = newCert.PrivateKey as RSACryptoServiceProvider;
                if (rsa != null)
                {
                    // Modifying the CryptoKeySecurity of a new CspParameters and then instantiating
                    // a new RSACryptoServiceProvider seems to be the trick to persist the access rule.
                    // cf. http://blogs.msdn.com/b/cagatay/archive/2009/02/08/removing-acls-from-csp-key-containers.aspx
                    var cspParams = new CspParameters(rsa.CspKeyContainerInfo.ProviderType, rsa.CspKeyContainerInfo.ProviderName, rsa.CspKeyContainerInfo.KeyContainerName)
                    {
                        Flags = CspProviderFlags.UseExistingKey | CspProviderFlags.UseMachineKeyStore,
                        CryptoKeySecurity = rsa.CspKeyContainerInfo.CryptoKeySecurity
                    };

                    var account = new SecurityIdentifier(WellKnownSidType.NetworkServiceSid, null).Translate(typeof(NTAccount)).Value;

                    cspParams.CryptoKeySecurity.AddAccessRule(new CryptoKeyAccessRule(account, CryptoKeyRights.GenericRead, AccessControlType.Allow));

                    // ReSharper disable once UnusedVariable
                    using (var rsa2 = new RSACryptoServiceProvider(cspParams))
                    {
                        // Only created to persist the rule change in the CryptoKeySecurity
                    }
                }
            }
        }
    }
}