﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

[string]$Path = "$PSScriptRoot\..\..\..\"

Start-Process -FilePath "$PSScriptRoot\..\..\..\Installers\Egain.Analytics.Mediator.Installer\Scripts\CopyBinaries.bat" -ArgumentList "$BuildConfiguration", "$Path" -NoNewWindow -Wait

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\SSIS\Exony.Dts.Runtime.Service\bin\$BuildConfiguration" -Destination "$PSScriptRoot\~installerTemp\Mediator" -Recurse

Copy-Item "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe",
           "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe.config",
           "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.pdb",
           "$PSScriptRoot\..\..\..\SSIS\Exony.Dts.Pipeline.DtsCmd\bin\$BuildConfiguration\dtscmd.exe",
           "$PSScriptRoot\..\..\..\SSIS\Exony.Dts.Pipeline.DtsCmd\bin\$BuildConfiguration\dtscmd.exe.config",
           "$PSScriptRoot\..\..\..\SSIS\Exony.Dts.Pipeline.DtsCmd\bin\$BuildConfiguration\dtscmd.pdb",
           "$PSScriptRoot\..\..\..\Caching\SearchUtility\bin\$BuildConfiguration\Exony.Data.Search.Utility.exe",
           "$PSScriptRoot\..\..\..\Caching\SearchUtility\bin\$BuildConfiguration\Exony.Data.Search.Utility.exe.config",
           "$PSScriptRoot\..\..\..\Caching\SearchUtility\bin\$BuildConfiguration\Exony.Data.Search.Utility.pdb",
           "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe",
           "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe.config",
           "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.pdb",
           "$PSScriptRoot\..\..\..\SSIS\Exony.Dts.Utilities.PackageManager\bin\$BuildConfiguration\Exony.Dts.Utilities.PackageManager.exe",
           "$PSScriptRoot\..\..\..\SSIS\Exony.Dts.Utilities.PackageManager\bin\$BuildConfiguration\Exony.Dts.Utilities.PackageManager.exe.config",
           "$PSScriptRoot\..\..\..\SSIS\Exony.Dts.Utilities.PackageManager\bin\$BuildConfiguration\Exony.Dts.Utilities.PackageManager.pdb",
           "$PSScriptRoot\..\..\..\Provisioning\Connectors\ICM\Exony.Provisioning.Icm.Common\bin\$BuildConfiguration\Exony.Provisioning.Icm.Common.dll",
           "$PSScriptRoot\..\..\..\Provisioning\Connectors\ICM\Exony.Provisioning.Icm.Common\bin\$BuildConfiguration\Exony.Provisioning.Icm.Common.pdb",
           "$PSScriptRoot\..\..\..\ThirdParty\Microsoft\Interop\Interop.MSMQ.dll",
           "$PSScriptRoot\..\..\..\Exony.Reporting.Application.Security\bin\$BuildConfiguration\Gma.DataStructures.StringSearch.dll",
           "$PSScriptRoot\..\..\..\SSIS\Exony.Dts.Pipeline.Common\bin\$BuildConfiguration\x64\SQLite.Interop.dll",
           "$PSScriptRoot\..\..\..\Caching\Exony.Cache.RemoteAccess\bin\$BuildConfiguration\Exony.Cache.RemoteAccess.dll",
           "$PSScriptRoot\..\..\..\Caching\Exony.Cache.RemoteAccess\bin\$BuildConfiguration\Exony.Cache.RemoteAccess.pdb",
           "$PSScriptRoot\..\..\..\Licencing\Exony.Licencing\bin\$BuildConfiguration\Exony.Licencing.dll",
           "$PSScriptRoot\..\..\..\Licencing\Exony.Licencing\bin\$BuildConfiguration\Exony.Licencing.pdb" -Destination "$PSScriptRoot\~installerTemp\Mediator" -Force
