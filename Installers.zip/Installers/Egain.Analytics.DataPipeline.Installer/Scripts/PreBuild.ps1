﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\DataPipeline\DataPipelineService\bin\$BuildConfiguration" -Destination "$PSScriptRoot\~installerTemp\DataPipeline" -Recurse
Copy-Item "$PSScriptRoot\..\..\..\DataPipeline\MicroExplorer\bin\$BuildConfiguration\*" -Destination "$PSScriptRoot\~installerTemp\DataPipeline" -Recurse -Force
Copy-Item "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe", 
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.exe.config",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ConnectionReset\bin\$BuildConfiguration\ConnectionUpdater.pdb",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.exe.config",
    "$PSScriptRoot\..\..\..\Tools\Exony.Portal.Tools.ServiceControl\bin\$BuildConfiguration\Exony.Portal.Tools.ServiceControl.pdb",
    "$PSScriptRoot\..\..\..\DataPipeline\MicroflowRuntime\bin\$BuildConfiguration\ClientLibrary.dll",
    "$PSScriptRoot\..\..\..\DataPipeline\MicroflowRuntime\bin\$BuildConfiguration\GatewayClient.dll" -Destination "$PSScriptRoot\~installerTemp\DataPipeline" -Recurse -Force
