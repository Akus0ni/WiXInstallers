﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using Microsoft.Win32;
    using System;
    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Custm actions for managing registry keys.
    /// </summary>
    public class RegistryCustomActions
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "RegistryCustomActions.";

        private static class Keys
        {
            public const string KeyRoot = "KeyRoot";
            public const string KeyName = "KeyName";
            public const string OutputVariableName = "OutputVariableName";
        }

        #endregion

        /// <summary>
        /// Test if a specific registry key exists.
        /// </summary>
        [CustomAction]
        public static ActionResult RegistryKeyExists(Session session)
        {
            try
            {
                session.Log("BEGIN RegistryKeyExists custom action");

                string keyRoot = CustomActionUtils.GetVariableValue(
                        session, Keys.KeyRoot, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Key root [{keyRoot}]"));

                string keyName = CustomActionUtils.GetVariableValue(
                        session, Keys.KeyName, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Key name [{keyName}]"));

                string outputVariableName = CustomActionUtils.GetVariableValue(
                        session, Keys.OutputVariableName, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Output variable name [{outputVariableName}]"));

                RegistryKey rootKey;

                switch (keyRoot.ToUpperInvariant())
                {
                    case "HKCR":
                        rootKey = Registry.ClassesRoot;
                        break;

                    case "HKCU":
                        rootKey = Registry.CurrentUser;
                        break;

                    case "HKU":
                        rootKey = Registry.Users;
                        break;

                    case "HKLM":
                    default:
                        rootKey = Registry.LocalMachine;
                        break;

                }
                RegistryKey regKey = rootKey.OpenSubKey(keyName);

                bool exists = regKey != null;

                session.Log(CustomActionUtils.EscapeString($"Key exists [{exists}]"));

                String existsStr = exists ? "1" : String.Empty;

                CustomActionUtils.SetVariableValue(session, outputVariableName, existsStr);

                session.Log("END RegistryKeyExists custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action RegistryKeyExists {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
