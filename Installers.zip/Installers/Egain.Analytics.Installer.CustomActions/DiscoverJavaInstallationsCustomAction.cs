#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Exony.Java.Common;
    using Exony.Java.Runtime;
    using WixToolset.Dtf.WindowsInstaller;

    public class DiscoverJavaInstallationsCustomAction
    {
        #region Session Keys

        private const string MinVersion = "DiscoverJavaInstallations.MinVersion";
        private const string MaxVersion = "DiscoverJavaInstallations.MaxVersion";
        private const string InstallationTypes = "DiscoverJavaInstallations.InstallationTypes";

        #endregion

        [CustomAction]
        public static ActionResult DiscoverJavaInstallations(Session session)
        {
            try
            {
                session.Log("Begin DiscoverJavaInstallations custom action");

                //System.Diagnostics.Debugger.Launch();
                //System.Diagnostics.Debugger.Break();

                string minVersionString = session[MinVersion];
                string maxVersionString = session[MaxVersion];
                string installationTypesString = session[InstallationTypes];

                JavaVersion minVersion = string.IsNullOrWhiteSpace(minVersionString) 
                    ? JavaVersion.MinValue : JavaVersion.Parse(minVersionString);

                JavaVersion maxVersion = string.IsNullOrWhiteSpace(maxVersionString) 
                    ? JavaVersion.MaxValue : JavaVersion.Parse(maxVersionString);

                JavaInstallationType installationTypes = string.IsNullOrWhiteSpace(installationTypesString) 
                    ? JavaInstallationType.All : (JavaInstallationType)int.Parse(installationTypesString);

                // Get the available installations matching the supplied criteria
                List<IJavaInstallationMeta> avaialbleJavaInstalls = JavaUtility.DiscoverLocalJavaInstallations(
                    installationTypes, minVersion, maxVersion).ToList();

                using (View view = session.Database.OpenView("SELECT * FROM ComboBox WHERE Property = 'JAVA_RUNTIME_LIB_PATH'"))
                {
                    view.Execute();

                    int index = view.Database.CountRows("ComboBox", "Property = 'JAVA_RUNTIME_LIB_PATH'");

                    foreach (IJavaInstallationMeta javaInstall in avaialbleJavaInstalls)
                    {
                        string displayName = javaInstall.InstallationType == JavaInstallationType.Jre 
                            ? $"JRE {javaInstall.Version}" : $"JDK {javaInstall.Version}";

                        Record record = session.Database.CreateRecord(4);
                        record.SetString(1, "JAVA_RUNTIME_LIB_PATH"); // Property
                        record.SetInteger(2, ++index); // Order
                        record.SetString(3, javaInstall.RuntimeLibraryPath); // Value
                        record.SetString(4, displayName); // Text

                        view.InsertTemporary(record);
                    }
                }

                string currentInstallPath = session["JAVA_RUNTIME_LIB_PATH"];

                if (!avaialbleJavaInstalls.Any(i => i.RuntimeLibraryPath.Equals(currentInstallPath)))
                {
                    // If the current selection is not valid then clear it to force selection of a valid install
                    currentInstallPath = string.Empty;
                }

                // Default to highest version avilable - prefer a jdk if requested 
                if (string.IsNullOrWhiteSpace(currentInstallPath))
                {
                    IJavaInstallationMeta defaultSelection = null;

                    if (installationTypes.HasFlag(JavaInstallationType.Jdk))
                    {
                        defaultSelection = avaialbleJavaInstalls
                            .OrderBy(j => j.Version).LastOrDefault(j => j.InstallationType == JavaInstallationType.Jdk);
                    }
                    
                    if (defaultSelection == null)
                    {
                        defaultSelection = avaialbleJavaInstalls.OrderBy(j => j.Version).LastOrDefault();
                    }

                    currentInstallPath = defaultSelection == null ? string.Empty : defaultSelection.RuntimeLibraryPath;
                }

                session["JAVA_RUNTIME_LIB_PATH"] = currentInstallPath;

                session.Log("End DiscoverJavaInstallations custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action DiscoverJavaInstallations {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
