#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Configuration;
    using System.IO;
    using System.Security.AccessControl;
    using System.Security.Cryptography;
    using System.Security.Principal;
    using System.Text;
    using System.Web.Configuration;
    using System.Xml;
    using WixToolset.Dtf.WindowsInstaller;
    using Microsoft.Win32;

    public class InstallSecurityRegistryCustomAction
    {
        #region Session Keys

        private const string PassphraseKey = "InstallSecurityRegistry.Passphrase";
        private const string CreateMachineKeyKey = "InstallSecurityRegistry.CreateMachineKey";

        #endregion

        /// <summary>
        /// The default security registry path
        /// </summary>
        private const string RegistryPath = @"SOFTWARE\Exony\ConfigurationManagement";

        /// <summary>
        /// Additional Entropy for DPAPI
        /// </summary>
        private static readonly byte[] Entropy = { 9, 8, 7, 6, 5 };

        [CustomAction]
        public static ActionResult InstallSecurityRegistry(Session session)
        {
            try
            {
                session.Log("Begin InstallSecurityRegistry custom action");

                string passphrase = session[PassphraseKey];
                string createMachineKeyString = session[CreateMachineKeyKey];

#if DEBUG
                session.Log($"Passphrase - {passphrase}. CreateMachineKey - {createMachineKeyString}.");
#endif

                if (!string.IsNullOrEmpty(createMachineKeyString) && Boolean.Parse(createMachineKeyString))
                {
                    CreateMachineKeys(passphrase);
                }

                CreateCryptographyRegistryKeys(passphrase);

                session.Log("End InstallSecurityRegistry custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action InstallSecurityRegistry {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Creates the cryptography registry keys based on the supplied password
        /// </summary>
        private static void CreateCryptographyRegistryKeys(string passPhrase)
        {
            // encrypt the secret using DPAPI
            byte[] passwordBytes = Encoding.UTF8.GetBytes(passPhrase);
            byte[] protectedBytes = ProtectedData.Protect(passwordBytes, Entropy, DataProtectionScope.LocalMachine);

            RegistrySecurity sec = new RegistrySecurity();

            // Give network service read access
            RegistryAccessRule rule = new RegistryAccessRule(
                        new SecurityIdentifier(WellKnownSidType.NetworkServiceSid, null),
                        RegistryRights.FullControl,
                        InheritanceFlags.ContainerInherit,
                        PropagationFlags.None,
                        AccessControlType.Allow);

            sec.AddAccessRule(rule);

            // Give local system read access
            RegistryAccessRule rule2 = new RegistryAccessRule(
                        new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null),
                        RegistryRights.FullControl,
                        InheritanceFlags.ContainerInherit,
                        PropagationFlags.None,
                        AccessControlType.Allow);

            sec.AddAccessRule(rule2);

            // Give creator full access
            RegistryAccessRule rule3 = new RegistryAccessRule(
                        new SecurityIdentifier(WellKnownSidType.CreatorOwnerSid, null),
                        RegistryRights.FullControl,
                        InheritanceFlags.ContainerInherit,
                        PropagationFlags.None,
                        AccessControlType.Allow);
            sec.AddAccessRule(rule3);

            // Give local admins full access
            RegistryAccessRule rule4 = new RegistryAccessRule(
                        new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null),
                        RegistryRights.FullControl,
                        InheritanceFlags.ContainerInherit,
                        PropagationFlags.None,
                        AccessControlType.Allow);
            sec.AddAccessRule(rule4);

            using (RegistryKey key = Registry.LocalMachine.CreateSubKey(RegistryPath, RegistryKeyPermissionCheck.Default, sec))
            {
                if (key != null)
                {
                    key.SetValue("machineKey", Convert.ToBase64String(protectedBytes));

                    // remove old keys, if present
                    key.DeleteValue("symmetricKey", false);
                    key.DeleteValue("initializationVector", false);
                    key.DeleteValue("hashKey", false);
                }
            }
        }

        /// <summary>
        /// Creates a machine key from the password and writes it to the .net 2 and 4 framework machine.config files. Also removes
        /// any machine key config from the global web.config.
        /// This is so that forms authentication encryption works between the app server, web server and reporting services for RS single sign on.
        /// </summary>
        private static void CreateMachineKeys(string passPhrase)
        {
            // Add machinekey to .NET v4 machine.config
            Configuration v4MachineConfig = ConfigurationManager.OpenMachineConfiguration();
            ConfigureMachineKeySection(v4MachineConfig, passPhrase);

            // Remove machine key from .NET v4 web.config (it will fall back to machine.config)
            Configuration v4WebConfig = WebConfigurationManager.OpenWebConfiguration(null);
            RemoveMachineKeySection(v4WebConfig.FilePath);

            // Now do the same for .NET v2 (the one that Reporting Services uses)
            FileInfo file = new FileInfo(v4MachineConfig.FilePath);
            DirectoryInfo[] version2Folder = file.Directory?.Parent?.Parent?.GetDirectories("v2.*");
            if (version2Folder?.Length > 0)
            {
                string v2ConfigFolder = Path.Combine(version2Folder[0].FullName, @"Config");

                if (Directory.Exists(v2ConfigFolder))
                {
                    // Add machinekey to .NET v2 machine.config
                    String machineConfigFilePath = Path.Combine(v2ConfigFolder, "machine.config");

                    if (File.Exists(machineConfigFilePath))
                    {
                        ConfigurationFileMap machineConfigMap = new ConfigurationFileMap(machineConfigFilePath);
                        Configuration v2MachineConfig = ConfigurationManager.OpenMappedMachineConfiguration(machineConfigMap);
                        ConfigureMachineKeySection(v2MachineConfig, passPhrase);
                    }

                    String webConfigFilePath = Path.Combine(v2ConfigFolder, "web.config");

                    if (File.Exists(webConfigFilePath))
                    {
                        // Remove machine key from .NET v2 web.config (it will fall back to machine.config)
                        RemoveMachineKeySection(webConfigFilePath);
                    }
                }
            }
        }

        private static void RemoveMachineKeySection(string configFilePath)
        {
            ConfigXmlDocument configFile = new ConfigXmlDocument();
            configFile.Load(configFilePath);

            XmlNode machineKeyNode = configFile.SelectSingleNode("configuration/system.web/machineKey");
            if (machineKeyNode?.ParentNode != null)
            {
                machineKeyNode.ParentNode.RemoveChild(machineKeyNode);
                configFile.Save(configFilePath);
            }
        }

        private static void ConfigureMachineKeySection(Configuration machineConfig, string password)
        {
            MachineKeySection machineKeySection = (MachineKeySection)machineConfig.GetSection("system.web/machineKey");
            if (machineKeySection != null)
            {
                machineKeySection.Decryption = "AES";
                machineKeySection.Validation = MachineKeyValidation.AES;
                machineKeySection.DecryptionKey = GenerateStringHexHash(password + "_dec", 64);
                machineKeySection.ValidationKey = GenerateStringHexHash(password + "_val", 64);
                machineConfig.Save(ConfigurationSaveMode.Modified);
            }
        }

        /// <summary>
        /// Generates a random hex string from the password with the specified length. Provided the parameters are the same, the same string will be
        /// generated.
        /// </summary>
        private static string GenerateStringHexHash(string password, int length)
        {
            byte[] salt = { 5, 2, 2, 3, 2, 5, 6, 9 };
            Rfc2898DeriveBytes cdk = new Rfc2898DeriveBytes(password, salt, 784);

            byte[] bytes = cdk.GetBytes(length / 2);

            StringBuilder hex = new StringBuilder(bytes.Length * 2);
            foreach (byte b in bytes)
            {
                hex.AppendFormat("{0:x2}", b);
            }

            return hex.ToString().Substring(0, length);
        }
    }
}
