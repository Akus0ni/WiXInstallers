#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.IO;
    using WixToolset.Dtf.WindowsInstaller;

    public class FileWriteAllTextCustomAction
    {
        #region Session Keys

        private const string FilePathKey = "FilePath";
        private const string FileContentsKey = "FileContents";

        #endregion

        [CustomAction]
        public static ActionResult FileWriteAllText(Session session)
        {
            try
            {
                session.Log("Begin FileWriteAllText custom action");

                string path = session.CustomActionData[FilePathKey];
                string contents = session.CustomActionData[FileContentsKey];

                File.WriteAllText(path, contents);

                session.Log("End FileWriteAllText custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action FileWriteAllText {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
