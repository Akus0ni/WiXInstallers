﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.IO;
    using WixToolset.Dtf.WindowsInstaller;

    public class UpdateJavaInstallationPropertiesCustomAction
    {
        [CustomAction]
        public static ActionResult UpdateJavaInstallationProperties(Session session)
        {
            try
            {
                session.Log("Begin UpdateJavaInstallationProperties custom action");

                //System.Diagnostics.Debugger.Launch();

                string javaRuntimeLibPath = session["JAVA_RUNTIME_LIB_PATH"];

                DirectoryInfo jreHomeDir = new DirectoryInfo(javaRuntimeLibPath).Parent.Parent.Parent;
                session["JAVA_JRE_HOME_DIR"] = jreHomeDir.FullName;

                string jreEndorsedDirectory = Path.Combine(jreHomeDir.FullName, "lib\\endorsed");
                session["JAVA_JRE_ENDORSED_DIR"] = jreEndorsedDirectory;

                session.Log("End UpdateJavaInstallationProperties custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action UpdateJavaInstallationProperties {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
