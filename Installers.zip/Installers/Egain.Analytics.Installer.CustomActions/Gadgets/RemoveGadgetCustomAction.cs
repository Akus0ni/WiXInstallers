﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions.Gadgets
{
    using Exony.Database.Common.Gadgets;
    using WixToolset.Dtf.WindowsInstaller;
    using System;

    public class RemoveGadgetCustomAction : SqlCustomActionBase
    {
        #region Session Keys

        private const string ConnectionStringKey = "ConnectionString";
        private const string FilePathKey = "FilePath";

        #endregion

        [CustomAction]
        public static ActionResult RemoveGadget(Session session)
        {
            try
            {
                session.Log("Begin RemoveGadget custom action");

                // Read session values

                // Connection String
                string connectionString = session.CustomActionData[ConnectionStringKey];
                session.Log("Connection String: {0}", connectionString);

                // File Path
                string filePath = session.CustomActionData[FilePathKey];
                session.Log("File Path: {0}", filePath);

                RemoveGadgetInternal(session, connectionString, filePath);

                session.Log("End RemoveGadget custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in RemoveGadget custom action {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Remove a gadget from the database
        /// </summary>
        private static void RemoveGadgetInternal(Session session, string connectionString, string archiveFilePath)
        {
            GadgetDeployer deployer = new GadgetDeployer(connectionString);
            deployer.RemoveGadget(archiveFilePath);
        }
    }
}
