﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions.Gadgets
{
    using Exony.Database.Common.Gadgets;
    using WixToolset.Dtf.WindowsInstaller;
    using System;

    public class DeployGadgetCustomAction : SqlCustomActionBase
    {
        #region Session Keys

        private const string ConnectionStringKey = "ConnectionString";
        private const string FilePathKey = "FilePath";

        #endregion

        [CustomAction]
        public static ActionResult DeployGadget(Session session)
        {
            try
            {
                session.Log("Begin DeployGadget custom action");

                // Read session values

                // Connection String
                string connectionString = session.CustomActionData[ConnectionStringKey];
                session.Log("Connection String: {0}", connectionString);

                // File Path
                string filePath = session.CustomActionData[FilePathKey];
                session.Log("File Path: {0}", filePath);

                DeployGadgetInternal(session, connectionString, filePath);

                session.Log("End DeployGadget custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in DeployGadget custom action {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Deploy a gadget to the database
        /// </summary>
        private static void DeployGadgetInternal(Session session, string connectionString, string archiveFilePath)
        {
            GadgetDeployer deployer = new GadgetDeployer(connectionString);
            deployer.DeployGadget(archiveFilePath);
        }
    }
}
