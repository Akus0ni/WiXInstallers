﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Custom actions used in the Tenant Selection Dialog.
    /// </summary>
    public class DiscoverTenantsCustomAction
    {
        #region Session Keys

        private const string DbConnectionStringSessionKey = "DiscoverTenants.DbConnectionString";
        private const string AllowAllTenantsSessionKey = "DiscoverTenants.AllowAllTenants";

        #endregion

        [CustomAction]
        public static ActionResult DiscoverTenants(Session session)
        {
            try
            {
                session.Log("Begin DiscoverTenants custom action");

                //System.Diagnostics.Debugger.Launch();

                string dbConnectionString = session[DbConnectionStringSessionKey];
                string allowAllTenantsString = session[AllowAllTenantsSessionKey];

                bool allowAllTenants;

                if (!bool.TryParse(allowAllTenantsString, out allowAllTenants))
                {
                    allowAllTenants = true;
                }

                // Delete any existing tenants
                session.Database.Execute("DELETE FROM ComboBox WHERE Property = 'TenantSelectionDlg.TenantId'");

                IDictionary<Guid, string> allTenants;

                try
                {
                    allTenants = LoadTenants(dbConnectionString);
                }
                catch (Exception ex)
                {
                    // Handle database exceptions gracefully
                    session.Log("ERROR loading tenants from database in custom action DiscoverTenants {0}", ex);
                    session["TenantSelectionDlg.ErrorMessage"] = 
                        string.Format("Tenants could not be loaded from database: {0}", ex.Message);
                    return ActionResult.Success;
                }

                session["TenantSelectionDlg.ErrorMessage"] = string.Empty;

                Guid? defaultTenantId = null;

                using (View view = session.Database.OpenView("SELECT * FROM ComboBox WHERE Property = 'TenantSelectionDlg.TenantId'"))
                {
                    view.Execute();

                    int index = view.Database.CountRows("ComboBox", "Property = 'TenantSelectionDlg.TenantId'"); // Should be 0

                    if (allowAllTenants)
                    {
                        Guid allTenantsId = Guid.Empty;

                        Record record = session.Database.CreateRecord(4);
                        record.SetString(1, "TenantSelectionDlg.TenantId"); // Property
                        record.SetInteger(2, ++index); // Order
                        record.SetString(3, allTenantsId.ToString("D")); // Value
                        record.SetString(4, "<All Tenants>"); // Text

                        defaultTenantId = allTenantsId;

                        view.InsertTemporary(record);
                    }

                    foreach (KeyValuePair<Guid, string> kvp in allTenants.OrderBy(p => p.Value))
                    {
                        if (defaultTenantId == null)
                        {
                            defaultTenantId = kvp.Key;
                        }

                        Record record = session.Database.CreateRecord(4);
                        record.SetString(1, "TenantSelectionDlg.TenantId"); // Property
                        record.SetInteger(2, ++index); // Order
                        record.SetString(3, kvp.Key.ToString("D")); // Value
                        record.SetString(4, kvp.Value); // Text

                        view.InsertTemporary(record);
                    }
                }

                string currentTenantIdString = session["TenantSelectionDlg.TenantId"];

                Guid currentTenantId;

                if (Guid.TryParse(currentTenantIdString, out currentTenantId))
                {
                    if (allTenants.ContainsKey(currentTenantId))
                    {
                        currentTenantIdString = currentTenantId.ToString("D");
                    }
                    else
                    {
                        currentTenantIdString = defaultTenantId.HasValue 
                            ? defaultTenantId.Value.ToString("D") : string.Empty;
                    }
                }
                else
                {
                    currentTenantIdString = defaultTenantId.HasValue 
                        ? defaultTenantId.Value.ToString("D") : string.Empty;
                }

                session["TenantSelectionDlg.TenantId"] = currentTenantIdString;

                session.Log("End DiscoverTenants custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action DiscoverTenants {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Retrieve all tenant names and ids from the database.
        /// </summary>
        private static IDictionary<Guid, string> LoadTenants(string dbConnectionString)
        {
            Dictionary<Guid, string> result = new Dictionary<Guid, string>();

            using (SqlConnection connection = new SqlConnection(dbConnectionString))
            {
                connection.Open();

                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = @"SELECT NAME, FOLDER_ID FROM TB_SEC_FOLDER WHERE FOLDER_TYPE = 'T'";

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                string name = reader.GetString(0);
                                Guid id = reader.GetGuid(1);

                                result.Add(id, name);
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}
