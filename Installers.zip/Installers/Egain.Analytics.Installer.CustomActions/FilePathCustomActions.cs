﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.IO;
    using WixToolset.Dtf.WindowsInstaller;
    
    /// <summary>
    /// Collection of custom actions for manipulating file paths.
    /// </summary>
    public class FilePathCustomActions
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "FilePathCustomActions.";

        private const string FullPathVariableKey = "FullPathVariable";
        private const string FileNameVariableKey = "FileNameVariable";
        private const string FolderPathVariableKey = "FolderPathVariable";

        #endregion

        /// <summary>
        /// Split a file path into a folder and file name.
        /// </summary>
        [CustomAction]
        public static ActionResult SplitPath(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin SplitPath custom action");

                string fullPath = CustomActionUtils.GetValueFromVariable(
                    session, FullPathVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Full path [{fullPath}]"));

                string fileNameVariable = CustomActionUtils.GetVariableValue(
                    session, FileNameVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File name variable [{fileNameVariable}]"));

                string folderPathVariable = CustomActionUtils.GetVariableValue(
                    session, FolderPathVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Folder path variable [{folderPathVariable}]"));

                string fileName = Path.GetFileName(fullPath);
                session.Log(CustomActionUtils.EscapeString($"File name [{fileName}]"));

                string folderPath = Path.GetDirectoryName(fullPath);
                session.Log(CustomActionUtils.EscapeString($"Folder path [{folderPath}]"));

                CustomActionUtils.SetVariableValue(session, fileNameVariable, fileName);
                CustomActionUtils.SetVariableValue(session, folderPathVariable, folderPath);

                session.Log("End SplitPath custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in SplitPath custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Join a folder path and file name into a single file path.
        /// </summary>
        [CustomAction]
        public static ActionResult JoinPath(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin JoinPath custom action");

                string fullPathVariable = CustomActionUtils.GetVariableValue(
                    session, FullPathVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Full path variable name [{fullPathVariable}]"));

                string fileName = CustomActionUtils.GetValueFromVariable(
                    session, FileNameVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File name [{fileName}]"));

                string folderPath = CustomActionUtils.GetValueFromVariable(
                    session, FolderPathVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Folder path [{folderPath}]"));

                string fullPath = Path.Combine(folderPath, fileName);
                session.Log(CustomActionUtils.EscapeString($"Full path calculated as [{fullPath}]"));

                CustomActionUtils.SetVariableValue(session, fullPathVariable, fullPath);

                session.Log("End JoinPath custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in JoinPath custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
