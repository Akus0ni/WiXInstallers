﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Runtime.InteropServices;
    using System.ServiceProcess;

    using WixToolset.Dtf.WindowsInstaller;
    using Microsoft.Web.Administration;

    /// <summary>
    /// Class holding all actions from the previous installers InstallScript.
    /// No methods should be added here and these should be phased out if/when a way to do it in pure WiX is found.
    /// </summary>
    public class WebsiteConfigurationCustomAction
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Interoperability", "CA1401:PInvokesShouldNotBeVisible")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1060:MovePInvokesToNativeMethodsClass")]
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern Boolean ChangeServiceConfig(
            IntPtr hService,
            UInt32 nServiceType,
            UInt32 nStartType,
            UInt32 nErrorControl,
            String lpBinaryPathName,
            String lpLoadOrderGroup,
            IntPtr lpdwTagId,
            [In] char[] lpDependencies,
            String lpServiceStartName,
            String lpPassword,
            String lpDisplayName);

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA2101:SpecifyMarshalingForPInvokeStringArguments", MessageId = "1")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1060:MovePInvokesToNativeMethodsClass")]
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr OpenService(
            IntPtr hSCManager, string lpServiceName, uint dwDesiredAccess);

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Interoperability", "CA1401:PInvokesShouldNotBeVisible")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1060:MovePInvokesToNativeMethodsClass")]
        [DllImport("advapi32.dll", EntryPoint = "OpenSCManagerW", ExactSpelling = true, CharSet = CharSet.Unicode,
            SetLastError = true)]
        public static extern IntPtr OpenSCManager(
            string machineName, string databaseName, uint dwAccess);

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Interoperability", "CA1401:PInvokesShouldNotBeVisible")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1060:MovePInvokesToNativeMethodsClass")]
        [DllImport("advapi32.dll", EntryPoint = "CloseServiceHandle")]
        public static extern int CloseServiceHandle(IntPtr hSCObject);

        private const uint SERVICE_NO_CHANGE = 0xFFFFFFFF;
        private const uint SERVICE_QUERY_CONFIG = 0x00000001;
        private const uint SERVICE_CHANGE_CONFIG = 0x00000002;
        private const uint SC_MANAGER_ALL_ACCESS = 0x000F003F;

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Interoperability", "CA1404:CallGetLastErrorImmediatelyAfterPInvoke")]
        [CustomAction]
        public static ActionResult SetupIISSettings(Session session)
        {
            try
            {
                //Set the aspnet_state service to auto start.
                ServiceController controller = new ServiceController("aspnet_state");
                bool succeeded = ChangeStartMode(controller, ServiceStartMode.Automatic);

                if (!succeeded)
                {
                    // We need to fish out the error code and attempt to work out what actually happened.
                    int nError = Marshal.GetLastWin32Error();
                    var win32Exception = new Win32Exception(nError);
                    session.Log($"Unable able to change the start-up mode of the aspnet_state service. Message: {win32Exception.Message}");
                    return ActionResult.Failure;
                }

                // Attempt to start up the service.
                if (controller.Status != ServiceControllerStatus.Running &&
                    controller.Status != ServiceControllerStatus.StartPending)
                {
                    controller.Start();
                }

                // Turn off rapid fail protection.
                using (ServerManager localServer = new ServerManager())
                {
                    ApplicationPool appPool = localServer.ApplicationPools["DefaultAppPool"];
                    appPool.Failure.RapidFailProtection = false;
                    localServer.CommitChanges();
                }

                RunCommand(session, "unlock config /section:system.webserver/security/authentication/windowsAuthentication");
                RunCommand(session, "unlock config /section:system.webserver/security/authentication/anonymousauthentication");
                RunCommand(session, "unlock config /section:system.webserver/rewrite/allowedServerVariables");

                int arrHeader = RunCommand(session, "set config -section:system.webServer/proxy /arrResponseHeader:\"False\" /commit:apphost");
                if (arrHeader != 0)
                {
                    session.Log($"ARR response header wasn't able to be turned off. Error code {arrHeader}.");
                }

                RunCommand(session, "unlock config /section:system.webserver/security/ipSecurity");
                RunCommand(session, "set apppool /apppool.name:ExonyAppPool /startMode:AlwaysRunning");

                int webProxy = RunCommand(session, "set config -section:system.webServer/proxy /enabled:\"True\" /commit:apphost");
                if (webProxy != 0)
                {
                    session.Log($"ARR header wasn't able to be set. Error code {webProxy}.");
                }

                int idleTimeout = RunCommand(session, "set config -section:applicationPools -applicationPoolDefaults.processModel.idleTimeout:00:00:00");
                if (idleTimeout != 0)
                {
                    session.Log($"Idle timeout on the application pools wasn't able to be set. Error code {idleTimeout}.");
                }

                RunCommand(session, "set app \"Default Web Site/Portal/ws\" -applicationPool:ARR");
                RunCommand(session, "set apppool /apppool.name:ARR -managedPipelineMode:Integrated");
                RunCommand(session, "set apppool /apppool.name:ARR -managedRuntimeVersion:\"\"");
                RunCommand(session, "set apppool /apppool.name:ARR /startMode:AlwaysRunning");
                RunCommand(session, "start apppool /apppool.name:ARR");
                RunCommand(session, "delete apppool /apppool.name:\"ASP.NET v4.0 ARR\"");
            }
            catch (Exception ex)
            {
                session.Log($"Error during setting up IIS settings. Message: {ex.Message} Inner message: {ex.InnerException?.Message}");
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        private static int RunCommand(Session session, string command)
        {
            return RunCommand(session, $@"{Environment.SystemDirectory}\inetsrv\appcmd", command);
        }

        private static int RunCommand(Session session, string exe, string command)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = exe;
            startInfo.Arguments = command;
            startInfo.UseShellExecute = false;
            startInfo.RedirectStandardOutput = true;
            startInfo.CreateNoWindow = true;
            startInfo.WindowStyle = ProcessWindowStyle.Hidden;

            int returnValue = -1;

            // Run the process and wait until it returns, ignoring way in which it exited.
            Process proc = Process.Start(startInfo);
            if (proc != null)
            {
                proc.WaitForExit();
                returnValue = proc.ExitCode;

                if (returnValue != 0)
                {
                    session.Log($"Console command failed with error code {returnValue}. Target exe: {exe}. Command: {command}.");
                }
            }

            return returnValue;
        }

        public static bool ChangeStartMode(ServiceController svc, ServiceStartMode mode)
        {
            var scManagerHandle = OpenSCManager(null, null, SC_MANAGER_ALL_ACCESS);
            if (scManagerHandle == IntPtr.Zero)
            {
                throw new ExternalException("Open Service Manager Error");
            }

            var serviceHandle = OpenService(
                scManagerHandle,
                svc.ServiceName,
                SERVICE_QUERY_CONFIG | SERVICE_CHANGE_CONFIG);

            if (serviceHandle == IntPtr.Zero)
            {
                throw new ExternalException("Open Service Error");
            }

            var result = ChangeServiceConfig(
                serviceHandle,
                SERVICE_NO_CHANGE,
                (uint)mode,
                SERVICE_NO_CHANGE,
                null,
                null,
                IntPtr.Zero,
                null,
                null,
                null,
                null);

            CloseServiceHandle(serviceHandle);
            CloseServiceHandle(scManagerHandle);

            return result;
        }
    }
}
