﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using Exony.Security.Encryption;

    using System;
    using System.Data.SqlClient;
    using System.Xml;

    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Custom actions for reading and modifying the boostrap connection string used for eGain Analytics products.
    /// </summary>
    public class BootstrapConnectionCustomActions
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "BootstrapConnectionCustomActions.";

        private const string FilePathKey = "FilePath";
        private const string ApplicationNameKey = "ApplicationName";
        private const string DbUserKey = "DbUser";
        private const string DbPassowrdKey = "DbPassword";
        private const string DbServerKey = "DbServer";
        private const string DbCatalogKey = "DbCatalog";
        private const string SectionNameKey = "SectionName";
        private const string SettingNameKey = "SettingName";

        #endregion

        #region Custom Actions

        /// <summary>
        /// Custom action to set the boostrap connection string in a specific app.config file.
        /// This action would generally be run as a deferred custom action.
        /// Application Name=Mediator Service Bootstrap;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=Portal;Data Source=localhost
        /// </summary>
        [CustomAction]
        public static ActionResult SetBootstrapConnection(Session session)
        {
            try
            {
                session.Log("BEGIN SetBootstrapConnection custom action");

                string filePath = CustomActionUtils.GetVariableValue(
                        session, FilePathKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

                string applicationName = CustomActionUtils.GetVariableValue(
                        session, ApplicationNameKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Application name [{applicationName}]"));

                string dbUser = CustomActionUtils.GetVariableValue(
                        session, DbUserKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"DB user [{dbUser}]"));

                String dbPassword = null;

                if (!String.IsNullOrEmpty(dbUser))
                {
                    dbPassword = CustomActionUtils.GetVariableValue(
                       session, DbPassowrdKey, ImmediateActionVariablePrefix);
                }

                string dbServer = CustomActionUtils.GetVariableValue(
                        session, DbServerKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"DB server [{dbServer}]"));

                string dbCatalog = CustomActionUtils.GetVariableValue(
                        session, DbCatalogKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"DB catalog [{dbCatalog}]"));

                string sectionName = CustomActionUtils.GetVariableValue(
                        session, SectionNameKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Section Name [{sectionName}]"));

                string settingName = CustomActionUtils.GetVariableValue(
                        session, SettingNameKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Setting Name [{settingName}]"));

                // Create connection string and save to specifed file
                WriteBootstrapConnectionString(session, filePath, applicationName, dbUser, dbPassword, dbServer, dbCatalog, sectionName, settingName);

                session.Log("END SetBootstrapConnection custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action SetBootstrapConnection {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Custom action to read the boostrap connection string from a specofoc app.config file.
        /// This action would generally be run as an immediate custom action.
        /// </summary>
        [CustomAction]
        public static ActionResult GetBootstrapConnection(Session session)
        {
            try
            {
                session.Log("BEGIN GetBootstrapConnection custom action");

                string filePath = CustomActionUtils.GetVariableValue(
                        session, FilePathKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

                string applicationName = null;
                string dbUser = null;
                string dbPassword = null;
                string dbServer = null;
                string dbCatalog = null;

                ReadBootstrapConnectionProperties(session, filePath, 
                    out applicationName, out dbUser, out dbPassword, out dbServer, out dbCatalog);

                CustomActionUtils.SetVariableValue(session, ApplicationNameKey, applicationName, ImmediateActionVariablePrefix);
                CustomActionUtils.SetVariableValue(session, DbUserKey, dbUser, ImmediateActionVariablePrefix);
                CustomActionUtils.SetVariableValue(session, DbPassowrdKey, dbPassword, ImmediateActionVariablePrefix);
                CustomActionUtils.SetVariableValue(session, DbServerKey, dbServer, ImmediateActionVariablePrefix);
                CustomActionUtils.SetVariableValue(session, DbCatalogKey, dbCatalog, ImmediateActionVariablePrefix);

                session.Log("END GetBootstrapConnection custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action GetBootstrapConnection {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        #endregion

        #region Utility Methods

        /// <summary>
        /// Read bootstrap connection string properties from the specified file.
        /// </summary>
        private static void ReadBootstrapConnectionProperties(Session session, String filePath, 
            out string applicationName, out string dbUser, out string dbPassword, out string dbServer, out string dbCatalog)
        {
            // Load the config into an xml document
            XmlDocument configDoc = new XmlDocument();
            configDoc.Load(filePath);

            // Read the bootstrap connection string
            XmlElement valueElement = GetBoostrapConnectionStringValueElement(configDoc);

            String connectionString = valueElement?.InnerText;

            if (String.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentException("Specified app.config file does not contain a valid Exony.Monitoring.Settings BootstrapConnectionString setting");
            }

            // Decrypt the connection string if needed
            if (connectionString.StartsWith("{alg:", StringComparison.OrdinalIgnoreCase))
            {
                session.Log("Decrypting connection string");

                connectionString = ExonySymmetricCryptographer.Decrypt(connectionString);
            }

            SqlConnectionStringBuilder sqlConnectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

            applicationName = sqlConnectionStringBuilder.ApplicationName;
            dbUser = sqlConnectionStringBuilder.UserID;
            dbPassword = sqlConnectionStringBuilder.Password;
            dbServer = sqlConnectionStringBuilder.DataSource;
            dbCatalog = sqlConnectionStringBuilder.InitialCatalog;
        }

        /// <summary>
        /// Read bootstrap connection string properties from the specified file.
        /// </summary>
        private static void WriteBootstrapConnectionString(Session session, String filePath,
            String applicationName, string dbUser, string dbPassword, string dbServer, string dbCatalog, string sectionName, string settingName)
        {
            SqlConnectionStringBuilder sqlConnectionStringBuilder = new SqlConnectionStringBuilder();
            sqlConnectionStringBuilder.ApplicationName = applicationName;

            if (String.IsNullOrEmpty(dbUser))
            {
                sqlConnectionStringBuilder.IntegratedSecurity = true;
            }
            else
            {
                sqlConnectionStringBuilder.UserID = dbUser;
                sqlConnectionStringBuilder.Password = dbPassword;
            }
            
            sqlConnectionStringBuilder.DataSource = dbServer;
            sqlConnectionStringBuilder.InitialCatalog = dbCatalog;

            // Encrypt the connection string
            String connectionString = ExonySymmetricCryptographer.EncryptUsingLocalKey(sqlConnectionStringBuilder.ConnectionString);

            // Load the config into an xml document
            XmlDocument configDoc = new XmlDocument();
            configDoc.Load(filePath);

            // Read the bootstrap connection string
            XmlElement valueElement = GetBoostrapConnectionStringValueElement(configDoc, sectionName, settingName);

            valueElement.InnerText = connectionString;

            configDoc.Save(filePath);
        }

        /// <summary>
        /// Get the boostrap connection string value element from a config file.
        /// </summary>
        private static XmlElement GetBoostrapConnectionStringValueElement(XmlDocument configDoc, string sectionName = null, string settingName = null)
        {
            sectionName = string.IsNullOrEmpty(sectionName) ? "Exony.Monitoring.Settings" : sectionName;
            XmlElement settingsRootElement =
                configDoc.SelectSingleNode($"/configuration/applicationSettings/{sectionName}") as XmlElement;

            if (settingsRootElement == null)
            {
                throw new ArgumentException($"Specified app.config file does not contain a valid {sectionName} block");
            }

            settingName = string.IsNullOrEmpty(settingName) ? "BootstrapConnectionString" : settingName;

            XmlElement settingElement =
                        settingsRootElement.SelectSingleNode($"setting[@name='{settingName}']") as XmlElement;

            if (settingElement == null)
            {
                throw new ArgumentException($"Specified app.config file does not contain a {settingName} setting in the {sectionName} block");
            }

            XmlElement valueElement = settingElement.SelectSingleNode("value") as XmlElement;

            if (valueElement == null)
            {
                throw new ArgumentException($"Specified app.config file does not contain a value for the {settingName} setting in the {sectionName} block");
            }

            return valueElement;
        }

        #endregion
    }
}
