﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Xml;
    using WixToolset.Dtf.WindowsInstaller;
    using Exony.Security.Encryption;

    /// <summary>
    /// Collection of custom actions for manipulating app.config files.
    /// </summary>
    public class AppConfigCustomActions
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "AppConfigCustomActions.";

        private const string FilePathKey = "FilePath";
        private const string SectionNameKey = "SectionName";
        private const string VariablePrefixKey = "VariablePrefix";

        #endregion

        #region Custom Actions

        /// <summary>
        /// Load all app.config settings into installer variables.
        /// </summary>
        [CustomAction]
        public static ActionResult LoadAllAppConfigSettings(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin LoadAllAppConfigSettings custom action");

                // It makes no sense to run this in deferred mode as the app settings won't be accessible 
                // outside of this action.
                if (CustomActionUtils.IsDeferred(session))
                {
                    throw new Exception("LoadAllAppConfigSettings must be run in immediate mode");
                }

                string filePath = CustomActionUtils.GetVariableValue(
                    session, FilePathKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

                string sectionName = CustomActionUtils.GetVariableValue(
                    session, SectionNameKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Section name [{sectionName}]"));

                string variablePrefix = CustomActionUtils.GetVariableValue(
                    session, VariablePrefixKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Variable prefix [{variablePrefix}]"));

                IDictionary<string, string> allSettings = ReadAllSettings(session, filePath, sectionName);

                if (allSettings.Count > 0)
                {
                    foreach (KeyValuePair<string, string> currentSetting in allSettings)
                    {
                        string settingName = currentSetting.Key;
                        string settingValue = currentSetting.Value;

                        if (settingValue.StartsWith("{alg:", StringComparison.OrdinalIgnoreCase))
                        {
                            session.Log("Detected encrypted setting: {0}", settingName);

                            settingValue = ExonySymmetricCryptographer.Decrypt(settingValue);
                        }
                        else
                        {
                            session.Log("Read Application Setting: {0}. Value: {1}.", settingName, settingValue);
                        }

                        // Empty strings cannot be inserted to the property table
                        if (string.IsNullOrWhiteSpace(settingValue))
                        {
                            continue;
                        }

                        string variableKey = $"{variablePrefix}{currentSetting.Key}";

                        CustomActionUtils.SetVariableValue(session, variableKey, settingValue);
                    }
                }

                session.Log("End LoadAllAppConfigSettings custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in LoadAllAppConfigSettings custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Save all app.config settings from installer variables.
        /// </summary>
        [CustomAction]
        public static ActionResult SaveAllAppConfigSettings(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin SaveAllAppConfigSettings custom action");

                // This modifies the file system so should always be run deferred once the files
                // have been copied to disk
                if (!CustomActionUtils.IsDeferred(session))
                {
                    throw new Exception("SaveAllAppConfigSettings must be run in deferred mode");
                }

                string filePath = CustomActionUtils.GetVariableValue(
                    session, FilePathKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

                string sectionName = CustomActionUtils.GetVariableValue(
                    session, SectionNameKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Section name [{sectionName}]"));

                string customActionDataString = CustomActionUtils.GetCustomActionDataString(session);

                const string settingsDelimiter = ";Settings=";
                const string settingsItemDelimiter = "@~eop~@";

                int settingsStartIndex = customActionDataString.IndexOf(settingsDelimiter, StringComparison.OrdinalIgnoreCase);
                string settingsString = customActionDataString.Substring(settingsStartIndex + settingsDelimiter.Length);
                string[] settingsBlocks = settingsString.Split(new[] { settingsItemDelimiter }, StringSplitOptions.RemoveEmptyEntries);

                IDictionary<string, string> allSettings = new Dictionary<string, string>();

                foreach (string currentSettingBlock in settingsBlocks)
                {
                    int keyValueDelimterIndex = currentSettingBlock.IndexOf("=", StringComparison.OrdinalIgnoreCase);
                    string key = currentSettingBlock.Substring(0, keyValueDelimterIndex).Trim();
                    string value = currentSettingBlock.Substring(keyValueDelimterIndex + 1).Trim();

                    session.Log("Write Application Setting: {0}. Value: {1}.", key, value);

                    allSettings[key] = value;
                }

                WriteSettings(session, filePath, sectionName, allSettings);

                session.Log("End SaveAllAppConfigSettings custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in SaveAllAppConfigSettings custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        #endregion

        #region Utility Methods

        /// <summary>
        /// Read all settings from the sppecified section of the supplied app configuration.
        /// </summary>
        private static IDictionary<string, string> ReadAllSettings(Session session, string filePath, string sectionName)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();

            if (!File.Exists(filePath))
            {
                session.Log($"Configuration file: {filePath} does not exist. Skipping load");
                return result;
            }

            // Load the config into an xml document
            XmlDocument configDoc = new XmlDocument();
            configDoc.Load(filePath);

            // Locate the component name node
            XmlElement componentRootElement =
                configDoc.SelectSingleNode($"/configuration/applicationSettings/{sectionName}") as XmlElement;

            if (componentRootElement != null)
            {
                foreach (XmlElement currentSettingElement in componentRootElement.SelectNodes("setting"))
                {
                    string settingName = currentSettingElement.GetAttribute("name");

                    if (string.IsNullOrWhiteSpace(settingName))
                    {
                        continue;
                    }

                    XmlElement valueElement =
                        currentSettingElement.SelectSingleNode("value") as XmlElement;

                    if (valueElement != null)
                    {
                        result[settingName] = valueElement.InnerText;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Read all settings from the sppecified section of the supplied app configuration.
        /// </summary>
        private static void WriteSettings(Session session, string filePath, string sectionName, IDictionary<string, string> newSettings)
        {
            // Clone callers collection
            newSettings = new Dictionary<string, string>(newSettings);

            if (!File.Exists(filePath))
            {
                session.Log($"Configuration file: {filePath} does not exist. Skipping save");
            }

            // Load the config into an xml document
            XmlDocument configDoc = new XmlDocument();
            configDoc.Load(filePath);

            // Locate the component name node
            XmlElement componentRootElement =
                configDoc.SelectSingleNode($"/configuration/applicationSettings/{sectionName}") as XmlElement;

            if (componentRootElement != null)
            {
                foreach (XmlElement currentSettingElement in componentRootElement.SelectNodes("setting"))
                {
                    string settingName = currentSettingElement.GetAttribute("name");

                    if (string.IsNullOrWhiteSpace(settingName))
                    {
                        continue;
                    }

                    if (newSettings.ContainsKey(settingName))
                    {
                        XmlElement valueElement =
                            currentSettingElement.SelectSingleNode("value") as XmlElement;

                        // Add value element if missing
                        if (valueElement == null)
                        {
                            valueElement = configDoc.CreateElement("value");
                            currentSettingElement.AppendChild(valueElement);
                        }

                        // Update value
                        valueElement.InnerText = newSettings[settingName];

                        newSettings.Remove(settingName);
                    }
                }

                // Add any settings that were missing from the app.config file
                foreach (KeyValuePair<string, string> missingAttribute in newSettings)
                {
                    session.Log($"Adding missing setting to app.config file: {missingAttribute.Key}");

                    XmlElement settingElement = configDoc.CreateElement("setting");
                    settingElement.SetAttribute("name", missingAttribute.Key);
                    settingElement.SetAttribute("serializeAs", "String");

                    XmlElement valueElement = configDoc.CreateElement("value");
                    valueElement.InnerText = missingAttribute.Value;

                    settingElement.AppendChild(valueElement);
                    componentRootElement.AppendChild(settingElement);
                }
            }
            else
            {
                session.Log(
                    $"Configuration file: {filePath} does not contain an application setting section for: {sectionName}. Skipping save");
            }

            configDoc.Save(filePath);
        }

        #endregion
    }
}
