#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using Exony.Security.Encryption;
    using WixToolset.Dtf.WindowsInstaller;

    public class EncryptStringCustomAction
    {
        #region Session Keys

        private const string StringToEncryptKey = "EncryptString.StringToEncrypt";
        private const string ResultVariableNameKey = "EncryptString.ResultVariableName";

        #endregion

        /// <summary>
        /// Encrypt a string value and store the result
        /// </summary>
        [CustomAction]
        public static ActionResult EncryptString(Session session)
        {
            try
            {
                session.Log("Begin EncryptString custom action");

                string stringToEncrypt = session[StringToEncryptKey];
                string resultVariableName = session[ResultVariableNameKey];

#if DEBUG
                session.Log($"StringToEncrypt - {stringToEncrypt}. ResultVariableName - {resultVariableName}.");
#endif

                // this will use the non-rotating local key for encryption
                session[resultVariableName] = ExonySymmetricCryptographer.EncryptUsingLocalKey(stringToEncrypt);

                session.Log("End EncryptString custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action EncryptString {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
