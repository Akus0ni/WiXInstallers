﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System.Data.SqlClient;
    using WixToolset.Dtf.WindowsInstaller;

    public class TestDbConnectionCustomAction
    {
        [CustomAction]
        public static ActionResult TestDbConnection(Session session)
        {
            //System.Diagnostics.Debugger.Launch();

            int integratedSecurityInt;
            bool integratedSecurity = false;
            
            if (int.TryParse(session["SqlConnectionDlg.IntegratedSecurity"], out integratedSecurityInt))
            {
                integratedSecurity = integratedSecurityInt == 1;
            }

            string dbServer = session["SqlConnectionDlg.DbServer"];
            string dbCatalog = session["SqlConnectionDlg.DbCatalog"];

            string connectionString;

            if (integratedSecurity)
            {
                connectionString = $"Data Source={dbServer};;Initial Catalog={dbCatalog};;Integrated Security=SSPI"; 
            }
            else
            {
                string dbUser = session["SqlConnectionDlg.DbUser"];
                string dbPassword = session["SqlConnectionDlg.DbPassword"];
                connectionString = $"Data Source={dbServer};;Initial Catalog={dbCatalog};;User ID={dbUser};;Password={dbPassword}";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    session["TEST_DB_CONNECTION_RESULT"] = "1";
                }
                catch
                {
                    session["TEST_DB_CONNECTION_RESULT"] = "0";
                }

                return ActionResult.Success;
            }
        }
    }
}
