﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using WixToolset.Dtf.WindowsInstaller;
    using System.Diagnostics;
    using System.DirectoryServices;

    public class ValidateUserCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "ValidateUserCustomAction.";

        private static class Keys
        {
            public const string UserName = "UserName";
            public const string UserValidationResult = "UserValidationResult";
        }

        #endregion

        [CustomAction]
        public static ActionResult ValidateUser(Session session)
        {
            //System.Diagnostics.Debugger.Launch();
            session.Log("BEGIN ValidateUser custom action");

            try
            {
                string userName = CustomActionUtils.GetVariableValue(
                           session, Keys.UserName, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Username [{userName}]"));

                bool isValid = UserValidation.UserOrServerExist(userName);
                String isValidStr = isValid ? "1" : "0";

                CustomActionUtils.SetVariableValue(session, Keys.UserValidationResult, isValidStr, ImmediateActionVariablePrefix);
                string result = CustomActionUtils.GetVariableValue(
                       session, Keys.UserValidationResult, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"User exist? [{result}]"));
            }
            catch (Exception ex)
            {
                session.Log("Error validation user {0}", ex);
                CustomActionUtils.SetVariableValue(session, Keys.UserValidationResult, "0", ImmediateActionVariablePrefix);
                return ActionResult.Success;
            }

            return ActionResult.Success;
        }

    }
}
