﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.IO;
    using System.Threading;
    using System.Windows.Forms;

    using WixToolset.Dtf.WindowsInstaller;

    public static class BrowseFileCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "BrowseFileCA.";

        private const string FilePathVariableKey = "FilePathVariable";
        private const string FileFilterKey = "FileFilter";

        #endregion

        /// <summary>
        /// Browse for a file using the .NET file browser.
        /// </summary>
        [CustomAction]
        public static ActionResult BrowseFile(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin BrowseFile custom action");

                string filePath = CustomActionUtils.GetValueFromVariable(
                    session, FilePathVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

                string fileFilter = CustomActionUtils.GetVariableValue(
                    session, FileFilterKey, ImmediateActionVariablePrefix, "All Files (*.*)|*.*");
                session.Log(CustomActionUtils.EscapeString($"File filter [{fileFilter}]"));

                Thread task = new Thread(() => GetFile(session, fileFilter, filePath));
                task.SetApartmentState(ApartmentState.STA);
                task.Start();
                task.Join();

                session.Log("End BrowseFile custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in BrowseFile custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /**
         * Retrieve a file using the .NET file dialog.
         */
        private static void GetFile(Session session, string fileFilter, string fileName)
        {
            OpenFileDialog fileDialog = new OpenFileDialog { Filter = fileFilter, CheckFileExists = true, CheckPathExists = true };

            if (!string.IsNullOrEmpty(fileName))
            {
                fileDialog.FileName = Path.GetFileName(fileName);
                fileDialog.InitialDirectory = Path.GetDirectoryName(fileName);
            }

            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = fileDialog.FileName;

                string resultVariableName = CustomActionUtils.GetVariableValue(
                    session, FilePathVariableKey, ImmediateActionVariablePrefix);

                CustomActionUtils.SetVariableValue(session, resultVariableName, filePath);

                session.Log(CustomActionUtils.EscapeString($"Selected file [{filePath}]"));
            }
        }
    }
}
