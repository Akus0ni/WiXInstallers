﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.IO;

    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Custom action for validating a file path.
    /// </summary>
    public static class CheckFileExistsCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "CheckFileExistsCA.";

        private const string PathKey = "Path";
        private const string ExistsVariableKey = "ExistsVariable";

        #endregion
        
        /// <summary>
        /// Check that a file exists.
        /// </summary>
        [CustomAction]
        public static ActionResult CheckFileExists(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin CheckFileExists custom action");

                string path = CustomActionUtils.GetVariableValue(
                    session, PathKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Path [{path}]"));

                bool fileExists = File.Exists(path);

                session.Log(CustomActionUtils.EscapeString($"File Exists [{fileExists}]"));

                string resultVariableName = CustomActionUtils.GetVariableValue(
                    session, ExistsVariableKey, ImmediateActionVariablePrefix);

                CustomActionUtils.SetVariableValue(session, resultVariableName, fileExists);

                session.Log("End CheckFileExists custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in CheckFileExists custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
