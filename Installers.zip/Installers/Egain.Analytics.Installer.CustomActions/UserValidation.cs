﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using WixToolset.Dtf.WindowsInstaller;
    using System.Diagnostics;
    using System.DirectoryServices;

    /// <summary>
    /// Class to validate user and Server
    /// </summary>
    public static class UserValidation
    {
        private const string NetworkService = "NT AUTHORITY\\NETWORK SERVICE";

        /// <summary>
        /// Method to validate user and server
        /// </summary>
        /// <param name="userInput"></param>
        /// <returns></returns>
        public static bool UserOrServerExist(string userInput)
        {
            string[] domainAndUser = new string[2];
            string path = string.Empty;
            string username = userInput;

            if(userInput == NetworkService)
            {
                return true;
            }

            //domain user
            if (username.Contains("\\"))
            {
                domainAndUser = username.Split('\\');
                path = domainAndUser[0] == "." ? string.Format(@"WinNT://{0}", System.Environment.MachineName) : string.Format(@"WinNT://{0}", domainAndUser[0]);
                username = domainAndUser[1];
            }
            else
            {
                // local user
                path = string.Format(@"WinNT://{0}", System.Environment.MachineName);
            }

            using (DirectoryEntry de = new DirectoryEntry(path))
            {
                try
                {
                    bool userExists = de.Children.Find(username) != null;
                    if (userExists)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
    }
}
