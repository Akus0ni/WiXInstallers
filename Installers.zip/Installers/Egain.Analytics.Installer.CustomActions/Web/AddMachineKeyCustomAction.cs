﻿// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Installer.CustomActions.Web
{
    using System;
    using System.IO;
    using System.Security.Cryptography;
    using System.Text;
    using System.Xml;
    using WixToolset.Dtf.WindowsInstaller;

    public class AddMachineKeyCustomAction
    {
        #region Session Keys

        private const string PassphraseKey = "PassPhrase";
        private const string WebConfigFolderKey = "WebConfigFolder";

        #endregion

        [CustomAction]
        public static ActionResult AddMachineKey(Session session)
        {
            ActionResult result = ActionResult.Success;

            session.Log("Begin AddMachineKey custom action");

            string configFileFolder = session.CustomActionData[WebConfigFolderKey];
            string passphrase = session.CustomActionData[PassphraseKey];

            string configFile = Path.Combine(configFileFolder, "web.config");

            FileInfo configInfo = new FileInfo(configFile);

            // use File.Exist as non-caching
            if (File.Exists(configInfo.FullName))
            {
                try
                {
                    configInfo.Attributes &= ~(System.IO.FileAttributes.ReadOnly | System.IO.FileAttributes.System);

                    // Load the config file into a DOM
                    XmlDocument doc = new XmlDocument();
                    doc.Load(configInfo.FullName);

                    XmlElement machineKeyNode = doc.SelectSingleNode("/configuration/system.web/machineKey") as XmlElement;
                    if (machineKeyNode == null)
                    {
                        // create if missing
                        machineKeyNode = doc.CreateElement("machineKey");

                        XmlNode systemWeb = doc.SelectSingleNode("/configuration/system.web");
                        if (systemWeb != null)
                        {
                            systemWeb.AppendChild(machineKeyNode);
                        }
                    }

                    // validationKey
                    var validationKey = GenerateStringHexHash(passphrase + "_val", 48);
                    machineKeyNode.SetAttribute("validationKey", validationKey);

                    // decryptionKey
                    var decryptionKey = GenerateStringHexHash(passphrase + "_dec", 48);
                    machineKeyNode.SetAttribute("decryptionKey", decryptionKey);

                    // validation == SHA1
                    machineKeyNode.SetAttribute("validation", "SHA1");

                    // decryption == 3DES
                    machineKeyNode.SetAttribute("decryption", "3DES");

                    // save file trying to preseve as much of the format as possible
                    // keep as close to the IIS Manager format as possible
                    XmlWriterSettings settings = new XmlWriterSettings();
                    settings.Indent = true;
                    settings.NewLineChars = Environment.NewLine;
                    using (XmlWriter writer = XmlWriter.Create(configInfo.FullName, settings))
                    {
                        doc.Save(writer);
                    }
                }
                catch (Exception ex)
                {
                    session.Log("ERROR: Error updating configuration file {0}. Exception: {1}", configFile, ex.Message);
                    return ActionResult.Failure;
                }
            }
            else
            {
                session.Log("ERROR: Could not find configuration file [{0}]", configFile);
                result = ActionResult.Failure;
            }

            session.Log("End AddMachineKey custom action for folder [{0}]", configFileFolder);

            return result;
        }

        /// <summary>
        /// Generates a random hex string from the password with the specified length. Provided the parameters are the same, the same string will be
        /// generated.
        /// </summary>
        private static string GenerateStringHexHash(string password, int length)
        {
            byte[] salt = { 5, 2, 2, 3, 2, 5, 6, 9 };
            Rfc2898DeriveBytes cdk = new Rfc2898DeriveBytes(password, salt, 784);

            byte[] bytes = cdk.GetBytes(length / 2);

            StringBuilder hex = new StringBuilder(bytes.Length * 2);
            foreach (byte b in bytes)
            {
                hex.AppendFormat("{0:x2}", b);
            }

            return hex.ToString().Substring(0, length);
        }
    }
}
