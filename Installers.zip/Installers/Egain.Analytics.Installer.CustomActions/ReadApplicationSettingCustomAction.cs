#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.IO;
    using System.Xml;
    using Exony.Security.Encryption;
    using WixToolset.Dtf.WindowsInstaller;
    
    /// <summary>
    /// Immedaite custom action for reading an application setting
    /// </summary>
    public class ReadApplicationSettingCustomAction
    {
        #region Session Keys

        private const string ConfigFilePathKey = "ReadApplicationSetting.ConfigFilePath";
        private const string SettingNameKey = "ReadApplicationSetting.SettingName";
        private const string OutputPropertyKey = "ReadApplicationSetting.OutputProperty";
        private const string SectionNameKey = "ReadApplicationSetting.SectionName";

        #endregion

        /// <summary>
        /// Read a setting from an app.config file
        /// </summary>
        [CustomAction]
        public static ActionResult ReadApplicationSetting(Session session)
        {
            try
            {
                session.Log("Begin ReadApplicationSetting custom action");

                ReadApplicationSettingInternal(session);

                session.Log("End ReadApplicationSetting custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in ReadApplicationSetting custom action {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        private static void ReadApplicationSettingInternal(Session session)
        {
            // Get the config file path
            string configFilePath = session[ConfigFilePathKey];

            // Get the section name
            string sectionName = session[SectionNameKey];

            // Get the setting name
            string settingName = session[SettingNameKey];

            // Get the output property name
            string outputPropertyName = session[OutputPropertyKey];

            session.Log("Reading app.config setting {0} for section {1} from file {2}. Output property name: {3}", 
                settingName, sectionName, configFilePath, outputPropertyName);

            if (!File.Exists(configFilePath))
            {
                // If the file isn't there then just fallback to the supplied value or default
                session.Log("Configuration file: {0} does not exist. Skipping configuration of property {1} from setting {2}",
                    configFilePath, outputPropertyName, settingName);

                return;
            }

            // Load the config into an xml document
            XmlDocument configDoc = new XmlDocument();
            configDoc.Load(configFilePath);

            string value;

            // Use naming convention to determine if the app.config setting is encrypted
            bool isEncrypted = false;
            string isEncryptedSettingName = $"{settingName}Encrypted";

            if (ReadApplicationSettingFromXml(configDoc, sectionName, isEncryptedSettingName, out value))
            {
                bool.TryParse(value, out isEncrypted);
            }

            if (!ReadApplicationSettingFromXml(configDoc, sectionName, settingName, out value))
            {
                session.Log("Could not locate setting: {0} in config file: {1}",
                    settingName, configFilePath);

                return;
            }

            if (isEncrypted)
            {
                session.Log("Detected encrypted setting: {0}", settingName);

                value = ExonySymmetricCryptographer.Decrypt(value);
            }

            if (!isEncrypted)
            {
                session.Log("Read app.config setting {0} for section {1} from file {2} as {3}",
                    settingName, sectionName, configFilePath, value);
            }
            else
            {
                session.Log("Read encrypted app.config setting {0} for section {1} from file {2} as ****",
                    settingName, sectionName, configFilePath);
            }

            session[outputPropertyName] = value;
        }

        private static bool ReadApplicationSettingFromXml(XmlDocument configDoc, string sectionName, string settingName, out string value)
        {
            value = null;

            // Locate the component name node
            XmlElement componentRootElement =
                configDoc.SelectSingleNode($"/configuration/applicationSettings/{sectionName}") as XmlElement;

            XmlElement settingElement =
                        componentRootElement?.SelectSingleNode($"setting[@name='{settingName}']") as XmlElement;

            XmlElement valueElement =
                        settingElement?.SelectSingleNode("value") as XmlElement;

            if (valueElement == null)
            {
                return false;
            }

            value = valueElement.InnerText;
            return true;
        }
    }
}
