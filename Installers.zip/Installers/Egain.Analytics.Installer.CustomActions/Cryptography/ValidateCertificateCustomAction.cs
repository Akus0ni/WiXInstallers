﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Security;
    using System.Security.Cryptography.X509Certificates;

    using WixToolset.Dtf.WindowsInstaller;

    public static class ValidateCertificateCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "ValidateCertificateCA.";

        private const string FilePathKey = "FilePath";
        private const string PasswordKey = "Password";
        private const string ResultVariableKey = "ResultVariable";

        #endregion

        /// <summary>
        /// Validate a certificate.
        /// </summary>
        [CustomAction]
        public static ActionResult ValidateCertificate(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin ValidateCertificate custom action");

                string filePath = CustomActionUtils.GetVariableValue(
                    session, FilePathKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

                string password = CustomActionUtils.GetVariableValue(
                    session, PasswordKey, ImmediateActionVariablePrefix);

                bool isValid = IsCertificateValid(session, filePath, password);

                session.Log(CustomActionUtils.EscapeString($"Is valid [{isValid}]"));

                string resultVariable = CustomActionUtils.GetVariableValue(
                    session, ResultVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Result variable [{resultVariable}]"));

                CustomActionUtils.SetVariableValue(session, resultVariable, isValid);

                session.Log("End ValidateCertificate custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in ValidateCertificate custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Check if a certificate is valid.
        /// </summary>
        private static bool IsCertificateValid(Session session, string filePath, string password)
        {
            try
            {
                X509Certificate2 x509 = new X509Certificate2();

                SecureString securePassword = null;

                if (!string.IsNullOrEmpty(password))
                {
                    securePassword = new SecureString();
                    foreach (char currentChar in password)
                    {
                        securePassword.AppendChar(currentChar);
                    }
                }
                x509.Import(filePath, securePassword, X509KeyStorageFlags.DefaultKeySet);
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR while validating certificate [{0}]"), ex);
                return false;
            }

            return true;
        }
    }
}
