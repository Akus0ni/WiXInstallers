﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Security;
    using System.Security.Cryptography.X509Certificates;

    using WixToolset.Dtf.WindowsInstaller;

    public static class GenerateCertificateThumbprintCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "GenerateCertificateThumbprintCA.";

        private const string FilePathKey = "FilePath";
        private const string PasswordKey = "Password";
        private const string ThumbprintVariableKey = "ThumbprintVariable";

        #endregion

        /// <summary>
        /// Generate a thumbprint for a certificate.
        /// </summary>
        [CustomAction]
        public static ActionResult GenerateCertificateThumbprint(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin GenerateCertificateThumbprint custom action");

                string filePath = CustomActionUtils.GetVariableValue(
                    session, FilePathKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

                string password = CustomActionUtils.GetVariableValue(
                    session, PasswordKey, ImmediateActionVariablePrefix);

                string certificateThumbprint = GenerateCertificateThumbprintFromFile(filePath, password);
                session.Log(CustomActionUtils.EscapeString($"Certificate thumbprint [{certificateThumbprint}]"));

                string thumbprintVariable = CustomActionUtils.GetVariableValue(
                    session, ThumbprintVariableKey, ImmediateActionVariablePrefix);
                session.Log(CustomActionUtils.EscapeString($"Thumbprint variable [{thumbprintVariable}]"));

                CustomActionUtils.SetVariableValue(session, thumbprintVariable, certificateThumbprint);

                session.Log("End GenerateCertificateThumbprint custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in GenerateCertificateThumbprint custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Generate a certificate thumbprint for the specified file.
        /// </summary>
        private static string GenerateCertificateThumbprintFromFile(string filePath, string password)
        {
            X509Certificate2 x509 = new X509Certificate2();

            SecureString securePassword = null;

            if (!string.IsNullOrEmpty(password))
            {
                securePassword = new SecureString();
                foreach (char currentChar in password)
                {
                    securePassword.AppendChar(currentChar);
                }
            }

            x509.Import(filePath, securePassword, X509KeyStorageFlags.DefaultKeySet);

            return x509.Thumbprint;
        }
    }
}
