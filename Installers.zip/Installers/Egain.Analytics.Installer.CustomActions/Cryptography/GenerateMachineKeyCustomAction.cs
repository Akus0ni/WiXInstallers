﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Security.Cryptography;
    using System.Text;

    using WixToolset.Dtf.WindowsInstaller;

    public static class GenerateMachineKeyCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "GenerateMachineKeyCA.";

        private const string PassPhraseKey = "PassPhrase";
        private const string MachineKeyVariableKey = "MachineKeyVariable";

        #endregion

        /// <summary>
        /// Additional Entropy for DPAPI
        /// </summary>
        private static readonly byte[] Entropy = { 9, 8, 7, 6, 5 };

        /// <summary>
        /// Generate a machine key.
        /// </summary>
        [CustomAction]
        public static ActionResult GenerateMachineKey(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin GenerateMachineKey custom action");

                string passPhrase = CustomActionUtils.GetVariableValue(
                    session, PassPhraseKey, ImmediateActionVariablePrefix);

                session.Log(CustomActionUtils.EscapeString($"Machine key passphrase [{passPhrase}]"));

                string machineKey = GenerateMachineKeyString(passPhrase);

                string resultVariableName = CustomActionUtils.GetVariableValue(
                    session, MachineKeyVariableKey, ImmediateActionVariablePrefix);

                CustomActionUtils.SetVariableValue(session, resultVariableName, machineKey);

                session.Log(CustomActionUtils.EscapeString($"Generated machine key [{machineKey}]"));

                session.Log("End GenerateMachineKey custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in GenerateMachineKey custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        /// <summary>
        /// Generate a machine key from the specified passphrase.
        /// </summary>
        /// <param name="passPhrase"></param>
        private static string GenerateMachineKeyString(string passPhrase)
        {
            // Encrypt the secret using DPAPI
            byte[] passwordBytes = Encoding.UTF8.GetBytes(passPhrase);
            byte[] protectedBytes = ProtectedData.Protect(passwordBytes, Entropy, DataProtectionScope.LocalMachine);

            return Convert.ToBase64String(protectedBytes);
        }
    }
}