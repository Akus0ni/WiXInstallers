﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Data.SqlClient;
    using System.IO;
    using System.Reflection;
    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Base class for custom actions that execute sql scripts.
    /// </summary>
    public class SqlCustomActionBase
    {
        /// <summary>
        /// Get the analytics version for the specified connection string.
        /// </summary>
        protected static VersionNumber GetAnalyticsVersion(Session session, String connectionString)
        {
            VersionNumber result;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmd = connection.CreateCommand();
                cmd.CommandText = "SELECT PROPERTY_VALUE FROM TB_ADM_LOCAL_PROPERTY WHERE PROPERTY_KEY='PROP_BUILD_VERSION'";
                string versionString = (string)cmd.ExecuteScalar();

                session.Log("Analytics Version: {0}", versionString);

                // If this is a dev build then make it look like its a higher version than anything else.
                if (versionString.Equals("@@BuildVersion@@", StringComparison.InvariantCultureIgnoreCase) ||
                    versionString.Equals("1.1.1.1", StringComparison.InvariantCultureIgnoreCase))
                {
                    result = new VersionNumber(int.MaxValue, int.MaxValue, int.MaxValue, int.MaxValue);
                }
                else
                {
                    result = new VersionNumber(versionString);
                }
            }

            return result;
        }

        /// <summary>
        /// Get embedded SQL text from this assembly
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times")]
        protected static string GetEmbeddedSqlText(string resourceName)
        {
            string result = string.Empty;

            Assembly executingAssembly = Assembly.GetCallingAssembly();

            using (Stream stream = executingAssembly.GetManifestResourceStream(resourceName))
            {
                if (stream == null)
                {
                    return result;
                }

                using (StreamReader reader = new StreamReader(stream))
                {
                    result = reader.ReadToEnd();
                }
            }

            return result;
        }
    }
}
