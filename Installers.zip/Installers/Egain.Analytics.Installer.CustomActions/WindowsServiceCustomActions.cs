﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.ServiceProcess;
    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Collection of custom actions for manipulating windows services.
    /// </summary>
    public class WindowsServiceCustomActions
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "WindowsServiceCustomActions.";

        private const string ServiceNameKey = "ServiceName";
        private const string TimeoutKey = "Timeout";

        #endregion

        #region Custom Actions

        /// <summary>
        /// Restart a windows service.
        /// </summary>
        [CustomAction]
        public static ActionResult RestartWindowsService(Session session)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();

                session.Log("Begin RestartService custom action");

                string serviceName = CustomActionUtils.GetVariableValue(
                    session, ServiceNameKey, ImmediateActionVariablePrefix);
                session.Log($"Service name: {serviceName}");

                // Timeout in seconds
                int timeout = CustomActionUtils.GetVariableValue(
                    session, TimeoutKey, ImmediateActionVariablePrefix, 60);
                session.Log($"Timeout: {timeout}");

                ServiceController service = new ServiceController(serviceName);

                // Only restart if currently running
                if (service.Status == ServiceControllerStatus.Running)
                {
                    session.Log(CustomActionUtils.EscapeString($"Stopping service [{serviceName}]"));

                    service.Stop();

                    service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(timeout));

                    session.Log(CustomActionUtils.EscapeString($"Starting service [{serviceName}]"));

                    service.Start();
                }

                session.Log("End RestartService custom action");
            }
            catch (Exception ex)
            {
                session.Log(CustomActionUtils.EscapeString("ERROR in RestartService custom action [{0}]"), ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
 
        #endregion
    }
}
