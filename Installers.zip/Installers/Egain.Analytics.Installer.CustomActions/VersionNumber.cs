﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;

    /// <summary>
    /// Class representing an up to four part version number.
    /// </summary>
    public class VersionNumber : IComparable<VersionNumber>
    {
        #region Construction

        /// <summary>
        /// Create a one part version number
        /// </summary>
        public VersionNumber(int major)
        {
            if (major < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(major), "Version part cannot be a negative number");
            }

            Major = major;
        }

        /// <summary>
        /// Create a two part version number
        /// </summary>
        public VersionNumber(int major, int minor)
        {
            if (major < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(major), "Version part cannot be a negative number");
            }

            if (minor < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(minor), "Version part cannot be a negative number");
            }

            Major = major;
            Minor = minor;
        }

        /// <summary>
        /// Create a three part version number
        /// </summary>
        public VersionNumber(int major, int minor, int build)
        {
            if (major < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(major), "Version part cannot be a negative number");
            }

            if (minor < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(minor), "Version part cannot be a negative number");
            }

            if (build < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(build), "Version part cannot be a negative number");
            }

            Major = major;
            Minor = minor;
            Build = build;
        }

        /// <summary>
        /// Create a four part version number
        /// </summary>
        public VersionNumber(int major, int minor, int build, int revision)
        {
            if (major < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(major), "Version part cannot be a negative number");
            }

            if (minor < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(minor), "Version part cannot be a negative number");
            }

            if (build < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(build), "Version part cannot be a negative number");
            }

            if (revision < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(revision), "Version part cannot be a negative number");
            }

            Major = major;
            Minor = minor;
            Build = build;
            Revision = revision;
        }

        /// <summary>
        /// Create a VersionNumber from a string.
        /// </summary>
        public VersionNumber(string versionString)
        {
            string[] versionParts = versionString.Split('.');

            int majorPart = int.Parse(versionParts[0]);

            if (majorPart < 0)
            {
                throw new ArgumentException("Major part cannot be a negative number", nameof(versionString));
            }

            Major = majorPart;

            if (versionParts.Length > 1)
            {
                int minorPart = int.Parse(versionParts[1]);

                if (minorPart < 0)
                {
                    throw new ArgumentException("Minor part cannot be a negative number", nameof(versionString));
                }

                Minor = minorPart;
            }

            if (versionParts.Length > 2)
            {
                int buildPart = int.Parse(versionParts[2]);

                if (buildPart < 0)
                {
                    throw new ArgumentException("Build part cannot be a negative number", nameof(versionString));
                }

                Build = buildPart;
            }

            if (versionParts.Length > 3)
            {
                int revisionPart = int.Parse(versionParts[3]);

                if (revisionPart < 0)
                {
                    throw new ArgumentException("Revision part cannot be a negative number", nameof(versionString));
                }

                Revision = revisionPart;
            }
        }

        /// <summary>
        /// Copy constructor.
        /// </summary>
        public VersionNumber(VersionNumber other)
        {
            Major = other.Major;
            Minor = other.Minor;
            Build = other.Build;
            Revision = other.Revision;
        }

        #endregion

            #region Properties

        public int Major { get; }

        public int? Minor { get; private set; }

        public int? Build { get; private set; }

        public int? Revision { get; private set; }

        #endregion

        #region Methods

        /// <summary>
        /// Convert this VersionNumber to another version with the specified number of parts.
        /// 
        /// e.g. Convert 1.2.0 to 1.2.0.0 (4 parts)
        /// or convert 1.2.0 to 1.2 (2 parts)
        /// </summary>
        public VersionNumber WithPartCount(int partCount)
        {
            if (partCount < 1 || partCount > 4)
            {
                throw new ArgumentOutOfRangeException(nameof(partCount), "Part count must be between 1 and 4");
            }

            VersionNumber result = new VersionNumber(this);

            if (!result.Minor.HasValue && partCount > 1)
            {
                result.Minor = 0;
            }

            if (!result.Build.HasValue && partCount > 2)
            {
                result.Build = 0;
            }

            if (!result.Revision.HasValue && partCount > 3)
            {
                result.Revision = 0;
            }

            if (partCount < 4)
            {
                result.Revision = null;
            }

            if (partCount < 3)
            {
                result.Build = null;
            }

            if (partCount < 2)
            {
                result.Minor = null;
            }

            return result;
        }

        #endregion

        #region Implementation of IComparable<VersionNumber>

        public int CompareTo(VersionNumber other)
        {
            // Use base class to check for nullptr
            if ((object)other != null)
            {
                if (other.Major > Major)
                {
                    return -1;
                }

                if (other.Major < Major)
                {
                    return 1;
                }

                // Same major version
                if ((other.Minor ?? 0) > (Minor ?? 0))
                {
                    return -1;
                }

                if ((other.Minor ?? 0) < (Minor ?? 0))
                {
                    return 1;
                }

                // Same minor version
                if ((other.Build ?? 0) > (Build ?? 0))
                {
                    return -1;
                }

                if ((other.Build ?? 0) < (Build ?? 0))
                {
                    return 1;
                }

                // Same build version
                if ((other.Revision ?? 0) > (Revision ?? 0))
                {
                    return -1;
                }

                if ((other.Revision ?? 0) < (Revision ?? 0))
                {
                    return 1;
                }

                // Same revision number
                return 0;
            }

            return -1;
        }

        #endregion

        #region Base Class Overloads

        /// <summary>
        /// Display this version as a string
        /// </summary>
        public override string ToString()
        {
            if (Revision.HasValue)
            {
                return $"{Major}.{Minor}.{Build}.{Revision}";
            }

            if (Build.HasValue)
            {
                return $"{Major}.{Minor}.{Build}";
            }

            return Minor.HasValue ? $"{Major}.{Minor}" : $"{Major}";
        }

        /// <summary>
        /// Determine if this object is equal to the specified object
        /// </summary>
        public override bool Equals(object other)
        {
            VersionNumber otherVersion = other as VersionNumber;
            return otherVersion != null && CompareTo(otherVersion) == 0;
        }

        /// <summary>
        /// Generate a unique hashcode for this object
        /// </summary>
        public override int GetHashCode()
        {
            return Major ^ (Minor ?? 0) ^ (Build ?? 0) ^ (Revision ?? 0);
        }

        #endregion

        #region  Operator Overloads

        public static bool operator >(VersionNumber v1, VersionNumber v2)
        {
            if ((object)v1 == null)
            {
                return (object)v2 != null;
            }

            return v1.CompareTo(v2) > 0;
        }

        public static bool operator <(VersionNumber v1, VersionNumber v2)
        {
            if ((object)v1 == null)
            {
                return false;
            }

            return v1.CompareTo(v2) < 0;
        }

        public static bool operator <=(VersionNumber v1, VersionNumber v2)
        {
            if ((object)v1 == null)
            {
                return false;
            }

            return v1.CompareTo(v2) <= 0;
        }

        public static bool operator >=(VersionNumber v1, VersionNumber v2)
        {
            if ((object)v1 == null)
            {
                return true;
            }

            return v1.CompareTo(v2) >= 0;
        }

        public static bool operator ==(VersionNumber v1, VersionNumber v2)
        {
            if ((object)v1 != null)
            {
                return v1.CompareTo(v2) == 0;
            }

            return (object)v2 == null;
        }

        public static bool operator !=(VersionNumber v1, VersionNumber v2)
        {
            return !(v1 == v2);
        }

        #endregion
    }
}