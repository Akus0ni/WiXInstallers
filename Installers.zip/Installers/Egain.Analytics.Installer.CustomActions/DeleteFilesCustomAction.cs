#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.IO;
    using WixToolset.Dtf.WindowsInstaller;

    public class DeleteFilesCustomAction
    {
        #region Session Keys

        private const string FolderPathKey = "FolderPath";
        private const string FilterKey = "Filter";
        private const string FailOnErrorKey = "FailOnError";
        private const string OnlyOnEmpty = "OnlyOnEmpty";

        #endregion

        [CustomAction]
        public static ActionResult DeleteFiles(Session session)
        {
            try
            {
                session.Log("Begin DeleteFiles custom action");

                string folderPath = session.CustomActionData[FolderPathKey];
                string filter = session.CustomActionData.ContainsKey(FilterKey) ? session.CustomActionData[FilterKey] : String.Empty;
                bool failOnError;
                if (!session.CustomActionData.ContainsKey(OnlyOnEmpty) || !bool.TryParse(session.CustomActionData[FailOnErrorKey], out failOnError))
                {
                    failOnError = false;
                }

                session.Log("Deleting files matching {0} in folder {1}. Fail on error: {2}.", filter, folderPath, failOnError);

                if (Directory.Exists(folderPath))
                {
                    foreach (string file in Directory.GetFiles(folderPath, filter))
                    {
                        try
                        {
                            File.Delete(file);
                        }
                        catch (Exception ex)
                        {
                            session.Log("Failed to delete file: {0}. Error: {1}", file, ex.Message);

                            if (failOnError)
                            {
                                throw;
                            }
                        }
                    }
                }
                else
                {
                    session.Log($"Folder [{folderPath}] dosen't exist, can't delete files.");
                }

                session.Log("End DeleteFiles custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in custom action DeleteFiles {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
       
        [CustomAction]
        public static ActionResult DeleteFolder(Session session)
        {
            try
            {
                session.Log("Attempting to delete folder(s).");
                CustomActionData customData = session.CustomActionData;

                string folderPath = customData[FolderPathKey];
                bool failOnError;
                if (!customData.ContainsKey(FailOnErrorKey) || !bool.TryParse(customData[FailOnErrorKey], out failOnError))
                {
                    failOnError = false;
                }

                session.Log($"Deleting folder {folderPath}.");

                if (Directory.Exists(folderPath))
                {
                    try
                    {
                        Directory.Delete(folderPath, true);
                    }
                    catch
                    {
                        if (failOnError)
                        {
                            throw;
                        }
                    }
                }
                else
                {
                    session.Log($"Folder {folderPath} dosen't exist, skipping delete.");
                }
                 
                session.Log("Successfully deleted folder(s).");
            }
            catch (Exception ex)
            {
                session.Log($"Error thrown while deleting folder. Message: [{ex.Message}]. Inner message: [{ex.InnerException?.Message}].");
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
