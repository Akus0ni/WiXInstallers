﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System.Text;
    using Exony;
    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Base class for custom action providers.
    /// </summary>
    public static class CustomActionUtils
    {
        #region Standard Variable Access

        /// <summary>
        /// Typed version of GetVariableValue.
        /// </summary>
        public static T GetVariableValue<T>(Session session, string key, string immediateVariablePrefix = null)
        {
            string variableString = GetVariableValue(session, key, immediateVariablePrefix);

            return TypeConversion.ConvertType<T>(variableString);
        }

        /// <summary>
        /// Typed version of GetVariableValue with default.
        /// </summary>
        public static T GetVariableValue<T>(Session session, string key, string immediateVariablePrefix, T defaultValue)
        {
            string variableString = GetVariableValue(session, key, immediateVariablePrefix);

            if (string.IsNullOrWhiteSpace(variableString))
            {
                return defaultValue;
            }

            return TypeConversion.ConvertType<T>(variableString);
        }

        /// <summary>
        /// Retrieve a value from the correct place based on the context in which this custom action is called.
        /// 
        /// Immediate actions will retrieve values via session.
        /// 
        /// Defferred actions will retrieve values via Custom Action Data.
        /// 
        /// A prefix for variable names may be defined for when the action is immediate. This helps prevent variable name clashes when
        /// variables must be declared and not stored in custom action data.
        /// </summary>
        public static string GetVariableValue(Session session, string key, string immediateVariablePrefix = null)
        {
            // Deferred custom action called from commit execution script.
            if (IsDeferred(session))
            {
                session.Log(EscapeString($"Retrieving custom action data value for [{key}]"));

                string result = null;

                session.CustomActionData.TryGetValue(key, out result);

                return result;
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(immediateVariablePrefix))
                {
                    key = $"{immediateVariablePrefix}{key}";
                }

                session.Log(EscapeString($"Retrieving session value for [{key}]"));
                return session[key];
            }
        }

        /// <summary>
        /// Typed version of GetValueFromVariable.
        /// </summary>
        public static T GetValueFromVariable<T>(Session session, string key, string immediateVariablePrefix = null)
        {
            string variableString = GetValueFromVariable(session, key, immediateVariablePrefix);

            return TypeConversion.ConvertType<T>(variableString);
        }

        /// <summary>
        /// Typed version of GetValueFromVariable with default.
        /// </summary>
        public static T GetValueFromVariable<T>(Session session, string key, string immediateVariablePrefix, T defaultValue)
        {
            string variableString = GetValueFromVariable(session, key, immediateVariablePrefix);

            if (string.IsNullOrWhiteSpace(variableString))
            {
                return defaultValue;
            }

            return TypeConversion.ConvertType<T>(variableString);
        }

        /// <summary>
        /// Retrieve a value from the correct place based on the context in which this custom action is called.
        /// 
        /// Immediate actions will retrieve values via session.
        /// 
        /// Defferred actions will retrieve values via Custom Action Data.
        /// 
        /// This version assumes the supplied key points to a variable name so provdies a single level
        /// of indirection to the value.
        /// 
        /// A prefix for variable names may be defined for when the action is immediate. This helps prevent variable name clashes when
        /// variables must be declared and not stored in custom action data.
        /// </summary>
        public static string GetValueFromVariable(Session session, string key, string immediateVariablePrefix = null)
        {
            string variableName = GetVariableValue(session, key, immediateVariablePrefix);

            // The second call must not use a prefix as the full varaible name was retrieved on the first call.
            return GetVariableValue(session, variableName, null);
        }

        /// <summary>
        /// Set a value in the correct place based on the context in which this custom action is called.
        /// </summary>
        public static void SetVariableValue(Session session, string key, object value, string immediateVariablePrefix = null)
        {
            string strValue = value == null ? null : 
                value is string ? (string)value : TypeConversion.ConvertType<string>(value);

            if (IsDeferred(session))
            {
                session.Log(EscapeString($"Setting custom action data value for [{key}] to [{strValue}]"));
                session.CustomActionData[key] = strValue;
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(immediateVariablePrefix))
                {
                    key = $"{immediateVariablePrefix}{key}";
                }

                session.Log(EscapeString($"Setting session value for [{key}] to [{strValue}]"));
                session[key] = strValue;
            }
        }

        #endregion

        #region Utility Methods

        /// <summary>
        /// Escape special characters in a string supplied to wix.
        /// </summary>
        public static string EscapeString(string str)
        {
            StringBuilder resultBuilder = new StringBuilder();

            foreach (char currentChar in str)
            {
                // Open and close square brackets will be considered a variable substitution unless escaped.
                if (currentChar == '[')
                {
                    resultBuilder.Append("[\\[]");
                }
                else if (currentChar == ']')
                {
                    resultBuilder.Append("[\\]]");
                }
                else
                {
                    resultBuilder.Append(currentChar);
                }
            }

            return resultBuilder.ToString();
        }

        /// <summary>
        /// Check if this custom action is being run in deferred mode.
        /// </summary>
        public static bool IsDeferred(Session session)
        {
            return session.GetMode(InstallRunMode.Scheduled) // Deferred custom action called from install script execution.
                || session.GetMode(InstallRunMode.Rollback) // Deferred custom action called from rollback execution script.
                || session.GetMode(InstallRunMode.Commit); // Deferred custom action called from commit execution script.
        }

        /// <summary>
        /// Get all custom action data as a string.
        /// </summary>
        public static string GetCustomActionDataString(Session session)
        {
            return session["CustomActionData"];
        }

        #endregion
    }
}
