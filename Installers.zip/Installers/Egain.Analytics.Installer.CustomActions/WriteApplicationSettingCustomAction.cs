#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Xml;
    using WixToolset.Dtf.WindowsInstaller;

    /// <summary>
    /// Defferred custom action for writing an application setting
    /// </summary>
    public class WriteApplicationSettingCustomAction
    {
        #region Session Keys

        private const string ConfigFilePathKey = "ConfigFilePath";
        private const string SectionNameKey = "SectionName";
        private const string SettingNameKey = "SettingName";
        private const string SettingValueKey = "SettingValue";

        #endregion

        /// <summary>
        /// Write a setting to an app.config file
        /// </summary>
        [CustomAction]
        public static ActionResult WriteApplicationSetting(Session session)
        {
            try
            {
                session.Log("Begin WriteApplicationSetting custom action");

                WriteApplicationSettingInternal(session);

                session.Log("End WriteApplicationSetting custom action");
            }
            catch (Exception ex)
            {
                session.Log("ERROR in WriteApplicationSetting custom action {0}", ex);
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        private static void WriteApplicationSettingInternal(Session session)
        {
            // Get the config file path
            string configFilePath = session.CustomActionData[ConfigFilePathKey];

            // Get the section name
            string sectionName = session.CustomActionData[SectionNameKey];

            // Get the setting name
            string settingName = session.CustomActionData[SettingNameKey];

            // Get the setting value
            string settingValue = session.CustomActionData[SettingValueKey].Trim();

            session.Log("Writing app.config setting {0} for section {1} to file {2}. Setting value: {3}",
                settingName, sectionName, configFilePath, settingValue);

            // Load the config into an xml document
            XmlDocument configDoc = new XmlDocument { PreserveWhitespace = true };
            configDoc.Load(configFilePath);

            // Locate the section root node
            XmlElement sectionRootElement =
                configDoc.SelectSingleNode($"/configuration/applicationSettings/{sectionName}") as XmlElement;

            if (sectionRootElement == null)
            {
                throw new Exception($"Could not locate root element in app.config file for section [{sectionName}]");
            }

            XmlElement settingElement =
                        sectionRootElement.SelectSingleNode($"setting[@name='{settingName}']") as XmlElement;

            if (settingElement == null)
            {
                settingElement = configDoc.CreateElement("setting");
                settingElement.SetAttribute("name", settingName);
                settingElement.SetAttribute("serializeAs", "String");
                sectionRootElement.AppendChild(settingElement);
            }

            XmlElement valueElement =
                        settingElement.SelectSingleNode("value") as XmlElement;

            if (valueElement == null)
            {
                valueElement = configDoc.CreateElement("value");
                settingElement.AppendChild(valueElement);
            }

            valueElement.InnerText = settingValue;

            // Save the changes
            configDoc.Save(configFilePath);
        }
    }
}
