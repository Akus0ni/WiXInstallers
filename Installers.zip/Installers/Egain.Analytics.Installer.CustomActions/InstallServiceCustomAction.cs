﻿#region Copyright © eGain Limited. All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#endregion

namespace Egain.Analytics.Installer.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Configuration.Install;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.ServiceProcess;
    using System.Text;
    using System.Text.RegularExpressions;
    using WixToolset.Dtf.WindowsInstaller;

    public class InstallServiceCustomAction
    {
        [CustomAction]
        public static ActionResult InstallService(Session session)
        {
            try
            {
                // If we have parameters to not escape, add them here.
                HashSet<string> noEscape = new HashSet<string>();
                if (session.CustomActionData.ContainsKey("noescape"))
                {
                    foreach (string str in session.CustomActionData["noescape"].Split(','))
                    {
                        noEscape.Add(str);
                    }
                }

                // To simplify matters we take care of seperator escaping. If something is wrapped in quotes we consider all ; escaped.
                StringBuilder sb = new StringBuilder();
                string unmodifiedCustomData = session.CustomActionData.ToString();

                // This regex escapes everything that's within quotes as long as the quote captures the entire parameter. 
                var match = Regex.Matches(unmodifiedCustomData, "(?<=([\\w]+[\\s]?=[\\s]?))\".*?\"(?=;)|(?<=([\\w]+[\\s]?=[\\s]?))\".*?\"$");
                var tuples = match.OfType<Match>().Select(val => new { StartIndex = val.Index, EndIndex = val.Index + val.Length, ParamName = string.IsNullOrWhiteSpace(val.Groups[1].Value) ? val.Groups[2].Value.Trim('=') : val.Groups[1].Value.Trim('=') });
                for (int i = 0; i < unmodifiedCustomData.Length; i++)
                {
                    char character = unmodifiedCustomData[i];
                    var tuple = tuples.FirstOrDefault(val => i > val.StartIndex && i < val.EndIndex);
                    if (character == ';' && tuple != null && !noEscape.Contains(tuple.ParamName))
                    {
                        sb.Append(';');
                    }

                    sb.Append(character);
                }

                CustomActionData modifiedData = new CustomActionData(sb.ToString());

                string exePath;
                if (!modifiedData.TryGetValue("exepath", out exePath))
                {
                    throw new ArgumentException($"Arguments don't contain an 'exepath' parameter. Please add the path of the service you want to install.");
                }

                // Normalize quoted/unquoted paths by stripping any quotes here and adding them later on.
                exePath = exePath.Trim('"');

                session.Log($"Starting install of service from path {exePath}.");

                if (!File.Exists(exePath))
                {
                    throw new ArgumentException($"The .exe at path {exePath} dosen't exist. Can't install service.");
                }

                modifiedData.Remove("exepath");
                modifiedData.Remove("noescape");

                RunCommand(session, $"{(modifiedData.Any() ? modifiedData.Select(val => "/" + val.Key.Trim() + "=" + val.Value.Trim()).Aggregate((start, next) => start + " " + next) : string.Empty)} \"{exePath}\"");
                
                session.Log("Installation of service completed.");
            }
            catch (Exception ex)
            {
                session.Log($"Error during service install: Message: {ex.Message} Inner message: {ex.InnerException?.Message}");
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }

        private static int RunCommand(Session session, string args)
        {
            return RunCommand(session, Path.Combine(RuntimeEnvironment.GetRuntimeDirectory(), "installutil"), args);
        }

        private static int RunCommand(Session session, string file, string args)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = file;
            startInfo.Arguments = args;
            startInfo.UseShellExecute = false;
            startInfo.RedirectStandardOutput = true;
            startInfo.CreateNoWindow = true;
            startInfo.WindowStyle = ProcessWindowStyle.Hidden;

            session.Log($"Executing command {startInfo.FileName} with these arguments: {startInfo.Arguments}.");

            int returnValue = -1;

            // Run the process and wait until it returns, ignoring way in which it exited.
            Process proc = Process.Start(startInfo);
            if (proc != null)
            {
                proc.WaitForExit();
                returnValue = proc.ExitCode;

                if (returnValue > 0)
                {
                    session.Log($"Console command failed with error code {returnValue}. Arguments: {args}.");
                }
            }

            return returnValue;
        }

        [CustomAction]
        public static ActionResult UninstallService(Session session)
        {
            try
            {
                string exePath;
                if (!session.CustomActionData.TryGetValue("exepath", out exePath))
                {
                    throw new ArgumentException($"Arguments don't contain an 'exepath' parameter. Please add the path of the service you want to install.");
                }

                // Normalize quoted/unquoted paths by stripping any quotes here and adding them later on.
                exePath = exePath.Trim('"');

                // TODO: Forcefully remove service if it's currently in a hung state.
                session.Log($"Starting uninstall of service from path {exePath}.");
                if (File.Exists(exePath))
                {
                    RunCommand(session, $"-u \"{exePath}\"");
                }
                else
                {
                    session.Log($"Can't find service file at {exePath}. Service uninstallation skipped.");
                }

                session.Log("Uninstallation of service completed.");
            }
            catch (InstallException iex)
            {
                session.Log($"Non-critical error during service uninstall: {iex.InnerException?.Message ?? "Unknown"}. Uninstallation will continue.");
            }
            catch (Exception ex)
            {
                session.Log($"Error during service uninstall. Message: {ex.Message}. Inner message: {ex.InnerException?.Message}.");
                return ActionResult.Failure;
            }

            return ActionResult.Success;
        }
    }
}
