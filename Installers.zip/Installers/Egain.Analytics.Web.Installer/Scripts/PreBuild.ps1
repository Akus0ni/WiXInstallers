﻿param(
     [Parameter()]
     [string]$BuildConfiguration = "Debug"
)

if (Test-Path "$PSScriptRoot\~installerTemp") 
{
  Remove-Item "$PSScriptRoot/~installerTemp" -recurse
}

# Specify the full path to the batch file
$batFilePath = "$PSScriptRoot\..\..\..\Web\Gadgets\Common\build-all-common.bat"
$workingDirectory = "$PSScriptRoot\..\..\..\Web\Gadgets\Common"
Start-Process -FilePath $batFilePath -NoNewWindow -Wait -WorkingDirectory $workingDirectory

New-Item "$PSScriptRoot/~installerTemp" -type directory

Copy-Item "$PSScriptRoot\..\..\..\Web\Exony.Portal.Web.Compiled" -Destination "$PSScriptRoot\~installerTemp\Web" -Recurse
Copy-Item "$PSScriptRoot\..\..\..\Web\WS" -Destination "$PSScriptRoot\~installerTemp\WS" -Recurse
Copy-Item "$PSScriptRoot\..\..\..\Web\Gadgets\Common\egain-gadgets-common\src\main\javascript" -Destination "$PSScriptRoot\~installerTemp\Web\Gadgets\Common\egain\ea" -Recurse
Copy-Item "$PSScriptRoot\..\..\..\Web\Exony.Portal.Web\ThirdParty\Libraries\*" -Destination "$PSScriptRoot\~installerTemp\Web\Thirdparty\Libraries" -Recurse -Force
Copy-Item "$PSScriptRoot\..\..\..\Web\Exony.Portal.Web\Help" -Destination "$PSScriptRoot\~installerTemp\Web\Help" -Recurse
