# eGain Analytics: Web Installer


## Overview

This project builds an msi that can be used to install the eGain Analytics Web product.


## MSBuild Properties

|Name|Description|Default|
|---|---|---|
|BuildVersion|The full build version number.|0.0.0.0|
|ReleaseName|Display name for the release.|Development Build|
|ProductSuiteShortName|Short name for the product suite.|EA|
|ProductSuiteFullName|Full name for the product suite.|eGain Analytics|
|CompanyName|Company name.|eGain Corporation|
|Skin|Installer UI skin.|eGain|


## MSI Public Properties

|Name|Description|Default|
|---|---|---|
|INSTALLFOLDER|The full root folder path for file installation.||
|SSL_CERTIFICATE_PATH|The full path to the PFX file used for securing HTTPS endpoints.|certificate.pfx|
|SSL_CERTIFICATE_PASSWORD|Password for the supplied PFX file.|****|
|REMOTE_APP_SERVER_MACHINE_NAME|Remote application server.|localhost|
|COOKIES_REQUIRE_SSL|Cookies require HTTPS.|true|
|CRYPTOGRAPHY_PASSPHRASE|The passphrase to use for generating machine key in web.config. Must match on load balanced web servers.|****|


## MSI Features

No individual features currently supported.


## Command Line Installation Examples

This installer can be run in UI mode with prefilled properties and logging enabled using the following command:

```console
msiexec /i Egain.Analytics.Web.Installer.msi [Properties] /L*v [Log File Location]
```

e.g.

```console
msiexec /i Egain.Analytics.Web.Installer.msi INSTALLFOLDER="" /L*v log.txt
```


This installer can be run in silent mode with prefilled properties and logging enabled using the following command:

```console
msiexec /i Egain.Analytics.Web.Installer.msi [Properties] /QN /L*v [Log File Location]
```

e.g.

```console
msiexec /i Egain.Analytics.Web.Installer.msi INSTALLFOLDER="" /QN /L*v log.txt
```

Features are added using ADDLOCAL="FeatureName,FeatureName,..." as follows: (Not currently supported)

```console
msiexec /i Egain.Analytics.Web.Installer.msi [Properties] ADDLOCAL="[Features]" /L*v [Log File Location]
```

e.g:

```console
msiexec /i Egain.Analytics.Web.Installer.msi INSTALLFOLDER="" ADDLOCAL="Feature1,Feature2" /L*v log.txt
```