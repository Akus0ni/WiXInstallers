﻿// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Application.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml;
    using Egain.Analytics.Installer.CustomActions;
    using Microsoft.Web.Administration;

    using WixToolset.Dtf.WindowsInstaller;
    using static System.Collections.Specialized.BitVector32;

    public class AddHandlerScriptMapCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "AddHandlerScriptMapCustomAction";

        private const string FilePathKey = "FilePath";

        #endregion

        #region Custom Action
        [CustomAction]
        public static ActionResult AddHandlerScriptMap(Session session)
        {
            session.Log("Begin AddHandlerScriptMapCustomAction");

            string filePath = CustomActionUtils.GetVariableValue(
                       session, FilePathKey, ImmediateActionVariablePrefix);
            session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

            //remove existing handler
            string removeCommand = $@"%windir%\system32\inetsrv\appcmd set config ""Default Web Site/OLAP"" /section:handlers /-[name='OLAP']";
            ExecuteCommand(filePath,removeCommand, session);

            // command to add handler mapping
            string addCommand = $@"%windir%\system32\inetsrv\appcmd set config ""Default Web Site/OLAP"" /section:handlers /+""[name='OLAP',path='*.dll',verb='*',modules='IsapiModule',scriptProcessor='{filePath}msmdpump.dll',resourceType='File',preCondition='bitness64']""";
            ExecuteCommand(filePath, addCommand, session);

            return ActionResult.Success;

        }

        #endregion

        #region[Private Method]
        /// <summary>
        /// command call
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="command"></param>
        /// <param name="session"></param>
        private static void ExecuteCommand(string filePath,string command, Session session) 
        {
            try
            {
                Process process = new Process();
                ProcessStartInfo startInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {command}",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                process.StartInfo = startInfo;
                process.Start();

                string output = process.StandardOutput.ReadToEnd();
                session.Log(output);

                process.WaitForExit();
                int exitCode = process.ExitCode;

                if (exitCode == 0)
                {
                    session.Log("Handler mapping added successfully");
                    AddExecutionPermission(session, filePath);
                }
                else
                {
                    session.Log($"Command execution failed with exit code {exitCode}.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }                       

            session.Log("End AddHandlerScriptMapCustomAction");
   
        }       

        /// <summary>
        /// This method adds a execution permission to OLAP handler
        /// </summary>
        /// <param name="session"></param>
        /// <param name="filePath"></param>
        private static void AddExecutionPermission(Session session,string filePath)
        {
            string siteName = "Default Web site";
            string applicationPath = "/OLAP";
            string scriptMapExecutable = filePath + "msmdpump.dll";
            using (ServerManager serverManager = new ServerManager())
            {
                Site site = serverManager.Sites[siteName];
                if (site != null)
                {
                    Application application = site.Applications[applicationPath];
                    if (application != null)
                    {
                        Configuration config = serverManager.GetWebConfiguration(site.Name, application.Path);

                        ConfigurationSection handlerSection = config.GetSection("system.webServer/handlers");

                        ConfigurationElementCollection handlersCollection = handlerSection.GetCollection();

                        ConfigurationElement existingScriptMap = handlersCollection.FirstOrDefault(
                        element => String.Equals((string)element["name"], "OLAP", StringComparison.OrdinalIgnoreCase));

                        serverManager.CommitChanges();

                        if (existingScriptMap != null)
                        {
                            // Load the XML document from a file
                            XmlDocument doc = new XmlDocument();
                            doc.Load(filePath + "web.config");

                            // Find the handlers element under system.webServer
                            XmlNode handlersNode = doc.SelectSingleNode("/configuration/system.webServer/handlers");

                            // Check if handlers element exists
                            if (handlersNode != null)
                            {
                                // Create the attribute and set its value
                                XmlAttribute accessPolicyAttribute = doc.CreateAttribute("accessPolicy");
                                accessPolicyAttribute.Value = "Read, Script";

                                // Add the attribute to the handlers element
                                handlersNode.Attributes.Append(accessPolicyAttribute);
                            }
                            else
                            {
                                session.Log("Handlers element not found in the XML.");
                            }

                            // Save the modified XML document back to the file
                            doc.Save(filePath + "web.config");

                            session.Log("accessPolicy set to execute");
                        }
                    }
                    else
                    {
                        session.Log("Application not found.");
                    }
                }
                else
                {
                    session.Log("Site not found.");
                }
            }

        }
        #endregion
    }
}
