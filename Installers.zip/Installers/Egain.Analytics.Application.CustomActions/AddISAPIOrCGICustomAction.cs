﻿// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Application.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml;
    using Egain.Analytics.Installer.CustomActions;

    using WixToolset.Dtf.WindowsInstaller;
    using Microsoft.Web.Administration;

    public class AddISAPIOrCGICustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "AddISAPIOrCGICustomAction.";

        private const string FilePathKey = "FilePath";

        #endregion

        #region Custom Action
        [CustomAction]
        public static ActionResult AddISAPIOrCGI(Session session)
        {
            session.Log("Begin AddISAPIOrCGICustomAction");

            string filePath = CustomActionUtils.GetVariableValue(
                       session, FilePathKey, ImmediateActionVariablePrefix);
            session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

            // Below code add ISAPI or CGI extension
            using (ServerManager serverManager = new ServerManager())
            {
                Configuration config = serverManager.GetApplicationHostConfiguration();

                ConfigurationSection isapiCgiRestrictionSection = config.GetSection("system.webServer/security/isapiCgiRestriction");

                ConfigurationElementCollection isapiCgiRestrictionCollection = isapiCgiRestrictionSection.GetCollection();

                ConfigurationElement existingScriptMap = isapiCgiRestrictionCollection.FirstOrDefault(
                       element => String.Equals((string)element["Description"], "OLAP", StringComparison.OrdinalIgnoreCase));

                //delete existing one and create new
                if (existingScriptMap != null)
                {
                    isapiCgiRestrictionCollection.Remove(existingScriptMap);
                    serverManager.CommitChanges();
                    Console.WriteLine("Existing script path deleted successfully.");
                }

                Configuration newConfig = serverManager.GetApplicationHostConfiguration();
                ConfigurationSection newIsapiCgiRestrictionSection = newConfig.GetSection("system.webServer/security/isapiCgiRestriction");
                ConfigurationElementCollection newIsapiCgiRestrictionCollection = newIsapiCgiRestrictionSection.GetCollection();

                ConfigurationElement addElement = newIsapiCgiRestrictionCollection.CreateElement();
                addElement["path"] = filePath + "msmdpump.dll";
                addElement["allowed"] = true;
                addElement["description"] = "OLAP";

                newIsapiCgiRestrictionCollection.Add(addElement);
                serverManager.CommitChanges();
            }

            session.Log("End AddISAPIOrCGICustomAction");

            return ActionResult.Success;
        }
    #endregion
    }
}
