// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//

namespace Egain.Analytics.Application.CustomActions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using WixToolset.Dtf.WindowsInstaller;
    using Egain.Analytics.Installer.CustomActions;
    using System.Xml;

    public class UpdateFQDNCustomAction
    {
        #region Session Keys

        private const string ImmediateActionVariablePrefix = "UpdateFQDNCustomAction.";

        private const string FilePathKey = "FilePath";
        private const string OlapServerKey = "OlapServer";

        #endregion

        #region Custom Action
        [CustomAction]
        public static ActionResult UpdateOlapFQDN(Session session)
        {
            session.Log("Begin UpdateFQDNCustomAction");

            string filePath = CustomActionUtils.GetVariableValue(
                       session, FilePathKey, ImmediateActionVariablePrefix);
            session.Log(CustomActionUtils.EscapeString($"File path [{filePath}]"));

            string olapServer = CustomActionUtils.GetVariableValue(
                    session, OlapServerKey, ImmediateActionVariablePrefix);
            session.Log(CustomActionUtils.EscapeString($"Application name [{olapServer}]"));

            XmlDocument doc = new XmlDocument();

            //Load msmdpump.ini
            doc.Load(filePath);

            XmlNode serverNode = doc.SelectSingleNode("/ConfigurationSettings");
            if (serverNode != null)
            {
                XmlNode serverNameNode = serverNode.SelectSingleNode("ServerName");
                if (serverNameNode != null)
                {
                    // Update ServerName
                    serverNameNode.InnerText = olapServer;
                    doc.Save(filePath);
                }
            }

            session.Log("End UpdateFQDNCustomAction1");

            return ActionResult.Success;
        }
        #endregion
    }
}
