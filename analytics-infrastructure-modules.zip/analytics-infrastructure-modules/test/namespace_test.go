package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

func TestNamespaces(t *testing.T) {
	t.Parallel()

	rootFolder := test_structure.CopyTerraformFolderToTemp(t, "../", ".")

	terraformOptions := &terraform.Options{
		TerraformDir:    rootFolder,
		TerraformBinary: "terraform",
		Vars: map[string]interface{}{
			"name":           "test-namespace",
			"description":    "Service discovery namespace",
			"namespace_type": "private",
			"registry":       []string{"registry1"},
			"nifi":           []string{"nifi1", "nifi2", "nifi2"},
			"zookeeper":      []string{"zookeeper1", "zookeeper2", "zookeeper3"},
		},
		EnvVars: map[string]string{},
	}

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)
}
