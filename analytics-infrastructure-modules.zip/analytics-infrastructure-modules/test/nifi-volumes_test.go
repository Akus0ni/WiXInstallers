package test

import (
	"fmt"
	"testing"

	"github.com/gruntwork-io/terratest/modules/random"

	"github.com/gruntwork-io/terratest/modules/terraform"
)

func TestVolumes(t *testing.T) {
	t.Parallel()

	terraformOptions := &terraform.Options{
		TerraformDir:    "../modules/nifi-ebs-volumes",
		TerraformBinary: "tofu",
		Vars: map[string]interface{}{
			"nodes": []interface{}{
				map[string]interface{}{
					"nifi_node_id":      fmt.Sprintf("test%s", random.UniqueId()),
					"availability_zone": "us-west-2a",
					"environment":       "test",
				},
			},
		},
		EnvVars: map[string]string{},
	}

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)
}
