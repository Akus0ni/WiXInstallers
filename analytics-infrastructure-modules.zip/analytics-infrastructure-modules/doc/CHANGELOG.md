# Changelog

All notable changes to this project will be documented in this file.

## [4.11.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.11.0...v4.11.1) (2025-04-16)

### Bug Fixes

* wrap Secrets Manager ARNs in quotes to ensure valid syntax ([#58](https://github.com/eGainDev/analytics-infrastructure-modules/issues/58)) ([e9bd93f](https://github.com/eGainDev/analytics-infrastructure-modules/commit/e9bd93fe9914d1191ad064ad400a1fe470e77fdb))

## [4.11.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.10.5...v4.11.0) (2025-04-14)

### Features

* VIM-20929 Automation support to configure/manage eGain as a tenant  ([#57](https://github.com/eGainDev/analytics-infrastructure-modules/issues/57)) ([1b009a1](https://github.com/eGainDev/analytics-infrastructure-modules/commit/1b009a17bf66229debb030f0f179adb52f5d0418)), closes [#49](https://github.com/eGainDev/analytics-infrastructure-modules/issues/49) [#46](https://github.com/eGainDev/analytics-infrastructure-modules/issues/46)

## [4.10.5](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.10.4...v4.10.5) (2025-02-24)

### Bug Fixes

* Fix file naming to ensure unique sequential filenames in S3 ([#56](https://github.com/eGainDev/analytics-infrastructure-modules/issues/56)) ([e627e06](https://github.com/eGainDev/analytics-infrastructure-modules/commit/e627e0641e60506f40bd3ed9abbec374273564e1))

## [4.10.4](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.10.3...v4.10.4) (2025-02-24)

### Bug Fixes

* Convert action to lowercase for case-insensitive comparison ([#55](https://github.com/eGainDev/analytics-infrastructure-modules/issues/55)) ([aed368c](https://github.com/eGainDev/analytics-infrastructure-modules/commit/aed368cb68655e86d8be6d10d59a3bafde1203af))

## [4.10.3](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.10.2...v4.10.3) (2025-02-12)

### Bug Fixes

* Set provisioned_concurrent_executions to -1 rather than 0 when disabled ([1123472](https://github.com/eGainDev/analytics-infrastructure-modules/commit/1123472b4af097fce1968b52ed7d2b6d2483bb68))

## [4.10.2](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.10.1...v4.10.2) (2025-02-11)

### Bug Fixes

* removing egain administrator support from provisioner ([b172638](https://github.com/eGainDev/analytics-infrastructure-modules/commit/b172638d2519d3ec1518ab7a3d9db632469563d9))
* removing egain administrator support from provisioner ([#53](https://github.com/eGainDev/analytics-infrastructure-modules/issues/53)) ([b77b3d5](https://github.com/eGainDev/analytics-infrastructure-modules/commit/b77b3d5db579de3c8cc4d338d85ea70b183bb112))

### Reverts

* revert PR [#49](https://github.com/eGainDev/analytics-infrastructure-modules/issues/49) and [#46](https://github.com/eGainDev/analytics-infrastructure-modules/issues/46) ([#52](https://github.com/eGainDev/analytics-infrastructure-modules/issues/52)) ([96f4d33](https://github.com/eGainDev/analytics-infrastructure-modules/commit/96f4d338446c0dcd19fc45b08862c5798ca86393))

## [4.10.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.10.0...v4.10.1) (2025-02-11)

### Bug Fixes

* deal with environment names with hyphens when building secrets arn ([b53ebb3](https://github.com/eGainDev/analytics-infrastructure-modules/commit/b53ebb31a647f3fd55e7756425bf92fc537a35c2))

## [4.10.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.9.3...v4.10.0) (2025-02-01)

### Features

* Add support for provisioned concurrency in provisioner lambda ([4d422ca](https://github.com/eGainDev/analytics-infrastructure-modules/commit/4d422ca61510b047f0b2775a79915d93fc708b34))

## [4.9.3](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.9.2...v4.9.3) (2025-01-15)

### Bug Fixes

* VIM-20929 Issues preventing tenant provisioner from running ([#49](https://github.com/eGainDev/analytics-infrastructure-modules/issues/49)) ([4fb6ba5](https://github.com/eGainDev/analytics-infrastructure-modules/commit/4fb6ba5f5d3004a760bebbc97fbeb533caf23be8))
* VIM-20929 Issues preventing tenant provisioner from running successfully ([8a000c7](https://github.com/eGainDev/analytics-infrastructure-modules/commit/8a000c75967c50341db43e2f9a37809abb91f5cd))

## [4.9.2](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.9.1...v4.9.2) (2025-01-10)

### Bug Fixes

* Missed a Python 3.13 reference ([#48](https://github.com/eGainDev/analytics-infrastructure-modules/issues/48)) ([840c08e](https://github.com/eGainDev/analytics-infrastructure-modules/commit/840c08e2fc634bb8b06ead7596f7f15abb0ae2fb))
* Missed a Python 3.13 reference in c0c322101c96eb5a543b6d9944c931c430d00d96 ([99f6a55](https://github.com/eGainDev/analytics-infrastructure-modules/commit/99f6a55a6eb209165a9c3c542f62d39ee4989ac9))

## [4.9.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.9.0...v4.9.1) (2025-01-10)

### Bug Fixes

* Moved to python 3.11 from 3.13 for terraform error ([bf4cb14](https://github.com/eGainDev/analytics-infrastructure-modules/commit/bf4cb149e9670d265addded1b05bf2747e6d71b2))
* Moved to python 3.11 from 3.13 for terraform error ([#47](https://github.com/eGainDev/analytics-infrastructure-modules/issues/47)) ([c0c3221](https://github.com/eGainDev/analytics-infrastructure-modules/commit/c0c322101c96eb5a543b6d9944c931c430d00d96))

## [4.9.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.8.0...v4.9.0) (2025-01-09)

### Features

* VIM-20929 Automation support to configure/manage eGain as a tenant ([43b8dc5](https://github.com/eGainDev/analytics-infrastructure-modules/commit/43b8dc54e8af551cf75d0d700db8ed6122fe3983))
* VIM-20929 Automation support to configure/manage eGain as a tenant ([#46](https://github.com/eGainDev/analytics-infrastructure-modules/issues/46)) ([ff5ed3f](https://github.com/eGainDev/analytics-infrastructure-modules/commit/ff5ed3f3d3bddf56f582854d0940b6166c5dbe8c))

## [4.8.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.7.0...v4.8.0) (2025-01-07)

### Features

* VIM-20567 Add GDPR tool for RedShift OA data ([52582ef](https://github.com/eGainDev/analytics-infrastructure-modules/commit/52582ef0d03d102dcc5afbfd7cc40b95d49167be))
* VIM-20567 Add GDPR tool for RedShift OA data ([#44](https://github.com/eGainDev/analytics-infrastructure-modules/issues/44)) ([954662a](https://github.com/eGainDev/analytics-infrastructure-modules/commit/954662a55e724b0d120330c58e6bf111b53ac4fb))

## [4.7.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.6.5...v4.7.0) (2025-01-07)

### Features

* VIM-20920 Tenant Decomission : Redshift ([4477dea](https://github.com/eGainDev/analytics-infrastructure-modules/commit/4477deaf11a808ea5af4af02ffb45621b52e9f7d))
* VIM-20920 Tenant Decomission : Redshift ([#45](https://github.com/eGainDev/analytics-infrastructure-modules/issues/45)) ([9ef331c](https://github.com/eGainDev/analytics-infrastructure-modules/commit/9ef331c997bbaeb3c0b9650ca52d64f7da24ee5d))

## [4.6.5](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.6.4...v4.6.5) (2024-09-02)

### Bug Fixes

* add tags to route53 zones ([1976c6f](https://github.com/eGainDev/analytics-infrastructure-modules/commit/1976c6fea7a423de062541456ce50edee698495a))

## [4.6.4](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.6.3...v4.6.4) (2024-08-30)

### Bug Fixes

* Provisioner IAM role & better error handling ([508f594](https://github.com/eGainDev/analytics-infrastructure-modules/commit/508f59425e804b2b3206e3f12bd5b93331101de9))

## [4.6.3](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.6.2...v4.6.3) (2024-08-30)

### Bug Fixes

* IAM PutResourcePolicy permission ([cc84c10](https://github.com/eGainDev/analytics-infrastructure-modules/commit/cc84c109f9a92c6cfde6672b456cd55089fe3841))

## [4.6.2](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.6.1...v4.6.2) (2024-08-29)

### Bug Fixes

* increase lambda terraform timeouts ([6f1faae](https://github.com/eGainDev/analytics-infrastructure-modules/commit/6f1faae28bc83b890c9c335fded0d1cae6883a41))

## [4.6.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.6.0...v4.6.1) (2024-08-29)

### Bug Fixes

* Using role ARN instead of deployment id ([624c59b](https://github.com/eGainDev/analytics-infrastructure-modules/commit/624c59b9248376715909466af445a2de3ad4ea78))

## [4.6.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.5.4...v4.6.0) (2024-08-29)

### Features

* Redshift secrets cross-account resource policy & skip rotation optional parameter ([3328f9a](https://github.com/eGainDev/analytics-infrastructure-modules/commit/3328f9a316d5c3f11d5c7e1a3db35e103c3ae8e0))

## [4.5.4](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.5.3...v4.5.4) (2024-08-28)

### Bug Fixes

* Use a KMS key for the secrets ([d00196f](https://github.com/eGainDev/analytics-infrastructure-modules/commit/d00196f86514e9245a9627742f0c0086346fd49e))

## [4.5.3](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.5.2...v4.5.3) (2024-08-23)

### Bug Fixes

* Secret Tags case sensitive ([eca9f2e](https://github.com/eGainDev/analytics-infrastructure-modules/commit/eca9f2ea3dfe3663b4023f117f4b45d03f353b0d))

## [4.5.2](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.5.1...v4.5.2) (2024-08-19)

### Bug Fixes

* datashare creation & master db naming ([1639199](https://github.com/eGainDev/analytics-infrastructure-modules/commit/1639199916dddaec9fb73a43d5c869c69a749531))
* logging & linting ([9bffd7b](https://github.com/eGainDev/analytics-infrastructure-modules/commit/9bffd7b4d18a36f7105618a4f21516363d911311))

## [4.5.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.5.0...v4.5.1) (2024-08-14)

### Bug Fixes

* changing imports and fixing pylint issues ([684559a](https://github.com/eGainDev/analytics-infrastructure-modules/commit/684559ab6536229e176f66132beed53b114a35ff))

## [4.5.1-beta.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.5.0...v4.5.1-beta.1) (2024-08-14)

### Bug Fixes

* changing imports and fixing pylint issues ([684559a](https://github.com/eGainDev/analytics-infrastructure-modules/commit/684559ab6536229e176f66132beed53b114a35ff))

## [4.5.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.4.0...v4.5.0) (2024-08-14)

### Features

* Capacity can use ALU and SKU ([9cd6f0f](https://github.com/eGainDev/analytics-infrastructure-modules/commit/9cd6f0f2f3367b46a57cb6d575975766efcf6c9e))
* Capacity can use ALU and SKU ([da3d5e6](https://github.com/eGainDev/analytics-infrastructure-modules/commit/da3d5e66ebdbbfdc7cb23f7aa89695c34ad246e0))

## [4.5.0-beta.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.4.0...v4.5.0-beta.1) (2024-08-14)

### Features

* Capacity can use ALU and SKU ([da3d5e6](https://github.com/eGainDev/analytics-infrastructure-modules/commit/da3d5e66ebdbbfdc7cb23f7aa89695c34ad246e0))

## [4.4.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.3.0...v4.4.0) (2024-08-13)

### Features

* Tenant Provisioning lambda ([e2b4104](https://github.com/eGainDev/analytics-infrastructure-modules/commit/e2b410496f83ece431d4131f29021711bc46ac80))

### Bug Fixes

* environment variable for dev boxes ([bcc757f](https://github.com/eGainDev/analytics-infrastructure-modules/commit/bcc757fc496183c4917a2e5a9270fa53a85f3bf3))
* environment variables for lambda ([cab4e2b](https://github.com/eGainDev/analytics-infrastructure-modules/commit/cab4e2bcd89e20a9d05c0fe1de10a5e84963dd72))
* Lambda IAM policy updates ([#21](https://github.com/eGainDev/analytics-infrastructure-modules/issues/21)) ([0e597e3](https://github.com/eGainDev/analytics-infrastructure-modules/commit/0e597e379711f79aa70624053018bd3e01c99b5e))
* logic for redshift user creation ([b88b163](https://github.com/eGainDev/analytics-infrastructure-modules/commit/b88b163d1ab07c1833471eea93b3c8c71ec763ad))
* refactored lambda into classes ([0c7c470](https://github.com/eGainDev/analytics-infrastructure-modules/commit/0c7c47034a52bceff128348705cd19504d05ca34))
* remove extra quotes from env vars ([56519eb](https://github.com/eGainDev/analytics-infrastructure-modules/commit/56519eb9a54f4bf388843cb16851419c3a1824d1))
* serverless cluster creation, error handling and config update ([a91a8da](https://github.com/eGainDev/analytics-infrastructure-modules/commit/a91a8daf5bf9b4b319a63993f3c2510c67285974))
* serverless iam permissions for lambda ([c097534](https://github.com/eGainDev/analytics-infrastructure-modules/commit/c097534a8d4fcc71c08b39294e966790b8d4750a))
* tenant provisioning secrets update + group permissions ([408b393](https://github.com/eGainDev/analytics-infrastructure-modules/commit/408b39391013a9e1d9dbb2bed50fcbaf73a9f31a))
* update lambda IAM policy ([9308b1a](https://github.com/eGainDev/analytics-infrastructure-modules/commit/9308b1a508e99b84a9d9a14335bc9477e504ba6e))

## [4.3.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.2.1...v4.3.0) (2024-08-13)

### Features

* Dedicated serverless provisioning ([#20](https://github.com/eGainDev/analytics-infrastructure-modules/issues/20)) ([dd3ab72](https://github.com/eGainDev/analytics-infrastructure-modules/commit/dd3ab72c954dff5437f313ae496d1d56b03785fd)), closes [#17](https://github.com/eGainDev/analytics-infrastructure-modules/issues/17) [#18](https://github.com/eGainDev/analytics-infrastructure-modules/issues/18)
* Publish Lamda function release ([f75b870](https://github.com/eGainDev/analytics-infrastructure-modules/commit/f75b870f606fc91ea94601248686517fce4cca7c))

## [4.2.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.2.0...v4.2.1) (2024-08-13)

### Bug Fixes

* update terraform-aws-modules/security-group/aws requirement from ~> 4.0 to ~> 5.1 ([#17](https://github.com/eGainDev/analytics-infrastructure-modules/issues/17)) ([94a45c4](https://github.com/eGainDev/analytics-infrastructure-modules/commit/94a45c4ed4134006e2b1bb1f94edb9dc4fa094d1))
* update terraform-aws-modules/security-group/aws requirement from ~> 4.0 to ~> 5.1 ([#18](https://github.com/eGainDev/analytics-infrastructure-modules/issues/18)) ([0a23fdf](https://github.com/eGainDev/analytics-infrastructure-modules/commit/0a23fdfcb119726c42415e3215d6e8574bdef9d1))

## [4.2.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.1.1...v4.2.0) (2024-07-26)

### Features

* Redshift Serverless module ([5e3bb7c](https://github.com/eGainDev/analytics-infrastructure-modules/commit/5e3bb7c977c437524a91f91bbf504a73fbdfcb8c))

## [4.1.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.1.0...v4.1.1) (2024-07-09)

### Bug Fixes

* downgrade to python 3.11 ([d60767e](https://github.com/eGainDev/analytics-infrastructure-modules/commit/d60767e32b76199de9ea4d8a6a53c0de2f378060))

## [4.1.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v4.0.0...v4.1.0) (2024-07-08)

### Features

* ecr scan module ([45b9a92](https://github.com/eGainDev/analytics-infrastructure-modules/commit/45b9a928d3c0895c7f6fb465911e049b87b90207))

### Bug Fixes

* IAM policies ([2de2e93](https://github.com/eGainDev/analytics-infrastructure-modules/commit/2de2e93f33a090c26e229ebfe8b37e9aa567b859))
* include environment in loggroup name ([81be87d](https://github.com/eGainDev/analytics-infrastructure-modules/commit/81be87d737de6880c5c49dc83acc9c615acc2528))
* include version of module required ([eef025f](https://github.com/eGainDev/analytics-infrastructure-modules/commit/eef025fca5b5acab20214232a8aa24c3070ecd3d))
* json fixed ([9341d88](https://github.com/eGainDev/analytics-infrastructure-modules/commit/9341d88eb061517e160de6af6faf09a8ce473a8f))
* remove iam statements for testing ([f5f30e8](https://github.com/eGainDev/analytics-infrastructure-modules/commit/f5f30e87d1e146fc1a33bfc8d715b55fe9537f03))
* set lambda log group retention ([ea96986](https://github.com/eGainDev/analytics-infrastructure-modules/commit/ea96986f5d1d7c02804e9e512539d1250ffc76ab))

## [4.0.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v3.0.0...v4.0.0) (2024-07-03)

### ⚠ BREAKING CHANGES

* bump major version
* prep for next beta

### Features

* bump major version ([e10cc04](https://github.com/eGainDev/analytics-infrastructure-modules/commit/e10cc04bcd5d7942ef224f7751d3d5f0fff762e1))
* prep for next beta ([aa356e1](https://github.com/eGainDev/analytics-infrastructure-modules/commit/aa356e1878561a3b92feceb2c22aae4aead94314))

### [1.0.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v1.0.0...v1.0.1) (2024-06-21)


### Bug Fixes

* namespace creation was failing with duplicates ([eca6eb1](https://github.com/eGainDev/analytics-infrastructure-modules/commit/eca6eb1709ed36ff8d52f77fb897a704e3db68b1))

## [1.0.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.5.0...v1.0.0) (2024-06-21)


### ⚠ BREAKING CHANGES

* Enable encryption on EBS volumes

### Features

* Enable encryption on EBS volumes ([c21c7e9](https://github.com/eGainDev/analytics-infrastructure-modules/commit/c21c7e9e3139122acc569df9254a534aff4fc0d7))

## [0.5.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.4.3...v0.5.0) (2024-06-19)


### Features

* wait for certificate validation ([f03a666](https://github.com/eGainDev/analytics-infrastructure-modules/commit/f03a66687c4ebd0c8ede6e1e615525f04491786e))

### [0.4.3](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.4.2...v0.4.3) (2024-06-19)


### Bug Fixes

* creation logic fixed ([690eb51](https://github.com/eGainDev/analytics-infrastructure-modules/commit/690eb510d1c676b5197e24c560d12b8ede65b601))

### [0.4.2](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.4.1...v0.4.2) (2024-06-19)


### Bug Fixes

* typo ([2b25582](https://github.com/eGainDev/analytics-infrastructure-modules/commit/2b255829315be27fda58f1cdf4c75309799868d9))

### [0.4.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.4.0...v0.4.1) (2024-06-19)


### Bug Fixes

* wrong use of "count" ([7b7e03b](https://github.com/eGainDev/analytics-infrastructure-modules/commit/7b7e03b15da418f5f551a109df0b49022016a5cf))

## [0.4.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.3.1...v0.4.0) (2024-06-19)


### Features

* adding optional create variable ([04d3470](https://github.com/eGainDev/analytics-infrastructure-modules/commit/04d347074540713de98a77a13b7d5257c21ec536))

### [0.3.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.3.0...v0.3.1) (2024-06-11)


### Bug Fixes

* correcting output of acm arn ([39fd91c](https://github.com/eGainDev/analytics-infrastructure-modules/commit/39fd91c7c0ce0873b924d119579e2c5fecab344e))
* temp removal of domain validation ([975da2b](https://github.com/eGainDev/analytics-infrastructure-modules/commit/975da2b4e03f6b062455894d613234f565551f3e))

## [0.3.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.2.1...v0.3.0) (2024-06-10)


### Features

* certificate module ([9995dc9](https://github.com/eGainDev/analytics-infrastructure-modules/commit/9995dc97cbaed64b7802b8bf216b6c922b9a7c36))

### [0.2.1](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.2.0...v0.2.1) (2024-06-05)


### Bug Fixes

* output services as a map ([34473d0](https://github.com/eGainDev/analytics-infrastructure-modules/commit/34473d00d4ada5167c4af42db6d42813d5a802bb))

## [0.2.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.1.0...v0.2.0) (2024-06-05)


### Features

* adding support for namespace services ([5968394](https://github.com/eGainDev/analytics-infrastructure-modules/commit/59683947b6234a9e644a2ce9c2acbb8b6811e46a))

## [0.1.0](https://github.com/eGainDev/analytics-infrastructure-modules/compare/v0.0.4...v0.1.0) (2024-06-05)


### Features

* Service Discovery Namespace module ([cdfc64e](https://github.com/eGainDev/analytics-infrastructure-modules/commit/cdfc64e9f454aea5e1ffa2a0fc96e461844a683b))
