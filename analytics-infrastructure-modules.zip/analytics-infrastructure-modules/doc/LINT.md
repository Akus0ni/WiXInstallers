
```
docker run \
  -e LOG_LEVEL=INFO \
  -e RUN_LOCAL=true \
  -e USE_FIND_ALGORITHM=true \
  -e VALIDATE_TERRAFORM_FMT=true \
  -e VALIDATE_GITHUB_ACTIONS=true \
  -e VALIDATE_EDITORCONFIG=true \
  -e VALIDATE_CHECKOV=true \
  -e VALIDATE_GO=true \
  -e FILTER_REGEX_EXCLUDE='.*doc/.*|.*terraform/.*' \
  -v /mnt/c/GitHub/analytics-infrastructure-modules:/tmp/lint \
  --rm \
  ghcr.io/super-linter/super-linter:latest
```
