<!-- editorconfig-checker-disable -->
# Analytics Infrastructure Modules
<!-- editorconfig-checker-disable -->
[![semantic-release: conventionalcommits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-%23FE5196?logo=conventionalcommits&logoColor=white)](https://conventionalcommits.org)
<!-- editorconfig-checker-enable -->
## Overview
A repo used to contain Terraform modules used by the
[analytics-infrastructure-live](https://github.com/eGainDev/analytics-infrastructure-live) repo

## How do you use these modules?

To use a module, create a  `terragrunt.hcl` file that specifies the module you want to use in the `source` URL as well
as values for the input variables of that module in the `inputs` block:

```hcl
# Use Terragrunt to download the module code
terraform {
    source = "git::git@github.com/eGainDev/analytics-infrastructure-modules.git//path/to/module?ref=<VERSION>"
}

# Fill in the variables for that module
inputs = {
    foo = "bar"
    baz = 3
}
```

(*Note: the double slash (`//`) in the `source` URL is intentional and required. It's part of Terraform and OpenTofu's
Git syntax for [module sources](https://www.terraform.io/docs/modules/sources.html).*)

You then run [Terragrunt](https://github.com/gruntwork-io/terragrunt), and it will download the source code specified
in the `source` URL into a temporary folder, copy your `terragrunt.hcl` file into that folder, and run your Terraform /
OpenTofu command in that folder:

<!-- editorconfig-checker-disable -->
```
> terragrunt apply
[terragrunt] Reading Terragrunt config file at terragrunt.hcl
[terragrunt] Downloading Tofu configurations from git::git@github.com:github.com/eGainDev/analytics-infrastructure-modules.git//path/to/module?ref=<VERSION>
[terragrunt] Copying files from . into .terragrunt-cache
[terragrunt] Running command: tofu apply
[...]
```
<!-- editorconfig-checker-enable -->

## How do you change a module?


### Local changes

Here is how to test out changes to a module locally:

1. `git clone` this repo.
1. Update the code as necessary.
1. Go into the folder where you have the `terragrunt.hcl` file that uses a module from this repo (preferably for a
dev or staging environment!).
1. Run `terragrunt plan --terragrunt-source <LOCAL_PATH>`, where `LOCAL_PATH` is the path to your local checkout of
the module code.
1. If the plan looks good, run `terragrunt apply --terragrunt-source <LOCAL_PATH>`.

Using the `--terragrunt-source` parameter (or `TERRAGRUNT_SOURCE` environment variable) allows you to do rapid,
iterative, make-a-change-and-rerun development.


### Releasing a new version

When you're done testing the changes locally, here is how you release a new version:

1. Update the code as necessary.
1. Commit your changes to Git: `git commit -m "commit message"`.
1. Add a new Git tag using one of the following options:
    1. Using GitHub: Go to the [releases page](/releases) and click "Draft a new release".
    1. Using Git:

```
git tag -a v0.0.2 -m "tag message"
git push --follow-tags
```
1. Now you can use the new Git tag (e.g. `v0.0.2`) in the `ref` attribute of the `source` URL in `terragrunt.hcl`.
1. Run `terragrunt plan`.
1. If the plan looks good, run `terragrunt apply`.

## Folder structure

This repo uses the following "standard" folder structure:

- `modules`: Put module code into this folder.
- `examples`: Put example code into this folder. These are examples of how to use the modules in the `modules` folder.
This is useful both for manual testing (you can manually run `tofu apply` on these examples) and automated testing
(as per the tests in the `test` folder, as described next).
- `test`: Put test code into this folder. These should be automated tests for the examples in the `examples` folder.
