"""
This module provides functions to generate SQL queries for handling PII data in a Redshift database.

The `generate_query` function creates a SELECT query to export rows containing matching PII data, 
while the `generate_bulk_update_query` function creates an UPDATE query to anonymize those rows. 
Both queries are tailored to handle multiple columns and PII keys/values provided in the `pii_data`.

Functions:
- generate_query(table, columns, pii_data, tenant_id): Generates a SELECT query to export rows with matching PII data.
- generate_bulk_update_query(table, columns, pii_data, tenant_id): Generates an UPDATE query to anonymize PII data
using SHA256.
"""

# Standard imports
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def generate_query(table, columns, pii_data, tenant_id):
    """
    Generate a SELECT query to export rows containing matching PII data.
    Match all PII keys and optional values against all columns.
    """
    if not pii_data or not columns:
        logger.warning("[generate_query] PII data or columns are empty; query cannot be generated.")
        return None
    keys = pii_data.get("Keys", [])
    if not keys:
        logger.error("[generate_query] No keys provided in PII data; query cannot be generated.")
        return None
    table = "internal." + table
    column_names = [col["name"] for col in columns]
    # Generate WHERE clause
    where_clause = generate_where_clause(columns, pii_data, keys, tenant_id)
    if not where_clause:
        logger.warning("[generate_query] No valid key-value pairs found for PII data.")
        return None
    query = f"SELECT {', '.join(column_names)} FROM {table} WHERE {where_clause};"
    logger.info("[generate_query] Generated query: %s", query)
    return query


def generate_bulk_update_query(table, columns, pii_data, tenant_id):
    """
    Generate an UPDATE query to anonymize rows containing matching PII data.
    Use SHA256 for hashing, trimming to column length.
    """
    if not pii_data or not columns:
        logger.warning("[generate_bulk_update_query] PII data or columns are empty; query cannot be generated.")
        return None

    table = "internal." + table
    set_clauses = [
        f"{col['name']} = CASE WHEN {col['name']} IS NOT NULL THEN "
        f"LEFT(SHA2({col['name']}, 256), {col['length']}) ELSE {col['name']} END"
        for col in columns
    ]
    keys = pii_data.get("Keys", [])
    if not keys:
        logger.error("[generate_bulk_update_query] No keys provided in PII data; query cannot be generated.")
        return None
    # Generate WHERE clause
    where_clause = generate_where_clause(columns, pii_data, keys, tenant_id)

    if not where_clause:
        logger.warning("[generate_bulk_update_query] No valid key-value pairs found for PII data.")
        return None

    set_clause = ", ".join(set_clauses)
    query = f"UPDATE {table} SET {set_clause} WHERE {where_clause};"
    logger.info("[generate_bulk_update_query] Generated query: %s", query)
    return query


def generate_where_clause(columns, pii_data, keys, tenant_id):
    """
    Helper function to generate the WHERE clause for both SELECT and UPDATE queries.
    """
    key_values = [pii_data.get(key, []) for key in keys]
    key_values = [value for sublist in key_values for value in sublist]
    # Handle optional value-based filtering
    value_values = [pii_data.get(value, []) for value in pii_data.get("Values", [])]
    value_values = [value for sublist in value_values for value in sublist]
    where_clauses = []
    for key_value in key_values:
        nested_clauses = generate_nested_clauses(columns, key_value, value_values)
        where_clauses.append(f"({' OR '.join(nested_clauses)})")
    if not where_clauses:
        return None
    return f"tm_tenant_id = '{tenant_id}' AND {' OR '.join(where_clauses)}"


def generate_nested_clauses(columns, key_value, value_values):
    """
    Helper function to generate nested WHERE clauses for each key-value pair.
    """
    nested_clauses = []
    if not value_values:
        # Only match key value against all columns
        nested_clauses.extend([f"({col['name']} = '{key_value}')" for col in columns])
    else:
        # Match key value and optionally any value
        for value_value in value_values:
            inner_clauses = [f"{col['name']} = '{value_value}'" for col in columns]
            if inner_clauses:
                for col in columns:
                    nested_clauses.append(f"({col['name']} = '{key_value}' AND ({' OR '.join(inner_clauses)}))")
            else:
                nested_clauses.extend([f"({col['name']} = '{key_value}')" for col in columns])
    return nested_clauses
