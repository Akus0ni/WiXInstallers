"""
This module provides functions to interact with Amazon S3 for handling GDPR configuration data. It includes 
operations for fetching a GDPR config file from an S3 bucket, uploading data to S3, and ensuring unique 
object keys when uploading. The module uses `boto3` for AWS S3 interactions, handles errors with appropriate 
logging, and manages JSON data encoding/decoding.

Functions:
- fetch_gdpr_config_from_s3(bucket_name, file_key): Fetches a GDPR configuration file (in JSON format) from 
an S3 bucket. Handles various errors such as missing credentials, connection issues, and JSON parsing errors.

- upload_to_s3(bucket_name, base_object_key, data): Uploads JSON data to an S3 bucket under a unique file name, 
ensuring that the file name is not already in use. If necessary, it generates a unique name by appending a 
number to the base object key.

- get_unique_s3_key(s3_client, bucket_name, base_object_key): Generates a unique key for uploading to S3 by 
checking if a file with the base object key already exists in the specified bucket. If it exists, it appends 
a counter to the key to ensure uniqueness.
"""

# Standard imports
import json
import logging
import socket
import traceback
import re

# Third party imports
import boto3
from botocore.exceptions import NoCredentialsError, EndpointConnectionError, ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def fetch_gdpr_config_from_s3(bucket_name, file_key):
    """Fetch the GDPR config JSON file from S3."""
    s3 = boto3.client("s3")
    try:
        logger.info(
            "Requesting GDPR config file from S3. Bucket: %s, File Key: %s",
            bucket_name,
            file_key,
        )
        response = s3.get_object(Bucket=bucket_name, Key=file_key)

        if "Body" not in response or response["Body"] is None:
            logger.error(
                "[fetch_gdpr_config_from_s3] Received empty or invalid response body from S3 for %s/%s",
                bucket_name,
                file_key,
            )
            raise ValueError("Empty or invalid response body from S3.")

        try:
            config_data = json.loads(response["Body"].read().decode("utf-8"))
            logger.info(
                "[fetch_gdpr_config_from_s3] Successfully fetched GDPR config: %s",
                config_data,
            )
            return config_data
        except json.JSONDecodeError as e:
            logger.error(
                "[fetch_gdpr_config_from_s3] Failed to decode JSON from response body: %s",
                e,
            )
            raise
    except NoCredentialsError:
        logger.error("[fetch_gdpr_config_from_s3] No valid AWS credentials found.")
        raise
    except EndpointConnectionError as e:
        logger.error("[fetch_gdpr_config_from_s3] Network or endpoint connection error: %s", e)
        raise
    except socket.timeout as e:
        logger.error("[fetch_gdpr_config_from_s3] Request timed out: %s", e)
        raise
    except Exception as e:
        logger.error("[fetch_gdpr_config_from_s3] Error fetching GDPR config from S3: %s", e)
        logger.error("[fetch_gdpr_config_from_s3] Exception details: %s", traceback.format_exc())
        raise


def upload_to_s3(bucket_name, base_object_key, data):
    """Uploads JSON data to an S3 bucket with a unique file name."""
    s3_client = boto3.client("s3")
    try:
        # Check for a unique file name
        unique_object_key = get_unique_s3_key(s3_client, bucket_name, base_object_key)
        # Upload the file to S3
        logger.info(
            "[upload_to_s3] Uploading data to S3: Bucket=%s, Key=%s",
            bucket_name,
            unique_object_key,
        )
        s3_client.put_object(
            Bucket=bucket_name,
            Key=unique_object_key,
            Body=json.dumps(data),
            ContentType="application/json",
        )
        logger.info(
            "[upload_to_s3] Successfully uploaded data to S3 with key: %s",
            unique_object_key,
        )
        return unique_object_key
    except Exception as e:
        logger.error("[upload_to_s3] Failed to upload data to S3: %s", e)
        raise RuntimeError(f"Failed to upload data to S3: {e}") from e


def get_unique_s3_key(s3_client, bucket_name, base_object_key):
    """Generate a unique S3 key by appending a number if the base key already exists."""
    existing_keys = []
    try:
        # List objects in the bucket with the same prefix as the base object key
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=base_object_key.rsplit(".", 1)[0])
        if "Contents" in response:
            existing_keys = [obj["Key"] for obj in response["Contents"]]
    except ClientError as e:
        logger.warning("[get_unique_s3_key] Error while listing objects: %s", e)
    except TimeoutError as e:
        logger.warning("[get_unique_s3_key] Error while listing objects: %s", e)
    if base_object_key not in existing_keys:
        return base_object_key
    logger.info("[get_unique_s3_key] Base key already exists: %s", base_object_key)
    # Extract the base name, extension, and number suffix from the base object key
    base_name, ext = base_object_key.rsplit(".", 1)
    # Create a regex pattern to match the base name and number suffix
    pattern = re.compile(rf"^{re.escape(base_name)}_(\d+)\.{ext}$")
    max_number = 0
    for key in existing_keys:
        # Check if the key matches the pattern
        match = pattern.match(key)
        if match:
            max_number = max(max_number, int(match.group(1)))
    # Generate a new unique S3 key
    unique_name = f"{base_name}_{max_number + 1}.{ext}"
    return unique_name
