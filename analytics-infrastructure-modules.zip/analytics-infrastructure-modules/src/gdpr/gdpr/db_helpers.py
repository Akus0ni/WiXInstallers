"""
This module contains the `RedshiftDataAPI` class and utility functions to interact with Amazon Redshift using 
both the Redshift Data API and Redshift Serverless. It supports performing various operations on Redshift 
databases such as executing SQL statements, fetching results, and managing Redshift Serverless workgroup endpoints. 

Functions:
    - `export_data`: Exports data from Redshift tables based on the provided configuration and PII data.
    - `forget_data`: Anonymizes (forgets) data in Redshift tables based on the provided configuration and PII data.

Classes:
    - `RedshiftDataAPI`: A class that encapsulates the functionality for interacting with the Redshift Data API 
    and Redshift Serverless. It allows for executing SQL statements, fetching results, and managing database 
    connections.
"""

# Standard imports
import logging
import time

# Third party imports
import boto3
from botocore.exceptions import ClientError

# Module imports
from query_utils import generate_query, generate_bulk_update_query

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


class RedshiftDataAPI:
    """
    A class to interact with Amazon Redshift using Redshift Data API and Redshift Serverless.

    This class provides methods to execute SQL statements, fetch results, and manage database connections
    either using the traditional Redshift Data API or the Redshift Serverless API based on the configuration.

    Attributes:
        client (boto3.client): The Redshift Data API client instance for interacting with Redshift Data API.
        serverless_client (boto3.client, optional): The Redshift Serverless client instance for interacting
        with Redshift Serverless, if enabled.
        serverless (bool): A flag indicating whether to use Redshift Serverless (True) or Redshift Data API (False).
        username (str): The Redshift username retrieved from the provided secret.
        password (str, optional): The Redshift password retrieved from the provided secret (if available).
        database_name (str): The database name retrieved from the provided secret.
        workgroup_name (str): The Redshift workgroup name retrieved from the provided secret.
        endpoint_address (str): The Redshift endpoint address for database connections.
        endpoint_port (str, optional): The Redshift endpoint port for database connections (if not using Serverless).

    Methods:
        __init__(self, secret, serverless, region=None):
            Initializes the RedshiftDataAPI client with the provided credentials and configuration.

        get_workgroup_endpoint(self, workgroup_name):
            Fetches the endpoint of a Redshift Serverless workgroup.

        execute_statement(self, sql):
            Executes a given SQL statement on Redshift and returns the execution ID.

        fetch_results(self, execution_id, query_type=None):
            Fetches the results of a previously executed SQL statement using the execution ID.

        check_current_database_and_schema(self):
            Executes a SQL query to check the current database, schema, and user connected to Redshift.
    """

    # pylint: disable=too-many-instance-attributes
    def __init__(self, secret, serverless, region=None):
        """Initializes the RedshiftDataAPI client with provided credentials and configuration"""
        self.serverless = serverless

        if region:
            logger.info(
                "[RedshiftDataAPI] Initialise Redshift Data API client with region: %s",
                region,
            )
            self.client = boto3.client("redshift-data", region_name=region)
            if serverless:
                self.serverless_client = boto3.client("redshift-serverless", region_name=region)
        else:
            logger.info("[RedshiftDataAPI] Initialise Redshift Data API client with default region")
            self.client = boto3.client("redshift-data")
            if serverless:
                self.serverless_client = boto3.client("redshift-serverless")

        self.username = secret["username"]
        self.password = secret.get("password")
        self.database_name = secret["database_name"]
        self.workgroup_name = secret["workgroup_name"]

        if serverless:
            self.endpoint_address = self.get_workgroup_endpoint(self.workgroup_name)
        else:
            self.endpoint_address = secret["endpoint_address"]
            self.endpoint_port = secret["endpoint_port"]

    def get_workgroup_endpoint(self, workgroup_name):
        """Fetch the endpoint of a Redshift Serverless workgroup"""
        try:
            response = self.serverless_client.get_workgroup(workgroupName=workgroup_name)
            logger.info("[get_workgroup_endpoint] Full Response: [%s]", response)
            endpoint = response["workgroup"]["endpoint"]
            logger.info(
                "[get_workgroup_endpoint] Fetched endpoint for workgroup %s: %s",
                workgroup_name,
                endpoint,
            )
            return endpoint
        except Exception as e:
            logger.error(
                "[get_workgroup_endpoint] Error fetching endpoint for workgroup %s: %s",
                workgroup_name,
                e,
            )
            raise

    def execute_statement(self, sql):
        """Executes a SQL statement using Redshift Data API."""
        try:
            if self.serverless:
                logger.info(
                    "[execute_statement] Executing query on Workgroup: %s, Database: %s",
                    self.workgroup_name,
                    self.database_name,
                )
                response = self.serverless_client.execute_statement(
                    Database=self.database_name,
                    WorkgroupName=self.workgroup_name,
                    Sql=sql,
                )
            else:
                logger.info(
                    "[execute_statement] Executing query on Cluster: %s, Database: %s",
                    self.workgroup_name,
                    self.database_name,
                )
                response = self.client.execute_statement(
                    Database=self.database_name,
                    DbUser=self.username,
                    ClusterIdentifier=self.workgroup_name,
                    Sql=sql,
                )
            return response["Id"]
        except ClientError as e:
            logger.error("[execute_statement] Error executing SQL statement: %s", e)
            raise

    def fetch_results(self, execution_id, query_type=None):
        """Fetches results of a previously executed SQL statement."""
        all_records = []
        try:
            while True:
                if self.serverless:
                    result = self.serverless_client.describe_statement(Id=execution_id)
                else:
                    result = self.client.describe_statement(Id=execution_id)
                logger.info("[fetch_results] Execution Status: %s", result["Status"])
                if result["Status"] == "FAILED":
                    error_message = f"[fetch_results] Query failed: {result['Error']}"
                    logger.error(error_message)
                    raise ClientError(
                        {"Error": {"Code": "QueryExecutionFailed", "Message": error_message}}, "fetch_results"
                    )
                if result["Status"] == "FINISHED":
                    if query_type == "SELECT":  # Only fetch results for SELECT queries
                        if self.serverless:
                            response = self.serverless_client.get_statement_result(Id=execution_id)
                        else:
                            response = self.client.get_statement_result(Id=execution_id)
                        all_records.extend(response.get("Records", []))
                        if "NextToken" not in response:
                            break
                        execution_id = response["NextToken"]
                    break
                time.sleep(1)
        except ClientError as e:
            logger.error("[fetch_results] AWS ClientError: %s", e)
            raise
        except TimeoutError as e:
            logger.error("[fetch_results] Timeout occurred: %s", e)
            raise
        return all_records

    def check_current_database_and_schema(self):
        """Execute SQL to check the current database, schema, and user."""
        query = "SELECT current_database(), current_schema(), current_user;"
        try:
            execution_id = self.execute_statement(query)
            rows = self.fetch_results(execution_id)
            if rows:

                def extract_value(column):
                    for key in ["stringValue", "longValue", "booleanValue", "isNull"]:
                        if key in column:
                            return column[key]
                    return None

                current_db = extract_value(rows[0][0])  # First column
                current_schema = extract_value(rows[0][1])  # Second column
                current_user = extract_value(rows[0][2])  # Third column
                logger.info(
                    "[check_current_database_and_schema] Connected to Database: %s, Schema: %s, User: %s",
                    current_db,
                    current_schema,
                    current_user,
                )
                return current_db, current_schema, current_user
            logger.warning(
                "[check_current_database_and_schema] No data returned for current database and schema check."
            )
            return None, None, None
        except ClientError as e:
            logger.error("[check_current_database_and_schema] AWS ClientError: %s", e)
            raise
        except TimeoutError as e:
            logger.error("[check_current_database_and_schema] Timeout occurred: %s", e)
            raise


def export_data(data_api_client, config, pii_data, tenant_id):
    """Exports data from Redshift based on the provided configuration and PII data."""
    results = []
    logger.info(
        "[export_data] Using Redshift endpoint address: %s",
        data_api_client.endpoint_address,
    )
    logger.info(
        "[export_data] Using Redshift region: %s",
        data_api_client.client.meta.region_name,
    )

    for table, columns in config.items():
        logger.info("[export_data] Exporting data for table: %s", table)
        query = generate_query(table, columns, pii_data, tenant_id)
        if not query:
            logger.warning("[export_data] No query generated for table: %s", table)
            continue

        try:
            execution_id = data_api_client.execute_statement(query)
            rows = data_api_client.fetch_results(execution_id, "SELECT")

            if not rows:
                logger.info("[export_data] No data returned for table: %s", table)
                continue

            for row in rows:
                results.append(
                    dict(
                        zip(
                            [col["name"] for col in columns],
                            [list(col.values())[0] for col in row],
                        )
                    )
                )

            logger.info("[export_data] Exported %d rows from table: %s", len(rows), table)
        except ClientError as e:
            logger.error("[export_data] AWS ClientError: %s", e)
        except TimeoutError as e:
            logger.error("[export_data] Timeout occurred: %s", e)
    return results


def forget_data(data_api_client, config, pii_data, tenant_id):
    """Anonymizes (forgets) data in Redshift based on the provided configuration and PII data."""
    logger.info(
        "[forget_data] Using Redshift endpoint address: %s",
        data_api_client.endpoint_address,
    )
    logger.info(
        "[forget_data] Using Redshift region: %s",
        data_api_client.client.meta.region_name,
    )

    for table, columns in config.items():
        logger.info("[forget_data] Anonymizing data for table: %s", table)
        update_query = generate_bulk_update_query(table, columns, pii_data, tenant_id)
        if not update_query:
            logger.warning("[forget_data] No update query generated for table: %s", table)
            continue

        try:
            execution_id = data_api_client.execute_statement(update_query)
            data_api_client.fetch_results(execution_id, "UPDATE")  # Wait for completion
            logger.info("[forget_data] Anonymized data for table: %s", table)
        except ClientError as e:
            logger.error("[forget_data] AWS ClientError: %s table %s", e, table)
        except TimeoutError as e:
            logger.error("[forget_data] Timeout occurred: %s table %s", e, table)
    return {"status": "success", "message": "Data anonymized successfully."}
