"""
Module for unit tests for the s3 utility functions.
"""

import json
import unittest
from unittest.mock import patch, MagicMock
import boto3

# Note, this requires "pip install "moto<5.0""
# This is because we're using Python 3.11 and moto 5.0 is not compatible
from moto import mock_s3
from botocore.exceptions import NoCredentialsError, EndpointConnectionError

from s3_utils import fetch_gdpr_config_from_s3, upload_to_s3, get_unique_s3_key


class TestS3Utils(unittest.TestCase):
    """Unit tests for S3 GDPR configuration functions."""

    def setUp(self):
        """Set up a mock S3 environment before each test."""
        self.mock_s3 = mock_s3()
        self.mock_s3.start()
        self.s3_client = boto3.client("s3", region_name="us-east-1")
        self.bucket_name = "test-bucket"
        self.file_key = "gdpr/config.json"
        self.test_data = {"key": "value"}

        # Create a test bucket
        self.s3_client.create_bucket(Bucket=self.bucket_name)
        # Upload a test GDPR config file
        self.s3_client.put_object(
            Bucket=self.bucket_name,
            Key=self.file_key,
            Body=json.dumps(self.test_data),
            ContentType="application/json",
        )

    def tearDown(self):
        """Tear down the mock S3 environment after each test."""
        self.mock_s3.stop()

    def test_fetch_gdpr_config_success(self):
        """Test successfully fetching GDPR config from S3."""
        config = fetch_gdpr_config_from_s3(self.bucket_name, self.file_key)
        self.assertEqual(config, self.test_data)

    @patch("s3_utils.boto3.client")
    def test_fetch_gdpr_config_no_credentials(self, mock_boto_client):
        """Test handling of missing AWS credentials."""
        mock_boto_client.side_effect = NoCredentialsError()
        with self.assertRaises(NoCredentialsError):
            fetch_gdpr_config_from_s3(self.bucket_name, self.file_key)

    @patch("s3_utils.boto3.client")
    def test_fetch_gdpr_config_connection_error(self, mock_boto_client):
        """Test handling of an endpoint connection error."""
        mock_boto_client.side_effect = EndpointConnectionError(endpoint_url="https://s3.amazonaws.com")
        with self.assertRaises(EndpointConnectionError):
            fetch_gdpr_config_from_s3(self.bucket_name, self.file_key)

    @patch("s3_utils.boto3.client")
    def test_fetch_gdpr_config_json_decode_error(self, mock_boto_client):
        """Test handling of JSON decoding errors."""
        mock_s3_bucket = MagicMock()
        mock_s3_bucket.get_object.return_value = {"Body": MagicMock(read=lambda: b"invalid json")}
        mock_boto_client.return_value = mock_s3_bucket
        with self.assertRaises(json.JSONDecodeError):
            fetch_gdpr_config_from_s3(self.bucket_name, self.file_key)

    def test_upload_to_s3_success(self):
        """Test successfully uploading data to S3."""
        new_key = upload_to_s3(self.bucket_name, "gdpr/data.json", self.test_data)
        response = self.s3_client.get_object(Bucket=self.bucket_name, Key=new_key)
        uploaded_data = json.loads(response["Body"].read().decode("utf-8"))
        self.assertEqual(uploaded_data, self.test_data)

    def test_get_unique_s3_key_new_key(self):
        """Test that get_unique_s3_key returns the base key if it does not exist."""
        s3_client = boto3.client("s3")
        unique_key = get_unique_s3_key(s3_client, self.bucket_name, "gdpr/new_file.json")
        self.assertEqual(unique_key, "gdpr/new_file.json")

    def test_get_unique_s3_key_existing_key(self):
        """Test that get_unique_s3_key appends a number if the key already exists."""
        existing_key = "gdpr/existing.json"
        self.s3_client.put_object(Bucket=self.bucket_name, Key=existing_key, Body=json.dumps(self.test_data))

        unique_key = get_unique_s3_key(self.s3_client, self.bucket_name, existing_key)
        self.assertEqual(unique_key, "gdpr/existing_1.json")

    def test_get_unique_s3_key_multiple_existing(self):
        """Test that get_unique_s3_key increments correctly if multiple versions exist."""
        self.s3_client.put_object(Bucket=self.bucket_name, Key="gdpr/multiple.json", Body=json.dumps(self.test_data))
        for i in range(1, 4):
            self.s3_client.put_object(
                Bucket=self.bucket_name, Key=f"gdpr/multiple_{i}.json", Body=json.dumps(self.test_data)
            )

        unique_key = get_unique_s3_key(self.s3_client, self.bucket_name, "gdpr/multiple.json")
        self.assertEqual(unique_key, "gdpr/multiple_4.json")


if __name__ == "__main__":
    unittest.main()
