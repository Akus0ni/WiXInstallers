"""
This Lambda function processes GDPR-related actions such as exporting or
anonymizing (forgetting) PII (Personally Identifiable Information) data
for a specified tenant.

The Lambda function is triggered by an event that contains information
about the tenant, S3 configuration, action to perform (export or forget),
and the PII data. Depending on the action specified in the event, the
function either:

- Exports the PII data to an S3 bucket in JSON format, or
- Anonymizes the PII data in the Redshift database.

Required Event Keys:
    - tenant_id (str): The identifier for the tenant.
    - bucket_name (str): The S3 bucket name for storage.
    - gdpr_config_key (str): The key for retrieving the GDPR config from S3.
    - action (str): The action to perform, either "export" or "forget".
    - pii_data (dict): The PII data, including "Keys" to process.

Returns:
    dict: A JSON response indicating the result of the operation with a status
    code and message.

Raises:
    ValueError: If required parameters are missing or invalid.
    Exception: For any unhandled exceptions that occur during the processing
    of the request.
"""

# Standard imports
import json
import logging

# Third party imports
from botocore.exceptions import ClientError

# Module imports
from s3_utils import fetch_gdpr_config_from_s3, upload_to_s3
from secrets_utils import get_redshift_config
from db_helpers import export_data, forget_data, RedshiftDataAPI
from const import Constants as const

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):  # pylint: disable=unused-argument
    """Lambda handler function to process GDPR export or forget requests."""
    try:
        logger.info("[lambda_handler] Received event: %s", json.dumps(event))
        tenant_id, bucket_name, gdpr_config_key, action, pii_data = extract_event_data(event)
        validate_input(tenant_id, bucket_name, gdpr_config_key, action, pii_data)
        logger.info("[lambda_handler] Fetching GDPR configuration from S3.")
        gdpr_config = fetch_gdpr_config_from_s3(bucket_name, gdpr_config_key)
        logger.info("[lambda_handler] Retrieving Redshift configuration.")
        redshift_config = get_redshift_config(tenant_id)
        logger.info("[lambda_handler] Initialise Redshift API.")
        data_api_client = initialize_redshift_api(redshift_config)
        current_db, current_schema, current_user = data_api_client.check_current_database_and_schema()
        logger.info(
            "[lambda_handler] Connected to Database: %s, Schema: %s, as User: %s",
            current_db,
            current_schema,
            current_user,
        )
        logger.info("[lambda_handler] Ready to perform action")
        response = perform_action(
            action,
            data_api_client,
            {
                "gdpr_config": gdpr_config,
                "pii_data": pii_data,
                "tenant_id": tenant_id,
                "bucket_name": bucket_name,
            },
        )
        return {"statusCode": 200, "body": json.dumps(response)}
    except ClientError as e:
        logger.error("[lambda_handler] AWS ClientError: %s", e)
        return {
            "statusCode": 500,
            "body": json.dumps({"status": "error", "message": "AWS Service error: " + str(e)}),
        }
    except ValueError as e:
        logger.error("[lambda_handler] Invalid input or configuration: %s", e)
        return {
            "statusCode": 400,
            "body": json.dumps({"status": "error", "message": "Invalid input: " + str(e)}),
        }
    except KeyError as e:
        logger.error("[lambda_handler] Missing required field: %s", e)
        return {
            "statusCode": 400,
            "body": json.dumps({"status": "error", "message": f"Missing required field: {str(e)}"}),
        }
    except Exception as e:  # pylint: disable=broad-except
        logger.error("[lambda_handler] Unexpected error: %s", e)
        return {
            "statusCode": 500,
            "body": json.dumps({"status": "error", "message": "Unexpected error: " + str(e)}),
        }


def extract_event_data(event):
    """Extracts and returns the necessary data from the event."""
    tenant_id = event.get("tenant_id")
    bucket_name = event.get("bucket_name")
    gdpr_config_key = event.get("gdpr_config_key")
    action = event.get("action")
    # Convert action to lowercase for case-insensitive comparison
    if action:
        action = action.lower()
    pii_data = event.get("pii_data")
    return tenant_id, bucket_name, gdpr_config_key, action, pii_data


def validate_input(tenant_id, bucket_name, gdpr_config_key, action, pii_data):
    """Validates the required input parameters."""
    if not all([tenant_id, bucket_name, gdpr_config_key, action, pii_data]):
        raise ValueError(
            "[lambda_handler] Missing required parameters: tenant_id, bucket_name, "
            "gdpr_config_key, action, or pii_data."
        )
    if not pii_data.get("Keys"):
        raise ValueError("[lambda_handler] At least one key must be provided in 'Keys'.")
    if action not in ["export", "forget"]:
        raise ValueError("[lambda_handler] Invalid action. Must be 'export' or 'forget'.")


def initialize_redshift_api(redshift_config):
    """Initializes and returns the Redshift API client."""
    if not const.ENDPOINT_ADDRESS:
        raise ValueError("[lambda_handler] Invalid endpoint address.")
    serverless = False
    if const.REGION_OVERRIDE:
        return RedshiftDataAPI(secret=redshift_config, serverless=serverless, region=const.REGION_OVERRIDE)
    return RedshiftDataAPI(secret=redshift_config, serverless=serverless)


def perform_action(action, data_api_client, config_data):
    """Performs the specified action (export or forget)."""
    gdpr_config = config_data.get("gdpr_config")
    pii_data = config_data.get("pii_data")
    tenant_id = config_data.get("tenant_id")
    bucket_name = config_data.get("bucket_name")
    if action == "export":
        logger.info("[lambda_handler] Exporting data...")
        export_results = export_data(data_api_client, gdpr_config, pii_data, tenant_id)
        if export_results:
            logger.info("[lambda_handler] Export results found, uploading to S3...")
            filename = upload_to_s3(bucket_name, f"{tenant_id}_gdpr_export.json", export_results)
            logger.info("[lambda_handler] Data uploaded to S3 to: %s", filename)
        else:
            logger.info("[lambda_handler] No data to export.")
        return {"status": "success", "data": export_results}
    logger.info("[lambda_handler] Anonymizing data...")
    anonymization_result = forget_data(data_api_client, gdpr_config, pii_data, tenant_id)
    logger.info("[lambda_handler] Anonymization Result: %s", anonymization_result)
    return {"status": "success", "message": anonymization_result}
