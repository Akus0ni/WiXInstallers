"""
Module for retrieving Redshift connection details from AWS Secrets Manager.
This module fetches the Redshift credentials (username, password, etc.)
for a given tenant and environment.
"""

# Standard imports
import json
import logging

# Third party imports
import boto3

# Module imports
from const import Constants as const

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_redshift_config(tenant_id):
    """Retrieve Redshift connection details."""
    secrets_manager = boto3.client("secretsmanager")

    secret_name = const.REDSHIFT_TENANT_CREDENTIALS_SECRET_FORMAT.format(env=const.ENVIRONMENT, tenant=tenant_id)

    try:
        logger.info(
            "[get_redshift_config] Retrieving secret from Secrets Manager: %s",
            secret_name,
        )
        secret_response = secrets_manager.get_secret_value(SecretId=secret_name)
        secret_data = json.loads(secret_response["SecretString"])
        logger.info("[get_redshift_config] Successfully retrieved secret")
        return {
            "username": secret_data["username"],
            "password": secret_data["password"],
            "endpoint_address": const.ENDPOINT_ADDRESS,
            "endpoint_port": const.ENDPOINT_PORT,
            "workgroup_name": const.WORKGROUP_NAME,
            "database_name": const.DATABASE_NAME,
        }
    except Exception as e:
        logger.error("[get_redshift_config] Error retrieving secret %s: %s", secret_name, e)
        raise
