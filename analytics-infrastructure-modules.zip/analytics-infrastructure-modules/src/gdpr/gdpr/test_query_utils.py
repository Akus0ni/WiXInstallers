"""
Module for unit tests for the query utility functions, such as generate_query
and generate_bulk_update_query.
"""

# Standard imports
import logging
import re
import unittest

# Third party imports
from colorama import Fore, init

# Module imports
from query_utils import generate_query, generate_bulk_update_query

init(autoreset=True)


class TestQueryUtils(unittest.TestCase):
    """
    Unit tests for the query utility functions, such as generate_query
    and generate_bulk_update_query.
    """

    def setUp(self):
        """
        Setup for each test. Initializes common test data used across multiple tests.
        Disables logging at the critical level to suppress log output during tests.

        Attributes:
            table_name (str): The name of the table to be queried.
            columns (list): A list of columns in the table with their attributes.
            pii_data (dict): Sample PII (Personally Identifiable Information) data.
            tenant_id (str): The tenant ID used for the queries.
            max_diff (None): Placeholder for maximum allowed difference for assertions.
        """
        logging.disable(logging.CRITICAL)

        self.table_name = "tb_fct_dialer_detail"
        self.columns = [
            {"name": "callback_phone", "length": 20},
            {"name": "phone", "length": 20},
            {"name": "first_name", "length": 50},
            {"name": "last_name", "length": 50},
        ]
        self.pii_data = {
            "Name": "Marco van Basten",
            "Email": "mvanbasten@associazionecalciomilan.it",
        }
        self.tenant_id = "tmprod10000000"
        self.max_diff = None

    def tearDown(self):
        """
        Teardown for each test. Restores logging settings to the default state after each test.
        """
        logging.disable(logging.NOTSET)

    @staticmethod
    def normalize(value):
        """
        Normalizes a string by removing extra spaces and trimming leading/trailing spaces.
        """
        return re.sub(r"\s+", " ", value).strip()

    def test_generate_query_with_valid_keys(self):
        """Test if generate_query creates a valid SELECT query with keys and values."""
        pii_data = {
            "Keys": ["Email"],
            "Email": ["mvanbasten@associazionecalciomilan.it"],
        }
        expected_query = (
            "SELECT callback_phone,"
            "    phone,"
            "    first_name,"
            "    last_name "
            "FROM internal.tb_fct_dialer_detail "
            "WHERE tm_tenant_id = 'tmprod10000000'"
            "    AND "
            "        ((callback_phone = 'mvanbasten@associazionecalciomilan.it')"
            "        OR (phone = 'mvanbasten@associazionecalciomilan.it')"
            "        OR (first_name = 'mvanbasten@associazionecalciomilan.it')"
            "        OR (last_name = 'mvanbasten@associazionecalciomilan.it'));"
        )
        query = generate_query(self.table_name, self.columns, pii_data, self.tenant_id)
        query = self.normalize(query)
        expected_query = self.normalize(expected_query)
        self.assertEqual(query, expected_query)

    def test_generate_query_with_empty_keys(self):
        """Test if generate_query handles empty keys correctly."""
        pii_data = {"Keys": []}
        query = generate_query(self.table_name, self.columns, pii_data, self.tenant_id)
        self.assertIsNone(query)

    def test_generate_query_with_no_values(self):
        """Test if generate_query handles keys with no values correctly."""
        pii_data = {"Keys": ["Email"], "Email": []}
        query = generate_query(self.table_name, self.columns, pii_data, self.tenant_id)
        self.assertIsNone(query)

    def test_generate_query_with_valid_keys_and_values(self):
        """Test if generate_query creates a valid SELECT query with keys and values."""
        pii_data = {
            "Keys": ["Email"],
            "Values": ["Name"],
            "Email": ["mvanbasten@associazionecalciomilan.it"],
            "Name": ["Marco van Basten"],
        }
        expected_query = (
            "SELECT callback_phone, phone, first_name, last_name "
            "FROM internal.tb_fct_dialer_detail "
            "WHERE tm_tenant_id = 'tmprod10000000' AND "
            "    ((callback_phone = 'mvanbasten@associazionecalciomilan.it' AND "
            "        (callback_phone = 'Marco van Basten' OR "
            "        phone = 'Marco van Basten' OR "
            "        first_name = 'Marco van Basten' OR "
            "        last_name = 'Marco van Basten')) OR "
            "    (phone = 'mvanbasten@associazionecalciomilan.it' AND "
            "        (callback_phone = 'Marco van Basten' OR "
            "        phone = 'Marco van Basten' OR "
            "        first_name = 'Marco van Basten' OR "
            "        last_name = 'Marco van Basten')) OR "
            "    (first_name = 'mvanbasten@associazionecalciomilan.it' AND "
            "        (callback_phone = 'Marco van Basten' OR "
            "        phone = 'Marco van Basten' OR "
            "        first_name = 'Marco van Basten' OR "
            "        last_name = 'Marco van Basten')) OR "
            "    (last_name = 'mvanbasten@associazionecalciomilan.it' AND "
            "        (callback_phone = 'Marco van Basten' OR "
            "        phone = 'Marco van Basten' OR "
            "        first_name = 'Marco van Basten' OR "
            "        last_name = 'Marco van Basten'))"
            ");"
        )
        query = generate_query(self.table_name, self.columns, pii_data, self.tenant_id)
        query = self.normalize(query)
        expected_query = self.normalize(expected_query)
        self.assertEqual(query, expected_query)

    def test_generate_query_empty_pii_data(self):
        """Test if generate_query handles empty pii_data correctly"""
        query = generate_query(self.table_name, self.columns, {}, self.tenant_id)
        self.assertIsNone(query)

    def test_generate_query_no_matching_columns(self):
        """Test if generate_query handles no matching columns correctly"""
        query = generate_query("tb_fct_dialer_detail", [], self.pii_data, self.tenant_id)
        self.assertIsNone(query)

    def test_generate_bulk_update_query_valid(self):
        """Test if generate_bulk_update_query creates a valid UPDATE query"""
        pii_data = {
            "Keys": ["Email"],
            "Values": ["Name"],
            "Email": ["mvanbasten@associazionecalciomilan.it"],
            "Name": ["Marco van Basten"],
        }
        expected_query = (
            "UPDATE internal.tb_fct_dialer_detail "
            "SET callback_phone = CASE WHEN callback_phone IS NOT NULL THEN "
            "LEFT(SHA2(callback_phone, 256), 20) ELSE callback_phone END, "
            "phone = CASE WHEN phone IS NOT NULL THEN LEFT(SHA2(phone, 256), 20) ELSE phone END, "
            "first_name = CASE WHEN first_name IS NOT NULL THEN LEFT(SHA2(first_name, 256), 50) ELSE first_name END, "
            "last_name = CASE WHEN last_name IS NOT NULL THEN LEFT(SHA2(last_name, 256), 50) ELSE last_name END "
            "WHERE tm_tenant_id = 'tmprod10000000' AND "
            "((callback_phone = 'mvanbasten@associazionecalciomilan.it' AND "
            "(callback_phone = 'Marco van Basten' OR phone = 'Marco van Basten' OR "
            "first_name = 'Marco van Basten' OR last_name = 'Marco van Basten')) OR "
            "(phone = 'mvanbasten@associazionecalciomilan.it' AND "
            "(callback_phone = 'Marco van Basten' OR phone = 'Marco van Basten' OR "
            "first_name = 'Marco van Basten' OR last_name = 'Marco van Basten')) OR "
            "(first_name = 'mvanbasten@associazionecalciomilan.it' AND "
            "(callback_phone = 'Marco van Basten' OR phone = 'Marco van Basten' OR "
            "first_name = 'Marco van Basten' OR last_name = 'Marco van Basten')) OR "
            "(last_name = 'mvanbasten@associazionecalciomilan.it' AND "
            "(callback_phone = 'Marco van Basten' OR phone = 'Marco van Basten' OR "
            "first_name = 'Marco van Basten' OR last_name = 'Marco van Basten'))"
            ");"
        )
        query = generate_bulk_update_query(self.table_name, self.columns, pii_data, self.tenant_id)
        query = self.normalize(query)
        expected_query = self.normalize(expected_query)
        self.assertEqual(query, expected_query)

    def test_generate_bulk_update_with_valid_keys(self):
        """Test if generate_bulk_update creates a valid SELECT query with keys."""
        pii_data = {
            "Keys": ["Email"],
            "Email": ["mvanbasten@associazionecalciomilan.it"],
        }
        expected_query = (
            "UPDATE internal.tb_fct_dialer_detail "
            "SET callback_phone = CASE WHEN callback_phone IS NOT NULL THEN "
            "LEFT(SHA2(callback_phone, 256), 20) ELSE callback_phone END, "
            "phone = CASE WHEN phone IS NOT NULL THEN LEFT(SHA2(phone, 256), 20) ELSE phone END, "
            "first_name = CASE WHEN first_name IS NOT NULL THEN LEFT(SHA2(first_name, 256), 50) ELSE first_name END, "
            "last_name = CASE WHEN last_name IS NOT NULL THEN LEFT(SHA2(last_name, 256), 50) ELSE last_name END "
            "WHERE tm_tenant_id = 'tmprod10000000' "
            "    AND "
            "        ((callback_phone = 'mvanbasten@associazionecalciomilan.it') "
            "        OR (phone = 'mvanbasten@associazionecalciomilan.it') "
            "        OR (first_name = 'mvanbasten@associazionecalciomilan.it') "
            "        OR (last_name = 'mvanbasten@associazionecalciomilan.it'));"
        )
        query = generate_bulk_update_query(self.table_name, self.columns, pii_data, self.tenant_id)
        query = self.normalize(query)
        expected_query = self.normalize(expected_query)
        self.assertEqual(query, expected_query)

    def test_generate_bulk_update_query_empty_pii_data(self):
        """Test if generate_bulk_update_query handles empty pii_data correctly"""
        query = generate_bulk_update_query(self.table_name, self.columns, {}, self.tenant_id)
        self.assertIsNone(query)

    def test_generate_bulk_update_query_no_matching_columns(self):
        """Test if generate_bulk_update_query handles no matching columns correctly"""
        query = generate_bulk_update_query(self.table_name, [], self.pii_data, self.tenant_id)
        self.assertIsNone(query)


def run_with_color(test_case):
    """
    Run the test case with colored output.
    """
    result = unittest.TestResult()
    test_case.run(result)

    test_name = test_case.id().split(".")[-1]
    description = test_case.shortDescription() or "No description provided"

    if result.wasSuccessful():
        print(f"{Fore.GREEN}PASS: {test_name} - {description}")
    else:
        print(f"{Fore.RED}FAIL: {test_name} - {description}")
        for failure in result.failures + result.errors:
            print(f"{Fore.RED}{failure[1]}")


# Run the tests by running this file
# or using the command: py -m unittest discover
if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestQueryUtils)
    for test in suite:
        run_with_color(test)
