"""
This module defines a `Constants` class that encapsulates environment variables 
and constants used throughout the application. These constants are primarily related 
to the environment configuration and connection details for services like Redshift.

The constants are retrieved from the system's environment variables, with default 
values provided for local development or when the environment variables are not set.

Constants are crucial for managing the application's environment configuration, 
such as Redshift credentials, connection details, and AWS regions.

Module Dependencies:
    - os: Used to retrieve environment variables.
"""

# Standard imports
import os


class Constants:
    """
    This class holds constants used throughout the application, primarily
    configuration values sourced from environment variables. It contains values
    such as the environment type (e.g., 'dev', 'prod'), AWS region, Redshift
    configuration, and endpoint details.

    The class ensures that essential environment variables are easily accessible
    throughout the application and offers default values if the environment variables
    are not set.

    Class Attributes:
        - ENVIRONMENT (str): The application's environment (defaults to 'dev').
        - REGION_OVERRIDE (str): The AWS region to use (defaults to 'us-west-2').
        - REDSHIFT_TENANT_CREDENTIALS_SECRET_FORMAT (str): The format string
        for Redshift tenant credentials.
        - ENDPOINT_PORT (str): The port for Redshift connection (defaults to '5439').
        - ENDPOINT_ADDRESS (str): The Redshift endpoint address (defaults to None).
        - WORKGROUP_NAME (str): The name of the workgroup (defaults to 'default').
        - DATABASE_NAME (str): The name of the database (defaults to 'master').

    Class Methods:
        - N/A
    """

    # pylint: disable=too-few-public-methods

    # Get the environment from environment variable
    ENVIRONMENT = os.environ.get("ENVIRONMENT", "dev")
    REGION_OVERRIDE = os.environ.get("REGION_OVERRIDE", "us-west-2")

    REDSHIFT_TENANT_CREDENTIALS_SECRET_FORMAT = "redshift!analytics-etl-redshift-{env}-awsuser"

    ENDPOINT_PORT = os.environ.get("ENDPOINT_PORT", "5439")
    ENDPOINT_ADDRESS = os.environ.get("ENDPOINT_ADDRESS", None)
    WORKGROUP_NAME = os.environ.get("WORKGROUP_NAME", "default")
    DATABASE_NAME = os.environ.get("DATABASE_NAME", "master")
