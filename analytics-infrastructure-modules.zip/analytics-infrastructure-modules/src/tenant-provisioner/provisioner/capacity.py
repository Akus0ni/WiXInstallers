"""This module contains the Capacity class that is used to calculate the base and max capacity for the cluster"""


class Capacity:
    """Class to calculate the base and max capacity for the cluster"""

    # pylint: disable=too-few-public-methods

    @staticmethod
    def get_capacity(alu, skus):
        """Get the base and max capacity for the cluster"""

        # pylint: disable=unused-argument

        # The base capacity can't be more than 16 RPUs
        # The base capacity must be a multiple of 8

        base_capacity = 8
        max_capacity = 16
        return base_capacity, max_capacity
