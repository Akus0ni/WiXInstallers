""" Provisions or deprovisions resources for a tenant """

from botocore.exceptions import ClientError
from configstorage import ConfigStorage
from const import Constants as const
from provisionedcluster import ProvisionedCluster
from serverlesscluster import ServerlessCluster


class Provisioner:
    # pylint: disable=too-many-instance-attributes
    """Class to provision or deprovision resources for a tenant"""

    def __init__(self, config):
        self.action = config.action
        self.deployment_type = config.deployment_type
        self.tenant_id = config.tenant_id
        self.deployment_id = config.deployment_id
        self.analytics_role_arn = config.analytics_role_arn
        self.skip_password_rotation = config.skip_password_rotation
        self.cluster_config = config.cluster_config
        self.response = {
            "action": self.action,
            "deployment_type": config.deployment_type,
            "tenant_id": config.tenant_id,
            "deployment_id": config.deployment_id,
            "resources": [],
            "errors": [],
        }

    def go(self):
        """Perform the provisioning or deprovisioning action"""
        if self.action == "create":
            self.create_resources()
        elif self.action == "delete":
            self.delete_resources()

        return self.response

    # pylint: disable=too-many-locals
    def create_resources(self):
        """Create resources for the tenant"""
        cluster_identifier = None
        shared = False

        # Create Redshift Serverless cluster
        if self.deployment_type == "dedicated":
            try:
                cluster_identifier = ServerlessCluster.create(self.tenant_id, self.cluster_config, self.response)
            except ClientError as e:
                self.response["errors"].append(f"Failed to create dedicated Redshift Serverless cluster: {str(e)}")
        elif self.deployment_type == "shared":
            shared = True
            cluster_identifier = self.cluster_config.get("shared_cluster_id", None)
            if not cluster_identifier:
                cluster_identifier = const.DEFAULT_SHARED_CLUSTER_NAME
            self.response["resources"].append(
                f"Using existing shared Redshift Serverless cluster: {cluster_identifier}"
            )
        else:
            raise ValueError(f"Invalid deployment type: {self.deployment_type}")

        prov_cluster_identifier = const.DEFAULT_PROV_CLUSTER_NAME

        if cluster_identifier:
            # Get the database name from the cluster identifier, in case it was created outside of automation
            db_name = ServerlessCluster.get_cluster_database_name(cluster_identifier)

            serverless_cluster = ServerlessCluster(cluster_identifier, self.response, shared, db_name)
            provisioned_cluster = ProvisionedCluster(prov_cluster_identifier, self.response)

            # Get the namespace ID from the provisioned cluster
            datashare_namespace_id = provisioned_cluster.get_cluster_namespace_id()

            # Get the namespace ID from the serverless cluster
            serverless_namespace_id, db_name, endpoint_address, port = serverless_cluster.get_cluster_details()

            # Grant access to Redshift datashare
            provisioned_cluster.grant_access_to_redshift_datashare(serverless_namespace_id)

            # Create Redshift database from datashare
            serverless_cluster.create_database_if_required(datashare_namespace_id)

            # Create Redshift database user
            username, password = serverless_cluster.create_redshift_user(self.tenant_id, self.skip_password_rotation)

            # Store config in Secrets Manager
            configuration = ConfigStorage(self.tenant_id, self.response)
            configuration.save(
                username,
                password,
                cluster_identifier,
                self.deployment_type,
                serverless_namespace_id,
                endpoint_address,
                port,
                db_name,
                self.analytics_role_arn,
                self.skip_password_rotation,
            )

            # Create Redshift tenant mappings
            provisioned_cluster.create_redshift_tenant_mappings(
                self.deployment_type,
                self.tenant_id,
                self.deployment_id,
                serverless_namespace_id,
                username,
            )

            egain_cluster_name = ServerlessCluster.ensure_egain_namespace(response=self.response)

            # Create a "ServerlessCluster" object for the eGain endpoint
            egain_cluster = ServerlessCluster(egain_cluster_name, self.response, shared=True, database="dev")
            egain_namespace_id, egain_db, egain_endpoint, egain_port = egain_cluster.get_cluster_details()

            # Grant access to Redshift datashare
            provisioned_cluster.grant_access_to_redshift_datashare(egain_namespace_id)

            # Create Redshift database from datashare
            egain_cluster.create_database_if_required(datashare_namespace_id)

            # Use a special "tenant" name so we don't conflict with real tenants
            egain_tenant_id = f"egain_{self.deployment_id}"

            # Create eGain admin database user
            egain_user_name = f"eg_{self.deployment_id}_egain_admin"

            # egain_password will be empty ("") if the user already existed
            _, egain_password = egain_cluster.create_redshift_user_by_name(egain_user_name)

            # Store the eGain user in Secrets manager
            egain_config_storage = ConfigStorage(egain_tenant_id, self.response)
            egain_config_storage.save(
                username=egain_user_name,
                password=egain_password,
                cluster_id=egain_cluster_name,
                deployment_type="shared",
                namespace_id=egain_namespace_id,
                endpoint_address=egain_endpoint,
                endpoint_port=egain_port,
                database_name=egain_db,
                analytics_role_arn=self.analytics_role_arn,
                skip_password_rotation=True,  # we do NOT want to overwrite eGain passwords on future runs
            )

            # Add the "tenant -> eGain namespace -> eGain user" mapping in the "provisioned" cluster
            provisioned_cluster.create_redshift_tenant_mappings(
                # For eGain tenant, we want sp_create_or_update_tenant_consumer_mapping to use auth_type='user'
                # so make it "shared" deployment type
                "shared",
                self.tenant_id,
                self.deployment_id,
                egain_namespace_id,
                egain_user_name,
            )

            # Add the "tenant -> eGain namespace -> eGain user" mapping in the "provisioned" cluster
            provisioned_cluster.create_redshift_tenant_mappings(
                # For "shared" tenant, we want sp_create_or_update_tenant_consumer_mapping to use auth_type='user'
                # so make it "shared" deployment type
                "shared",
                "shared",
                self.deployment_id,
                egain_namespace_id,
                egain_user_name,
            )
        else:
            self.response["errors"].append("Failed to determine cluster identifier")

    def delete_resources(self):
        """Delete resources for the tenant"""
        cluster_id = None
        shared = False

        # Delete Redshift Serverless cluster
        if self.deployment_type == "dedicated":
            cluster_id = const.DEDICATED_TENANT_CLUSTER_NAME_FORMAT.format(tenant=self.tenant_id, env=const.ENVIRONMENT)
        elif self.deployment_type == "shared":
            shared = True
            cluster_id = self.cluster_config.get("shared_cluster_id", None)
            if not cluster_id:
                cluster_id = const.DEFAULT_SHARED_CLUSTER_NAME
        else:
            raise ValueError(f"Invalid deployment type: {self.deployment_type}")

        prov_cluster_identifier = const.DEFAULT_PROV_CLUSTER_NAME

        if cluster_id:

            serverless_cluster = ServerlessCluster(cluster_id, self.response, shared)
            provisioned_cluster = ProvisionedCluster(prov_cluster_identifier, self.response)

            # Delete Redshift tenant mappings
            provisioned_cluster.delete_redshift_tenant_mappings(self.tenant_id, self.deployment_id)

            # Remove config in Secrets Manager
            configuration = ConfigStorage(self.tenant_id, self.response)
            configuration.remove()

            if self.deployment_type == "dedicated":
                try:
                    serverless_cluster.delete()
                except ClientError as e:
                    self.response["errors"].append(f"Failed to delete dedicated Redshift Serverless cluster: {str(e)}")
        else:
            self.response["errors"].append("Failed to determine cluster identifier")
