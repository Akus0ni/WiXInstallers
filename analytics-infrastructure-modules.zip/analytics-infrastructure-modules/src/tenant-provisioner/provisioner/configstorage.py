"""Store the Redshift credentials in Secrets Manager"""

import json
import boto3
from botocore.exceptions import ClientError
from const import Constants as const


# pylint: disable=too-few-public-methods


class ConfigStorage:
    """Class to store Redshift credentials in Secrets Manager"""

    def __init__(self, tenant_id, response):
        self.tenant_id = tenant_id
        self.response = response

    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-locals
    def save(
        self,
        username,
        password,
        cluster_id,
        deployment_type,
        namespace_id,
        endpoint_address,
        endpoint_port,
        database_name,
        analytics_role_arn,
        skip_password_rotation,
    ):
        """Store the Redshift credentials in Secrets Manager"""
        secrets_manager = boto3.client("secretsmanager")

        secret_name = const.REDSHIFT_TENANT_CREDENTIALS_SECRET_FORMAT.format(
            env=const.ENVIRONMENT, tenant=self.tenant_id
        )
        secret_value = {
            "username": username,
            "password": password,
            "workgroup_name": cluster_id,
            "deployment_type": deployment_type,
            "namespace_id": namespace_id,
            "endpoint_address": endpoint_address,
            "endpoint_port": endpoint_port,
            "database_name": database_name,
        }

        secret_exists = False
        try:
            # Try to retrieve the secret
            secrets_manager.describe_secret(SecretId=secret_name)
            secret_exists = True
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                secret_exists = False
            else:
                raise e

        # Create or update the secret
        if not secret_exists:
            try:
                # Create the secret
                secret_response = secrets_manager.create_secret(
                    Name=secret_name,
                    Description=f"Credentials for Redshift user {username} in {const.ENVIRONMENT}",
                    SecretString=json.dumps(secret_value),
                    KmsKeyId=const.KMS_KEY_ID,
                    Tags=[
                        {"Key": "Project", "Value": "analytics"},
                        {"Key": "Environment", "Value": const.ENVIRONMENT},
                        {"Key": "Tenant", "Value": self.tenant_id},
                        {"Key": "Terraform", "Value": "true"},
                    ],
                )
                self.response["resources"].append(f"Password created in Secrets Manager: {secret_name}")
                self.response["resources"].append(f"Secret ARN: {secret_response['ARN']}")
            except ClientError as e:
                self.response["errors"].append(f"Error creating password in Secrets Manager: {str(e)}")
        else:
            try:
                if skip_password_rotation:
                    # Retrieve the secret
                    secret = secrets_manager.get_secret_value(SecretId=secret_name)
                    secret_string = secret["SecretString"]
                    secret_dict = json.loads(secret_string)
                    secret_value["password"] = secret_dict["password"]

                # Update the secret
                secret_response = secrets_manager.update_secret(
                    SecretId=secret_name,
                    Description=f"Credentials for Redshift user {username} in {const.ENVIRONMENT}",
                    SecretString=json.dumps(secret_value),
                    KmsKeyId=const.KMS_KEY_ID,
                )
                self.response["resources"].append(f"Password updated in Secrets Manager: {secret_name}")
                self.response["resources"].append(f"Secret ARN: {secret_response['ARN']}")
            except ClientError as e:
                self.response["errors"].append(f"Error updating password in Secrets Manager: {str(e)}")

        # give read access to the secret to the deployment role in the specified account
        policy = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Sid": "EnableAnalyticsRoleToReadTheSecret",
                    "Effect": "Allow",
                    "Principal": {"AWS": analytics_role_arn},
                    "Action": "secretsmanager:GetSecretValue",
                    "Resource": "*",
                }
            ],
        }

        try:
            # Attach the resource policy to the secret
            put_policy_response = secrets_manager.put_resource_policy(
                SecretId=secret_name, ResourcePolicy=json.dumps(policy)
            )
            self.response["resources"].append(f"Resource policy attached: {put_policy_response['ARN']}")
        except ClientError as e:
            self.response["errors"].append(f"Error attaching resource policy to secret: {str(e)}")

    def remove(
        self,
    ):
        """Delete the Redshift credentials in Secrets Manager"""
        secrets_manager = boto3.client("secretsmanager")

        secret_name = const.REDSHIFT_TENANT_CREDENTIALS_SECRET_FORMAT.format(
            env=const.ENVIRONMENT, tenant=self.tenant_id
        )

        secret_exists = False
        try:
            # Try to retrieve the secret
            secrets_manager.describe_secret(SecretId=secret_name)
            secret_exists = True
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                secret_exists = False
            else:
                raise e

        # Delete the secret
        if secret_exists:
            try:
                # Create the secret
                secret_response = secrets_manager.delete_secret(
                    SecretId=secret_name,
                    ForceDeleteWithoutRecovery=True,
                )
                self.response["resources"].append(f"Password deleted in Secrets Manager: {secret_name}")
                self.response["resources"].append(f"Secret ARN: {secret_response['ARN']}")
            except ClientError as e:
                self.response["errors"].append(f"Error deleting password in Secrets Manager: {str(e)}")
