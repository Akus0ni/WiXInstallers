""" Constants for the provisioner module """

import os


class Constants:
    """Constants for the provisioner module"""

    # pylint: disable=too-few-public-methods

    # Get the environment from environment variable
    ENVIRONMENT = os.environ.get("ENVIRONMENT", "dev")
    REGION_OVERRIDE = os.environ.get("REGION_OVERRIDE", None)

    DATABASE_NAME = "master"

    ANALYTICS_DATABASE_NAME = "analytics"

    REPORT_USERS_GROUP = "report_users"

    DEFAULT_SHARED_CLUSTER_NAME = f"analytics-reporting-shared-{ENVIRONMENT}"
    DEFAULT_PROV_CLUSTER_NAME = f"analytics-etl-redshift-{ENVIRONMENT}"

    DEDICATED_TENANT_CLUSTER_NAME_FORMAT = "analytics-reporting-{tenant}-{env}"

    REDSHIFT_TENANT_CREDENTIALS_SECRET_FORMAT = "ern/{env}/analytics/redshift/{tenant}/credentials"

    DEFAULT_ALU = 1
    DEFAULT_SKUS = []

    KMS_KEY_ID = f"alias/analytics-reporting-secmgr-key-{ENVIRONMENT}"

    EGAIN_NAMESPACE_NAME = f"analytics-reporting-egain-{ENVIRONMENT}"
