"""Lambda handler function to provision and deprovision tenant resources"""

import json
import boto3
from const import Constants as const
from config import Config
from provisioner import Provisioner


def lambda_handler(event, context):  # pylint: disable=unused-argument
    """Lambda handler function to provision and deprovision tenant resources"""

    # Log the event
    print(event)

    # Set up the default session
    if const.REGION_OVERRIDE:
        boto3.setup_default_session(region_name=f"{const.REGION_OVERRIDE}")

    # Create a Config object
    config = Config.parse(event)

    # Validate input
    is_valid, error_message = config.is_valid()
    if not is_valid:
        return {"statusCode": 400, "body": json.dumps({"error": error_message})}

    # Perform the requested action
    provisioner = Provisioner(config)
    response = provisioner.go()

    # Return response
    return {"statusCode": 200, "body": json.dumps(response)}
