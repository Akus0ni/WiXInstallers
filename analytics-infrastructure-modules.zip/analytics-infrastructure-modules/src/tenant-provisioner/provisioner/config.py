"""Configuration module for the tenant provisioner"""


class Config:
    """Configuration class for the tenant provisioner"""

    # pylint: disable=too-many-arguments

    def __init__(
        self,
        action,
        tenant_id,
        deployment_id,
        analytics_role_arn,
        deployment_type,
        cluster_config,
        skip_password_rotation,
    ):
        self.action = action
        self.tenant_id = tenant_id
        self.deployment_id = deployment_id
        self.analytics_role_arn = analytics_role_arn
        self.deployment_type = deployment_type
        self.cluster_config = cluster_config
        self.skip_password_rotation = skip_password_rotation

    def is_valid(self):
        """Validate the configuration"""
        if not self.tenant_id:
            return False, "tenant_id is required"

        if not self.deployment_id:
            return False, "deployment_id is required"

        if self.action == "create" and not self.analytics_role_arn:
            return False, "analytics_role_arn is required"

        if self.action not in ["create", "delete"]:
            return False, "action must be either create or delete"

        return True, None

    @staticmethod
    def parse(event):
        """Parse the input JSON"""
        input_data = event

        # Extract action and deployment type
        action = input_data.get("action", "").lower()
        deployment_type = input_data.get("deployment_type", "").lower()
        tenant_id = input_data.get("tenant_id").lower()
        deployment_id = input_data.get("deployment_id").lower()
        analytics_role_arn = input_data.get("analytics_role_arn")  # IAM roles case-sensitive
        skip_password_rotation = input_data.get("skip_password_rotation", False)

        # Extract cluster configuration
        cluster_config = input_data.get("cluster_config", {})

        return Config(
            action,
            tenant_id,
            deployment_id,
            analytics_role_arn,
            deployment_type,
            cluster_config,
            skip_password_rotation,
        )
