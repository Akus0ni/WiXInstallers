""" Module for the ProvisionedCluster class """

import boto3
from botocore.exceptions import ClientError

from const import Constants as const
from cluster import Cluster


class ProvisionedCluster(Cluster):
    """Class representing a provisioned Redshift cluster"""

    def __init__(self, cluster_id, response, database=const.ANALYTICS_DATABASE_NAME):
        Cluster.__init__(self, boto3.client("redshift"), cluster_id, database)
        self.response = response

    def execute_statement(self, sql, database_override):
        """Execute a statement on the provisioned cluster"""
        # pylint: disable=duplicate-code
        secret_arn = self.get_redshift_secret_arn()
        try:
            response = self.data.execute_statement(
                SecretArn=secret_arn,
                Database=database_override if database_override else self.database,
                ClusterIdentifier=self.cluster_id,
                Sql=sql,
            )
            # pylint: enable=duplicate-code
            return response
        except ClientError as e:
            print(f"Error executing statement on the provisioned cluster: {e}")
            raise e

    def get_redshift_secret_arn(self):
        """Generate the ARN for the Redshift secret"""
        new_string = "redshift!" + self.cluster_id + "-awsuser"
        return new_string

    def get_cluster_namespace_id(self):
        """Get the namespace ID from the cluster identifier"""
        # Describe the cluster
        try:
            response = self.client.describe_clusters(ClusterIdentifier=self.cluster_id)
            clusters = response.get("Clusters", [])
            if clusters:
                # Assuming one cluster is returned
                cluster = clusters[0]
                return cluster.get("ClusterNamespaceArn").split(":")[-1]
        except self.client.exceptions.ClusterNotFoundFault:
            print(f"Cluster {self.cluster_id} not found.")

        return None

    def grant_access_to_redshift_datashare(self, namespace_id):
        """Grant access to the Redshift datashare"""
        try:
            # Grant access to the datashare
            grant_sql = f"GRANT USAGE ON DATASHARE {const.ANALYTICS_DATABASE_NAME} TO NAMESPACE '{namespace_id}'"
            _, status = self.execute_query(grant_sql)
            if status["Status"] != "FINISHED":
                self.response["errors"].append(
                    f"Error granting access to datashare for namespace: {namespace_id} {status}"
                )
            else:
                self.response["resources"].append(f"Redshift datashare granted access for namespace: {namespace_id}")
        except ClientError as e:
            self.response["errors"].append(f"Error granting access to datashare for namespace {namespace_id}: {str(e)}")

    def create_redshift_tenant_mappings(self, deployment_type, tenant_id, deployment_id, namespace_id, username):
        """Create tenant mappings in the Redshift cluster"""

        map_id = None
        try:
            # Create tenant mappings
            create_tenant_sql = f"call internal.sp_create_or_update_tenant('{tenant_id}', '{deployment_id}')"
            map_id = self.fetch_single_integer_result(create_tenant_sql)
            self.response["resources"].append(f"Tenant mapping {deployment_id}[{map_id}] applied for: {tenant_id}")

            # Create consumer mappings
            auth_type = "user"
            if deployment_type == "dedicated":
                auth_type = "namespace"

            create_consumer_sql = (
                f"call internal.sp_create_or_update_tenant_consumer_mapping({map_id}, '{namespace_id}', '{auth_type}')"
            )

            consumer_id = self.fetch_single_integer_result(create_consumer_sql)
            self.response["resources"].append(
                f"Consumer mapping {namespace_id}[{consumer_id}] applied for: {tenant_id}. Auth type: {auth_type}"
            )

            # Create user mappings
            if deployment_type == "shared":
                create_user_sql = (
                    f"call internal.sp_create_or_update_tenant_consumer_user_mapping({consumer_id}, '{username}')"
                )
                user_id = self.fetch_single_integer_result(create_user_sql)
                self.response["resources"].append(f"User mapping {username}[{user_id}] applied for: {tenant_id}")

        except ClientError as e:
            self.response["errors"].append(
                f"Error creating/updating tenant mappings: {deployment_type}, {tenant_id}, {deployment_id}: {str(e)}"
            )

        return map_id

    # pylint: disable=unused-argument
    def delete_redshift_tenant_mappings(self, tenant_id, deployment_id):
        """Delete tenant mappings in the Redshift cluster"""

        try:
            # Delete tenant & mappings
            if tenant_id == "shared":
                delete_tenant_sql = f"call internal.sp_delete_shared_tenant('{deployment_id}')"
            else:
                delete_tenant_sql = f"call internal.sp_delete_tenant('{tenant_id}')"
            _, status = self.execute_query(delete_tenant_sql)
            if status["Status"] != "FINISHED":
                if status["Error"] != f"ERROR: Tenant {tenant_id} does not exist":
                    self.response["errors"].append(f"Error deleting tenant mappings: {tenant_id} Status = {status}")
            else:
                self.response["resources"].append(f"Tenant mappings deleted for: {tenant_id}")
        except ClientError as e:
            self.response["errors"].append(f"Error deleting tenant mappings {tenant_id}: {str(e)}")
