﻿"""Provision a Redshift Serverless cluster for a tenant"""

import os
import time
import boto3
from botocore.exceptions import ClientError
from botocore.waiter import WaiterModel, create_waiter_with_client

from const import Constants as const
from cluster import Cluster
from capacity import Capacity


class ServerlessCluster(Cluster):
    """Class representing a Redshift Serverless cluster"""

    def __init__(self, cluster_id, response, shared=False, database=const.DATABASE_NAME):
        Cluster.__init__(self, boto3.client("redshift-serverless"), cluster_id, database)
        self.response = response
        self.shared = shared

    def get_redshift_secret_arn(self):
        """Generate the ARN for the Redshift secret"""
        # If it's dedicated or eGain, use the default admin user
        # otherwise, use the tenant-specific admin user
        if not self.shared or self.cluster_id == const.EGAIN_NAMESPACE_NAME:
            return f"redshift!{self.cluster_id}-admin"

        # Ensure cluster_id ends with environment
        if not self.cluster_id.endswith(const.ENVIRONMENT):
            raise ValueError("Cluster ID does not match the expected environment format")

        # Remove the environment part from cluster_id
        name_part = self.cluster_id[: -len(const.ENVIRONMENT)].rstrip("-")

        # Construct new identifier
        new_string = f"redshift-{name_part}-admin-{const.ENVIRONMENT}"
        return new_string

    def execute_statement(self, sql, database_override):
        """Execute a statement on the serverless cluster"""
        # pylint: disable=duplicate-code
        secret_arn = self.get_redshift_secret_arn()
        try:
            response = self.data.execute_statement(
                SecretArn=secret_arn,
                Database=database_override if database_override else self.database,
                WorkgroupName=self.cluster_id,
                Sql=sql,
            )
            # pylint: enable=duplicate-code
            return response
        except ClientError as e:
            print(f"Error executing statement on the serverless cluster: {e}")
            raise e

    def create_database_if_required(self, namespace_id):
        """Create the analytics database from the datashare if required"""
        try:
            # if database doesnt exist, create it
            check_database_sql = f"SELECT 1 FROM pg_database WHERE datname = '{const.ANALYTICS_DATABASE_NAME}'"
            db_exists = self.fetch_boolean_result(check_database_sql)

            # Create the database if it doesn't exist
            if not db_exists:
                # Create the analytics database from datashare
                create_database_sql = (
                    f"CREATE DATABASE {const.ANALYTICS_DATABASE_NAME} "
                    + f"FROM DATASHARE {const.ANALYTICS_DATABASE_NAME} OF NAMESPACE '{namespace_id}'"
                )

                _, status = self.execute_query(create_database_sql)
                if status["Status"] != "FINISHED":
                    self.response["errors"].append(f"Error creating database from datashare: {namespace_id} {status}")
                else:
                    self.response["resources"].append(
                        f"Redshift database created from datashare on: {namespace_id} {self.cluster_id}"
                    )

        except ClientError as e:
            self.response["errors"].append(f"Error creating database from datashare: {namespace_id} {str(e)}")

    def get_cluster_details(self):
        """Get config details from the cluster identifier"""
        try:
            # Get the namespace ID
            namespace_response = self.client.get_namespace(namespaceName=self.cluster_id)
            workspace_response = self.client.get_workgroup(workgroupName=self.cluster_id)
            return (
                namespace_response["namespace"]["namespaceId"],
                namespace_response["namespace"]["dbName"],
                workspace_response["workgroup"]["endpoint"]["address"],
                workspace_response["workgroup"]["endpoint"]["port"],
            )
        except ClientError as e:
            print(f"Cluster details {self.cluster_id} not found: {str(e)}")
            raise e

    @staticmethod
    def get_cluster_database_name(cluster_id):
        """Get the database name from the cluster identifier"""
        client = boto3.client("redshift-serverless")
        try:
            # Get the namespace ID
            namespace_response = client.get_namespace(namespaceName=cluster_id)
            return namespace_response["namespace"]["dbName"]
        except ClientError as e:
            print(f"Namespace dbName {cluster_id} not found: {str(e)}")
            raise e

    def __create_update_db_user(self, username, skip_password_rotation):
        """Create or update a Redshift user"""
        new_password = ""
        try:
            password = self.__generate_password()

            # Check if the user already exists
            check_user_sql = f"SELECT 1 FROM pg_user WHERE usename = '{username}'"
            user_exists = self.fetch_boolean_result(check_user_sql)
            if not user_exists:
                # Create the user
                create_user_sql = f"CREATE USER {username} WITH PASSWORD '{password}'"
                _, status = self.execute_query(create_user_sql)
                if status["Status"] != "FINISHED":
                    self.response["errors"].append(f"Error creating Redshift user: {username} {status})")
                else:
                    new_password = password
                    self.response["resources"].append(f"Redshift user created: {username}")
            else:
                # Update the user password
                if not skip_password_rotation:
                    update_password_sql = f"ALTER USER {username} WITH PASSWORD '{password}'"
                    _, status = self.execute_query(update_password_sql)
                    if status["Status"] != "FINISHED":
                        self.response["errors"].append(f"Error updating Redshift user password: {username} {status}")
                    else:
                        new_password = password
                        self.response["resources"].append(f"Redshift user password updated: {username}")

        except ClientError as e:
            self.response["errors"].append(f"Error creating or updating Redshift user: {username} {str(e)}")

        return new_password

    def __create_update_db_group(self, username):
        try:
            # if the group does not exist, create it
            check_group_sql = f"SELECT 1 FROM pg_group WHERE groname = '{const.REPORT_USERS_GROUP}'"
            group_exist = self.fetch_boolean_result(check_group_sql)
            if not group_exist:
                # Create a group
                create_group_sql = f"CREATE GROUP {const.REPORT_USERS_GROUP} WITH USER {username}"
                _, status = self.execute_query(create_group_sql)
                if status["Status"] != "FINISHED":
                    self.response["errors"].append(
                        f"Error creating Redshift group: {const.REPORT_USERS_GROUP} with user: {username} {status}"
                    )
                else:
                    self.response["resources"].append(
                        f"Redshift group created: {const.REPORT_USERS_GROUP} with user: {username}"
                    )
            else:
                # else, add user to the group
                add_user_to_group_sql = f"ALTER GROUP {const.REPORT_USERS_GROUP} ADD USER {username}"
                _, status = self.execute_query(add_user_to_group_sql)
                if status["Status"] != "FINISHED":
                    self.response["errors"].append(f"Error adding user to Redshift group: {username} {status}")
                else:
                    self.response["resources"].append(
                        f"Redshift user added to group: {const.REPORT_USERS_GROUP} {username}"
                    )

            # Grant USAGE on the database
            grant_usage_sql = (
                f"GRANT USAGE ON DATABASE {const.ANALYTICS_DATABASE_NAME} TO GROUP {const.REPORT_USERS_GROUP}"
            )
            _, status = self.execute_query(grant_usage_sql)
            if status["Status"] != "FINISHED":
                self.response["errors"].append(
                    f"Error granting usage on database to group: {const.REPORT_USERS_GROUP} {status}"
                )
            else:
                self.response["resources"].append(
                    f"Redshift database usage granted to group: {const.REPORT_USERS_GROUP}"
                )

        except ClientError as e:
            self.response["errors"].append(
                f"Error creating or updating Redshift group: {const.REPORT_USERS_GROUP} with user {username}: {str(e)}"
            )

    def create_redshift_user(self, tenant_id, skip_password_rotation):
        """Create a Redshift user and grant access to the database"""
        # Generate username and random password
        username = f"{tenant_id}_reports"

        # Create or update the user
        password = self.__create_update_db_user(username, skip_password_rotation)

        # Create or update the group
        self.__create_update_db_group(username)

        return username, password

    def create_redshift_user_by_name(self, username):
        """
        Create or update a Redshift user (by explicit username) and add to the `report_users` group.
        Returns the password if newly created or rotated, else empty string if already exists
        """
        skip_password_rotation = True
        new_password = self.__create_update_db_user(username, skip_password_rotation)
        self.__create_update_db_group(username)
        return username, new_password

    def __generate_password(self):
        """Generate a random string of the specified length"""

        secrets_manager = boto3.client("secretsmanager")

        try:
            response = secrets_manager.get_random_password(
                PasswordLength=16,
                ExcludeCharacters="/@\"'\\",
                ExcludeNumbers=False,
                ExcludePunctuation=False,
                ExcludeUppercase=False,
                ExcludeLowercase=False,
                IncludeSpace=False,
                RequireEachIncludedType=True,
            )
            return response["RandomPassword"]
        except ClientError as e:
            print(f"Error generating password: {e}")
            raise e

    def delete(self):
        """Delete the Redshift Serverless cluster"""
        try:
            if not self.shared:
                workgroup_exists = False
                try:
                    self.client.get_workgroup(workgroupName=self.cluster_id)
                    workgroup_exists = True
                except ClientError as e:
                    if e.response["Error"]["Code"] == "ResourceNotFoundException":
                        workgroup_exists = False
                    else:
                        raise e
                if workgroup_exists:
                    self.client.delete_workgroup(workgroupName=self.cluster_id)
                    ServerlessCluster.wait_for_workgroup_deletion(self.client, self.cluster_id)
                    self.response["resources"].append(f"Redshift Serverless workgroup deleted: {self.cluster_id}")

                namespace_exists = False
                try:
                    self.client.get_namespace(namespaceName=self.cluster_id)
                    namespace_exists = True
                except ClientError as e:
                    if e.response["Error"]["Code"] == "ResourceNotFoundException":
                        namespace_exists = False
                    else:
                        raise e
                if namespace_exists:
                    self.client.delete_namespace(namespaceName=self.cluster_id)
                    ServerlessCluster.wait_for_namespace_deletion(self.client, self.cluster_id)
                    self.response["resources"].append(f"Redshift Serverless namespace deleted: {self.cluster_id}")

                self.response["resources"].append(f"Redshift Serverless cluster deleted: {self.cluster_id}")
        except ClientError as e:
            self.response["errors"].append(f"Error deleting Redshift Serverless cluster: {self.cluster_id} {str(e)}")

    @staticmethod
    def __create_namespace(client, namespace_name, tenant_id, response):
        """Create a Redshift Serverless namespace"""
        namespace_exists = False
        try:
            namespace_response = client.get_namespace(namespaceName=namespace_name)
            namespace_exists = True
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                namespace_exists = False
            else:
                raise e

        if namespace_exists:
            # print(f"Redshift Serverless namespace already exists: {namespace_name}")
            response["resources"].append(f"Redshift Serverless namespace already exists: {namespace_name}")
        else:
            # Create namespace
            try:
                namespace_response = client.create_namespace(
                    namespaceName=namespace_name,
                    adminUsername="admin",
                    dbName=const.DATABASE_NAME,
                    manageAdminPassword=True,
                    tags=[
                        {"key": "Project", "value": "analytics"},
                        {"key": "Environment", "value": const.ENVIRONMENT},
                        {"key": "Tenant", "value": tenant_id},
                        {"key": "Terraform", "value": "true"},
                    ],
                )
            except ClientError as e:
                print(f"Error creating Redshift Serverless namespace: {namespace_name} {str(e)}")
                response["errors"].append(f"Error creating Redshift Serverless namespace: {namespace_name}")
                raise e

        ServerlessCluster.wait_for_namespace(client, namespace_name)

        return namespace_response["namespace"]["namespaceName"]

    @staticmethod
    def __create_workgroup(client, workgroup_name, namespace_name, tenant_id, cluster_config, response):
        """Create a Redshift Serverless workgroup"""
        # pylint: disable=too-many-arguments

        alu = cluster_config.get("alu", const.DEFAULT_ALU)
        skus = cluster_config.get("skus", const.DEFAULT_SKUS)
        base_capacity, max_capacity = Capacity.get_capacity(alu, skus)

        subnet_ids, securitygroup_ids = ServerlessCluster.get_infra_config()

        if not subnet_ids or not securitygroup_ids:
            raise ValueError("Invalid infrastructure configuration, check the environment variables")

        workgroup_response = None
        workgroup_exists = False
        try:
            workgroup_response = client.get_workgroup(workgroupName=workgroup_name)
            workgroup_exists = True
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                workgroup_exists = False
            else:
                raise e

        if workgroup_exists:
            response["resources"].append(f"Redshift Serverless workgroup already exists: {workgroup_name}")

            # Update workgroup, if changed
            # You can only update one setting at a time
            # You can only update when the workgroup is in AVAILABLE status

            if workgroup_response["workgroup"]["baseCapacity"] != base_capacity:
                ServerlessCluster.wait_for_workgroup(client, workgroup_name)
                try:
                    workgroup_response = client.update_workgroup(
                        workgroupName=workgroup_name, baseCapacity=base_capacity
                    )
                    response["resources"].append(f"Redshift Serverless workgroup updated baseCapacity={base_capacity}")
                except ClientError as e:
                    print(f"Error updating Redshift Serverless workgroup baseCapacity: {workgroup_name} {str(e)}")
                    response["errors"].append(f"Error updating Redshift Serverless workgroup: {workgroup_name}")
                    raise e

            if workgroup_response["workgroup"]["maxCapacity"] != max_capacity:
                ServerlessCluster.wait_for_workgroup(client, workgroup_name)
                try:
                    workgroup_response = client.update_workgroup(workgroupName=workgroup_name, maxCapacity=max_capacity)
                    response["resources"].append(f"Redshift Serverless workgroup updated maxCapacity={max_capacity}")
                except ClientError as e:
                    print(f"Error updating Redshift Serverless workgroup maxCapacity: {workgroup_name} {str(e)}")
                    response["errors"].append(f"Error updating Redshift Serverless workgroup: {workgroup_name}")
                    raise e
        else:
            # Create workgroup
            try:
                workgroup_response = client.create_workgroup(
                    workgroupName=workgroup_name,
                    namespaceName=namespace_name,
                    baseCapacity=base_capacity,
                    maxCapacity=max_capacity,
                    subnetIds=subnet_ids,
                    securityGroupIds=securitygroup_ids,
                    tags=[
                        {"key": "Project", "value": "analytics"},
                        {"key": "Environment", "value": const.ENVIRONMENT},
                        {"key": "Tenant", "value": tenant_id},
                        {"key": "Terraform", "value": "true"},
                    ],
                )

                response["resources"].append(
                    f"Redshift Serverless workgroup created: {workgroup_name}, "
                    + f"[{base_capacity}/{max_capacity}],"
                    + f"subnets: {subnet_ids}, sg: {securitygroup_ids}"
                )
            except ClientError as e:
                print(f"Error creating Redshift Serverless workgroup: {workgroup_name} {str(e)}")
                response["errors"].append(f"Error creating Redshift Serverless workgroup: {workgroup_name}")
                raise e

        ServerlessCluster.wait_for_workgroup(client, workgroup_name)

        return workgroup_response["workgroup"]["workgroupArn"]

    @staticmethod
    def ensure_egain_namespace(response):
        """
        Create (or ensure) the eGain Serverless namespace/workgroup.
        Returns the name of the eGain cluster (namespace).
        """
        client = boto3.client("redshift-serverless")
        egain_cluster_name = const.EGAIN_NAMESPACE_NAME

        try:
            namespace_name = ServerlessCluster.__create_namespace(
                client, egain_cluster_name, tenant_id="egain", response=response
            )

            workgroup_arn = ServerlessCluster.__create_workgroup(
                client, egain_cluster_name, egain_cluster_name, tenant_id="egain", cluster_config={}, response=response
            )

            response["resources"].append(f"eGain Namespace ARN: {namespace_name}")
            response["resources"].append(f"eGain Workgroup ARN: {workgroup_arn}")
        except ClientError as e:
            print(f"Error creating Redshift Serverless cluster: {egain_cluster_name} {str(e)}")
            raise e

        return egain_cluster_name

    @staticmethod
    def create(tenant_id, cluster_config, response):
        """Create a Redshift Serverless cluster"""

        dedicated_name = const.DEDICATED_TENANT_CLUSTER_NAME_FORMAT.format(tenant=tenant_id, env=const.ENVIRONMENT)
        cluster_name = dedicated_name
        workgroup_name = dedicated_name
        namespace_name = dedicated_name

        client = boto3.client("redshift-serverless")

        try:
            # Create namespace
            namespace_arn = ServerlessCluster.__create_namespace(client, namespace_name, tenant_id, response)

            # Create workgroup
            workgroup_arn = ServerlessCluster.__create_workgroup(
                client, workgroup_name, namespace_name, tenant_id, cluster_config, response
            )

            response["resources"].append(f"Namespace ARN: {namespace_arn}")
            response["resources"].append(f"Workgroup ARN: {workgroup_arn}")
        except ClientError as e:
            print(f"Error creating Redshift Serverless cluster: {cluster_name} {str(e)}")
            raise e

        return cluster_name

    @staticmethod
    def wait_for_workgroup(client, workgroup_name):
        """Wait for the workgroup to be ready"""
        # Define the waiter configuration
        waiter_config = {
            "version": 2,
            "waiters": {
                "WorkgroupAvailable": {
                    "operation": "GetWorkgroup",
                    "delay": 30,
                    "maxAttempts": 30,
                    "acceptors": [
                        {
                            "expected": "AVAILABLE",
                            "matcher": "path",
                            "state": "success",
                            "argument": "workgroup.status",
                        },
                        {"expected": "CREATING", "matcher": "path", "state": "retry", "argument": "workgroup.status"},
                        {"expected": "MODIFYING", "matcher": "path", "state": "retry", "argument": "workgroup.status"},
                        {"expected": "DELETING", "matcher": "path", "state": "failure", "argument": "workgroup.status"},
                    ],
                }
            },
        }
        waiter_model = WaiterModel(waiter_config)
        custom_waiter = create_waiter_with_client("WorkgroupAvailable", waiter_model, client)

        # Use the custom waiter
        # print(f"Waiting for workgroup {workgroup_name} to be ready...")
        custom_waiter.wait(workgroupName=workgroup_name)
        # print(f"Workgroup {workgroup_name} is now ready.")

    @staticmethod
    def wait_for_namespace_deletion(client, namespace_name, poll_interval=30, timeout=900):
        """
        Waits for a Redshift Serverless namespace to be deleted.

        :param namespace_name: Name of the namespace to check.
        :param poll_interval: Time in seconds between status checks.
        :param timeout: Maximum time in seconds to wait for deletion.
        """
        start_time = time.time()

        while True:
            try:
                # Check if the namespace still exists
                response = client.get_namespace(namespaceName=namespace_name)
                status = response["namespace"]["status"]
                print(f"Namespace status: {status}")

                if status.lower() == "deleting":
                    # Keep polling if the namespace is still being deleted
                    print(f"Namespace {namespace_name} is still deleting. Waiting...")
                else:
                    # If the namespace exists but is not being deleted, something went wrong
                    print(f"Unexpected namespace status: {status}")
                    return False

            except ClientError as e:
                # If we get a ResourceNotFoundException, the namespace is deleted
                if e.response["Error"]["Code"] == "ResourceNotFoundException":
                    print(f"Namespace {namespace_name} has been deleted.")
                    return True
                # Handle other exceptions
                print(f"Error while checking namespace status: {e}")
                return False

            # Check timeout
            elapsed_time = time.time() - start_time
            if elapsed_time > timeout:
                print(f"Timeout reached while waiting for namespace {namespace_name} to be deleted.")
                return False

            # Wait before checking again
            time.sleep(poll_interval)

    @staticmethod
    def wait_for_workgroup_deletion(client, workgroup_name, poll_interval=30, timeout=900):
        """
        Waits for a Redshift Serverless workgroup to be deleted.

        :param workgroup_name: Name of the workgroup to check.
        :param poll_interval: Time in seconds between status checks.
        :param timeout: Maximum time in seconds to wait for deletion.
        """
        start_time = time.time()

        while True:
            try:
                # Check if the workgroup still exists
                response = client.get_workgroup(workgroupName=workgroup_name)
                status = response["workgroup"]["status"]
                print(f"Workgroup status: {status}")

                if status.lower() == "deleting":
                    # Keep polling if the workgroup is still being deleted
                    print(f"Workgroup {workgroup_name} is still deleting. Waiting...")
                else:
                    # If the workgroup exists but is not being deleted, something went wrong
                    print(f"Unexpected workgroup status: {status}")
                    return False

            except ClientError as e:
                # If we get a ResourceNotFoundException, the workgroup is deleted
                if e.response["Error"]["Code"] == "ResourceNotFoundException":
                    print(f"Workgroup {workgroup_name} has been deleted.")
                    return True

                # Handle other exceptions
                print(f"Error while checking workgroup status: {e}")
                return False

            # Check timeout
            elapsed_time = time.time() - start_time
            if elapsed_time > timeout:
                print(f"Timeout reached while waiting for workgroup {workgroup_name} to be deleted.")
                return False

            # Wait before checking again
            time.sleep(poll_interval)

    @staticmethod
    def wait_for_namespace(client, namespace_name):
        """Wait for the namespace to be ready"""
        # Define the waiter configuration
        waiter_config = {
            "version": 2,
            "waiters": {
                "NamespaceAvailable": {
                    "operation": "GetNamespace",
                    "delay": 30,
                    "maxAttempts": 30,
                    "acceptors": [
                        {
                            "expected": "AVAILABLE",
                            "matcher": "path",
                            "state": "success",
                            "argument": "namespace.status",
                        },
                        {"expected": "MODIFYING", "matcher": "path", "state": "retry", "argument": "namespace.status"},
                        {"expected": "DELETING", "matcher": "path", "state": "failure", "argument": "namespace.status"},
                    ],
                }
            },
        }
        waiter_model = WaiterModel(waiter_config)
        custom_waiter = create_waiter_with_client("NamespaceAvailable", waiter_model, client)

        # Use the custom waiter
        # print(f"Waiting for namespace {namespace_name} to be ready...")
        custom_waiter.wait(namespaceName=namespace_name)
        # print(f"Namespace {namespace_name} is now ready.")

    @staticmethod
    def get_infra_config():
        """Get the subnet and security group IDs from the infrastructure"""

        subnet_ids = ServerlessCluster.get_environment_var_array("SUBNET_IDS")
        securitygroup_ids = ServerlessCluster.get_environment_var_array("SECURITY_GROUP_IDS")

        return (subnet_ids, securitygroup_ids)

    @staticmethod
    def get_environment_var_array(env_var):
        """Get an array from an environment variable"""
        # Read the environment variable
        env_var = os.getenv(env_var, "")

        # Split the string into an array, or use an empty array if the variable is blank
        id_array = env_var.split(",") if env_var else []

        # Remove any empty strings from the array (in case of trailing comma)
        id_array = [id.strip() for id in id_array if id.strip()]

        return id_array
