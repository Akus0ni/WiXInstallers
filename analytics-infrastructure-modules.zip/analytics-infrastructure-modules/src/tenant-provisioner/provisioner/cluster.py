""" Define the Cluster abstract class """

import time

import boto3
from botocore.exceptions import ClientError


class Cluster:
    """Class representing a Redshift cluster"""

    def __init__(self, client, cluster_id, database):
        self.client = client
        self.data = boto3.client("redshift-data")
        self.cluster_id = cluster_id
        self.database = database

    def execute_statement(self, sql, database_override):
        """Execute a statement on the cluster"""
        raise NotImplementedError("execute_statement method must be implemented in a subclass")

    def execute_query(self, sql, database_override=None):
        """Execute a query on the provisioned cluster"""
        try:
            response = self.execute_statement(sql, database_override)
            statement_id = response["Id"]
            response = self.__wait_for_query_to_complete(statement_id)
            return statement_id, response
        except ClientError as e:
            print(f"Error executing query: {e}")
            raise e

    def __wait_for_query_to_complete(self, statement_id):
        """Wait for a query to complete"""
        while True:
            response = self.data.describe_statement(Id=statement_id)
            status = response["Status"]
            if status in ["FINISHED", "FAILED", "ABORTED"]:
                return response
            time.sleep(1)

    def fetch_single_integer_result(self, sql, database_override=None):
        """Fetch a single integer result from a query"""
        try:
            statement_id, status = self.execute_query(sql, database_override)
            if status["Status"] != "FINISHED":
                raise RuntimeError(f"Query did not finish successfully: {status}. Sql: {sql}")

            response = self.data.get_statement_result(Id=statement_id)
            rows = response["Records"]
            # Assume the query returns a single row with a single column
            if rows:
                # The integer value will be in the first row and the first column
                # Adjust the extraction if the data type is not stringValue
                return int(rows[0][0]["longValue"])
            return None
        except ClientError as e:
            print(f"Error fetching query results: {e}")
            raise e

    def fetch_boolean_result(self, sql, database_override=None):
        """Fetch a boolean result from a query"""
        try:
            statement_id, status = self.execute_query(sql, database_override)
            if status["Status"] != "FINISHED":
                raise RuntimeError(f"Query did not finish successfully: {status}. Sql: {sql}")

            response = self.data.get_statement_result(Id=statement_id)
            # Check if there are any records returned
            rows = response["Records"]
            # If there are records, the query returned a result
            return bool(rows)
        except ClientError as e:
            print(f"Error fetching query results: {e}")
            raise e
