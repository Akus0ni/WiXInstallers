import boto3
import json
import time
import botocore
from botocore.exceptions import ClientError
import datetime
import requests
import os


def get_release_tag(ssm_client, param_name):
    print("Reading SSM parameter with name: " + param_name)
    try:
        response = ssm_client.get_parameter(Name=param_name)
        release_tag = response["Parameter"]["Value"]
        print("Release tag: " + release_tag)
        return release_tag
    except ClientError as e:
        print("Exception reading ssm parameter: ", e)
    return None


def delete_ssm_parameter(ssm_client, param_name):
    print("Deleting SSM parameter with name: " + param_name)
    try:
        ssm_client.delete_parameter(Name=param_name)
    except ClientError as e:
        print("Exception deleting ssm parameter: ", e)


def get_auth_token():
    sm_client = boto3.client("secretsmanager")
    environment_id = str(os.environ.get("environment"))
    name = "ern/" + environment_id + "/analytics/github_action/any/credentials"
    print("Reading github credential secret with name: ", name)
    try:
        response = sm_client.get_secret_value(SecretId=name)
        value = response["SecretString"]
        return json.loads(value)["token"]
    except ClientError as e:
        print("Exception reading the secret: ", e)
    return None


def trigger_github_action(repository_name, image_digest):
    ssm_client = boto3.client("ssm")
    param_name = "/analytics/" + repository_name + "/github_action/digest_release_mapping/" + image_digest[7:]
    release_tag = get_release_tag(ssm_client, param_name)
    if not release_tag:
        print("Not triggering github action, since could not find release tag.")
        return
    delete_ssm_parameter(ssm_client, param_name)
    token = get_auth_token()
    if not token:
        print("Not triggering github action, since could not find github authentication token.")
        return
    url = "https://api.github.com/repos/eGainDev/" + repository_name + "/dispatches"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": "Bearer " + token,
        "X-GitHub-Api-Version": "2022-11-28"
    }
    data = {
        "event_type": "attach_ecr_scan_report",
        "client_payload": {
            "repository_name": repository_name,
            "image_digest": image_digest,
            "release_tag": release_tag
        }
    }
    print("Triggering github action to attach ecr scan report to release: ", release_tag)
    res = requests.post(url, headers=headers, json=data)
    print(f"Response: {res}")


def lambda_handler(event, context):
    print(event)

    event = json.loads(event['Records'][0]['body'])

    # Setting the client for ECR (client), and for CloudWatch (cwclient)
    client = boto3.client('ecr')
    cwclient = boto3.client('logs')

    millis = int(round(time.time() * 1000))

    # Getting information from the event, to use it in the 'describe_image_scan_findings' API request
    accId = event['account']
    image_digest = event['detail']["image-digest"]
    image = {"imageDigest": image_digest}
    repo = event['detail']['repository-name']

    try:
        trigger_github_action(repo, image_digest)
    except Exception as e:
        print("Exception triggering github action to attach ecr scan report to a release: ", e)

    # Initiate the DescribeImageScanFinding request, saving the response as a dictionary
    response = client.describe_image_scan_findings(
        registryId=accId,
        repositoryName=repo,
        imageId=image,
        maxResults=1000
    )

    # Try to create a Log Group for the repository with the repo's name passed in the event, i
    # f it already exists (from a previous scan, for example), creation will be aborted.
    # Log group name format: /aws/ecr/image-scan-findings-[environment]/repo-name
    environment_id = str(os.environ.get("environment"))

    RepoLogGroupName = '/aws/ecr/image-scan-findings-' + environment_id + '/' + event['detail']['repository-name']
    try:
        cwclient.create_log_group(
            logGroupName=RepoLogGroupName
        )
    except cwclient.exceptions.ResourceAlreadyExistsException:
        print('Log Group already exists for the repo ' + RepoLogGroupName + ', creating aborted')

    # Create Log streams, one log stream for each severity, and one for total numbers (summary)
    SummaryLogStream = 'SUMMARY' + '-' + event['detail']["image-digest"].replace('sha256:', '') + '-' + event[
        'time'].replace(':', '-')
    print(response)
    cwclient.create_log_stream(logGroupName=RepoLogGroupName, logStreamName=SummaryLogStream)
    cwclient.put_log_events(logGroupName=RepoLogGroupName, logStreamName=SummaryLogStream,
                            logEvents=[
                                {
                                    'timestamp': millis,
                                    'message': json.dumps(event['detail'].get('finding-severity-counts', {}))
                                }
                            ])

    # StreamNameDictMapping used for mapping each severity (key) to StreamName (value)
    StreamNameDictMapping = {}
    # SequenceTokenDict maps each severity (key) to sequenceToken (value), used for put_log_events later
    SequenceTokenDict = {}

    # Log stream name format: SEVERITY-IMAGE_TAG-DIGEST-TIME_OF_SCAN, only dashes with no colons
    # Log stream names are uniquely named, as it uses the 'time' value from the scan complete ECR event.
    for i in response['imageScanFindings']['findingSeverityCounts']:
        StreamName = i + '-' + event['detail']["image-digest"].replace('sha256:', '') + '-' + event['time'].replace(':',
                                                                                                                    '-')
        StreamNameDictMapping[i] = StreamName

        cwclient.create_log_stream(
            logGroupName=RepoLogGroupName,
            logStreamName=StreamName
        )
        SequenceTokenDict[i] = '0'

    # The following loop with 'put_log_events' will go through each finding, and based on severity,
    # puts each finding in the corresponding log stream
    if 'enhancedFindings' in response['imageScanFindings']:
        for i in response['imageScanFindings']['enhancedFindings']:
            severity = i['severity']

            loggingResponse = cwclient.put_log_events(
                logGroupName=RepoLogGroupName,
                logStreamName=StreamNameDictMapping[severity],
                logEvents=[
                    {
                        'timestamp': millis,
                        'message': json.dumps(i, cls=DateTimeEncoder)
                    }
                ],
                sequenceToken=SequenceTokenDict[severity]

            )
            SequenceTokenDict[severity] = loggingResponse['nextSequenceToken']
            print('Logged ' + i['title'] + ' in ' + StreamNameDictMapping[severity])

    print('Scan logging for ' + event['detail']["image-digest"] + ':' + ' is complete.')


class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()
        return super(DateTimeEncoder, self).default(obj)
