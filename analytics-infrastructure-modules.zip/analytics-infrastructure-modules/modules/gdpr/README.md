GDPR Lambda
