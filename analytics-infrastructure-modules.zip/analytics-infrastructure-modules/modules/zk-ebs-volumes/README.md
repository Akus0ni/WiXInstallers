
Create EBS Volumes for a Zookeeper Node

"zookeeper_data"    "$nifi_data/data"
"zookeeper_datalog" "$nifi_data/datalog"
"zookeeper_logs"    "$nifi_data/logs"
"zookeeper_conf"    "$nifi_data/conf"
