Tenant Provisioning Lambda
