# AWS EC2 Instance Connect Endpoint module

## Usage

```hcl
module "ec2-connect-endpoint" {
    source = "git@github.com/eGainDev/analytics-infrastructure-modules.git//modules/ec2-connect-endpoint"

    name      = "connect-endpoint"
    subnet_id = "subnet-0123456789"
    vpc_id    = "vpc-1234"
}
```
