
Create EBS Volumes for a Nifi Node

nifi_conf	         /nifi_data/conf
nifi_content	     /nifi_data/content
nifi_database	     /nifi_data/database
nifi_flow	         /nifi_data/flow
nifi_logs	         /nifi_data/logs
nifi_provenance	   /nifi_data/provenance
nifi_state	       /nifi_data/state
